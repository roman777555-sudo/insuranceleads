<?php
defined('_JEXEC') or die;

class LeadMarketControllerConfig extends JControllerLegacy
{
  protected function posted(array $data, $key)
  {
    return array_key_exists($key, $data);
  }

  protected function currentValue(JRegistry $registry, $key, $default = null)
  {
    return $registry->get($key, $default);
  }

  protected function postedString(array $data, JRegistry $registry, $key, $default = '')
  {
    if ($this->posted($data, $key)) {
      return trim((string) $data[$key]);
    }
    return (string) $this->currentValue($registry, $key, $default);
  }

  protected function postedText(array $data, JRegistry $registry, $key, $default = '')
  {
    if ($this->posted($data, $key)) {
      return (string) $data[$key];
    }
    return (string) $this->currentValue($registry, $key, $default);
  }

  protected function postedInt(array $data, JRegistry $registry, $key, $default = 0)
  {
    if ($this->posted($data, $key)) {
      return (int) $data[$key];
    }
    return (int) $this->currentValue($registry, $key, $default);
  }

  /**
   * Save settings. Used by toolbar tasks: config.save, config.apply, config.save2close
   * Only posted fields are changed; non-posted keys stay untouched, including bridge settings and secrets.
   */
  public function save($key = null, $urlVar = null)
  {
    JSession::checkToken() or jexit('Invalid Token');

    $app   = JFactory::getApplication();
    $input = $app->input;

    $data = $input->post->get('jform', array(), 'array');

    $db = JFactory::getDbo();
    $db->setQuery('SELECT extension_id, params FROM #__extensions WHERE element=' . $db->q('com_leadmarket') . ' AND type=' . $db->q('component'));
    $row = $db->loadObject();

    if (!$row) {
      $app->enqueueMessage('Cannot find extension row for com_leadmarket', 'error');
      $this->setRedirect('index.php?option=com_leadmarket&view=config');
      return false;
    }

    $registry = new JRegistry($row->params);

    $params = array(
      'from_email'         => $this->postedString($data, $registry, 'from_email', 'support@insuranceleads.co'),
      'from_name'          => $this->postedString($data, $registry, 'from_name', 'InsuranceLeads.co'),
      'usdt_trc20_address' => $this->postedString($data, $registry, 'usdt_trc20_address', ''),
      'admin_activity_notify_enabled' => $this->postedInt($data, $registry, 'admin_activity_notify_enabled', 0),
      'admin_activity_notify_email' => $this->postedString($data, $registry, 'admin_activity_notify_email', 'roman777555123@icloud.com'),
      'reserve_minutes'    => $this->postedInt($data, $registry, 'reserve_minutes', 30),
      'exclusive_hours'    => $this->postedInt($data, $registry, 'exclusive_hours', 3),
      'exclusive_hours_auto' => $this->postedInt($data, $registry, 'exclusive_hours_auto', 6),
      'exclusive_hours_home' => $this->postedInt($data, $registry, 'exclusive_hours_home', 12),
      'instant_enabled'    => $this->postedInt($data, $registry, 'instant_enabled', 1),
      'daily_enabled'      => $this->postedInt($data, $registry, 'daily_enabled', 1),
      'daily_time_utc'     => $this->postedString($data, $registry, 'daily_time_utc', '10:00'),
      'mini_widget_limit' => $this->postedInt($data, $registry, 'mini_widget_limit', 5),
      'mini_widget_hours' => $this->postedInt($data, $registry, 'mini_widget_hours', 25),
      'mini_widget_title' => $this->postedString($data, $registry, 'mini_widget_title', 'Latest Lead Activity'),
      'opening_promo_text' => $this->postedText($data, $registry, 'opening_promo_text', 'Launch offer: <strong>shared auto leads from $10</strong> for the first 2 months.'),
      'free_test_enabled' => $this->postedInt($data, $registry, 'free_test_enabled', 1),
      'free_test_badge_text' => $this->postedString($data, $registry, 'free_test_badge_text', 'Free Buyer Trial'),
      'free_test_title' => $this->postedString($data, $registry, 'free_test_title', 'Unlock Real Insurance Test Leads'),
      'free_test_subtitle' => $this->postedString($data, $registry, 'free_test_subtitle', 'Choose your states and lead types, subscribe to instant email alerts, and unlock a curated set of real auto and home insurance leads from our marketplace.'),
      'free_test_unlock_button_text' => $this->postedString($data, $registry, 'free_test_unlock_button_text', 'Unlock Free Test Leads'),
      'free_test_success_title' => $this->postedString($data, $registry, 'free_test_success_title', 'Your free test leads are unlocked'),
      'free_test_success_text' => $this->postedString($data, $registry, 'free_test_success_text', 'You are now subscribed to instant alerts for new matching leads.'),
      'free_test_market_cta_text' => $this->postedString($data, $registry, 'free_test_market_cta_text', 'Open Live Marketplace'),
      'free_test_market_cta_url' => $this->postedString($data, $registry, 'free_test_market_cta_url', 'index.php?option=com_leadmarket&view=leads'),
      'free_test_access_days' => $this->postedInt($data, $registry, 'free_test_access_days', 30),
      'free_test_welcome_email_enabled' => $this->postedInt($data, $registry, 'free_test_welcome_email_enabled', 1),
      'marketplace_show_freshness' => $this->postedInt($data, $registry, 'marketplace_show_freshness', 1),
      'marketplace_freshness_today_hours' => $this->postedInt($data, $registry, 'marketplace_freshness_today_hours', 24),
      'marketplace_freshness_relative_days' => $this->postedInt($data, $registry, 'marketplace_freshness_relative_days', 7),
      'public_home_url' => $this->postedString($data, $registry, 'public_home_url', '/'),
      'public_how_it_works_url' => $this->postedString($data, $registry, 'public_how_it_works_url', 'how-it-works'),
      'public_pricing_url' => $this->postedString($data, $registry, 'public_pricing_url', 'pricing'),
      'public_faq_url' => $this->postedString($data, $registry, 'public_faq_url', 'faq'),
      'credit_request_window_hours' => $this->postedInt($data, $registry, 'credit_request_window_hours', 24),
      'trc20_verify_enabled' => $this->postedInt($data, $registry, 'trc20_verify_enabled', 0),
      'trc20_amount_tolerance' => $this->postedString($data, $registry, 'trc20_amount_tolerance', '0.01'),
      'trc20_verify_api_base' => $this->postedString($data, $registry, 'trc20_verify_api_base', 'https://apilist.tronscanapi.com/api/transfer/trc20'),
      'trc20_token_contract' => $this->postedString($data, $registry, 'trc20_token_contract', 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t'),
      'trc20_verify_api_key' => $this->postedString($data, $registry, 'trc20_verify_api_key', ''),
      'trc20_time_window_before_minutes' => $this->postedInt($data, $registry, 'trc20_time_window_before_minutes', 20),
      'trc20_time_window_after_minutes' => $this->postedInt($data, $registry, 'trc20_time_window_after_minutes', 180),
      'trc20_verify_limit' => $this->postedInt($data, $registry, 'trc20_verify_limit', 50),
      'auto_confirm_matched_payment' => $this->postedInt($data, $registry, 'auto_confirm_matched_payment', 0),
      'enable_order_event_log' => $this->postedInt($data, $registry, 'enable_order_event_log', 1),
      'background_verify_enabled' => $this->postedInt($data, $registry, 'background_verify_enabled', 0),
      'background_verify_secret' => $this->postedString($data, $registry, 'background_verify_secret', ''),
      'background_verify_interval_minutes' => $this->postedInt($data, $registry, 'background_verify_interval_minutes', 5),
      'background_verify_batch_limit' => $this->postedInt($data, $registry, 'background_verify_batch_limit', 25),
      'background_verify_include_expired_late' => $this->postedInt($data, $registry, 'background_verify_include_expired_late', 0),
      'background_verify_retry_limit' => $this->postedInt($data, $registry, 'background_verify_retry_limit', 50),
      'background_verify_retry_delay_minutes' => $this->postedInt($data, $registry, 'background_verify_retry_delay_minutes', 5),
      'checking_timeout_minutes' => $this->postedInt($data, $registry, 'checking_timeout_minutes', 60),
      'late_checking_timeout_minutes' => $this->postedInt($data, $registry, 'late_checking_timeout_minutes', 180),
      'amount_reuse_quarantine_minutes' => $this->postedInt($data, $registry, 'amount_reuse_quarantine_minutes', 1440),
      'amount_reuse_short_minutes' => $this->postedInt($data, $registry, 'amount_reuse_short_minutes', 1440),
      'amount_reuse_paid_minutes' => $this->postedInt($data, $registry, 'amount_reuse_paid_minutes', 4320),
      'amount_overflow_max_extra' => $this->postedInt($data, $registry, 'amount_overflow_max_extra', 5),
      'auto_shared_max_sales' => $this->postedInt($data, $registry, 'auto_shared_max_sales', 3),
      'home_shared_max_sales' => $this->postedInt($data, $registry, 'home_shared_max_sales', 2),
      'post_exclusive_shared_slots' => $this->postedInt($data, $registry, 'post_exclusive_shared_slots', 1),
      'exclusive_buyer_block_text' => $this->postedString($data, $registry, 'exclusive_buyer_block_text', 'Exclusive protected first-contact access for {{hours}} hours|You receive the first protected contact window for this {{type_label}}. {{distribution_note}}'),
      'exclusive_buyer_notice_text' => $this->postedString($data, $registry, 'exclusive_buyer_notice_text', 'Checkout: Protected first-contact access|You are purchasing a protected first-contact window for {{hours}} hours on this {{type_label}}. {{distribution_note}}'),
      'premium_multiplier' => $this->postedString($data, $registry, 'premium_multiplier', '1.20'),
      'standard_multiplier' => $this->postedString($data, $registry, 'standard_multiplier', '1.00'),
      'premium_states_csv' => $this->postedString($data, $registry, 'premium_states_csv', 'CA,TX,FL,NY,NJ,PA,IL,OH,GA,NC,MI,VA,WA,MA,AZ,TN,IN,MO,MD,CO,MN,WI,CT,OR,SC'),
      'auto_shared_base' => $this->postedString($data, $registry, 'auto_shared_base', '15'),
      'auto_exclusive_base' => $this->postedString($data, $registry, 'auto_exclusive_base', '35'),
      'home_shared_base' => $this->postedString($data, $registry, 'home_shared_base', '25'),
      'home_exclusive_base' => $this->postedString($data, $registry, 'home_exclusive_base', '55'),
      'age_coef_0_1h' => $this->postedString($data, $registry, 'age_coef_0_1h', '1.00'),
      'age_coef_1_3h' => $this->postedString($data, $registry, 'age_coef_1_3h', '0.80'),
      'age_coef_3_12h' => $this->postedString($data, $registry, 'age_coef_3_12h', '0.60'),
      'age_coef_12p_h' => $this->postedString($data, $registry, 'age_coef_12p_h', '0.40'),
      'fresh_max_hours' => $this->postedInt($data, $registry, 'fresh_max_hours', 12),
      'aged_auto_max_hours' => $this->postedInt($data, $registry, 'aged_auto_max_hours', 24),
      'aged_home_max_hours' => $this->postedInt($data, $registry, 'aged_home_max_hours', 48),
      'show_archived_unsold_in_market' => $this->postedInt($data, $registry, 'show_archived_unsold_in_market', 1),
      'show_archived_sold_in_market' => $this->postedInt($data, $registry, 'show_archived_sold_in_market', 0),
      'archived_unsold_price_coef' => $this->postedString($data, $registry, 'archived_unsold_price_coef', '0.45'),
      'archived_sold_price_coef' => $this->postedString($data, $registry, 'archived_sold_price_coef', '0.25'),
      'cooldown_minutes'   => $this->postedInt($data, $registry, 'cooldown_minutes', 5),
      'minimum_topup_usd' => $this->postedString($data, $registry, 'minimum_topup_usd', '10'),
      'topup_presets' => $this->postedString($data, $registry, 'topup_presets', '10,50,100'),
      'topup_allow_custom' => $this->postedInt($data, $registry, 'topup_allow_custom', 1),
      'topup_custom_min' => $this->postedString($data, $registry, 'topup_custom_min', '10'),
      'topup_default_preset' => $this->postedString($data, $registry, 'topup_default_preset', '10'),
      'topup_auto_apply_on_paid' => $this->postedInt($data, $registry, 'topup_auto_apply_on_paid', 0),
      'wallet_allow_partial_usage' => $this->postedInt($data, $registry, 'wallet_allow_partial_usage', 1),
      'wallet_allow_direct_when_insufficient' => $this->postedInt($data, $registry, 'wallet_allow_direct_when_insufficient', 0),
      'paypal_enabled' => $this->postedInt($data, $registry, 'paypal_enabled', 0),
      'paypal_client_id' => $this->postedString($data, $registry, 'paypal_client_id', ''),
      'paypal_client_secret' => $this->postedString($data, $registry, 'paypal_client_secret', ''),
      'paypal_webhook_id' => $this->postedString($data, $registry, 'paypal_webhook_id', ''),
      'moneygram_enabled' => $this->postedInt($data, $registry, 'moneygram_enabled', 1),
      'moneygram_min_amount_usd' => $this->postedString($data, $registry, 'moneygram_min_amount_usd', '100'),
      'moneygram_receiver_name' => $this->postedString($data, $registry, 'moneygram_receiver_name', ''),
      'moneygram_receiver_country' => $this->postedString($data, $registry, 'moneygram_receiver_country', 'Turkey'),
      'moneygram_instructions' => $this->postedText($data, $registry, 'moneygram_instructions', ''),
      'cron_key'           => $this->postedString($data, $registry, 'cron_key', ''),
      'instant_subject_tpl'=> $this->postedText($data, $registry, 'instant_subject_tpl', 'New {{state}} {{type}} lead (UTC)'),
      'daily_subject_tpl'  => $this->postedText($data, $registry, 'daily_subject_tpl', '{{state}} {{type_label}} Leads Digest: {{count}} new leads'),
      'instant_body_tpl'   => $this->postedText($data, $registry, 'instant_body_tpl', ''),
      'daily_body_tpl'     => $this->postedText($data, $registry, 'daily_body_tpl', ''),
      'bridge_enabled' => $this->postedInt($data, $registry, 'bridge_enabled', 0),
      'bridge_key_id' => $this->postedString($data, $registry, 'bridge_key_id', 'paperclip-main'),
      'bridge_shared_secret' => $this->postedString($data, $registry, 'bridge_shared_secret', ''),
      'bridge_enforce_ip_allowlist' => $this->postedInt($data, $registry, 'bridge_enforce_ip_allowlist', 1),
      'bridge_allowed_ips' => $this->postedString($data, $registry, 'bridge_allowed_ips', ''),
      'bridge_max_skew_seconds' => $this->postedInt($data, $registry, 'bridge_max_skew_seconds', 300),
      'bridge_read_rpm' => $this->postedInt($data, $registry, 'bridge_read_rpm', 60),
      'bridge_write_rpm' => $this->postedInt($data, $registry, 'bridge_write_rpm', 20),
      'bridge_approve_rpm' => $this->postedInt($data, $registry, 'bridge_approve_rpm', 10),
      'bridge_storage_path' => $this->postedString($data, $registry, 'bridge_storage_path', 'administrator/logs/leadmarket_bridge'),
      'bridge_allow_live_site_writes' => $this->postedInt($data, $registry, 'bridge_allow_live_site_writes', 0),
      'bridge_live_allowed_article_ids' => $this->postedString($data, $registry, 'bridge_live_allowed_article_ids', ''),
      'bridge_live_allowed_module_ids' => $this->postedString($data, $registry, 'bridge_live_allowed_module_ids', ''),
      'bridge_live_allowed_component_params' => $this->postedString($data, $registry, 'bridge_live_allowed_component_params', ''),
    );
    foreach ($params as $k => $v) {
      $registry->set($k, $v);
    }

    $db->setQuery(
      $db->getQuery(true)
        ->update('#__extensions')
        ->set('params=' . $db->q($registry->toString()))
        ->where('extension_id=' . (int) $row->extension_id)
    );
    $db->execute();

    $app->enqueueMessage('Settings saved.', 'message');

    // Decide where to go depending on task
    $task = $this->getTask();
    $returnView = preg_replace('/[^a-z0-9_]/i', '', (string) $input->getCmd('return_view', 'config'));
    if ($returnView === '') $returnView = 'config';
    if ($task === 'save2close') {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads');
    } else {
      $this->setRedirect('index.php?option=com_leadmarket&view=' . $returnView);
    }

    return true;
  }

  public function apply()
  {
    return $this->save();
  }

  public function save2close()
  {
    // Map to save() with task check
    return $this->save();
  }

  public function cancel($key = null)
  {
    $this->setRedirect('index.php?option=com_leadmarket&view=leads');
    return true;
  }
}
