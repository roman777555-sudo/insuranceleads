<?php
defined('_JEXEC') or die;

$p = $this->params;
$auditItems = is_array($this->auditConnections) ? $this->auditConnections : array();
$auditPage = max(1, (int) $this->auditPage);
$auditTotalPages = max(1, (int) $this->auditTotalPages);
$auditTotal = (int) $this->auditTotal;
$summary = is_array($this->connectionSummary) ? $this->connectionSummary : array();
$readiness = is_array($this->readiness) ? $this->readiness : array();
$recentFailures = is_array($this->recentFailures) ? $this->recentFailures : array();
$pendingProposals = is_array($this->pendingProposals) ? $this->pendingProposals : array();
$openTasks = is_array($this->openTasks) ? $this->openTasks : array();
$selfCheck = is_array($this->selfCheck) ? $this->selfCheck : array();
$safeMatrix = is_array($this->safeControlMatrix) ? $this->safeControlMatrix : array();
$requestDetails = is_array($this->requestDetails) ? $this->requestDetails : array();
$requestId = trim((string) $this->requestId);
$eventData = is_array($this->eventStream) ? $this->eventStream : array();
$eventItems = isset($eventData['items']) && is_array($eventData['items']) ? $eventData['items'] : array();
$eventPage = isset($eventData['page']) ? (int) $eventData['page'] : 1;
$eventTotalPages = isset($eventData['total_pages']) ? (int) $eventData['total_pages'] : 1;
$eventTotal = isset($eventData['total']) ? (int) $eventData['total'] : 0;
$eventHasPrev = !empty($eventData['has_prev']);
$eventHasNext = !empty($eventData['has_next']);
$eventType = trim((string) $this->eventType);
$eventActor = trim((string) $this->eventActor);
$eventIp = trim((string) $this->eventIp);
$eventRange = trim((string) $this->eventRange);
$eventQuery = trim((string) $this->eventQuery);
$auditStatus = trim((string) $this->auditStatus);
if ($auditStatus === '') $auditStatus = 'all';
$auditQuery = trim((string) $this->auditQuery);
$checks = isset($readiness['checks']) && is_array($readiness['checks']) ? $readiness['checks'] : array();
$overallStatus = isset($readiness['overall_status']) ? (string) $readiness['overall_status'] : 'info';
$window = isset($summary['window']) && is_array($summary['window']) ? $summary['window'] : array();
$last24 = isset($summary['last_24h']) && is_array($summary['last_24h']) ? $summary['last_24h'] : array();
$topTasks = isset($summary['top_tasks']) && is_array($summary['top_tasks']) ? $summary['top_tasks'] : array();
$topErrors = isset($summary['top_errors']) && is_array($summary['top_errors']) ? $summary['top_errors'] : array();
$related = isset($requestDetails['related']) && is_array($requestDetails['related']) ? $requestDetails['related'] : array('tasks'=>array(),'proposals'=>array(),'tags'=>array());
$detailConn = isset($requestDetails['connection']) && is_array($requestDetails['connection']) ? $requestDetails['connection'] : array();
$detailEvents = isset($requestDetails['events']) && is_array($requestDetails['events']) ? $requestDetails['events'] : array();

$badgeStyle = function ($status) {
  switch ((string) $status) {
    case 'success':
    case 'ready':
      return 'background:#eefaf0;color:#1f6b35;border:1px solid #cde8d4;';
    case 'warning':
      return 'background:#fff8ef;color:#8a4d00;border:1px solid #f1d6aa;';
    case 'error':
      return 'background:#fff0f0;color:#b42318;border:1px solid #f1c0c0;';
    default:
      return 'background:#f4f5f7;color:#667085;border:1px solid #d5e3ee;';
  }
};
$fmtTime = function ($ts) {
  $ts = trim((string) $ts);
  if ($ts === '') return '—';
  try {
    $dt = new DateTime($ts);
    return $dt->format('Y-m-d H:i:s') . ' UTC';
  } catch (Exception $e) {
    return htmlspecialchars($ts, ENT_COMPAT, 'UTF-8');
  }
};
$short = function ($value, $max) {
  if (is_array($value) || is_object($value)) {
    $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  }
  $value = trim((string) $value);
  if ($value === '') return '—';
  if (function_exists('mb_strlen') && function_exists('mb_substr')) {
    if (mb_strlen($value) <= $max) return $value;
    return mb_substr($value, 0, $max - 1) . '…';
  }
  if (strlen($value) <= $max) return $value;
  return substr($value, 0, $max - 1) . '…';
};
$arrGet = function ($array, $key, $default = '') {
  return (is_array($array) && array_key_exists($key, $array)) ? $array[$key] : $default;
};
$baseBridgeUrl = 'index.php?option=com_leadmarket&view=bridge';
$buildUrl = function ($params = array(), $anchor = '') use ($baseBridgeUrl, $auditStatus, $auditQuery, $eventType, $eventActor, $eventIp, $eventRange, $eventQuery, $requestId) {
  $merged = array(
    'audit_status' => $auditStatus,
    'audit_q' => $auditQuery,
    'event_type' => $eventType,
    'event_actor' => $eventActor,
    'event_ip' => $eventIp,
    'event_range' => $eventRange,
    'event_q' => $eventQuery,
  );
  if ($requestId !== '') {
    $merged['request_id'] = $requestId;
  }
  foreach ((array) $params as $k => $v) {
    if ($v === null || $v === '') {
      unset($merged[$k]);
      continue;
    }
    $merged[$k] = $v;
  }
  $query = array();
  foreach ($merged as $k => $v) {
    $query[] = urlencode($k) . '=' . urlencode((string) $v);
  }
  return $baseBridgeUrl . (count($query) ? '&' . implode('&', $query) : '') . ($anchor !== '' ? '#' . $anchor : '');
};
$returnUrl = $buildUrl();
$matrixRead = isset($safeMatrix['read_access']) && is_array($safeMatrix['read_access']) ? $safeMatrix['read_access'] : array('enabled'=>false,'endpoints'=>array());
$matrixLive = isset($safeMatrix['live_writes']) && is_array($safeMatrix['live_writes']) ? $safeMatrix['live_writes'] : array();
$matrixProposal = isset($safeMatrix['proposal_only']) && is_array($safeMatrix['proposal_only']) ? $safeMatrix['proposal_only'] : array();
$matrixForbidden = isset($safeMatrix['forbidden']) && is_array($safeMatrix['forbidden']) ? $safeMatrix['forbidden'] : array();
?>
<?php echo LeadMarketHelper::renderAdminQuickNav('bridge'); ?>

<div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:18px 20px;margin-bottom:18px;">
  <div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start;flex-wrap:wrap;">
    <div>
      <h2 style="margin:0 0 6px;font-size:22px;line-height:1.25;">Bridge control center</h2>
      <div style="color:#5f6f7f;max-width:880px;">Monitor orchestrator traffic, inspect request details, review event flow, run self-checks, and control proposal/task execution from one place.</div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap;">
      <span style="display:inline-flex;align-items:center;min-height:34px;padding:0 12px;border-radius:999px;<?php echo $badgeStyle(((int)$p->get('bridge_enabled',0)===1) ? 'success' : 'info'); ?>font-weight:700;">Bridge <?php echo ((int)$p->get('bridge_enabled',0)===1) ? 'Enabled' : 'Disabled'; ?></span>
      <span style="display:inline-flex;align-items:center;min-height:34px;padding:0 12px;border-radius:999px;<?php echo $badgeStyle($overallStatus); ?>font-weight:700;">Readiness <?php echo ucfirst($overallStatus); ?></span>
      <span style="display:inline-flex;align-items:center;min-height:34px;padding:0 12px;border-radius:999px;<?php echo $badgeStyle((int)$p->get('bridge_allow_live_site_writes',0)===1 ? 'warning' : 'info'); ?>font-weight:700;">Live writes <?php echo ((int)$p->get('bridge_allow_live_site_writes',0)===1) ? 'Enabled' : 'Disabled'; ?></span>
      <span style="display:inline-flex;align-items:center;min-height:34px;padding:0 12px;border-radius:999px;background:#f4f5f7;color:#667085;border:1px solid #d5e3ee;font-weight:700;">24h: <?php echo (int) (isset($last24['total']) ? $last24['total'] : 0); ?> requests</span>
    </div>
  </div>
</div>

<div class="row-fluid">
  <div class="span8">
    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <h3 style="margin:0 0 12px;font-size:17px;">Health, readiness, and activity</h3>
      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:14px;">
        <div style="flex:1 1 180px;min-width:170px;background:#f8fbff;border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
          <div style="font-size:12px;color:#667085;text-transform:uppercase;letter-spacing:.04em;">Last 24h</div>
          <div style="font-size:24px;font-weight:700;margin-top:4px;"><?php echo (int) (isset($last24['total']) ? $last24['total'] : 0); ?></div>
          <div style="color:#667085;margin-top:4px;">Success <?php echo (int) (isset($last24['success']) ? $last24['success'] : 0); ?> · Errors <?php echo (int) (isset($last24['error']) ? $last24['error'] : 0); ?></div>
        </div>
        <div style="flex:1 1 180px;min-width:170px;background:#f8fbff;border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
          <div style="font-size:12px;color:#667085;text-transform:uppercase;letter-spacing:.04em;">Last success</div>
          <div style="font-size:16px;font-weight:700;margin-top:8px;"><?php echo $fmtTime(isset($summary['last_success_at']) ? $summary['last_success_at'] : ''); ?></div>
        </div>
        <div style="flex:1 1 180px;min-width:170px;background:#f8fbff;border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
          <div style="font-size:12px;color:#667085;text-transform:uppercase;letter-spacing:.04em;">Last issue</div>
          <div style="font-size:16px;font-weight:700;margin-top:8px;"><?php echo $fmtTime(isset($summary['last_error_at']) ? $summary['last_error_at'] : ''); ?></div>
        </div>
        <div style="flex:1 1 180px;min-width:170px;background:#f8fbff;border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
          <div style="font-size:12px;color:#667085;text-transform:uppercase;letter-spacing:.04em;">Connected sources</div>
          <div style="font-size:24px;font-weight:700;margin-top:4px;"><?php echo (int) (isset($summary['unique_actors']) ? $summary['unique_actors'] : 0); ?></div>
          <div style="color:#667085;margin-top:4px;">IPs <?php echo (int) (isset($summary['unique_ips']) ? $summary['unique_ips'] : 0); ?></div>
        </div>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;">
        <?php foreach ($checks as $check): ?>
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;background:#fff;">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;">
              <div style="font-weight:700;"><?php echo htmlspecialchars($check['label'], ENT_COMPAT, 'UTF-8'); ?></div>
              <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle(!empty($check['ok']) ? 'success' : (($check['key'] === 'bridge_enabled' || $check['key'] === 'storage_writable') ? 'error' : 'warning')); ?>font-size:12px;font-weight:700;"><?php echo !empty($check['ok']) ? 'OK' : 'Attention'; ?></span>
            </div>
            <div style="margin-top:8px;color:#667085;"><?php echo htmlspecialchars($check['detail'], ENT_COMPAT, 'UTF-8'); ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <div style="margin-top:14px;display:flex;gap:8px;flex-wrap:wrap;">
        <a class="btn btn-small btn-primary" href="<?php echo $buildUrl(array(), 'bridge-self-check'); ?>">Run self-check</a>
        <a class="btn btn-small" href="<?php echo $buildUrl(array(), 'bridge-self-check'); ?>">Rebuild bridge status</a>
        <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:0;">
          <input type="hidden" name="option" value="com_leadmarket">
          <input type="hidden" name="task" value="bridge.testAuditWrite">
          <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-self-check'), ENT_COMPAT, 'UTF-8'); ?>">
          <?php echo JHtml::_('form.token'); ?>
          <button class="btn btn-small" type="submit">Test audit write</button>
        </form>
      </div>
    </div>

    <div id="bridge-self-check" style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
        <div>
          <h3 style="margin:0 0 6px;font-size:17px;">Bridge self-check</h3>
          <div style="color:#667085;">Current storage, configuration, and queue state.</div>
        </div>
        <span style="display:inline-flex;align-items:center;min-height:28px;padding:0 10px;border-radius:999px;<?php echo $badgeStyle(isset($selfCheck['overall_status']) ? $selfCheck['overall_status'] : 'info'); ?>font-weight:700;">Overall <?php echo ucfirst((string) (isset($selfCheck['overall_status']) ? $selfCheck['overall_status'] : 'info')); ?></span>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px;">
        <?php $selfCounts = isset($selfCheck['counts']) && is_array($selfCheck['counts']) ? $selfCheck['counts'] : array(); ?>
        <?php foreach (array('pending_proposals' => 'Pending proposals', 'open_tasks' => 'Open tasks', 'recent_failures' => 'Recent failures', 'recent_connections_24h' => 'Requests (24h)') as $key => $label): ?>
          <div style="flex:1 1 160px;min-width:150px;background:#f8fbff;border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
            <div style="font-size:12px;color:#667085;text-transform:uppercase;letter-spacing:.04em;"><?php echo htmlspecialchars($label, ENT_COMPAT, 'UTF-8'); ?></div>
            <div style="font-size:24px;font-weight:700;margin-top:4px;"><?php echo (int) (isset($selfCounts[$key]) ? $selfCounts[$key] : 0); ?></div>
          </div>
        <?php endforeach; ?>
      </div>
      <div style="margin-top:12px;color:#667085;"><strong>Storage:</strong> <?php echo htmlspecialchars((string) (isset($selfCheck['storage_path']) ? $selfCheck['storage_path'] : ''), ENT_COMPAT, 'UTF-8'); ?> · <strong>Run at:</strong> <?php echo $fmtTime(isset($selfCheck['run_at']) ? $selfCheck['run_at'] : ''); ?></div>
    </div>

    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <h3 style="margin:0 0 12px;font-size:17px;">Safe control matrix</h3>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
        <div style="border:1px solid #cde8d4;border-radius:12px;padding:12px 14px;background:#f7fdf8;">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;">
            <strong>Green zone</strong>
            <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle($matrixRead['enabled'] ? 'success' : 'info'); ?>font-size:12px;font-weight:700;">Read <?php echo $matrixRead['enabled'] ? 'Enabled' : 'Disabled'; ?></span>
          </div>
          <div style="margin-top:8px;color:#667085;">Read endpoints and safe draft visibility.</div>
          <ul style="margin:10px 0 0 18px;">
            <?php foreach ((array) $matrixRead['endpoints'] as $endpoint): ?>
              <li><?php echo htmlspecialchars($endpoint, ENT_COMPAT, 'UTF-8'); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <div style="border:1px solid #f1d6aa;border-radius:12px;padding:12px 14px;background:#fffaf3;">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;">
            <strong>Yellow zone</strong>
            <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle('warning'); ?>font-size:12px;font-weight:700;">Proposal only</span>
          </div>
          <div style="margin-top:8px;color:#667085;">These actions should stay behind proposal approval.</div>
          <ul style="margin:10px 0 0 18px;">
            <?php foreach ($matrixProposal as $item): ?>
              <li><?php echo htmlspecialchars($item, ENT_COMPAT, 'UTF-8'); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
        <div style="border:1px solid #f1c0c0;border-radius:12px;padding:12px 14px;background:#fff7f7;">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:center;">
            <strong>Red zone</strong>
            <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle('error'); ?>font-size:12px;font-weight:700;">Forbidden</span>
          </div>
          <div style="margin-top:8px;color:#667085;">Never hand these areas to the orchestrator.</div>
          <ul style="margin:10px 0 0 18px;">
            <?php foreach ($matrixForbidden as $item): ?>
              <li><?php echo htmlspecialchars($item, ENT_COMPAT, 'UTF-8'); ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      </div>
      <div style="margin-top:12px;padding:12px 14px;border:1px solid #dbe7f1;border-radius:12px;background:#f8fbff;">
        <div style="font-weight:700;margin-bottom:6px;">Live scope</div>
        <div style="color:#667085;margin-bottom:6px;">Enabled: <strong><?php echo !empty($matrixLive['enabled']) ? 'Yes' : 'No'; ?></strong></div>
        <div><strong>Article IDs:</strong> <?php echo htmlspecialchars(implode(', ', (array) (isset($matrixLive['allowed_article_ids']) ? $matrixLive['allowed_article_ids'] : array())), ENT_COMPAT, 'UTF-8'); ?><?php if (empty($matrixLive['allowed_article_ids'])) echo '—'; ?></div>
        <div><strong>Module IDs:</strong> <?php echo htmlspecialchars(implode(', ', (array) (isset($matrixLive['allowed_module_ids']) ? $matrixLive['allowed_module_ids'] : array())), ENT_COMPAT, 'UTF-8'); ?><?php if (empty($matrixLive['allowed_module_ids'])) echo '—'; ?></div>
        <div><strong>Component keys:</strong> <?php echo htmlspecialchars(implode(', ', (array) (isset($matrixLive['allowed_component_param_keys']) ? $matrixLive['allowed_component_param_keys'] : array())), ENT_COMPAT, 'UTF-8'); ?><?php if (empty($matrixLive['allowed_component_param_keys'])) echo '—'; ?></div>
      </div>
    </div>

    <?php if ($requestId !== '' && $detailConn): ?>
      <div id="bridge-request-details" style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
          <div>
            <h3 style="margin:0 0 6px;font-size:17px;">Request details</h3>
            <div style="color:#667085;">Inspect one request end to end using its request ID.</div>
          </div>
          <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
            <span style="display:inline-flex;align-items:center;min-height:28px;padding:0 10px;border-radius:999px;<?php echo $badgeStyle(isset($detailConn['status']) ? $detailConn['status'] : 'info'); ?>font-weight:700;"><?php echo htmlspecialchars((string) (isset($detailConn['status_label']) ? $detailConn['status_label'] : 'Info'), ENT_COMPAT, 'UTF-8'); ?></span>
            <a class="btn btn-small" href="<?php echo $buildUrl(array('request_id' => null), 'bridge-audit-log'); ?>">Clear</a>
          </div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px;margin-top:12px;">
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;"><strong>Request ID</strong><div style="margin-top:6px;"><?php echo htmlspecialchars($requestId, ENT_COMPAT, 'UTF-8'); ?></div></div>
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;"><strong>When</strong><div style="margin-top:6px;"><?php echo $fmtTime(isset($detailConn['last_at']) ? $detailConn['last_at'] : ''); ?></div></div>
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;"><strong>Actor / IP</strong><div style="margin-top:6px;"><?php echo htmlspecialchars((string) (isset($detailConn['actor']) ? $detailConn['actor'] : ''), ENT_COMPAT, 'UTF-8'); ?> · <?php echo htmlspecialchars((string) (isset($detailConn['ip']) ? $detailConn['ip'] : ''), ENT_COMPAT, 'UTF-8'); ?></div></div>
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;"><strong>HTTP</strong><div style="margin-top:6px;"><?php echo isset($detailConn['http_status']) ? (int) $detailConn['http_status'] : '—'; ?> · <?php echo isset($detailConn['duration_ms']) && $detailConn['duration_ms'] !== null ? (int) $detailConn['duration_ms'] . ' ms' : '—'; ?></div></div>
        </div>
        <div style="margin-top:12px;border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;background:#f8fbff;">
          <div><strong>Task:</strong> <?php echo htmlspecialchars((string) (isset($detailConn['task']) ? $detailConn['task'] : ''), ENT_COMPAT, 'UTF-8'); ?></div>
          <div><strong>Route:</strong> <?php echo htmlspecialchars((string) (isset($detailConn['request_uri']) ? $detailConn['request_uri'] : ''), ENT_COMPAT, 'UTF-8'); ?></div>
          <div style="margin-top:6px;"><strong>Target summary:</strong> <?php echo htmlspecialchars((string) (isset($detailConn['target_summary']) ? $detailConn['target_summary'] : ''), ENT_COMPAT, 'UTF-8'); ?></div>
          <div style="margin-top:6px;"><strong>Result summary:</strong> <?php echo htmlspecialchars((string) (isset($detailConn['result_summary']) ? $detailConn['result_summary'] : ''), ENT_COMPAT, 'UTF-8'); ?></div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px;margin-top:12px;">
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
            <strong>Request payload preview</strong>
            <pre style="margin:8px 0 0;white-space:pre-wrap;word-break:break-word;max-height:220px;overflow:auto;background:#f8fbff;padding:10px;border-radius:10px;"><?php echo htmlspecialchars((string) (isset($requestDetails['request_payload_preview']) ? $requestDetails['request_payload_preview'] : ''), ENT_COMPAT, 'UTF-8'); ?></pre>
          </div>
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
            <strong>Result preview</strong>
            <pre style="margin:8px 0 0;white-space:pre-wrap;word-break:break-word;max-height:220px;overflow:auto;background:#f8fbff;padding:10px;border-radius:10px;"><?php echo htmlspecialchars((string) (isset($requestDetails['result_preview']) ? $requestDetails['result_preview'] : ''), ENT_COMPAT, 'UTF-8'); ?></pre>
          </div>
        </div>
        <div style="margin-top:12px;display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;">
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
            <strong>Related proposals</strong>
            <?php if (empty($related['proposals'])): ?>
              <div style="margin-top:8px;color:#667085;">No related proposals found.</div>
            <?php else: foreach ($related['proposals'] as $proposal): ?>
              <div style="margin-top:8px;padding-top:8px;border-top:1px dashed #e4edf5;">
                <div><strong><?php echo htmlspecialchars((string) $proposal['id'], ENT_COMPAT, 'UTF-8'); ?></strong></div>
                <div style="color:#667085;"><?php echo htmlspecialchars((string) $proposal['proposal_type'], ENT_COMPAT, 'UTF-8'); ?> · <?php echo htmlspecialchars((string) $proposal['status'], ENT_COMPAT, 'UTF-8'); ?></div>
              </div>
            <?php endforeach; endif; ?>
          </div>
          <div style="border:1px solid #dbe7f1;border-radius:12px;padding:12px 14px;">
            <strong>Related tasks & drafts</strong>
            <?php if (empty($related['tasks'])): ?>
              <div style="margin-top:8px;color:#667085;">No related tasks found.</div>
            <?php else: foreach ($related['tasks'] as $task): ?>
              <div style="margin-top:8px;padding-top:8px;border-top:1px dashed #e4edf5;">
                <div><strong><?php echo htmlspecialchars((string) $task['id'], ENT_COMPAT, 'UTF-8'); ?></strong></div>
                <div style="color:#667085;"><?php echo htmlspecialchars((string) $arrGet($task,'type',''), ENT_COMPAT, 'UTF-8'); ?> · <?php echo htmlspecialchars((string) $arrGet($task,'status',''), ENT_COMPAT, 'UTF-8'); ?></div>
              </div>
            <?php endforeach; endif; ?>
          </div>
        </div>
        <div style="margin-top:12px;">
          <strong>Audit events</strong>
          <?php if (!$detailEvents): ?>
            <div style="margin-top:8px;color:#667085;">No events recorded for this request.</div>
          <?php else: ?>
            <?php foreach ($detailEvents as $event): ?>
              <div style="margin-top:8px;padding:10px 12px;border:1px solid #e4edf5;border-radius:10px;">
                <div style="display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;align-items:center;">
                  <div><strong><?php echo htmlspecialchars((string) (isset($event['event_type']) ? $event['event_type'] : ''), ENT_COMPAT, 'UTF-8'); ?></strong></div>
                  <div style="color:#667085;"><?php echo $fmtTime(isset($event['ts']) ? $event['ts'] : ''); ?></div>
                </div>
                <div style="margin-top:6px;color:#667085;"><?php echo htmlspecialchars($short(isset($event['result']) ? $event['result'] : '', 220), ENT_COMPAT, 'UTF-8'); ?></div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endif; ?>

    <div id="bridge-events" style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap;margin-bottom:12px;">
        <div>
          <h3 style="margin:0 0 6px;font-size:18px;">Event stream</h3>
          <div style="color:#667085;">Follow auth, proposal, task, and safe-action events as they happen.</div>
        </div>
        <span style="display:inline-flex;align-items:center;min-height:32px;padding:0 10px;border-radius:999px;background:#f4f5f7;color:#667085;border:1px solid #d5e3ee;font-weight:700;">Showing <?php echo count($eventItems); ?> of <?php echo $eventTotal; ?></span>
      </div>
      <form action="index.php" method="get" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin-bottom:14px;">
        <input type="hidden" name="option" value="com_leadmarket">
        <input type="hidden" name="view" value="bridge">
        <div>
          <label style="display:block;font-weight:700;margin-bottom:4px;">Event type</label>
          <input type="text" name="event_type" value="<?php echo htmlspecialchars($eventType, ENT_COMPAT, 'UTF-8'); ?>" placeholder="auth_failed" style="min-width:180px;">
        </div>
        <div>
          <label style="display:block;font-weight:700;margin-bottom:4px;">Actor</label>
          <input type="text" name="event_actor" value="<?php echo htmlspecialchars($eventActor, ENT_COMPAT, 'UTF-8'); ?>" style="min-width:160px;">
        </div>
        <div>
          <label style="display:block;font-weight:700;margin-bottom:4px;">IP</label>
          <input type="text" name="event_ip" value="<?php echo htmlspecialchars($eventIp, ENT_COMPAT, 'UTF-8'); ?>" style="min-width:140px;">
        </div>
        <div>
          <label style="display:block;font-weight:700;margin-bottom:4px;">Range</label>
          <select name="event_range">
            <?php foreach (array('1h' => '1h', '24h' => '24h', '7d' => '7d', 'all' => 'All') as $v => $label): ?>
              <option value="<?php echo $v; ?>" <?php echo $eventRange === $v ? 'selected' : ''; ?>><?php echo $label; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div style="min-width:220px;flex:1 1 220px;">
          <label style="display:block;font-weight:700;margin-bottom:4px;">Search</label>
          <input type="text" name="event_q" value="<?php echo htmlspecialchars($eventQuery, ENT_COMPAT, 'UTF-8'); ?>" style="width:100%;" placeholder="request id, task, summary">
        </div>
        <div>
          <button class="btn btn-primary" type="submit">Filter</button>
          <a class="btn" href="<?php echo $buildUrl(array('event_type' => null, 'event_actor' => null, 'event_ip' => null, 'event_range' => '24h', 'event_q' => null), 'bridge-events'); ?>">Reset</a>
        </div>
      </form>
      <?php if (!$eventItems): ?>
        <div style="padding:14px;border:1px dashed #d5e3ee;border-radius:12px;color:#667085;">No audit events matched the current filter.</div>
      <?php else: foreach ($eventItems as $event): ?>
        <div style="border:1px solid #e4edf5;border-radius:12px;padding:12px 14px;margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
            <div>
              <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle(isset($event['status']) ? $event['status'] : 'info'); ?>font-size:12px;font-weight:700;"><?php echo htmlspecialchars(ucfirst((string) (isset($event['status']) ? $event['status'] : 'info')), ENT_COMPAT, 'UTF-8'); ?></span>
                <strong><?php echo htmlspecialchars((string) $arrGet($event, 'event_type', ''), ENT_COMPAT, 'UTF-8'); ?></strong>
              </div>
              <div style="margin-top:6px;color:#445566;"><?php echo htmlspecialchars((string) $arrGet($event, 'summary', ''), ENT_COMPAT, 'UTF-8'); ?></div>
            </div>
            <div style="min-width:220px;color:#667085;font-size:12px;line-height:1.65;">
              <div><strong>When:</strong> <?php echo $fmtTime(isset($event['ts']) ? $event['ts'] : ''); ?></div>
              <div><strong>Actor:</strong> <?php echo htmlspecialchars((string) $arrGet($event, 'actor', ''), ENT_COMPAT, 'UTF-8'); ?> · <strong>IP:</strong> <?php echo htmlspecialchars((string) $arrGet($event, 'ip', ''), ENT_COMPAT, 'UTF-8'); ?></div>
              <div><strong>Task:</strong> <?php echo htmlspecialchars((string) $arrGet($event, 'task', ''), ENT_COMPAT, 'UTF-8'); ?></div>
              <div><strong>Request:</strong> <a href="<?php echo $buildUrl(array('request_id' => (string) $arrGet($event, 'request_id', '')), 'bridge-request-details'); ?>"><?php echo htmlspecialchars((string) $arrGet($event, 'request_id', ''), ENT_COMPAT, 'UTF-8'); ?></a></div>
            </div>
          </div>
        </div>
      <?php endforeach; endif; ?>
      <?php if ($eventTotalPages > 1): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
          <div style="color:#667085;">Page <?php echo $eventPage; ?> of <?php echo $eventTotalPages; ?></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <?php if ($eventHasPrev): ?><a class="btn" href="<?php echo $buildUrl(array('event_page' => $eventPage - 1), 'bridge-events'); ?>">Prev</a><?php endif; ?>
            <?php for ($i = 1; $i <= $eventTotalPages; $i++): if ($i >= max(1, $eventPage - 2) && $i <= min($eventTotalPages, $eventPage + 2)): ?>
              <a class="btn <?php echo $i === $eventPage ? 'btn-primary' : ''; ?>" href="<?php echo $buildUrl(array('event_page' => $i), 'bridge-events'); ?>"><?php echo $i; ?></a>
            <?php endif; endfor; ?>
            <?php if ($eventHasNext): ?><a class="btn" href="<?php echo $buildUrl(array('event_page' => $eventPage + 1), 'bridge-events'); ?>">Next</a><?php endif; ?>
          </div>
        </div>
      <?php endif; ?>
    </div>

    <div id="bridge-audit-log" style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;gap:14px;align-items:flex-start;flex-wrap:wrap;margin-bottom:12px;">
        <div>
          <h3 style="margin:0 0 6px;font-size:18px;">Recent bridge connections</h3>
          <div style="color:#667085;">Browse the latest grouped bridge requests with outcome, task, target summary, actor, IP, status, and duration.</div>
        </div>
        <span style="display:inline-flex;align-items:center;min-height:32px;padding:0 10px;border-radius:999px;background:#f4f5f7;color:#667085;border:1px solid #d5e3ee;font-weight:700;">Showing <?php echo count($auditItems); ?> of <?php echo $auditTotal; ?></span>
      </div>
      <form action="index.php" method="get" style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;margin-bottom:14px;">
        <input type="hidden" name="option" value="com_leadmarket">
        <input type="hidden" name="view" value="bridge">
        <div>
          <label style="display:block;font-weight:700;margin-bottom:4px;">Status</label>
          <select name="audit_status" style="min-width:150px;">
            <?php foreach (array('all' => 'All', 'success' => 'Success', 'warning' => 'Warning', 'error' => 'Error', 'info' => 'Info') as $value => $label): ?>
              <option value="<?php echo $value; ?>" <?php echo $auditStatus === $value ? 'selected' : ''; ?>><?php echo $label; ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div style="min-width:280px;flex:1 1 280px;">
          <label style="display:block;font-weight:700;margin-bottom:4px;">Search</label>
          <input type="text" name="audit_q" value="<?php echo htmlspecialchars($auditQuery, ENT_COMPAT, 'UTF-8'); ?>" style="width:100%;" placeholder="request id, task, actor, IP, target">
        </div>
        <div>
          <button class="btn btn-primary" type="submit">Filter</button>
          <a class="btn" href="<?php echo $buildUrl(array('audit_status' => 'all', 'audit_q' => null, 'audit_page' => 1), 'bridge-audit-log'); ?>">Reset</a>
        </div>
      </form>
      <?php if (!$auditItems): ?>
        <div style="padding:14px;border:1px dashed #d5e3ee;border-radius:12px;color:#667085;">No bridge connections matched the current filter.</div>
      <?php else: foreach ($auditItems as $item): ?>
        <div style="border:1px solid #e4edf5;border-radius:12px;padding:14px 16px;margin-bottom:12px;">
          <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
            <div>
              <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle($item['status']); ?>font-size:12px;font-weight:700;"><?php echo htmlspecialchars($item['status_label'], ENT_COMPAT, 'UTF-8'); ?></span>
                <strong><?php echo htmlspecialchars($short(isset($item['task']) ? $item['task'] : 'unknown', 80), ENT_COMPAT, 'UTF-8'); ?></strong>
                <span style="color:#667085;"><?php echo htmlspecialchars((string) (isset($item['request_method']) ? $item['request_method'] : ''), ENT_COMPAT, 'UTF-8'); ?></span>
              </div>
              <div style="margin-top:6px;color:#445566;"><?php echo htmlspecialchars($short(isset($item['target_summary']) ? $item['target_summary'] : '', 150), ENT_COMPAT, 'UTF-8'); ?></div>
              <div style="margin-top:6px;color:#667085;"><?php echo htmlspecialchars($short(isset($item['result_summary']) ? $item['result_summary'] : '', 180), ENT_COMPAT, 'UTF-8'); ?></div>
            </div>
            <div style="min-width:220px;color:#667085;font-size:12px;line-height:1.65;">
              <div><strong>When:</strong> <?php echo $fmtTime(isset($item['last_at']) ? $item['last_at'] : ''); ?></div>
              <div><strong>Request ID:</strong> <a href="<?php echo $buildUrl(array('request_id' => (string) (isset($item['request_id']) ? $item['request_id'] : '')), 'bridge-request-details'); ?>"><?php echo htmlspecialchars((string) (isset($item['request_id']) ? $item['request_id'] : ''), ENT_COMPAT, 'UTF-8'); ?></a></div>
              <div><strong>Actor:</strong> <?php echo htmlspecialchars((string) (isset($item['actor']) ? $item['actor'] : ''), ENT_COMPAT, 'UTF-8'); ?></div>
              <div><strong>IP:</strong> <?php echo htmlspecialchars((string) (isset($item['ip']) ? $item['ip'] : ''), ENT_COMPAT, 'UTF-8'); ?></div>
              <div><strong>HTTP:</strong> <?php echo isset($item['http_status']) && $item['http_status'] !== null ? (int) $item['http_status'] : '—'; ?> · <strong>Duration:</strong> <?php echo isset($item['duration_ms']) && $item['duration_ms'] !== null ? (int) $item['duration_ms'] . ' ms' : '—'; ?></div>
            </div>
          </div>
        </div>
      <?php endforeach; endif; ?>
      <?php if ($auditTotalPages > 1): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;">
          <div style="color:#667085;">Page <?php echo $auditPage; ?> of <?php echo $auditTotalPages; ?></div>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <?php if ($this->auditHasPrev): ?><a class="btn" href="<?php echo $buildUrl(array('audit_page' => $auditPage - 1), 'bridge-audit-log'); ?>">Prev</a><?php endif; ?>
            <?php for ($i = 1; $i <= $auditTotalPages; $i++): if ($i >= max(1, $auditPage - 2) && $i <= min($auditTotalPages, $auditPage + 2)): ?>
              <a class="btn <?php echo $i === $auditPage ? 'btn-primary' : ''; ?>" href="<?php echo $buildUrl(array('audit_page' => $i), 'bridge-audit-log'); ?>"><?php echo $i; ?></a>
            <?php endif; endfor; ?>
            <?php if ($this->auditHasNext): ?><a class="btn" href="<?php echo $buildUrl(array('audit_page' => $auditPage + 1), 'bridge-audit-log'); ?>">Next</a><?php endif; ?>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="span4">
    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <h3 style="margin:0 0 12px;font-size:17px;">Bridge settings</h3>
      <form action="index.php?option=com_leadmarket&view=bridge" method="post" name="adminForm" id="adminForm">
        <input type="hidden" name="return_view" value="bridge">
        <input type="hidden" name="option" value="com_leadmarket">
        <input type="hidden" name="view" value="bridge">
        <input type="hidden" name="task" value="config.save">
        <fieldset class="adminform">
          <legend>Authentication & access</legend>
          <div class="control-group"><div class="control-label"><label>Bridge enabled</label></div><div class="controls"><select name="jform[bridge_enabled]"><option value="1" <?php echo ((int)$p->get('bridge_enabled',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('bridge_enabled',0)===0)?'selected':''; ?>>Disabled</option></select></div></div>
          <div class="control-group"><div class="control-label"><label>Bridge key ID</label></div><div class="controls"><input type="text" name="jform[bridge_key_id]" value="<?php echo htmlspecialchars($p->get('bridge_key_id','paperclip-main'), ENT_COMPAT, 'UTF-8'); ?>" style="width:100%;"></div></div>
          <div class="control-group"><div class="control-label"><label>Bridge shared secret</label></div><div class="controls"><input type="text" name="jform[bridge_shared_secret]" value="<?php echo htmlspecialchars($p->get('bridge_shared_secret',''), ENT_COMPAT, 'UTF-8'); ?>" style="width:100%;"></div></div>
          <div class="control-group"><div class="control-label"><label>Enforce IP allowlist</label></div><div class="controls"><select name="jform[bridge_enforce_ip_allowlist]"><option value="1" <?php echo ((int)$p->get('bridge_enforce_ip_allowlist',1)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('bridge_enforce_ip_allowlist',1)===0)?'selected':''; ?>>Disabled (accept any IP)</option></select><div style="margin-top:6px;color:#667085;font-size:12px;line-height:1.45;">When disabled, bridge requests are accepted from any source IP. HMAC key, signature, timestamp, and rate limits still apply.</div></div></div>
          <div class="control-group"><div class="control-label"><label>Allowed IPs / CIDRs</label></div><div class="controls"><textarea name="jform[bridge_allowed_ips]" rows="3" style="width:100%;"><?php echo htmlspecialchars($p->get('bridge_allowed_ips',''), ENT_COMPAT, 'UTF-8'); ?></textarea><div style="margin-top:6px;color:#667085;font-size:12px;line-height:1.45;">Supports comma-separated or newline-separated IPv4, IPv6, and CIDR entries. Ignored when IP allowlist enforcement is disabled.</div></div></div>
          <div class="control-group"><div class="control-label"><label>Max skew seconds</label></div><div class="controls"><input type="number" name="jform[bridge_max_skew_seconds]" value="<?php echo (int)$p->get('bridge_max_skew_seconds',300); ?>" style="width:120px;"></div></div>
        </fieldset>
        <fieldset class="adminform">
          <legend>Rate limits & storage</legend>
          <div class="control-group"><div class="control-label"><label>Read RPM</label></div><div class="controls"><input type="number" name="jform[bridge_read_rpm]" value="<?php echo (int)$p->get('bridge_read_rpm',60); ?>" style="width:120px;"></div></div>
          <div class="control-group"><div class="control-label"><label>Write / proposal RPM</label></div><div class="controls"><input type="number" name="jform[bridge_write_rpm]" value="<?php echo (int)$p->get('bridge_write_rpm',20); ?>" style="width:120px;"></div></div>
          <div class="control-group"><div class="control-label"><label>Approve RPM</label></div><div class="controls"><input type="number" name="jform[bridge_approve_rpm]" value="<?php echo (int)$p->get('bridge_approve_rpm',10); ?>" style="width:120px;"></div></div>
          <div class="control-group"><div class="control-label"><label>Storage path</label></div><div class="controls"><input type="text" name="jform[bridge_storage_path]" value="<?php echo htmlspecialchars($p->get('bridge_storage_path','administrator/logs/leadmarket_bridge'), ENT_COMPAT, 'UTF-8'); ?>" style="width:100%;"></div></div>
        </fieldset>
        <fieldset class="adminform">
          <legend>Live control scope</legend>
          <div class="control-group"><div class="control-label"><label>Allow live site writes</label></div><div class="controls"><select name="jform[bridge_allow_live_site_writes]"><option value="1" <?php echo ((int)$p->get('bridge_allow_live_site_writes',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('bridge_allow_live_site_writes',0)===0)?'selected':''; ?>>Disabled</option></select></div></div>
          <div class="control-group"><div class="control-label"><label>Allowed article IDs</label></div><div class="controls"><textarea name="jform[bridge_live_allowed_article_ids]" rows="2" style="width:100%;"><?php echo htmlspecialchars($p->get('bridge_live_allowed_article_ids',''), ENT_COMPAT, 'UTF-8'); ?></textarea></div></div>
          <div class="control-group"><div class="control-label"><label>Allowed module IDs</label></div><div class="controls"><textarea name="jform[bridge_live_allowed_module_ids]" rows="2" style="width:100%;"><?php echo htmlspecialchars($p->get('bridge_live_allowed_module_ids',''), ENT_COMPAT, 'UTF-8'); ?></textarea></div></div>
          <div class="control-group"><div class="control-label"><label>Allowed component param keys</label></div><div class="controls"><textarea name="jform[bridge_live_allowed_component_params]" rows="3" style="width:100%;"><?php echo htmlspecialchars($p->get('bridge_live_allowed_component_params',''), ENT_COMPAT, 'UTF-8'); ?></textarea></div></div>
        </fieldset>
        <?php echo JHtml::_('form.token'); ?>
      </form>
    </div>

    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <h3 style="margin:0 0 12px;font-size:17px;">Pending proposals</h3>
      <?php if (!$pendingProposals): ?>
        <div style="color:#667085;">No pending proposals.</div>
      <?php else: foreach ($pendingProposals as $proposal): ?>
        <div style="border-top:1px solid #eef2f6;padding-top:12px;margin-top:12px;">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
            <div>
              <strong><?php echo htmlspecialchars((string) $proposal['proposal_type'], ENT_COMPAT, 'UTF-8'); ?></strong>
              <div style="color:#667085;margin-top:4px;"><?php echo htmlspecialchars($short(isset($proposal['target_key']) ? $proposal['target_key'] : '', 60), ENT_COMPAT, 'UTF-8'); ?></div>
            </div>
            <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle('warning'); ?>font-size:12px;font-weight:700;">Pending</span>
          </div>
          <div style="margin-top:6px;color:#667085;"><?php echo $fmtTime(isset($proposal['created_at']) ? $proposal['created_at'] : ''); ?></div>
          <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
            <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:0;">
              <input type="hidden" name="option" value="com_leadmarket"><input type="hidden" name="task" value="bridge.approveProposal"><input type="hidden" name="proposal_id" value="<?php echo htmlspecialchars((string) $proposal['id'], ENT_COMPAT, 'UTF-8'); ?>"><input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-audit-log'), ENT_COMPAT, 'UTF-8'); ?>"><?php echo JHtml::_('form.token'); ?><button class="btn btn-small btn-success" type="submit">Approve</button>
            </form>
            <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:6px;align-items:center;flex-wrap:wrap;">
              <input type="hidden" name="option" value="com_leadmarket"><input type="hidden" name="task" value="bridge.rejectProposal"><input type="hidden" name="proposal_id" value="<?php echo htmlspecialchars((string) $proposal['id'], ENT_COMPAT, 'UTF-8'); ?>"><input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-audit-log'), ENT_COMPAT, 'UTF-8'); ?>"><input type="text" name="reason" value="" placeholder="Reason" style="width:88px;"><?php echo JHtml::_('form.token'); ?><button class="btn btn-small" type="submit">Reject</button>
            </form>
            <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:0;">
              <input type="hidden" name="option" value="com_leadmarket"><input type="hidden" name="task" value="bridge.expireProposal"><input type="hidden" name="proposal_id" value="<?php echo htmlspecialchars((string) $proposal['id'], ENT_COMPAT, 'UTF-8'); ?>"><input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-audit-log'), ENT_COMPAT, 'UTF-8'); ?>"><?php echo JHtml::_('form.token'); ?><button class="btn btn-small" type="submit">Expire</button>
            </form>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>

    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;margin-bottom:16px;">
      <h3 style="margin:0 0 12px;font-size:17px;">Open tasks & drafts</h3>
      <?php if (!$openTasks): ?>
        <div style="color:#667085;">No open tasks or drafts.</div>
      <?php else: foreach ($openTasks as $task): ?>
        <div style="border-top:1px solid #eef2f6;padding-top:12px;margin-top:12px;">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
            <div>
              <strong><?php echo htmlspecialchars((string) $arrGet($task,'title', $arrGet($task,'type','Task')), ENT_COMPAT, 'UTF-8'); ?></strong>
              <div style="color:#667085;margin-top:4px;"><?php echo htmlspecialchars((string) $arrGet($task,'type',''), ENT_COMPAT, 'UTF-8'); ?> · <?php echo htmlspecialchars((string) $arrGet($task,'status',''), ENT_COMPAT, 'UTF-8'); ?></div>
            </div>
            <div style="color:#667085;font-size:12px;"><?php echo $fmtTime(isset($task['updated_at']) ? $task['updated_at'] : (isset($task['created_at']) ? $task['created_at'] : '')); ?></div>
          </div>
          <div style="margin-top:6px;color:#667085;"><?php echo htmlspecialchars($short(isset($task['notes']) ? $task['notes'] : (isset($task['draft_body']) ? $task['draft_body'] : ''), 140), ENT_COMPAT, 'UTF-8'); ?></div>
          <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
            <?php if ((string) $arrGet($task,'status','') !== 'done'): ?>
              <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:0;"><input type="hidden" name="option" value="com_leadmarket"><input type="hidden" name="task" value="bridge.updateTaskStatus"><input type="hidden" name="task_id" value="<?php echo htmlspecialchars((string) $task['id'], ENT_COMPAT, 'UTF-8'); ?>"><input type="hidden" name="status" value="done"><input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-audit-log'), ENT_COMPAT, 'UTF-8'); ?>"><?php echo JHtml::_('form.token'); ?><button class="btn btn-small btn-success" type="submit">Mark done</button></form>
            <?php endif; ?>
            <?php if ((string) $arrGet($task,'status','') !== 'canceled'): ?>
              <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:0;"><input type="hidden" name="option" value="com_leadmarket"><input type="hidden" name="task" value="bridge.updateTaskStatus"><input type="hidden" name="task_id" value="<?php echo htmlspecialchars((string) $task['id'], ENT_COMPAT, 'UTF-8'); ?>"><input type="hidden" name="status" value="canceled"><input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-audit-log'), ENT_COMPAT, 'UTF-8'); ?>"><?php echo JHtml::_('form.token'); ?><button class="btn btn-small" type="submit">Cancel</button></form>
            <?php endif; ?>
            <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:0;"><input type="hidden" name="option" value="com_leadmarket"><input type="hidden" name="task" value="bridge.updateTaskStatus"><input type="hidden" name="task_id" value="<?php echo htmlspecialchars((string) $task['id'], ENT_COMPAT, 'UTF-8'); ?>"><input type="hidden" name="status" value="open"><input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-audit-log'), ENT_COMPAT, 'UTF-8'); ?>"><?php echo JHtml::_('form.token'); ?><button class="btn btn-small" type="submit">Reopen</button></form>
            <form action="index.php" method="post" style="margin:0;display:inline-flex;gap:0;"><input type="hidden" name="option" value="com_leadmarket"><input type="hidden" name="task" value="bridge.duplicateTask"><input type="hidden" name="task_id" value="<?php echo htmlspecialchars((string) $task['id'], ENT_COMPAT, 'UTF-8'); ?>"><input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buildUrl(array(), 'bridge-audit-log'), ENT_COMPAT, 'UTF-8'); ?>"><?php echo JHtml::_('form.token'); ?><button class="btn btn-small" type="submit">Duplicate</button></form>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>

    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;">
      <h3 style="margin:0 0 12px;font-size:17px;">Recent failures & warnings</h3>
      <?php if (!$recentFailures): ?>
        <div style="color:#667085;">No recent failures or warnings.</div>
      <?php else: foreach ($recentFailures as $item): ?>
        <div style="border-top:1px solid #eef2f6;padding-top:12px;margin-top:12px;">
          <div style="display:flex;justify-content:space-between;gap:8px;align-items:flex-start;">
            <div>
              <span style="display:inline-flex;align-items:center;min-height:24px;padding:0 8px;border-radius:999px;<?php echo $badgeStyle($item['status']); ?>font-size:12px;font-weight:700;"><?php echo htmlspecialchars($item['status_label'], ENT_COMPAT, 'UTF-8'); ?></span>
              <div style="margin-top:6px;font-weight:700;"><?php echo htmlspecialchars((string) $arrGet($item,'task','unknown'), ENT_COMPAT, 'UTF-8'); ?></div>
              <div style="margin-top:4px;color:#667085;"><?php echo htmlspecialchars($short(isset($item['result_summary']) ? $item['result_summary'] : '', 150), ENT_COMPAT, 'UTF-8'); ?></div>
            </div>
            <div style="color:#667085;font-size:12px;"><?php echo $fmtTime(isset($item['last_at']) ? $item['last_at'] : ''); ?></div>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
