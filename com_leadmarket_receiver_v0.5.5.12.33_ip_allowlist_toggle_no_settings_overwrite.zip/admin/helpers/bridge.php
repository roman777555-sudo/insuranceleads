<?php
/**
 * LeadMarket private bridge helper.
 * File-backed no-migration v1 for orchestrator integration.
 */
defined('_JEXEC') or die;

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');
jimport('joomla.mail.helper');
jimport('joomla.filter.output');

class LeadMarketBridgeHelper
{
    protected static $params = null;
    protected static $rawBody = null;
    protected static $storageBase = null;
    protected static $auditGroupsCache = null;

    public static function handleRead($actionGroup, $callback)
    {
        $baseCtx = self::buildFallbackContext();
        $ctx = $baseCtx;

        try {
            $verifiedCtx = self::verifyRequest($actionGroup, 'GET');
            $ctx = array_merge($baseCtx, $verifiedCtx);
            $result = call_user_func($callback);
            self::audit('read_endpoint_called', $ctx, array(
                'task' => self::arrGet($ctx, 'task', self::currentTask()),
                'query' => self::currentQueryForAudit(),
            ), self::runtimeResultMeta($ctx, array('ok' => true), 200));
            self::respond(self::withMeta(array_merge(array('ok' => true), (array) $result), $ctx), 200);
        } catch (Exception $e) {
            self::handleException($e, $ctx);
        }
    }

    public static function handleWrite($actionGroup, $callback)
    {
        $baseCtx = self::buildFallbackContext();
        $ctx = $baseCtx;

        try {
            $verifiedCtx = self::verifyRequest($actionGroup, 'POST');
            $ctx = array_merge($baseCtx, $verifiedCtx);
            $payload = self::readJsonBody();
            $result = call_user_func($callback, $payload, $ctx);
            self::respond(self::withMeta(array_merge(array('ok' => true), (array) $result), $ctx), 200);
        } catch (Exception $e) {
            self::handleException($e, $ctx);
        }
    }


    public static function buildAdminContext($task = '', $actor = '')
    {
        $user = JFactory::getUser();
        if ($actor === '') {
            if ($user && !empty($user->id)) {
                $name = trim((string) ($user->username !== '' ? $user->username : $user->name));
                $actor = $name !== '' ? 'admin:' . $name : 'admin:user_' . (int) $user->id;
            } else {
                $actor = 'admin:unknown';
            }
        }

        return array(
            'request_id' => self::buildRequestId(),
            'ip' => self::getClientIp(),
            'actor' => $actor,
            'task' => $task !== '' ? $task : self::currentTask(),
            'started_microtime' => microtime(true),
        );
    }

    public static function verifyRequest($actionGroup, $expectedMethod)
    {
        $method = strtoupper((string) self::server('REQUEST_METHOD', 'GET'));
        if ($method !== strtoupper((string) $expectedMethod)) {
            throw new RuntimeException('method_not_allowed', 405);
        }

        $params = self::params();
        $requestId = self::buildRequestId();
        $clientIp = self::getClientIp();
        $keyId = self::getHeader('X-Bridge-Key');
        $timestamp = self::getHeader('X-Bridge-Timestamp');
        $signature = self::getHeader('X-Bridge-Signature');
        $ctx = array(
            'request_id' => $requestId,
            'ip' => $clientIp,
            'actor' => $keyId !== '' ? $keyId : 'unknown',
            'task' => self::currentTask(),
            'started_microtime' => microtime(true),
        );

        if ((int) $params->get('bridge_enabled', 0) !== 1) {
            throw new RuntimeException('bridge_disabled', 503);
        }

        if (self::isIpAllowlistEnforced($params) && !self::isAllowedIp($clientIp, (string) $params->get('bridge_allowed_ips', ''))) {
            self::audit('auth_failed', $ctx, array('reason' => 'ip_denied'), array('ok' => false));
            throw new RuntimeException('ip_denied', 403);
        }

        $configKey = trim((string) $params->get('bridge_key_id', ''));
        $secret = trim((string) $params->get('bridge_shared_secret', ''));
        $maxSkew = max(30, (int) $params->get('bridge_max_skew_seconds', 300));

        if ($keyId === '' || $timestamp === '' || $signature === '' || $configKey === '' || $secret === '') {
            self::audit('auth_failed', $ctx, array('reason' => 'auth_missing'), array('ok' => false));
            throw new RuntimeException('auth_missing', 401);
        }

        if (!hash_equals($configKey, $keyId)) {
            self::audit('auth_failed', $ctx, array('reason' => 'auth_invalid_key'), array('ok' => false));
            throw new RuntimeException('auth_invalid_key', 401);
        }

        $ts = self::normalizeTimestamp($timestamp);
        if ($ts <= 0) {
            self::audit('auth_failed', $ctx, array('reason' => 'auth_invalid_timestamp'), array('ok' => false));
            throw new RuntimeException('auth_invalid_timestamp', 401);
        }

        if (abs(time() - $ts) > $maxSkew) {
            self::audit('auth_failed', $ctx, array('reason' => 'auth_timestamp_expired', 'timestamp' => $timestamp), array('ok' => false));
            throw new RuntimeException('auth_timestamp_expired', 401);
        }

        $rawBody = self::readRawBody();
        $expected = hash_hmac('sha256', $timestamp . "\n" . $rawBody, $secret);
        if (!hash_equals(strtolower($expected), strtolower($signature))) {
            self::audit('auth_failed', $ctx, array('reason' => 'auth_bad_signature'), array('ok' => false));
            throw new RuntimeException('auth_bad_signature', 401);
        }

        self::enforceRateLimit($keyId, $actionGroup, $params, $ctx);
        self::audit('auth_ok', $ctx, array('group' => $actionGroup), array('ok' => true));

        $ctx['raw_body'] = $rawBody;
        return $ctx;
    }

    public static function getKpiOverview()
    {
        $db = JFactory::getDbo();
        $data = array(
            'new_buyers_7d' => 0,
            'free_test_signups_7d' => 0,
            'first_paid_7d' => 0,
            'repeat_buyers_7d' => 0,
            'inactive_30d_count' => 0,
            'stale_leads_count' => 0,
            'top_states' => array(),
            'top_lead_types' => array(),
        );

        $paidWhere = self::paidWhere('o');

        $db->setQuery("SELECT COUNT(DISTINCT LOWER(t.email)) FROM #__leadmarket_trial_access t WHERE t.created_at_utc >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)");
        $data['free_test_signups_7d'] = (int) $db->loadResult();

        $db->setQuery("SELECT COUNT(*) FROM (SELECT LOWER(o.buyer_email) AS buyer_key, MIN(o.paid_at_utc) AS first_paid_at FROM #__leadmarket_orders o WHERE {$paidWhere} GROUP BY LOWER(o.buyer_email) HAVING first_paid_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)) x");
        $data['new_buyers_7d'] = (int) $db->loadResult();

        $db->setQuery(
            "SELECT COUNT(*)
             FROM (
                SELECT LOWER(o.buyer_email) AS buyer_key, MIN(o.paid_at_utc) AS first_paid_at
                FROM #__leadmarket_orders o
                INNER JOIN #__leadmarket_trial_access t ON LOWER(t.email)=LOWER(o.buyer_email)
                WHERE {$paidWhere}
                GROUP BY LOWER(o.buyer_email)
                HAVING first_paid_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)
             ) x"
        );
        $data['first_paid_7d'] = (int) $db->loadResult();

        $db->setQuery("SELECT COUNT(*) FROM (SELECT LOWER(o.buyer_email) AS buyer_key, COUNT(*) AS cnt, MAX(o.paid_at_utc) AS last_paid_at FROM #__leadmarket_orders o WHERE {$paidWhere} GROUP BY LOWER(o.buyer_email) HAVING cnt >= 2 AND last_paid_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 7 DAY)) x");
        $data['repeat_buyers_7d'] = (int) $db->loadResult();

        $db->setQuery("SELECT COUNT(*) FROM (SELECT LOWER(o.buyer_email) AS buyer_key, MAX(o.paid_at_utc) AS last_paid_at FROM #__leadmarket_orders o WHERE {$paidWhere} GROUP BY LOWER(o.buyer_email) HAVING last_paid_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY)) x");
        $data['inactive_30d_count'] = (int) $db->loadResult();

        $db->setQuery(
            "SELECT COUNT(*)
             FROM #__leadmarket_leads l
             WHERE l.sold_count < l.max_sales
               AND TIMESTAMPDIFF(HOUR, l.uploaded_at_utc, UTC_TIMESTAMP()) >=
                   CASE WHEN l.type='home' THEN " . (int) self::params()->get('aged_home_max_hours', 48) . " ELSE " . (int) self::params()->get('aged_auto_max_hours', 24) . " END"
        );
        $data['stale_leads_count'] = (int) $db->loadResult();

        $db->setQuery("SELECT l.state FROM #__leadmarket_orders o INNER JOIN #__leadmarket_leads l ON l.id = o.lead_id WHERE {$paidWhere} AND o.paid_at_utc >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY) AND l.state IS NOT NULL AND l.state <> '' GROUP BY l.state ORDER BY COUNT(*) DESC LIMIT 5");
        $data['top_states'] = array_values(array_filter((array) $db->loadColumn()));

        $db->setQuery("SELECT l.type FROM #__leadmarket_orders o INNER JOIN #__leadmarket_leads l ON l.id = o.lead_id WHERE {$paidWhere} AND o.paid_at_utc >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 30 DAY) AND l.type IS NOT NULL AND l.type <> '' GROUP BY l.type ORDER BY COUNT(*) DESC LIMIT 5");
        $data['top_lead_types'] = array_values(array_filter((array) $db->loadColumn()));

        return $data;
    }

    public static function getBuyersFreeTestPending($limit)
    {
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $paidWhere = self::paidWhere('o');

        $sql = "SELECT
                    LOWER(t.email) AS buyer_key,
                    t.email AS buyer_email,
                    MAX(s.email) AS name_source_email,
                    MAX(t.states_json) AS states_json,
                    MIN(t.created_at_utc) AS created_at,
                    MAX(CASE WHEN COALESCE(t.view_count, 0) > 0 THEN 1 ELSE 0 END) AS opened_test_lead,
                    NULL AS first_purchase_at,
                    'free_test_pending' AS status,
                    MAX(COALESCE(t.last_view_at_utc, t.first_view_at_utc, t.created_at_utc)) AS last_activity_at,
                    MAX(COALESCE(t.marketplace_click_count, 0)) AS marketplace_click_count
                FROM #__leadmarket_trial_access t
                LEFT JOIN #__leadmarket_subscribers s ON s.id = t.subscriber_id
                LEFT JOIN #__leadmarket_orders o ON LOWER(o.buyer_email) = LOWER(t.email) AND {$paidWhere}
                WHERE t.email <> ''
                  AND t.is_active = 1
                  AND o.id IS NULL
                GROUP BY LOWER(t.email), t.email
                ORDER BY last_activity_at DESC
                LIMIT {$limit}";
        $db->setQuery($sql);
        $rows = (array) $db->loadAssocList();

        foreach ($rows as &$row) {
            $row['name'] = '';
            if (!empty($row['name_source_email'])) {
                $row['name'] = '';
            }
            $row['state_interest'] = self::extractPrimaryState($row['states_json']);
            unset($row['states_json'], $row['name_source_email']);
        }
        unset($row);

        return $rows;
    }

    public static function getBuyersInactive($bucket, $limit)
    {
        $daysMap = array('7d' => 7, '30d' => 30, '60d' => 60, '90d' => 90);
        $bucket = isset($daysMap[$bucket]) ? $bucket : '30d';
        $days = $daysMap[$bucket];
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $paidWhere = self::paidWhere('o');

        $sql = "SELECT
                    x.buyer_email,
                    LOWER(x.buyer_email) AS buyer_key,
                    '' AS name,
                    x.last_purchase_at,
                    x.total_orders,
                    x.total_spent,
                    x.preferred_state,
                    x.preferred_lead_type,
                    '{$bucket}' AS inactivity_bucket
                FROM (
                    SELECT
                        o.buyer_email,
                        MAX(o.paid_at_utc) AS last_purchase_at,
                        COUNT(*) AS total_orders,
                        ROUND(SUM(COALESCE(o.amount_usd, 0)), 2) AS total_spent,
                        SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(l.state, '') ORDER BY o.paid_at_utc DESC SEPARATOR ','), ',', 1) AS preferred_state,
                        SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(l.type, '') ORDER BY o.paid_at_utc DESC SEPARATOR ','), ',', 1) AS preferred_lead_type
                    FROM #__leadmarket_orders o
                    LEFT JOIN #__leadmarket_leads l ON l.id = o.lead_id
                    WHERE {$paidWhere}
                    GROUP BY LOWER(o.buyer_email), o.buyer_email
                    HAVING last_purchase_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL {$days} DAY)
                ) x
                ORDER BY x.last_purchase_at ASC
                LIMIT {$limit}";
        $db->setQuery($sql);
        return (array) $db->loadAssocList();
    }

    public static function getBuyersRepeat($limit)
    {
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $paidWhere = self::paidWhere('o');

        $sql = "SELECT
                    o.buyer_email,
                    LOWER(o.buyer_email) AS buyer_key,
                    '' AS name,
                    COUNT(*) AS total_orders,
                    ROUND(SUM(COALESCE(o.amount_usd, 0)), 2) AS total_spent,
                    MIN(o.paid_at_utc) AS first_purchase_at,
                    MAX(o.paid_at_utc) AS last_purchase_at,
                    SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(l.state, '') ORDER BY o.paid_at_utc DESC SEPARATOR ','), ',', 1) AS preferred_state,
                    SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(l.type, '') ORDER BY o.paid_at_utc DESC SEPARATOR ','), ',', 1) AS preferred_lead_type
                FROM #__leadmarket_orders o
                LEFT JOIN #__leadmarket_leads l ON l.id = o.lead_id
                WHERE {$paidWhere}
                GROUP BY LOWER(o.buyer_email), o.buyer_email
                HAVING COUNT(*) >= 2
                ORDER BY last_purchase_at DESC
                LIMIT {$limit}";
        $db->setQuery($sql);
        return (array) $db->loadAssocList();
    }

    public static function getLeadInventory($state, $type, $limit)
    {
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $query = $db->getQuery(true)
            ->select(array(
                'l.id AS lead_id',
                'l.type AS category',
                'l.state',
                'l.uploaded_at_utc AS created_at',
                'l.lead_status AS status',
                '(CASE WHEN l.sold_count < l.max_sales THEN (l.max_sales - l.sold_count) ELSE 0 END) AS shared_available',
                '(CASE WHEN (l.exclusive_owner_order_id IS NULL OR l.exclusive_owner_order_id = 0) THEN 1 ELSE 0 END) AS exclusive_available',
                'TIMESTAMPDIFF(HOUR, l.uploaded_at_utc, UTC_TIMESTAMP()) AS age_hours',
                'l.price_usd AS price_shared',
                'ROUND(l.price_usd * 2, 2) AS price_exclusive',
                'l.is_free_test',
                'l.free_test_active',
            ))
            ->from('#__leadmarket_leads l')
            ->order('l.uploaded_at_utc DESC');

        if ($state !== '') {
            $query->where('l.state = ' . $db->q($state));
        }
        if ($type !== '') {
            $query->where('l.type = ' . $db->q($type));
        }

        $db->setQuery($query, 0, $limit);
        return (array) $db->loadAssocList();
    }

    public static function getStaleLeads($minAgeHours, $state, $type, $limit)
    {
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $minAgeHours = max(1, (int) $minAgeHours);

        $query = $db->getQuery(true)
            ->select(array(
                'l.id AS lead_id',
                'l.type AS category',
                'l.state',
                'l.uploaded_at_utc AS created_at',
                'l.lead_status AS status',
                '(CASE WHEN l.sold_count < l.max_sales THEN (l.max_sales - l.sold_count) ELSE 0 END) AS shared_available',
                '(CASE WHEN (l.exclusive_owner_order_id IS NULL OR l.exclusive_owner_order_id = 0) THEN 1 ELSE 0 END) AS exclusive_available',
                'TIMESTAMPDIFF(HOUR, l.uploaded_at_utc, UTC_TIMESTAMP()) AS age_hours',
                'l.price_usd AS price_shared',
                'ROUND(l.price_usd * 2, 2) AS price_exclusive',
            ))
            ->from('#__leadmarket_leads l')
            ->where('TIMESTAMPDIFF(HOUR, l.uploaded_at_utc, UTC_TIMESTAMP()) >= ' . (int) $minAgeHours)
            ->where('l.sold_count < l.max_sales')
            ->order('l.uploaded_at_utc ASC');

        if ($state !== '') {
            $query->where('l.state = ' . $db->q($state));
        }
        if ($type !== '') {
            $query->where('l.type = ' . $db->q($type));
        }

        $db->setQuery($query, 0, $limit);
        return (array) $db->loadAssocList();
    }

    public static function getRecentEvents($limit)
    {
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $events = array();

        $db->setQuery("SELECT 'free_test_signup_created' AS event_type, 'buyer' AS entity_type, LOWER(email) AS entity_key, email AS entity_label, created_at_utc AS created_at, source_page, lead_type FROM #__leadmarket_trial_access ORDER BY created_at_utc DESC LIMIT " . $limit);
        foreach ((array) $db->loadAssocList() as $row) {
            $events[] = array(
                'event_type' => $row['event_type'],
                'entity_type' => $row['entity_type'],
                'entity_key' => $row['entity_key'],
                'entity_label' => $row['entity_label'],
                'created_at' => $row['created_at'],
                'payload' => array(
                    'source_page' => $row['source_page'],
                    'lead_type' => $row['lead_type'],
                ),
            );
        }

        $db->setQuery("SELECT 'buyer_opened_test_lead' AS event_type, 'buyer' AS entity_type, LOWER(email) AS entity_key, email AS entity_label, viewed_at_utc AS created_at, lead_id, lead_state, lead_type FROM #__leadmarket_trial_lead_views ORDER BY viewed_at_utc DESC LIMIT " . $limit);
        foreach ((array) $db->loadAssocList() as $row) {
            $events[] = array(
                'event_type' => $row['event_type'],
                'entity_type' => $row['entity_type'],
                'entity_key' => $row['entity_key'],
                'entity_label' => $row['entity_label'],
                'created_at' => $row['created_at'],
                'payload' => array(
                    'lead_id' => (int) $row['lead_id'],
                    'lead_state' => $row['lead_state'],
                    'lead_type' => $row['lead_type'],
                ),
            );
        }

        $paidWhere = self::paidWhere('o');
        $db->setQuery("SELECT LOWER(o.buyer_email) AS buyer_key, o.buyer_email, MIN(o.paid_at_utc) AS created_at FROM #__leadmarket_orders o WHERE {$paidWhere} GROUP BY LOWER(o.buyer_email), o.buyer_email HAVING created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 90 DAY) ORDER BY created_at DESC LIMIT " . $limit);
        foreach ((array) $db->loadAssocList() as $row) {
            $events[] = array(
                'event_type' => 'buyer_first_purchase',
                'entity_type' => 'buyer',
                'entity_key' => $row['buyer_key'],
                'entity_label' => $row['buyer_email'],
                'created_at' => $row['created_at'],
                'payload' => array(),
            );
        }

        $db->setQuery("SELECT LOWER(o.buyer_email) AS buyer_key, o.buyer_email, MAX(o.paid_at_utc) AS created_at, COUNT(*) AS total_orders FROM #__leadmarket_orders o WHERE {$paidWhere} GROUP BY LOWER(o.buyer_email), o.buyer_email HAVING total_orders >= 2 AND created_at >= DATE_SUB(UTC_TIMESTAMP(), INTERVAL 90 DAY) ORDER BY created_at DESC LIMIT " . $limit);
        foreach ((array) $db->loadAssocList() as $row) {
            $events[] = array(
                'event_type' => 'buyer_repeat_purchase',
                'entity_type' => 'buyer',
                'entity_key' => $row['buyer_key'],
                'entity_label' => $row['buyer_email'],
                'created_at' => $row['created_at'],
                'payload' => array('total_orders' => (int) $row['total_orders']),
            );
        }

        $db->setQuery("SELECT id, type, state, uploaded_at_utc FROM #__leadmarket_leads ORDER BY uploaded_at_utc DESC LIMIT " . $limit);
        foreach ((array) $db->loadAssocList() as $row) {
            $events[] = array(
                'event_type' => 'new_lead_added',
                'entity_type' => 'lead',
                'entity_key' => (string) $row['id'],
                'entity_label' => (string) $row['id'],
                'created_at' => $row['uploaded_at_utc'],
                'payload' => array('type' => $row['type'], 'state' => $row['state']),
            );
        }

        $stale = self::getStaleLeads(max(1, (int) self::params()->get('aged_auto_max_hours', 24)), '', '', $limit);
        foreach ($stale as $row) {
            $events[] = array(
                'event_type' => 'lead_became_stale',
                'entity_type' => 'lead',
                'entity_key' => (string) $row['lead_id'],
                'entity_label' => (string) $row['lead_id'],
                'created_at' => $row['created_at'],
                'payload' => array('category' => $row['category'], 'state' => $row['state'], 'age_hours' => (int) $row['age_hours']),
            );
        }

        usort($events, array('LeadMarketBridgeHelper', 'sortEventsByCreatedAtDesc'));
        if (count($events) > $limit) {
            $events = array_slice($events, 0, $limit);
        }

        return $events;
    }

    public static function getCapabilities()
    {
        return array(
            'component' => 'com_leadmarket',
            'component_version' => self::getComponentVersion(),
            'storage_mode' => 'file_backed_no_migration',
            'auth' => array(
                'scheme' => 'hmac_sha256',
                'headers' => array('X-Bridge-Key', 'X-Bridge-Timestamp', 'X-Bridge-Signature'),
                'ip_allowlist' => self::isIpAllowlistEnforced(),
                'rate_limit' => true,
            ),
            'read_endpoints' => array(
                'bridge.capabilities',
                'bridge.systemStatus',
                'bridge.projectSnapshot',
                'bridge.connectionSummary',
                'bridge.recentFailures',
                'bridge.siteContentSummary',
                'bridge.articlesList',
                'bridge.articleGet',
                'bridge.modulesList',
                'bridge.moduleGet',
                'bridge.componentConfigGet',
                'bridge.kpiOverview',
                'bridge.buyersFreeTestPending',
                'bridge.buyersInactive',
                'bridge.buyersRepeat',
                'bridge.buyersSearch',
                'bridge.buyerProfile',
                'bridge.buyerTimeline',
                'bridge.buyerTags',
                'bridge.leadsInventory',
                'bridge.leadsStale',
                'bridge.eventsRecent',
                'bridge.auditRecent',
                'bridge.tasksList',
                'bridge.taskGet',
                'bridge.proposalsPending',
                'bridge.proposalsAll',
                'bridge.proposalGet',
            ),
            'write_endpoints' => array(
                'bridge.createFollowupDraft',
                'bridge.createCampaignDraft',
                'bridge.createCheckoutExperimentDraft',
                'bridge.createDiscountCodeDraft',
                'bridge.createArticlePatchDraft',
                'bridge.createModulePatchDraft',
                'bridge.createComponentConfigPatchDraft',
                'bridge.applyArticlePatch',
                'bridge.applyModulePatch',
                'bridge.applyComponentConfigPatch',
                'bridge.createInternalNote',
                'bridge.addBuyerTag',
                'bridge.removeBuyerTag',
                'bridge.createTask',
                'bridge.taskUpdate',
                'bridge.markOutreachAttempted',
                'bridge.proposalCreate',
                'bridge.proposalApprove',
                'bridge.proposalReject',
                'bridge.proposalExpire',
            ),
            'proposal_types' => self::allowedProposalTypes(),
            'safe_execution_only' => true,
        );
    }

    public static function getSystemStatus()
    {
        $params = self::params();
        $storage = self::storagePath('');
        $auditFile = self::storagePath('audit.log');
        $taskItems = self::loadTaskItems();
        $proposalItems = self::loadProposalItems();
        $tagItems = self::loadTagMap();

        $pending = 0;
        $openTasks = 0;
        foreach ($proposalItems as $proposal) {
            if ((string) self::arrGet($proposal, 'status', '') === 'pending' && !self::isProposalExpired($proposal)) {
                $pending++;
            }
        }
        foreach ($taskItems as $task) {
            if (in_array((string) self::arrGet($task, 'status', ''), array('open', 'draft', 'in_progress'), true)) {
                $openTasks++;
            }
        }

        return array(
            'component_version' => self::getComponentVersion(),
            'bridge_enabled' => ((int) $params->get('bridge_enabled', 0) === 1),
            'storage_path' => $storage,
            'storage_exists' => is_dir($storage),
            'storage_writable' => is_writable($storage),
            'audit_file_exists' => JFile::exists($auditFile),
            'ip_allowlist_enforced' => self::isIpAllowlistEnforced($params),
            'allowed_ips_configured' => count(self::parseAllowedIpList((string) $params->get('bridge_allowed_ips', ''))) > 0,
            'rate_limits' => array(
                'read_rpm' => (int) $params->get('bridge_read_rpm', 60),
                'write_rpm' => (int) $params->get('bridge_write_rpm', 20),
                'approve_rpm' => (int) $params->get('bridge_approve_rpm', 10),
            ),
            'live_site_writes_enabled' => ((int) $params->get('bridge_allow_live_site_writes', 0) === 1),
            'live_site_write_scope' => array(
                'allowed_article_ids' => self::liveAllowedIdsFromParam('bridge_live_allowed_article_ids'),
                'allowed_module_ids' => self::liveAllowedIdsFromParam('bridge_live_allowed_module_ids'),
                'allowed_component_param_keys' => self::componentWritableKeys(),
            ),
            'counts' => array(
                'tasks_total' => count($taskItems),
                'tasks_open_like' => $openTasks,
                'proposals_total' => count($proposalItems),
                'proposals_pending' => $pending,
                'buyers_with_tags' => count($tagItems),
            ),
            'capabilities' => self::getCapabilities(),
        );
    }

    public static function getProjectSnapshot()
    {
        $kpi = self::getKpiOverview();
        $pendingProposals = self::getPendingProposals(10);
        $openTasks = self::getTasks(array('limit' => 10, 'status' => 'open_like'));
        $recentAudit = self::getAuditRecent(25, '');

        $auditByType = array();
        foreach ($recentAudit as $row) {
            $type = (string) self::arrGet($row, 'event_type', 'unknown');
            if (!isset($auditByType[$type])) {
                $auditByType[$type] = 0;
            }
            $auditByType[$type]++;
        }

        return array(
            'kpi' => $kpi,
            'site_content_summary' => self::getSiteContentSummary(),
            'pending_proposals_count' => count($pendingProposals),
            'open_tasks_count' => count($openTasks),
            'pending_proposals' => $pendingProposals,
            'open_tasks' => $openTasks,
            'recent_audit_by_type' => $auditByType,
            'system_status' => array(
                'component_version' => self::getComponentVersion(),
                'storage_path' => self::storagePath(''),
            ),
        );
    }


    public static function getSiteContentSummary()
    {
        $db = JFactory::getDbo();
        $summary = array(
            'articles' => array('total' => 0, 'published' => 0, 'unpublished' => 0),
            'modules' => array('total' => 0, 'published' => 0, 'custom_html_total' => 0),
            'component' => array('name' => 'com_leadmarket', 'version' => self::getComponentVersion(), 'writable_param_keys' => self::componentWritableKeys()),
        );

        $db->setQuery("SELECT COUNT(*) FROM #__content");
        $summary['articles']['total'] = (int) $db->loadResult();
        $db->setQuery("SELECT COUNT(*) FROM #__content WHERE state = 1");
        $summary['articles']['published'] = (int) $db->loadResult();
        $db->setQuery("SELECT COUNT(*) FROM #__content WHERE state <> 1");
        $summary['articles']['unpublished'] = (int) $db->loadResult();

        $db->setQuery("SELECT COUNT(*) FROM #__modules WHERE client_id = 0");
        $summary['modules']['total'] = (int) $db->loadResult();
        $db->setQuery("SELECT COUNT(*) FROM #__modules WHERE client_id = 0 AND published = 1");
        $summary['modules']['published'] = (int) $db->loadResult();
        $db->setQuery("SELECT COUNT(*) FROM #__modules WHERE module = 'mod_custom'");
        $summary['modules']['custom_html_total'] = (int) $db->loadResult();

        return $summary;
    }

    public static function getArticles($q, $status, $limit)
    {
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $query = $db->getQuery(true)
            ->select(array(
                'c.id AS article_id',
                'c.title',
                'c.alias',
                'c.state',
                'c.catid',
                'c.access',
                'c.language',
                'c.created',
                'c.modified',
                'c.publish_up',
                'c.publish_down',
                'c.metadesc',
            ))
            ->from('#__content c')
            ->order('COALESCE(c.modified, c.created) DESC');

        if ($q !== '') {
            $like = $db->q('%' . $db->escape($q, true) . '%', false);
            $query->where('(c.title LIKE ' . $like . ' OR c.alias LIKE ' . $like . ' OR c.metadesc LIKE ' . $like . ')');
        }
        if ($status !== '' && $status !== 'all') {
            $stateMap = array('published' => 1, 'unpublished' => 0, 'archived' => 2, 'trashed' => -2);
            if (isset($stateMap[$status])) {
                $query->where('c.state = ' . (int) $stateMap[$status]);
            }
        }

        $db->setQuery($query, 0, $limit);
        return (array) $db->loadAssocList();
    }

    public static function getArticle($articleId)
    {
        $articleId = (int) $articleId;
        if ($articleId <= 0) {
            throw new RuntimeException('article_id_required', 422);
        }

        $db = JFactory::getDbo();
        $query = $db->getQuery(true)
            ->select('*')
            ->from('#__content')
            ->where('id = ' . $articleId);
        $db->setQuery($query);
        $row = (array) $db->loadAssoc();
        if (!$row) {
            throw new RuntimeException('article_not_found', 404);
        }
        foreach (array('images', 'attribs', 'metadata') as $field) {
            $decoded = json_decode((string) self::arrGet($row, $field, ''), true);
            $row[$field] = is_array($decoded) ? $decoded : self::arrGet($row, $field, '');
        }
        $row['article_id'] = (int) $row['id'];
        return $row;
    }

    public static function getModules($q, $clientId, $published, $limit)
    {
        $db = JFactory::getDbo();
        $limit = self::normalizeLimit($limit);
        $query = $db->getQuery(true)
            ->select(array(
                'm.id AS module_id',
                'm.title',
                'm.module',
                'm.position',
                'm.published',
                'm.client_id',
                'm.ordering',
                'm.note',
                'm.language',
            ))
            ->from('#__modules m')
            ->order('m.client_id ASC, m.position ASC, m.ordering ASC');

        if ($q !== '') {
            $like = $db->q('%' . $db->escape($q, true) . '%', false);
            $query->where('(m.title LIKE ' . $like . ' OR m.note LIKE ' . $like . ' OR m.module LIKE ' . $like . ' OR m.position LIKE ' . $like . ')');
        }
        if ($clientId !== '' && $clientId !== 'all') {
            $query->where('m.client_id = ' . (int) $clientId);
        }
        if ($published !== '' && $published !== 'all') {
            $query->where('m.published = ' . (int) $published);
        }

        $db->setQuery($query, 0, $limit);
        return (array) $db->loadAssocList();
    }

    public static function getModule($moduleId)
    {
        $moduleId = (int) $moduleId;
        if ($moduleId <= 0) {
            throw new RuntimeException('module_id_required', 422);
        }

        $db = JFactory::getDbo();
        $query = $db->getQuery(true)
            ->select('*')
            ->from('#__modules')
            ->where('id = ' . $moduleId);
        $db->setQuery($query);
        $row = (array) $db->loadAssoc();
        if (!$row) {
            throw new RuntimeException('module_not_found', 404);
        }
        $decoded = json_decode((string) self::arrGet($row, 'params', ''), true);
        $row['params'] = is_array($decoded) ? $decoded : self::arrGet($row, 'params', '');
        $row['module_id'] = (int) $row['id'];
        return $row;
    }

    public static function getComponentConfig()
    {
        $params = self::params()->toArray();
        $sanitized = self::sanitizeConfigForOutput($params);
        return array(
            'component' => 'com_leadmarket',
            'version' => self::getComponentVersion(),
            'params' => $sanitized,
            'writable_param_keys' => self::componentWritableKeys(),
            'live_site_writes_enabled' => ((int) self::params()->get('bridge_allow_live_site_writes', 0) === 1),
        );
    }

    public static function searchBuyers($segment, $q, $state, $type, $limit)
    {
        $segment = trim((string) $segment);
        if ($segment === '') {
            $segment = 'all';
        }

        $sets = array();
        if ($segment === 'all' || $segment === 'free_test_pending') {
            foreach (self::getBuyersFreeTestPending($limit) as $row) {
                $row['segment'] = 'free_test_pending';
                $sets[] = $row;
            }
        }
        if ($segment === 'all' || $segment === 'inactive') {
            foreach (self::getBuyersInactive('30d', $limit) as $row) {
                $row['segment'] = 'inactive';
                $sets[] = $row;
            }
        }
        if ($segment === 'all' || $segment === 'repeat') {
            foreach (self::getBuyersRepeat($limit) as $row) {
                $row['segment'] = 'repeat';
                $sets[] = $row;
            }
        }

        $q = strtolower(trim((string) $q));
        $indexed = array();
        foreach ($sets as $row) {
            $buyerKey = (string) self::arrGet($row, 'buyer_key', strtolower((string) self::arrGet($row, 'buyer_email', self::arrGet($row, 'email', ''))));
            if ($buyerKey === '') {
                continue;
            }
            if ($q !== '') {
                $haystack = strtolower(implode(' ', array(
                    (string) self::arrGet($row, 'buyer_email', self::arrGet($row, 'email', '')),
                    (string) self::arrGet($row, 'name', ''),
                    (string) self::arrGet($row, 'preferred_state', self::arrGet($row, 'state_interest', '')),
                    (string) self::arrGet($row, 'preferred_lead_type', ''),
                    (string) self::arrGet($row, 'segment', ''),
                )));
                if (strpos($haystack, $q) === false) {
                    continue;
                }
            }
            if ($state !== '') {
                $rowState = strtoupper((string) self::arrGet($row, 'preferred_state', self::arrGet($row, 'state_interest', '')));
                if ($rowState !== $state) {
                    continue;
                }
            }
            if ($type !== '') {
                $rowType = strtolower((string) self::arrGet($row, 'preferred_lead_type', ''));
                if ($rowType !== '' && $rowType !== $type) {
                    continue;
                }
                if ($rowType === '' && $segment === 'free_test_pending') {
                    continue;
                }
            }
            if (!isset($indexed[$buyerKey])) {
                $indexed[$buyerKey] = $row;
                continue;
            }
            $existingCreated = (string) self::arrGet($indexed[$buyerKey], 'last_activity_at', self::arrGet($indexed[$buyerKey], 'last_purchase_at', self::arrGet($indexed[$buyerKey], 'created_at', '')));
            $currentCreated = (string) self::arrGet($row, 'last_activity_at', self::arrGet($row, 'last_purchase_at', self::arrGet($row, 'created_at', '')));
            if (strcmp($currentCreated, $existingCreated) > 0) {
                $indexed[$buyerKey] = array_merge($indexed[$buyerKey], $row);
            }
        }

        $items = array_values($indexed);
        usort($items, array('LeadMarketBridgeHelper', 'sortBuyerRowsByActivityDesc'));
        if (count($items) > self::normalizeLimit($limit)) {
            $items = array_slice($items, 0, self::normalizeLimit($limit));
        }
        return $items;
    }

    public static function getBuyerProfile($buyerEmail)
    {
        $buyerEmail = strtolower(trim((string) $buyerEmail));
        if ($buyerEmail === '' || !JMailHelper::isEmailAddress($buyerEmail)) {
            throw new RuntimeException('buyer_email_required', 422);
        }

        $db = JFactory::getDbo();
        $paidWhere = self::paidWhere('o');
        $quoted = $db->q($buyerEmail);

        $profile = array(
            'buyer_email' => $buyerEmail,
            'buyer_key' => self::buyerKey($buyerEmail),
            'free_test' => array(),
            'orders' => array(
                'total_orders' => 0,
                'total_spent' => 0.0,
                'first_purchase_at' => null,
                'last_purchase_at' => null,
                'preferred_state' => '',
                'preferred_lead_type' => '',
            ),
            'tags' => array(),
            'recent_tasks' => array(),
        );

        $db->setQuery("SELECT COUNT(*) AS signup_count, MIN(created_at_utc) AS first_signup_at, MAX(COALESCE(last_view_at_utc, first_view_at_utc, created_at_utc)) AS last_activity_at, MAX(CASE WHEN COALESCE(view_count,0) > 0 THEN 1 ELSE 0 END) AS opened_test_lead, MAX(states_json) AS states_json, MAX(COALESCE(marketplace_click_count,0)) AS marketplace_click_count FROM #__leadmarket_trial_access WHERE LOWER(email) = {$quoted}");
        $trial = (array) $db->loadAssoc();
        $profile['free_test'] = array(
            'signup_count' => (int) self::arrGet($trial, 'signup_count', 0),
            'first_signup_at' => self::arrGet($trial, 'first_signup_at', null),
            'last_activity_at' => self::arrGet($trial, 'last_activity_at', null),
            'opened_test_lead' => (int) self::arrGet($trial, 'opened_test_lead', 0),
            'state_interest' => self::extractPrimaryState((string) self::arrGet($trial, 'states_json', '')),
            'marketplace_click_count' => (int) self::arrGet($trial, 'marketplace_click_count', 0),
        );

        $db->setQuery("SELECT COUNT(*) AS total_orders, ROUND(SUM(COALESCE(o.amount_usd,0)),2) AS total_spent, MIN(o.paid_at_utc) AS first_purchase_at, MAX(o.paid_at_utc) AS last_purchase_at, SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(l.state,'') ORDER BY o.paid_at_utc DESC SEPARATOR ','), ',', 1) AS preferred_state, SUBSTRING_INDEX(GROUP_CONCAT(COALESCE(l.type,'') ORDER BY o.paid_at_utc DESC SEPARATOR ','), ',', 1) AS preferred_lead_type FROM #__leadmarket_orders o LEFT JOIN #__leadmarket_leads l ON l.id = o.lead_id WHERE LOWER(o.buyer_email) = {$quoted} AND {$paidWhere}");
        $orders = (array) $db->loadAssoc();
        $profile['orders'] = array(
            'total_orders' => (int) self::arrGet($orders, 'total_orders', 0),
            'total_spent' => (float) self::arrGet($orders, 'total_spent', 0),
            'first_purchase_at' => self::arrGet($orders, 'first_purchase_at', null),
            'last_purchase_at' => self::arrGet($orders, 'last_purchase_at', null),
            'preferred_state' => (string) self::arrGet($orders, 'preferred_state', ''),
            'preferred_lead_type' => (string) self::arrGet($orders, 'preferred_lead_type', ''),
        );

        $profile['tags'] = self::getBuyerTags($buyerEmail, 1);
        $profile['recent_tasks'] = self::getTasks(array('buyer_email' => $buyerEmail, 'limit' => 10));

        return $profile;
    }

    public static function getBuyerTimeline($buyerEmail, $limit)
    {
        $buyerEmail = strtolower(trim((string) $buyerEmail));
        if ($buyerEmail === '' || !JMailHelper::isEmailAddress($buyerEmail)) {
            throw new RuntimeException('buyer_email_required', 422);
        }

        $db = JFactory::getDbo();
        $paidWhere = self::paidWhere('o');
        $quoted = $db->q($buyerEmail);
        $items = array();
        $limit = self::normalizeLimit($limit);

        $db->setQuery("SELECT created_at_utc, source_page, lead_type, states_json FROM #__leadmarket_trial_access WHERE LOWER(email) = {$quoted} ORDER BY created_at_utc DESC LIMIT {$limit}");
        foreach ((array) $db->loadAssocList() as $row) {
            $items[] = array(
                'created_at' => $row['created_at_utc'],
                'event_type' => 'free_test_signup_created',
                'payload' => array(
                    'source_page' => self::arrGet($row, 'source_page', ''),
                    'lead_type' => self::arrGet($row, 'lead_type', ''),
                    'state_interest' => self::extractPrimaryState((string) self::arrGet($row, 'states_json', '')),
                ),
            );
        }

        $db->setQuery("SELECT viewed_at_utc, lead_id, lead_state, lead_type FROM #__leadmarket_trial_lead_views WHERE LOWER(email) = {$quoted} ORDER BY viewed_at_utc DESC LIMIT {$limit}");
        foreach ((array) $db->loadAssocList() as $row) {
            $items[] = array(
                'created_at' => $row['viewed_at_utc'],
                'event_type' => 'buyer_opened_test_lead',
                'payload' => array(
                    'lead_id' => (int) self::arrGet($row, 'lead_id', 0),
                    'lead_state' => self::arrGet($row, 'lead_state', ''),
                    'lead_type' => self::arrGet($row, 'lead_type', ''),
                ),
            );
        }

        $db->setQuery("SELECT o.paid_at_utc, o.id AS order_id, o.lead_id, o.amount_usd, l.state, l.type FROM #__leadmarket_orders o LEFT JOIN #__leadmarket_leads l ON l.id = o.lead_id WHERE LOWER(o.buyer_email) = {$quoted} AND {$paidWhere} ORDER BY o.paid_at_utc DESC LIMIT {$limit}");
        $orderRows = (array) $db->loadAssocList();
        $countOrders = count($orderRows);
        foreach ($orderRows as $index => $row) {
            $items[] = array(
                'created_at' => $row['paid_at_utc'],
                'event_type' => ($countOrders > 0 && $index === ($countOrders - 1)) ? 'buyer_first_purchase' : 'buyer_paid_order',
                'payload' => array(
                    'order_id' => (int) self::arrGet($row, 'order_id', 0),
                    'lead_id' => (int) self::arrGet($row, 'lead_id', 0),
                    'amount_usd' => (float) self::arrGet($row, 'amount_usd', 0),
                    'state' => self::arrGet($row, 'state', ''),
                    'type' => self::arrGet($row, 'type', ''),
                ),
            );
        }

        foreach (self::getTasks(array('buyer_email' => $buyerEmail, 'limit' => $limit)) as $task) {
            $items[] = array(
                'created_at' => (string) self::arrGet($task, 'updated_at', self::arrGet($task, 'created_at', '')),
                'event_type' => 'task_' . (string) self::arrGet($task, 'type', 'item'),
                'payload' => $task,
            );
        }

        foreach (self::getAllProposals('all', $limit) as $proposal) {
            if (self::buyerKey((string) self::arrGet($proposal, 'target_key', '')) !== self::buyerKey($buyerEmail)) {
                continue;
            }
            $items[] = array(
                'created_at' => (string) self::arrGet($proposal, 'created_at', ''),
                'event_type' => 'proposal_' . (string) self::arrGet($proposal, 'status', 'unknown'),
                'payload' => $proposal,
            );
        }

        usort($items, array('LeadMarketBridgeHelper', 'sortEventsByCreatedAtDesc'));
        if (count($items) > $limit) {
            $items = array_slice($items, 0, $limit);
        }
        return $items;
    }

    public static function getBuyerTags($buyerEmail, $limit)
    {
        $map = self::loadTagMap();
        if ($buyerEmail !== '') {
            $key = self::buyerKey($buyerEmail);
            return isset($map[$key]) ? array($map[$key]) : array();
        }
        $items = array_values($map);
        usort($items, array('LeadMarketBridgeHelper', 'sortByUpdatedAtDesc'));
        if (count($items) > self::normalizeLimit($limit)) {
            $items = array_slice($items, 0, self::normalizeLimit($limit));
        }
        return $items;
    }

    public static function getTasks($filters)
    {
        $limit = self::normalizeLimit((int) self::arrGet($filters, 'limit', 100));
        $status = trim((string) self::arrGet($filters, 'status', ''));
        $type = trim((string) self::arrGet($filters, 'type', ''));
        $owner = strtolower(trim((string) self::arrGet($filters, 'owner', '')));
        $buyerEmail = strtolower(trim((string) self::arrGet($filters, 'buyer_email', '')));

        $items = array();
        foreach (self::loadTaskItems() as $task) {
            if ($status !== '') {
                $taskStatus = (string) self::arrGet($task, 'status', '');
                if ($status === 'open_like') {
                    if (!in_array($taskStatus, array('open', 'draft', 'in_progress'), true)) {
                        continue;
                    }
                } elseif ($taskStatus !== $status) {
                    continue;
                }
            }
            if ($type !== '' && (string) self::arrGet($task, 'type', '') !== $type) {
                continue;
            }
            if ($owner !== '' && strtolower((string) self::arrGet($task, 'owner', '')) !== $owner) {
                continue;
            }
            if ($buyerEmail !== '' && self::buyerKey((string) self::arrGet($task, 'buyer_email', '')) !== self::buyerKey($buyerEmail)) {
                continue;
            }
            $items[] = $task;
        }

        usort($items, array('LeadMarketBridgeHelper', 'sortByUpdatedAtDesc'));
        if (count($items) > $limit) {
            $items = array_slice($items, 0, $limit);
        }
        return $items;
    }

    public static function getTask($taskId)
    {
        $taskId = trim((string) $taskId);
        if ($taskId === '') {
            throw new RuntimeException('task_id_required', 422);
        }
        $task = self::loadJson(self::storagePath('tasks/' . basename($taskId) . '.json'), array());
        if (!is_array($task) || empty($task['id'])) {
            throw new RuntimeException('task_not_found', 404);
        }
        return $task;
    }


    public static function getAuditRecent($limit, $eventType)
    {
        $limit = self::normalizeLimit($limit);
        $eventType = trim((string) $eventType);
        $items = array();
        $file = self::storagePath('audit.log');
        if (!JFile::exists($file)) {
            self::$auditGroupsCache = array();
            return self::$auditGroupsCache;
        }
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) {
            return array();
        }
        foreach (array_reverse($lines) as $line) {
            $row = json_decode($line, true);
            if (!is_array($row)) {
                continue;
            }
            if ($eventType !== '' && (string) self::arrGet($row, 'event_type', '') !== $eventType) {
                continue;
            }
            $items[] = $row;
            if (count($items) >= $limit) {
                break;
            }
        }
        return $items;
    }

    public static function getAuditConnectionPage($page, $perPage, $filters = array())
    {
        $page = max(1, (int) $page);
        $perPage = max(1, min(100, (int) $perPage));
        $groups = self::buildAuditConnectionGroups();
        $groups = self::filterAuditConnectionGroups($groups, is_array($filters) ? $filters : array());
        $total = count($groups);
        $totalPages = max(1, (int) ceil($total / $perPage));
        if ($page > $totalPages) {
            $page = $totalPages;
        }
        $offset = ($page - 1) * $perPage;
        $items = array_slice($groups, $offset, $perPage);
        return array(
            'items' => $items,
            'page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_prev' => $page > 1,
            'has_next' => $page < $totalPages,
            'filters' => array(
                'status' => trim((string) self::arrGet($filters, 'status', 'all')),
                'q' => trim((string) self::arrGet($filters, 'q', '')),
            ),
        );
    }


    public static function getConnectionSummary($days)
    {
        $days = max(1, min(30, (int) $days));
        $groups = self::buildAuditConnectionGroups();
        $windowStart = time() - ($days * 86400);
        $last24Start = time() - 86400;

        $summary = array(
            'window_days' => $days,
            'all_time_total' => count($groups),
            'window' => array('total' => 0, 'success' => 0, 'warning' => 0, 'error' => 0, 'info' => 0),
            'last_24h' => array('total' => 0, 'success' => 0, 'warning' => 0, 'error' => 0, 'info' => 0),
            'unique_actors' => 0,
            'unique_ips' => 0,
            'last_success_at' => '',
            'last_error_at' => '',
            'top_tasks' => array(),
            'top_errors' => array(),
        );

        $actors = array();
        $ips = array();
        $taskCounts = array();
        $errorCounts = array();

        foreach ($groups as $group) {
            $lastTs = self::toTimestamp(self::arrGet($group, 'last_at', ''));
            $status = (string) self::arrGet($group, 'status', 'info');
            if (!isset($summary['window'][$status])) {
                $status = 'info';
            }
            if ($lastTs >= $windowStart) {
                $summary['window']['total']++;
                $summary['window'][$status]++;
                $actor = trim((string) self::arrGet($group, 'actor', ''));
                $ip = trim((string) self::arrGet($group, 'ip', ''));
                if ($actor !== '') {
                    $actors[$actor] = true;
                }
                if ($ip !== '') {
                    $ips[$ip] = true;
                }
                $task = trim((string) self::arrGet($group, 'task', 'unknown'));
                if ($task === '') {
                    $task = 'unknown';
                }
                $taskCounts[$task] = isset($taskCounts[$task]) ? ((int) $taskCounts[$task] + 1) : 1;
                if ($status === 'error' || $status === 'warning') {
                    $reason = trim((string) self::arrGet($group, 'result_summary', ''));
                    if ($reason === '') {
                        $reason = 'Unknown issue';
                    }
                    $errorCounts[$reason] = isset($errorCounts[$reason]) ? ((int) $errorCounts[$reason] + 1) : 1;
                }
            }
            if ($lastTs >= $last24Start) {
                $summary['last_24h']['total']++;
                $summary['last_24h'][$status]++;
            }
            if ($status === 'success' && $summary['last_success_at'] === '') {
                $summary['last_success_at'] = (string) self::arrGet($group, 'last_at', '');
            }
            if (($status === 'error' || $status === 'warning') && $summary['last_error_at'] === '') {
                $summary['last_error_at'] = (string) self::arrGet($group, 'last_at', '');
            }
        }

        $summary['unique_actors'] = count($actors);
        $summary['unique_ips'] = count($ips);
        arsort($taskCounts);
        foreach (array_slice($taskCounts, 0, 5, true) as $task => $count) {
            $summary['top_tasks'][] = array('task' => $task, 'count' => (int) $count);
        }
        arsort($errorCounts);
        foreach (array_slice($errorCounts, 0, 5, true) as $reason => $count) {
            $summary['top_errors'][] = array('reason' => $reason, 'count' => (int) $count);
        }

        return $summary;
    }

    public static function getRecentFailures($limit)
    {
        $limit = self::normalizeLimit($limit);
        $groups = self::buildAuditConnectionGroups();
        $items = array();
        foreach ($groups as $group) {
            $status = (string) self::arrGet($group, 'status', 'info');
            if ($status !== 'error' && $status !== 'warning') {
                continue;
            }
            $items[] = $group;
            if (count($items) >= $limit) {
                break;
            }
        }
        return $items;
    }

    public static function getBridgeReadiness()
    {
        $status = self::getSystemStatus();
        $checks = array(
            array(
                'key' => 'bridge_enabled',
                'label' => 'Bridge enabled',
                'ok' => !empty($status['bridge_enabled']),
                'detail' => !empty($status['bridge_enabled']) ? 'Ready to accept authenticated requests.' : 'Bridge is disabled.',
            ),
            array(
                'key' => 'allowed_ips',
                'label' => 'IP allowlist',
                'ok' => empty($status['ip_allowlist_enforced']) ? true : !empty($status['allowed_ips_configured']),
                'detail' => empty($status['ip_allowlist_enforced']) ? 'IP verification is disabled. Requests from any source IP are accepted if HMAC auth passes.' : (!empty($status['allowed_ips_configured']) ? 'Only allowlisted orchestrator IPs may connect.' : 'IP allowlist enforcement is enabled but no IPs/CIDRs are configured.'),
            ),
            array(
                'key' => 'storage_exists',
                'label' => 'Storage folder exists',
                'ok' => !empty($status['storage_exists']),
                'detail' => !empty($status['storage_exists']) ? (string) self::arrGet($status, 'storage_path', '') : 'Bridge storage directory is missing.',
            ),
            array(
                'key' => 'storage_writable',
                'label' => 'Storage is writable',
                'ok' => !empty($status['storage_writable']),
                'detail' => !empty($status['storage_writable']) ? 'Audit, proposals, and tasks can be persisted.' : 'Storage path is not writable by PHP.',
            ),
            array(
                'key' => 'audit_file_exists',
                'label' => 'Audit log exists',
                'ok' => !empty($status['audit_file_exists']),
                'detail' => !empty($status['audit_file_exists']) ? 'Bridge has already written at least one audit line.' : 'Audit file will appear after the first request.',
            ),
            array(
                'key' => 'live_writes',
                'label' => 'Live site writes',
                'ok' => empty($status['live_site_writes_enabled']) ? true : (count((array) self::arrGet($status['live_site_write_scope'], 'allowed_article_ids', array())) + count((array) self::arrGet($status['live_site_write_scope'], 'allowed_module_ids', array())) + count((array) self::arrGet($status['live_site_write_scope'], 'allowed_component_param_keys', array())) > 0),
                'detail' => empty($status['live_site_writes_enabled']) ? 'Disabled, which is recommended until bridge smoke tests pass.' : 'Enabled with allowlists. Keep scope narrow.',
            ),
        );

        $overall = 'ready';
        foreach ($checks as $check) {
            if (!$check['ok']) {
                $overall = ($check['key'] === 'bridge_enabled' || $check['key'] === 'storage_writable') ? 'error' : 'warning';
                break;
            }
        }

        return array(
            'overall_status' => $overall,
            'checks' => $checks,
            'system_status' => $status,
        );
    }

    public static function getAllProposals($status, $limit)
    {
        $status = trim((string) $status);
        if ($status === '') {
            $status = 'all';
        }
        $items = array();
        foreach (self::loadProposalItems() as $proposal) {
            if (self::isProposalExpired($proposal) && (string) self::arrGet($proposal, 'status', '') === 'pending') {
                $proposal['status'] = 'expired';
            }
            if ($status !== 'all' && (string) self::arrGet($proposal, 'status', '') !== $status) {
                continue;
            }
            $items[] = $proposal;
        }
        usort($items, array('LeadMarketBridgeHelper', 'sortProposalsByCreatedAtDesc'));
        if (count($items) > self::normalizeLimit($limit)) {
            $items = array_slice($items, 0, self::normalizeLimit($limit));
        }
        return $items;
    }

    public static function getProposal($proposalId)
    {
        $proposalId = trim((string) $proposalId);
        if ($proposalId === '') {
            throw new RuntimeException('proposal_id_required', 422);
        }
        $item = self::loadJson(self::storagePath('proposals/' . basename($proposalId) . '.json'), array());
        if (!is_array($item) || empty($item['id'])) {
            throw new RuntimeException('proposal_not_found', 404);
        }
        if (self::isProposalExpired($item) && (string) self::arrGet($item, 'status', '') === 'pending') {
            $item['status'] = 'expired';
        }
        return $item;
    }

    public static function createFollowupDraft($payload, $ctx)
    {
        $buyerEmail = self::mustEmail($payload, 'buyer_email');
        $channel = self::mustIn($payload, 'channel', array('email', 'sms', 'call'));
        $subject = self::trimField($payload, 'draft_subject');
        $body = self::trimField($payload, 'draft_body');
        $reason = self::trimField($payload, 'reason');
        $source = self::trimField($payload, 'source_agent', 'orchestrator');

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'followup_draft',
            'status' => 'draft',
            'buyer_email' => $buyerEmail,
            'buyer_key' => self::buyerKey($buyerEmail),
            'channel' => $channel,
            'draft_subject' => $subject,
            'draft_body' => $body,
            'reason' => $reason,
            'source_agent' => $source,
            'created_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('followup_draft_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }

    public static function createCampaignDraft($payload, $ctx)
    {
        $campaignType = self::trimField($payload, 'campaign_type');
        if ($campaignType === '') {
            throw new RuntimeException('campaign_type_required', 422);
        }

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'campaign_draft',
            'status' => 'draft',
            'campaign_type' => $campaignType,
            'target_segment' => self::trimField($payload, 'target_segment'),
            'subject' => self::trimField($payload, 'subject'),
            'body' => self::trimField($payload, 'body'),
            'notes' => self::trimField($payload, 'notes'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('campaign_draft_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }

    public static function createInternalNote($payload, $ctx)
    {
        $note = self::trimField($payload, 'note');
        if ($note === '') {
            throw new RuntimeException('note_required', 422);
        }

        $buyerEmail = self::optionalEmail($payload, 'buyer_email');
        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'internal_note',
            'status' => 'open',
            'buyer_email' => $buyerEmail,
            'buyer_key' => $buyerEmail !== '' ? self::buyerKey($buyerEmail) : '',
            'note' => $note,
            'title' => self::trimField($payload, 'title', 'Internal note'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('internal_note_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }

    public static function addBuyerTag($payload, $ctx)
    {
        $buyerEmail = self::mustEmail($payload, 'buyer_email');
        $tag = self::trimField($payload, 'tag');
        if ($tag === '') {
            throw new RuntimeException('tag_required', 422);
        }

        $file = self::storagePath('tags/buyer_tags.json');
        $all = self::loadJson($file, array());
        if (!is_array($all)) {
            $all = array();
        }

        $buyerKey = self::buyerKey($buyerEmail);
        if (!isset($all[$buyerKey]) || !is_array($all[$buyerKey])) {
            $all[$buyerKey] = array(
                'buyer_email' => $buyerEmail,
                'buyer_key' => $buyerKey,
                'tags' => array(),
                'updated_at' => gmdate('Y-m-d H:i:s'),
                'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            );
        }

        if (!in_array($tag, (array) $all[$buyerKey]['tags'], true)) {
            $all[$buyerKey]['tags'][] = $tag;
        }
        sort($all[$buyerKey]['tags']);
        $all[$buyerKey]['updated_at'] = gmdate('Y-m-d H:i:s');

        self::saveJson($file, $all);
        self::audit('buyer_tag_added', $ctx, self::auditPayload($payload), array('ok' => true, 'buyer_key' => $buyerKey, 'tag' => $tag));

        return array('buyer' => $all[$buyerKey]);
    }

    public static function createTask($payload, $ctx)
    {
        $title = self::trimField($payload, 'title');
        if ($title === '') {
            throw new RuntimeException('title_required', 422);
        }

        $buyerEmail = self::optionalEmail($payload, 'buyer_email');
        $item = array(
            'id' => self::buildItemId('task'),
            'type' => self::trimField($payload, 'task_type', 'internal_task'),
            'status' => 'open',
            'buyer_email' => $buyerEmail,
            'buyer_key' => $buyerEmail !== '' ? self::buyerKey($buyerEmail) : '',
            'title' => $title,
            'notes' => self::trimField($payload, 'notes'),
            'owner' => self::trimField($payload, 'owner'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('task_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }

    public static function markOutreachAttempted($payload, $ctx)
    {
        $buyerEmail = self::mustEmail($payload, 'buyer_email');
        $channel = self::mustIn($payload, 'channel', array('email', 'sms', 'call'));

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'outreach_attempted',
            'status' => 'logged',
            'buyer_email' => $buyerEmail,
            'buyer_key' => self::buyerKey($buyerEmail),
            'channel' => $channel,
            'result' => self::trimField($payload, 'result'),
            'notes' => self::trimField($payload, 'notes'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'updated_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('outreach_attempted_logged', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }

    public static function createCheckoutExperimentDraft($payload, $ctx)
    {
        $experimentType = self::trimField($payload, 'experiment_type');
        if ($experimentType === '') {
            throw new RuntimeException('experiment_type_required', 422);
        }

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'checkout_experiment_draft',
            'status' => 'draft',
            'experiment_type' => $experimentType,
            'target_state' => strtoupper(self::trimField($payload, 'target_state')),
            'target_lead_type' => strtolower(self::trimField($payload, 'target_lead_type')),
            'headline' => self::trimField($payload, 'headline'),
            'offer_copy' => self::trimField($payload, 'offer_copy'),
            'cta' => self::trimField($payload, 'cta'),
            'notes' => self::trimField($payload, 'notes'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'updated_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('checkout_experiment_draft_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }

    public static function createDiscountCodeDraft($payload, $ctx)
    {
        $offerType = self::trimField($payload, 'offer_type');
        if ($offerType === '') {
            throw new RuntimeException('offer_type_required', 422);
        }

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'discount_code_draft',
            'status' => 'draft',
            'code_hint' => self::trimField($payload, 'code_hint'),
            'offer_type' => $offerType,
            'value_type' => self::trimField($payload, 'value_type', 'percent'),
            'value' => (string) self::arrGet($payload, 'value', ''),
            'expires_at' => self::trimField($payload, 'expires_at'),
            'usage_cap' => (int) self::arrGet($payload, 'usage_cap', 0),
            'target_segment' => self::trimField($payload, 'target_segment'),
            'notes' => self::trimField($payload, 'notes'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'updated_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('discount_code_draft_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }


    public static function createArticlePatchDraft($payload, $ctx)
    {
        $articleId = (int) self::arrGet($payload, 'article_id', 0);
        if ($articleId <= 0) {
            throw new RuntimeException('article_id_required', 422);
        }

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'article_patch_draft',
            'status' => 'draft',
            'article_id' => $articleId,
            'patch' => (array) self::arrGet($payload, 'patch', array()),
            'notes' => self::trimField($payload, 'notes'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'updated_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('article_patch_draft_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id'], 'article_id' => $articleId));

        return array('item' => $item);
    }

    public static function createModulePatchDraft($payload, $ctx)
    {
        $moduleId = (int) self::arrGet($payload, 'module_id', 0);
        if ($moduleId <= 0) {
            throw new RuntimeException('module_id_required', 422);
        }

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'module_patch_draft',
            'status' => 'draft',
            'module_id' => $moduleId,
            'patch' => (array) self::arrGet($payload, 'patch', array()),
            'notes' => self::trimField($payload, 'notes'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'updated_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('module_patch_draft_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id'], 'module_id' => $moduleId));

        return array('item' => $item);
    }

    public static function createComponentConfigPatchDraft($payload, $ctx)
    {
        $patch = (array) self::arrGet($payload, 'patch', array());
        if (!$patch) {
            throw new RuntimeException('patch_required', 422);
        }

        $item = array(
            'id' => self::buildItemId('task'),
            'type' => 'component_config_patch_draft',
            'status' => 'draft',
            'patch' => $patch,
            'notes' => self::trimField($payload, 'notes'),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'updated_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        self::audit('component_config_patch_draft_created', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $item['id']));

        return array('item' => $item);
    }

    public static function applyArticlePatch($payload, $ctx)
    {
        self::ensureLiveSiteWritesEnabled();

        $articleId = (int) self::arrGet($payload, 'article_id', 0);
        if ($articleId <= 0) {
            throw new RuntimeException('article_id_required', 422);
        }
        self::enforceAllowedEntityId($articleId, 'bridge_live_allowed_article_ids', 'article');

        $patch = (array) self::arrGet($payload, 'patch', array());
        if (!$patch) {
            throw new RuntimeException('patch_required', 422);
        }

        $current = self::getArticle($articleId);
        $allowed = array('title', 'alias', 'introtext', 'fulltext', 'metadesc', 'state', 'featured', 'catid', 'access', 'language', 'images', 'attribs', 'metadata');
        $db = JFactory::getDbo();
        $fields = array();

        foreach ($allowed as $key) {
            if (!array_key_exists($key, $patch)) {
                continue;
            }
            $value = $patch[$key];
            if ($key === 'title') {
                $value = trim((string) $value);
                if ($value === '') {
                    throw new RuntimeException('title_invalid', 422);
                }
                $fields[] = $db->qn('title') . ' = ' . $db->q($value);
                continue;
            }
            if ($key === 'alias') {
                $alias = trim((string) $value);
                if ($alias === '' && isset($patch['title'])) {
                    $alias = JFilterOutput::stringURLSafe((string) $patch['title']);
                }
                if ($alias !== '') {
                    $fields[] = $db->qn('alias') . ' = ' . $db->q($alias);
                }
                continue;
            }
            if (in_array($key, array('state', 'featured', 'catid', 'access'), true)) {
                $fields[] = $db->qn($key) . ' = ' . (int) $value;
                continue;
            }
            if (in_array($key, array('images', 'attribs', 'metadata'), true)) {
                $merged = self::mergeStructuredField(self::arrGet($current, $key, ''), $value);
                $fields[] = $db->qn($key) . ' = ' . $db->q($merged);
                continue;
            }
            $fields[] = $db->qn($key) . ' = ' . $db->q((string) $value);
        }

        if (!$fields) {
            throw new RuntimeException('no_allowed_article_patch_fields', 422);
        }

        $fields[] = $db->qn('modified') . ' = ' . $db->q(gmdate('Y-m-d H:i:s'));
        $fields[] = $db->qn('modified_by') . ' = 0';

        $query = $db->getQuery(true)
            ->update($db->qn('#__content'))
            ->set($fields)
            ->where($db->qn('id') . ' = ' . $articleId);
        $db->setQuery($query);
        $db->execute();

        $updated = self::getArticle($articleId);
        self::audit('article_patch_applied', $ctx, self::auditPayload($payload), array('ok' => true, 'article_id' => $articleId));
        return array('item' => $updated);
    }

    public static function applyModulePatch($payload, $ctx)
    {
        self::ensureLiveSiteWritesEnabled();

        $moduleId = (int) self::arrGet($payload, 'module_id', 0);
        if ($moduleId <= 0) {
            throw new RuntimeException('module_id_required', 422);
        }
        self::enforceAllowedEntityId($moduleId, 'bridge_live_allowed_module_ids', 'module');

        $patch = (array) self::arrGet($payload, 'patch', array());
        if (!$patch) {
            throw new RuntimeException('patch_required', 422);
        }

        $current = self::getModule($moduleId);
        $allowed = array('title', 'note', 'content', 'position', 'published', 'ordering', 'showtitle', 'params');
        $db = JFactory::getDbo();
        $fields = array();

        foreach ($allowed as $key) {
            if (!array_key_exists($key, $patch)) {
                continue;
            }
            $value = $patch[$key];
            if (in_array($key, array('published', 'ordering', 'showtitle'), true)) {
                $fields[] = $db->qn($key) . ' = ' . (int) $value;
                continue;
            }
            if ($key === 'params') {
                $merged = self::mergeStructuredField(self::arrGet($current, 'params', ''), $value);
                $fields[] = $db->qn('params') . ' = ' . $db->q($merged);
                continue;
            }
            $fields[] = $db->qn($key) . ' = ' . $db->q((string) $value);
        }

        if (!$fields) {
            throw new RuntimeException('no_allowed_module_patch_fields', 422);
        }

        $query = $db->getQuery(true)
            ->update($db->qn('#__modules'))
            ->set($fields)
            ->where($db->qn('id') . ' = ' . $moduleId);
        $db->setQuery($query);
        $db->execute();

        $updated = self::getModule($moduleId);
        self::audit('module_patch_applied', $ctx, self::auditPayload($payload), array('ok' => true, 'module_id' => $moduleId));
        return array('item' => $updated);
    }

    public static function applyComponentConfigPatch($payload, $ctx)
    {
        self::ensureLiveSiteWritesEnabled();

        $patch = (array) self::arrGet($payload, 'patch', array());
        if (!$patch) {
            throw new RuntimeException('patch_required', 422);
        }

        $allowedKeys = self::componentWritableKeys();
        if (!$allowedKeys) {
            throw new RuntimeException('no_writable_component_param_keys_configured', 422);
        }

        $db = JFactory::getDbo();
        $query = $db->getQuery(true)
            ->select(array('extension_id', 'params'))
            ->from('#__extensions')
            ->where("type='component'")
            ->where("element='com_leadmarket'")
            ->setLimit(1);
        $db->setQuery($query);
        $row = (array) $db->loadAssoc();
        if (!$row) {
            throw new RuntimeException('component_extension_not_found', 404);
        }

        $params = json_decode((string) self::arrGet($row, 'params', '{}'), true);
        if (!is_array($params)) {
            $params = array();
        }

        $applied = array();
        foreach ($patch as $key => $value) {
            $key = trim((string) $key);
            if ($key === '' || !in_array($key, $allowedKeys, true)) {
                continue;
            }
            $params[$key] = $value;
            $applied[] = $key;
        }
        if (!$applied) {
            throw new RuntimeException('no_allowed_component_param_keys_in_patch', 422);
        }

        $update = $db->getQuery(true)
            ->update('#__extensions')
            ->set($db->qn('params') . ' = ' . $db->q(json_encode($params, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)))
            ->where($db->qn('extension_id') . ' = ' . (int) self::arrGet($row, 'extension_id', 0));
        $db->setQuery($update);
        $db->execute();

        self::$params = null;
        $updated = self::getComponentConfig();
        self::audit('component_config_patch_applied', $ctx, self::auditPayload($payload), array('ok' => true, 'applied_keys' => $applied));
        return array('item' => $updated, 'applied_keys' => $applied);
    }

    public static function removeBuyerTag($payload, $ctx)
    {
        $buyerEmail = self::mustEmail($payload, 'buyer_email');
        $tag = self::trimField($payload, 'tag');
        if ($tag === '') {
            throw new RuntimeException('tag_required', 422);
        }

        $file = self::storagePath('tags/buyer_tags.json');
        $all = self::loadTagMap();
        $buyerKey = self::buyerKey($buyerEmail);
        if (!isset($all[$buyerKey])) {
            throw new RuntimeException('buyer_tags_not_found', 404);
        }

        $all[$buyerKey]['tags'] = array_values(array_filter((array) self::arrGet($all[$buyerKey], 'tags', array()), function ($existing) use ($tag) {
            return (string) $existing !== (string) $tag;
        }));
        $all[$buyerKey]['updated_at'] = gmdate('Y-m-d H:i:s');
        self::saveJson($file, $all);
        self::audit('buyer_tag_removed', $ctx, self::auditPayload($payload), array('ok' => true, 'buyer_key' => $buyerKey, 'tag' => $tag));

        return array('buyer' => $all[$buyerKey]);
    }

    public static function updateTask($payload, $ctx)
    {
        $taskId = self::trimField($payload, 'task_id');
        if ($taskId === '') {
            throw new RuntimeException('task_id_required', 422);
        }
        $file = self::storagePath('tasks/' . basename($taskId) . '.json');
        $item = self::loadJson($file, array());
        if (!is_array($item) || empty($item['id'])) {
            throw new RuntimeException('task_not_found', 404);
        }

        $status = self::trimField($payload, 'status');
        if ($status !== '') {
            $item['status'] = self::mustIn(array('status' => $status), 'status', array('draft', 'open', 'in_progress', 'done', 'canceled', 'logged'));
        }
        $owner = self::trimField($payload, 'owner');
        if ($owner !== '') {
            $item['owner'] = $owner;
        }
        $title = self::trimField($payload, 'title');
        if ($title !== '') {
            $item['title'] = $title;
        }
        $notes = self::trimField($payload, 'notes');
        if ($notes !== '') {
            $item['notes'] = $notes;
        }
        $append = self::trimField($payload, 'notes_append');
        if ($append !== '') {
            $existing = trim((string) self::arrGet($item, 'notes', ''));
            $item['notes'] = trim($existing === '' ? $append : ($existing . "

" . $append));
        }
        $item['updated_at'] = gmdate('Y-m-d H:i:s');
        $item['updated_by'] = self::trimField($payload, 'updated_by', (string) self::arrGet($ctx, 'actor', 'orchestrator'));
        self::saveJson($file, $item);
        self::audit('task_updated', $ctx, self::auditPayload($payload), array('ok' => true, 'task_id' => $taskId));

        return array('item' => $item);
    }

    public static function proposalCreate($payload, $ctx)
    {
        $proposalType = self::mustIn($payload, 'proposal_type', self::allowedProposalTypes());

        $item = array(
            'id' => self::buildItemId('proposal'),
            'proposal_type' => $proposalType,
            'status' => 'pending',
            'target_type' => self::trimField($payload, 'target_type', 'generic'),
            'target_key' => self::trimField($payload, 'target_key'),
            'payload' => (array) self::arrGet($payload, 'payload', array()),
            'source_agent' => self::trimField($payload, 'source_agent', 'orchestrator'),
            'created_at' => gmdate('Y-m-d H:i:s'),
            'expires_at' => self::trimField($payload, 'expires_at'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );

        self::saveJson(self::storagePath('proposals/' . $item['id'] . '.json'), $item);
        self::audit('proposal_created', $ctx, self::auditPayload($payload), array('ok' => true, 'proposal_id' => $item['id']));

        return array('item' => $item);
    }

    public static function getPendingProposals($limit)
    {
        $limit = self::normalizeLimit($limit);
        $items = array();
        $files = (array) glob(self::storagePath('proposals/*.json'));
        foreach ($files as $file) {
            $row = self::loadJson($file, array());
            if (!is_array($row) || empty($row['id'])) {
                continue;
            }
            if (self::isProposalExpired($row)) {
                if ((string) self::arrGet($row, 'status', '') === 'pending') {
                    $row['status'] = 'expired';
                    $row['expired_at'] = gmdate('Y-m-d H:i:s');
                    self::saveJson($file, $row);
                }
                continue;
            }
            if ((string) self::arrGet($row, 'status', '') === 'pending') {
                $items[] = $row;
            }
        }

        usort($items, array('LeadMarketBridgeHelper', 'sortProposalsByCreatedAtDesc'));
        if (count($items) > $limit) {
            $items = array_slice($items, 0, $limit);
        }

        return $items;
    }

    public static function proposalApprove($payload, $ctx)
    {
        $proposalId = self::trimField($payload, 'proposal_id');
        $approvedBy = self::trimField($payload, 'approved_by');
        if ($proposalId === '' || $approvedBy === '') {
            throw new RuntimeException('proposal_id_and_approved_by_required', 422);
        }

        $file = self::storagePath('proposals/' . basename($proposalId) . '.json');
        $proposal = self::loadJson($file, array());
        if (!$proposal || !is_array($proposal)) {
            throw new RuntimeException('proposal_not_found', 404);
        }
        if (self::isProposalExpired($proposal)) {
            $proposal['status'] = 'expired';
            $proposal['expired_at'] = gmdate('Y-m-d H:i:s');
            self::saveJson($file, $proposal);
            throw new RuntimeException('proposal_expired', 409);
        }
        if ((string) self::arrGet($proposal, 'status', '') !== 'pending') {
            throw new RuntimeException('proposal_not_pending', 409);
        }

        $execution = self::executeApprovedProposal($proposal, $ctx);
        $proposal['status'] = 'approved';
        $proposal['approved_by'] = $approvedBy;
        $proposal['approved_at'] = gmdate('Y-m-d H:i:s');
        $proposal['execution_result'] = $execution;
        self::saveJson($file, $proposal);
        self::audit('proposal_approved', $ctx, self::auditPayload($payload), array('ok' => true, 'proposal_id' => $proposalId, 'execution' => $execution));

        return array('item' => $proposal);
    }

    public static function proposalReject($payload, $ctx)
    {
        $proposalId = self::trimField($payload, 'proposal_id');
        $rejectedBy = self::trimField($payload, 'rejected_by');
        if ($proposalId === '' || $rejectedBy === '') {
            throw new RuntimeException('proposal_id_and_rejected_by_required', 422);
        }

        $file = self::storagePath('proposals/' . basename($proposalId) . '.json');
        $proposal = self::loadJson($file, array());
        if (!$proposal || !is_array($proposal)) {
            throw new RuntimeException('proposal_not_found', 404);
        }
        if ((string) self::arrGet($proposal, 'status', '') !== 'pending') {
            throw new RuntimeException('proposal_not_pending', 409);
        }

        $proposal['status'] = 'rejected';
        $proposal['rejected_by'] = $rejectedBy;
        $proposal['rejected_at'] = gmdate('Y-m-d H:i:s');
        $proposal['rejected_reason'] = self::trimField($payload, 'reason');
        self::saveJson($file, $proposal);
        self::audit('proposal_rejected', $ctx, self::auditPayload($payload), array('ok' => true, 'proposal_id' => $proposalId));

        return array('item' => $proposal);
    }

    public static function proposalExpire($payload, $ctx)
    {
        $proposalId = self::trimField($payload, 'proposal_id');
        if ($proposalId === '') {
            throw new RuntimeException('proposal_id_required', 422);
        }

        $file = self::storagePath('proposals/' . basename($proposalId) . '.json');
        $proposal = self::loadJson($file, array());
        if (!$proposal || !is_array($proposal)) {
            throw new RuntimeException('proposal_not_found', 404);
        }
        if ((string) self::arrGet($proposal, 'status', '') !== 'pending') {
            throw new RuntimeException('proposal_not_pending', 409);
        }

        $proposal['status'] = 'expired';
        $proposal['expired_at'] = gmdate('Y-m-d H:i:s');
        $proposal['expired_by'] = self::trimField($payload, 'expired_by', (string) self::arrGet($ctx, 'actor', 'orchestrator'));
        $proposal['expired_reason'] = self::trimField($payload, 'reason');
        self::saveJson($file, $proposal);
        self::audit('proposal_expired_manually', $ctx, self::auditPayload($payload), array('ok' => true, 'proposal_id' => $proposalId));

        return array('item' => $proposal);
    }


    public static function getRequestDetails($requestId)
    {
        $requestId = trim((string) $requestId);
        if ($requestId === '') {
            throw new RuntimeException('request_id_required', 422);
        }
        $group = null;
        foreach (self::buildAuditConnectionGroups() as $item) {
            if ((string) self::arrGet($item, 'request_id', '') === $requestId) {
                $group = $item;
                break;
            }
        }
        if (!$group) {
            throw new RuntimeException('request_not_found', 404);
        }

        $related = array(
            'tasks' => array(),
            'proposals' => array(),
            'tags' => array(),
        );
        foreach (self::loadTaskItems() as $task) {
            if ((string) self::arrGet($task, 'request_id', '') === $requestId) {
                $related['tasks'][] = $task;
            }
        }
        foreach (self::loadProposalItems() as $proposal) {
            $matched = ((string) self::arrGet($proposal, 'request_id', '') === $requestId);
            if (!$matched) {
                $exec = (array) self::arrGet($proposal, 'execution_result', array());
                $execResult = (array) self::arrGet($exec, 'result', array());
                $taskId = (string) self::arrGet((array) self::arrGet($execResult, 'item', array()), 'id', '');
                if ($taskId !== '') {
                    foreach ($related['tasks'] as $task) {
                        if ((string) self::arrGet($task, 'id', '') === $taskId) {
                            $matched = true;
                            break;
                        }
                    }
                }
            }
            if ($matched) {
                $related['proposals'][] = $proposal;
            }
        }

        return array(
            'connection' => $group,
            'events' => (array) self::arrGet($group, 'events', array()),
            'related' => $related,
            'request_payload_preview' => self::previewData(self::arrGet($group, 'final_payload', array()), 1200),
            'result_preview' => self::previewData(self::arrGet($group, 'final_result', array()), 1200),
        );
    }

    public static function getEventStream($filters = array())
    {
        $filters = is_array($filters) ? $filters : array();
        $page = max(1, (int) self::arrGet($filters, 'page', 1));
        $perPage = max(1, min(100, (int) self::arrGet($filters, 'per_page', 10)));
        $eventType = trim((string) self::arrGet($filters, 'event_type', ''));
        $actor = strtolower(trim((string) self::arrGet($filters, 'actor', '')));
        $ip = trim((string) self::arrGet($filters, 'ip', ''));
        $q = strtolower(trim((string) self::arrGet($filters, 'q', '')));
        $range = trim((string) self::arrGet($filters, 'range', '24h'));

        $rangeStart = 0;
        switch ($range) {
            case '1h': $rangeStart = time() - 3600; break;
            case '24h': $rangeStart = time() - 86400; break;
            case '7d': $rangeStart = time() - (7 * 86400); break;
            default: $rangeStart = 0; break;
        }

        $rows = array();
        $file = self::storagePath('audit.log');
        if (JFile::exists($file)) {
            $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (is_array($lines)) {
                foreach (array_reverse($lines) as $line) {
                    $row = json_decode($line, true);
                    if (!is_array($row)) {
                        continue;
                    }
                    $ts = self::toTimestamp(self::arrGet($row, 'ts', ''));
                    if ($rangeStart > 0 && ($ts <= 0 || $ts < $rangeStart)) {
                        continue;
                    }
                    if ($eventType !== '' && (string) self::arrGet($row, 'event_type', '') !== $eventType) {
                        continue;
                    }
                    if ($actor !== '' && strpos(strtolower((string) self::arrGet($row, 'actor', '')), $actor) === false) {
                        continue;
                    }
                    if ($ip !== '' && strpos((string) self::arrGet($row, 'ip', ''), $ip) === false) {
                        continue;
                    }
                    $summary = self::buildEventSummary($row);
                    if ($q !== '') {
                        $haystack = strtolower(implode(' | ', array(
                            (string) self::arrGet($row, 'event_type', ''),
                            (string) self::arrGet($row, 'actor', ''),
                            (string) self::arrGet($row, 'ip', ''),
                            (string) self::arrGet($row, 'task', ''),
                            (string) self::arrGet($row, 'request_id', ''),
                            (string) $summary,
                            self::previewData(self::arrGet($row, 'payload', array()), 400),
                        )));
                        if (strpos($haystack, $q) === false) {
                            continue;
                        }
                    }
                    $row['status'] = self::classifyAuditEventStatus($row);
                    $row['summary'] = $summary;
                    $row['duration_ms'] = self::arrGet((array) self::arrGet($row, 'result', array()), 'duration_ms', null);
                    $row['status_code'] = self::arrGet((array) self::arrGet($row, 'result', array()), 'status_code', null);
                    $rows[] = $row;
                }
            }
        }

        $total = count($rows);
        $totalPages = max(1, (int) ceil($total / $perPage));
        if ($page > $totalPages) {
            $page = $totalPages;
        }
        $offset = ($page - 1) * $perPage;
        $items = array_slice($rows, $offset, $perPage);
        return array(
            'items' => $items,
            'page' => $page,
            'per_page' => $perPage,
            'total' => $total,
            'total_pages' => $totalPages,
            'has_prev' => $page > 1,
            'has_next' => $page < $totalPages,
        );
    }

    public static function runBridgeSelfCheck()
    {
        $readiness = self::getBridgeReadiness();
        $status = (array) self::arrGet($readiness, 'system_status', array());
        return array(
            'run_at' => gmdate('Y-m-d H:i:s'),
            'overall_status' => (string) self::arrGet($readiness, 'overall_status', 'info'),
            'checks' => (array) self::arrGet($readiness, 'checks', array()),
            'counts' => array(
                'pending_proposals' => count(self::getPendingProposals(500)),
                'open_tasks' => count(self::getTasks(array('limit' => 500, 'status' => 'open_like'))),
                'recent_failures' => count(self::getRecentFailures(100)),
                'recent_connections_24h' => (int) self::arrGet((array) self::arrGet((array) self::getConnectionSummary(1), 'last_24h', array()), 'total', 0),
            ),
            'storage_path' => (string) self::arrGet($status, 'storage_path', ''),
        );
    }

    public static function getSafeControlMatrix()
    {
        $status = self::getSystemStatus();
        return array(
            'read_access' => array(
                'enabled' => !empty($status['bridge_enabled']),
                'endpoints' => array(
                    'bridge.capabilities',
                    'bridge.systemStatus',
                    'bridge.projectSnapshot',
                    'bridge.kpiOverview',
                    'bridge.buyersFreeTestPending',
                    'bridge.buyersInactive',
                    'bridge.leadsStale',
                    'bridge.proposalsPending',
                    'bridge.tasksList',
                    'bridge.auditRecent',
                ),
            ),
            'proposal_only' => array(
                'followup_draft',
                'campaign_draft',
                'checkout_experiment_draft',
                'discount_code_draft',
                'article_patch',
                'module_patch',
                'component_config_patch',
                'internal_task',
                'internal_note',
                'buyer_tag_change',
                'buyer_tag_remove',
            ),
            'live_writes' => array(
                'enabled' => !empty($status['live_site_writes_enabled']),
                'allowed_article_ids' => (array) self::arrGet((array) self::arrGet($status, 'live_site_write_scope', array()), 'allowed_article_ids', array()),
                'allowed_module_ids' => (array) self::arrGet((array) self::arrGet($status, 'live_site_write_scope', array()), 'allowed_module_ids', array()),
                'allowed_component_param_keys' => (array) self::arrGet((array) self::arrGet($status, 'live_site_write_scope', array()), 'allowed_component_param_keys', array()),
            ),
            'forbidden' => array(
                'payment',
                'wallet_topup_balance_logic',
                'checkout_critical_logic',
                'gateway_mail_secrets',
                'receiver_import',
                'unsafe_live_writes_outside_allowlist',
            ),
        );
    }

    public static function adminProposalApprove($proposalId, $approvedBy)
    {
        return self::proposalApprove(array('proposal_id' => $proposalId, 'approved_by' => $approvedBy), self::buildAdminContext('bridge.approveProposal', $approvedBy));
    }

    public static function adminProposalReject($proposalId, $rejectedBy, $reason = '')
    {
        return self::proposalReject(array('proposal_id' => $proposalId, 'rejected_by' => $rejectedBy, 'reason' => $reason), self::buildAdminContext('bridge.rejectProposal', $rejectedBy));
    }

    public static function adminProposalExpire($proposalId, $expiredBy, $reason = '')
    {
        return self::proposalExpire(array('proposal_id' => $proposalId, 'expired_by' => $expiredBy, 'reason' => $reason), self::buildAdminContext('bridge.expireProposal', $expiredBy));
    }

    public static function adminTaskSetStatus($taskId, $status, $actor, $notesAppend = '')
    {
        $payload = array('task_id' => $taskId, 'status' => $status, 'updated_by' => $actor);
        if ($notesAppend !== '') {
            $payload['notes_append'] = $notesAppend;
        }
        return self::updateTask($payload, self::buildAdminContext('bridge.updateTaskStatus', $actor));
    }

    public static function adminTaskDuplicate($taskId, $actor)
    {
        $original = self::getTask($taskId);
        $copy = $original;
        $copy['id'] = self::buildItemId('task');
        $copy['status'] = in_array((string) self::arrGet($original, 'status', ''), array('draft', 'open', 'in_progress'), true) ? (string) self::arrGet($original, 'status', 'draft') : 'draft';
        $copy['created_at'] = gmdate('Y-m-d H:i:s');
        $copy['updated_at'] = gmdate('Y-m-d H:i:s');
        $copy['duplicated_from'] = $taskId;
        $copy['request_id'] = self::buildRequestId();
        $file = self::storagePath('tasks/' . $copy['id'] . '.json');
        self::saveJson($file, $copy);
        $ctx = self::buildAdminContext('bridge.duplicateTask', $actor);
        self::audit('task_duplicated', $ctx, array('task_id' => $taskId), array('ok' => true, 'task_id' => $copy['id']));
        return array('item' => $copy);
    }

    public static function adminTestAuditWrite($actor)
    {
        $ctx = self::buildAdminContext('bridge.testAuditWrite', $actor);
        self::audit('admin_self_check', $ctx, array('action' => 'test_audit_write'), array('ok' => true, 'status_code' => 200));
        return array('ok' => true, 'request_id' => self::arrGet($ctx, 'request_id', ''));
    }

    public static function params()
    {
        if (self::$params === null) {
            self::$params = JComponentHelper::getParams('com_leadmarket');
        }
        return self::$params;
    }

    public static function storagePath($suffix)
    {
        $base = self::storageBase();
        $suffix = ltrim((string) $suffix, '/');
        return JPath::clean($suffix === '' ? $base : ($base . '/' . $suffix));
    }

    public static function audit($eventType, $ctx, $payload, $result)
    {
        $result = self::runtimeResultMeta($ctx, (array) $result, isset($result['status_code']) ? (int) $result['status_code'] : null);
        $line = array(
            'ts' => gmdate('c'),
            'event_type' => (string) $eventType,
            'request_id' => (string) self::arrGet($ctx, 'request_id', ''),
            'actor' => (string) self::arrGet($ctx, 'actor', ''),
            'ip' => (string) self::arrGet($ctx, 'ip', ''),
            'task' => self::arrGet($ctx, 'task', self::currentTask()),
            'request_method' => strtoupper((string) self::server('REQUEST_METHOD', 'GET')),
            'request_uri' => (string) self::server('REQUEST_URI', ''),
            'payload' => $payload,
            'result' => $result,
        );
        self::appendJsonLine(self::storagePath('audit.log'), $line);
    }

    protected static function executeApprovedProposal($proposal, $ctx)
    {
        $type = (string) self::arrGet($proposal, 'proposal_type', '');
        $payload = (array) self::arrGet($proposal, 'payload', array());

        switch ($type) {
            case 'followup_draft':
                $result = self::createFollowupDraft($payload, $ctx);
                return array('action' => 'createFollowupDraft', 'result' => $result);
            case 'campaign_draft':
            case 'homepage_cta_draft':
            case 'landing_content_draft':
            case 'reactivation_draft':
                $result = self::createGenericDraft($payload, $ctx, $type);
                return array('action' => 'createGenericDraft', 'result' => $result);
            case 'checkout_experiment_draft':
                $result = self::createCheckoutExperimentDraft($payload, $ctx);
                return array('action' => 'createCheckoutExperimentDraft', 'result' => $result);
            case 'discount_code_draft':
                $result = self::createDiscountCodeDraft($payload, $ctx);
                return array('action' => 'createDiscountCodeDraft', 'result' => $result);
            case 'article_patch':
                $result = self::applyArticlePatch($payload, $ctx);
                return array('action' => 'applyArticlePatch', 'result' => $result);
            case 'module_patch':
                $result = self::applyModulePatch($payload, $ctx);
                return array('action' => 'applyModulePatch', 'result' => $result);
            case 'component_config_patch':
                $result = self::applyComponentConfigPatch($payload, $ctx);
                return array('action' => 'applyComponentConfigPatch', 'result' => $result);
            case 'buyer_tag_change':
                $result = self::addBuyerTag($payload, $ctx);
                return array('action' => 'addBuyerTag', 'result' => $result);
            case 'buyer_tag_remove':
                $result = self::removeBuyerTag($payload, $ctx);
                return array('action' => 'removeBuyerTag', 'result' => $result);
            case 'internal_task':
                $result = self::createTask($payload, $ctx);
                return array('action' => 'createTask', 'result' => $result);
            case 'internal_note':
                $result = self::createInternalNote($payload, $ctx);
                return array('action' => 'createInternalNote', 'result' => $result);
        }

        throw new RuntimeException('proposal_type_not_whitelisted', 422);
    }

    protected static function createGenericDraft($payload, $ctx, $type)
    {
        $item = array(
            'id' => self::buildItemId('task'),
            'type' => $type,
            'status' => 'draft',
            'payload' => $payload,
            'created_at' => gmdate('Y-m-d H:i:s'),
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        );
        self::saveJson(self::storagePath('tasks/' . $item['id'] . '.json'), $item);
        return array('item' => $item);
    }

    protected static function buildFallbackContext()
    {
        return array(
            'request_id' => self::buildRequestId(),
            'ip' => self::getClientIp(),
            'actor' => self::getHeader('X-Bridge-Key') !== '' ? self::getHeader('X-Bridge-Key') : 'unknown',
            'task' => self::currentTask(),
            'started_microtime' => microtime(true),
        );
    }

    protected static function withMeta($payload, $ctx)
    {
        $payload['request_id'] = self::arrGet($ctx, 'request_id', '');
        $payload['meta'] = array(
            'generated_at_utc' => gmdate('Y-m-d H:i:s'),
            'task' => self::arrGet($ctx, 'task', self::currentTask()),
        );
        return $payload;
    }


    protected static function runtimeResultMeta($ctx, $result, $statusCode)
    {
        if (!is_array($result)) {
            $result = array();
        }
        if ($statusCode !== null && !isset($result['status_code'])) {
            $result['status_code'] = (int) $statusCode;
        }
        if (!isset($result['duration_ms'])) {
            $result['duration_ms'] = self::durationMs($ctx);
        }
        return $result;
    }

    protected static function durationMs($ctx)
    {
        $start = (float) self::arrGet($ctx, 'started_microtime', 0);
        if ($start <= 0) {
            return null;
        }
        return max(0, (int) round((microtime(true) - $start) * 1000));
    }

    protected static function enforceRateLimit($keyId, $actionGroup, $params, $ctx)
    {
        $limitMap = array(
            'read' => max(1, (int) $params->get('bridge_read_rpm', 60)),
            'write' => max(1, (int) $params->get('bridge_write_rpm', 20)),
            'proposal' => max(1, (int) $params->get('bridge_write_rpm', 20)),
            'approve' => max(1, (int) $params->get('bridge_approve_rpm', 10)),
        );
        $limit = isset($limitMap[$actionGroup]) ? $limitMap[$actionGroup] : max(1, (int) $params->get('bridge_write_rpm', 20));
        $minute = gmdate('YmdHi');
        $hash = sha1($keyId . ':' . $actionGroup . ':' . $minute);
        $file = self::storagePath('rate_limit/' . $actionGroup . '_' . $hash . '.json');
        $row = self::loadJson($file, array('minute' => $minute, 'count' => 0));
        if (!is_array($row) || (string) self::arrGet($row, 'minute', '') !== $minute) {
            $row = array('minute' => $minute, 'count' => 0);
        }
        $row['count'] = (int) self::arrGet($row, 'count', 0) + 1;
        $row['updated_at'] = gmdate('Y-m-d H:i:s');
        self::saveJson($file, $row);

        if ((int) $row['count'] > $limit) {
            self::audit('rate_limited', $ctx, array('group' => $actionGroup), array('ok' => false, 'count' => (int) $row['count'], 'limit' => $limit));
            throw new RuntimeException('rate_limited', 429);
        }
    }

    protected static function handleException($e, $ctx)
    {
        $code = (int) $e->getCode();
        if ($code < 400 || $code > 599) {
            $code = 500;
        }

        if ($code >= 500) {
            self::audit('bridge_error', $ctx, array('task' => self::currentTask()), self::runtimeResultMeta($ctx, array('ok' => false, 'error' => $e->getMessage(), 'code' => $code), $code));
        }

        self::respond(array(
            'ok' => false,
            'error' => $e->getMessage(),
            'code' => $code,
            'request_id' => self::arrGet($ctx, 'request_id', ''),
        ), $code);
    }

    protected static function respond($payload, $status)
    {
        while (ob_get_level()) {
            @ob_end_clean();
        }
        if (!headers_sent()) {
            header('Content-Type: application/json; charset=utf-8', true, (int) $status);
            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('X-Content-Type-Options: nosniff');
        }
        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        JFactory::getApplication()->close();
    }

    protected static function readJsonBody()
    {
        $raw = self::readRawBody();
        if ($raw === '') {
            return array();
        }
        $data = json_decode($raw, true);
        if (!is_array($data)) {
            throw new RuntimeException('invalid_json', 400);
        }
        return $data;
    }

    protected static function readRawBody()
    {
        if (self::$rawBody === null) {
            $body = file_get_contents('php://input');
            self::$rawBody = is_string($body) ? $body : '';
        }
        return self::$rawBody;
    }

    protected static function getHeader($name)
    {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', (string) $name));
        if (isset($_SERVER[$key])) {
            return trim((string) $_SERVER[$key]);
        }
        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (is_array($headers)) {
                foreach ($headers as $headerName => $headerValue) {
                    if (strcasecmp((string) $headerName, (string) $name) === 0) {
                        return trim((string) $headerValue);
                    }
                }
            }
        }
        return '';
    }

    protected static function getClientIp()
    {
        $candidates = array('HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        foreach ($candidates as $key) {
            $raw = trim((string) self::server($key, ''));
            if ($raw === '') {
                continue;
            }
            if ($key === 'HTTP_X_FORWARDED_FOR') {
                $parts = explode(',', $raw);
                $raw = trim((string) $parts[0]);
            }
            return $raw;
        }
        return '';
    }

    protected static function isAllowedIp($ip, $csv)
    {
        $allowed = self::parseAllowedIpList($csv);
        if (!$allowed) {
            return true;
        }
        if ($ip === '') {
            return false;
        }

        foreach ($allowed as $item) {
            if ($item === '*') {
                return true;
            }
            if (strpos($item, '/') !== false) {
                if (self::ipMatchesCidr($ip, $item)) {
                    return true;
                }
                continue;
            }
            if (strcasecmp($ip, $item) === 0) {
                return true;
            }
        }

        return false;
    }

    protected static function parseAllowedIpList($csv)
    {
        $csv = trim((string) $csv);
        if ($csv === '') {
            return array();
        }

        $parts = preg_split('/[
,]+/', $csv);
        $allowed = array();
        foreach ((array) $parts as $part) {
            $part = trim((string) $part);
            if ($part !== '') {
                $allowed[] = $part;
            }
        }
        return array_values(array_unique($allowed));
    }

    protected static function isIpAllowlistEnforced($params = null)
    {
        if ($params === null) {
            $params = self::params();
        }
        return ((int) $params->get('bridge_enforce_ip_allowlist', 1) === 1);
    }

    protected static function ipMatchesCidr($ip, $cidr)
    {
        $parts = explode('/', $cidr, 2);
        if (count($parts) !== 2) {
            return false;
        }
        $subnet = trim((string) $parts[0]);
        $maskBits = (int) trim((string) $parts[1]);
        $ipBin = @inet_pton($ip);
        $subnetBin = @inet_pton($subnet);
        if ($ipBin === false || $subnetBin === false || strlen($ipBin) !== strlen($subnetBin)) {
            return false;
        }

        $bytes = strlen($ipBin);
        $fullBytes = (int) floor($maskBits / 8);
        $remainder = $maskBits % 8;

        if ($fullBytes > 0 && substr($ipBin, 0, $fullBytes) !== substr($subnetBin, 0, $fullBytes)) {
            return false;
        }
        if ($remainder === 0) {
            return true;
        }

        $mask = chr((0xFF << (8 - $remainder)) & 0xFF);
        return ((ord($ipBin[$fullBytes]) & ord($mask)) === (ord($subnetBin[$fullBytes]) & ord($mask)));
    }


    protected static function ensureLiveSiteWritesEnabled()
    {
        if ((int) self::params()->get('bridge_allow_live_site_writes', 0) !== 1) {
            throw new RuntimeException('live_site_writes_disabled', 403);
        }
    }

    protected static function liveAllowedIdsFromParam($paramName)
    {
        $raw = trim((string) self::params()->get($paramName, ''));
        if ($raw === '') {
            return array();
        }
        $parts = preg_split('/[\s,]+/', $raw);
        $ids = array();
        foreach ((array) $parts as $part) {
            $id = (int) trim((string) $part);
            if ($id > 0 && !in_array($id, $ids, true)) {
                $ids[] = $id;
            }
        }
        sort($ids);
        return $ids;
    }

    protected static function enforceAllowedEntityId($entityId, $paramName, $label)
    {
        $allowed = self::liveAllowedIdsFromParam($paramName);
        if ($allowed && !in_array((int) $entityId, $allowed, true)) {
            throw new RuntimeException($label . '_id_not_allowlisted', 403);
        }
    }

    protected static function componentWritableKeys()
    {
        $raw = trim((string) self::params()->get('bridge_live_allowed_component_params', ''));
        if ($raw === '') {
            return array();
        }
        $parts = preg_split('/[\s,]+/', $raw);
        $keys = array();
        foreach ((array) $parts as $part) {
            $key = trim((string) $part);
            if ($key !== '' && !in_array($key, $keys, true)) {
                $keys[] = $key;
            }
        }
        sort($keys);
        return $keys;
    }

    protected static function sanitizeConfigForOutput($params)
    {
        $out = array();
        foreach ((array) $params as $key => $value) {
            $keyString = (string) $key;
            if (preg_match('/(secret|token|password|key)/i', $keyString)) {
                $out[$keyString] = ($keyString === 'bridge_key_id') ? (string) $value : '[redacted]';
                continue;
            }
            $out[$keyString] = $value;
        }
        return $out;
    }

    protected static function mergeStructuredField($currentValue, $patchValue)
    {
        if (is_array($patchValue)) {
            $base = array();
            if (is_array($currentValue)) {
                $base = $currentValue;
            } elseif (is_string($currentValue) && trim($currentValue) !== '') {
                $decoded = json_decode((string) $currentValue, true);
                if (is_array($decoded)) {
                    $base = $decoded;
                }
            }
            $merged = array_replace_recursive($base, $patchValue);
            return json_encode($merged, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        if (is_string($patchValue)) {
            return $patchValue;
        }
        return json_encode($patchValue, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    protected static function storageBase()
    {
        if (self::$storageBase !== null) {
            return self::$storageBase;
        }

        $base = trim((string) self::params()->get('bridge_storage_path', 'administrator/logs/leadmarket_bridge'));
        if ($base === '') {
            $base = 'administrator/logs/leadmarket_bridge';
        }
        if (strpos($base, JPATH_ROOT) !== 0) {
            $base = JPath::clean(JPATH_ROOT . '/' . ltrim($base, '/'));
        } else {
            $base = JPath::clean($base);
        }

        self::ensureStorage($base);
        self::$storageBase = $base;
        return self::$storageBase;
    }

    protected static function ensureStorage($base)
    {
        if (!JFolder::exists($base)) {
            JFolder::create($base);
        }
        $subdirs = array('proposals', 'tasks', 'tags', 'rate_limit', 'snapshots');
        foreach ($subdirs as $dir) {
            if (!JFolder::exists($base . '/' . $dir)) {
                JFolder::create($base . '/' . $dir);
            }
            if (!JFile::exists($base . '/' . $dir . '/index.html')) {
                JFile::write($base . '/' . $dir . '/index.html', '<!doctype html><title></title>');
            }
        }
        if (!JFile::exists($base . '/index.html')) {
            JFile::write($base . '/index.html', '<!doctype html><title></title>');
        }
    }

    protected static function loadJson($file, $default)
    {
        if (!JFile::exists($file)) {
            return $default;
        }
        $raw = @file_get_contents($file);
        if (!is_string($raw) || $raw === '') {
            return $default;
        }
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $default;
    }

    protected static function saveJson($file, $data)
    {
        $dir = dirname($file);
        if (!JFolder::exists($dir)) {
            JFolder::create($dir);
        }
        JFile::write($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }

    protected static function appendJsonLine($file, $line)
    {
        $dir = dirname($file);
        if (!JFolder::exists($dir)) {
            JFolder::create($dir);
        }
        @file_put_contents($file, json_encode($line, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL, FILE_APPEND | LOCK_EX);
    }


    protected static function buildAuditConnectionGroups()
    {
        if (is_array(self::$auditGroupsCache)) {
            return self::$auditGroupsCache;
        }
        $file = self::storagePath('audit.log');
        if (!JFile::exists($file)) {
            self::$auditGroupsCache = array();
            return self::$auditGroupsCache;
        }
        $lines = @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines) || !$lines) {
            self::$auditGroupsCache = array();
            return self::$auditGroupsCache;
        }

        $groups = array();
        foreach ($lines as $idx => $line) {
            $row = json_decode($line, true);
            if (!is_array($row)) {
                continue;
            }
            $requestId = trim((string) self::arrGet($row, 'request_id', ''));
            if ($requestId === '') {
                $requestId = 'no_request_' . $idx;
            }
            if (!isset($groups[$requestId])) {
                $groups[$requestId] = array(
                    'request_id' => $requestId,
                    'started_at' => (string) self::arrGet($row, 'ts', ''),
                    'last_at' => (string) self::arrGet($row, 'ts', ''),
                    'actor' => (string) self::arrGet($row, 'actor', ''),
                    'ip' => (string) self::arrGet($row, 'ip', ''),
                    'task' => (string) self::arrGet($row, 'task', ''),
                    'request_method' => (string) self::arrGet($row, 'request_method', ''),
                    'request_uri' => (string) self::arrGet($row, 'request_uri', ''),
                    'events' => array(),
                    'event_types' => array(),
                    'final_event_type' => '',
                    'final_payload' => array(),
                    'final_result' => array(),
                    'status' => 'unknown',
                    'status_label' => 'Unknown',
                    'target_summary' => '',
                    'result_summary' => '',
                    'duration_ms' => null,
                    'http_status' => null,
                );
            }
            $groups[$requestId]['events'][] = $row;
            $groups[$requestId]['event_types'][] = (string) self::arrGet($row, 'event_type', '');
            $groups[$requestId]['last_at'] = (string) self::arrGet($row, 'ts', $groups[$requestId]['last_at']);
            if ($groups[$requestId]['actor'] === '' && self::arrGet($row, 'actor', '') !== '') {
                $groups[$requestId]['actor'] = (string) self::arrGet($row, 'actor', '');
            }
            if ($groups[$requestId]['ip'] === '' && self::arrGet($row, 'ip', '') !== '') {
                $groups[$requestId]['ip'] = (string) self::arrGet($row, 'ip', '');
            }
            if ($groups[$requestId]['task'] === '' && self::arrGet($row, 'task', '') !== '') {
                $groups[$requestId]['task'] = (string) self::arrGet($row, 'task', '');
            }
            if ($groups[$requestId]['request_method'] === '' && self::arrGet($row, 'request_method', '') !== '') {
                $groups[$requestId]['request_method'] = (string) self::arrGet($row, 'request_method', '');
            }
            if ($groups[$requestId]['request_uri'] === '' && self::arrGet($row, 'request_uri', '') !== '') {
                $groups[$requestId]['request_uri'] = (string) self::arrGet($row, 'request_uri', '');
            }
        }

        $items = array();
        foreach ($groups as $requestId => $group) {
            $group['event_types'] = array_values(array_unique(array_filter($group['event_types'])));
            $events = $group['events'];
            usort($events, array('LeadMarketBridgeHelper', 'sortAuditEventsByTsAsc'));
            $group['events'] = $events;
            if (!empty($events)) {
                $first = $events[0];
                $last = $events[count($events) - 1];
                $group['started_at'] = (string) self::arrGet($first, 'ts', $group['started_at']);
                $group['last_at'] = (string) self::arrGet($last, 'ts', $group['last_at']);
                $group['final_event_type'] = (string) self::arrGet($last, 'event_type', '');
                $group['final_payload'] = (array) self::arrGet($last, 'payload', array());
                $group['final_result'] = (array) self::arrGet($last, 'result', array());
            }
            $group['status'] = self::classifyAuditConnectionStatus($group);
            $group['status_label'] = self::labelAuditConnectionStatus($group['status']);
            $group['target_summary'] = self::buildAuditTargetSummary($group);
            $group['result_summary'] = self::buildAuditResultSummary($group);
            $group['duration_ms'] = self::resolveAuditDurationMs($group);
            $group['http_status'] = self::resolveAuditHttpStatus($group);
            $items[] = $group;
        }

        usort($items, array('LeadMarketBridgeHelper', 'sortAuditConnectionsByLastAtDesc'));
        self::$auditGroupsCache = $items;
        return self::$auditGroupsCache;
    }

    protected static function classifyAuditConnectionStatus($group)
    {
        $finalEvent = (string) self::arrGet($group, 'final_event_type', '');
        $finalResult = (array) self::arrGet($group, 'final_result', array());
        $ok = self::arrGet($finalResult, 'ok', null);

        if ($finalEvent === 'auth_failed' || $finalEvent === 'bridge_error' || $finalEvent === 'rate_limited') {
            return 'error';
        }
        if ($finalEvent === 'proposal_rejected' || $finalEvent === 'proposal_expired_manually') {
            return 'warning';
        }
        if ($ok === true) {
            return 'success';
        }
        if ($ok === false) {
            return 'error';
        }
        if (in_array('auth_failed', (array) self::arrGet($group, 'event_types', array()), true)) {
            return 'error';
        }
        if (in_array('proposal_rejected', (array) self::arrGet($group, 'event_types', array()), true)) {
            return 'warning';
        }
        return 'info';
    }

    protected static function labelAuditConnectionStatus($status)
    {
        switch ((string) $status) {
            case 'success': return 'Success';
            case 'warning': return 'Warning';
            case 'error': return 'Error';
            default: return 'Info';
        }
    }

    protected static function buildAuditTargetSummary($group)
    {
        $finalPayload = (array) self::arrGet($group, 'final_payload', array());
        $finalResult = (array) self::arrGet($group, 'final_result', array());
        $parts = array();
        $task = trim((string) self::arrGet($group, 'task', ''));
        if ($task !== '') {
            $parts[] = $task;
        }
        $payloadKeys = array(
            'buyer_email' => 'Buyer',
            'proposal_id' => 'Proposal',
            'task_id' => 'Task',
            'article_id' => 'Article',
            'module_id' => 'Module',
            'tag' => 'Tag',
            'owner' => 'Owner',
            'reason' => 'Reason',
        );
        foreach ($payloadKeys as $key => $label) {
            $value = self::arrGet($finalPayload, $key, '');
            if ($value !== '' && $value !== null) {
                if (is_array($value)) {
                    $value = implode(', ', $value);
                }
                $parts[] = $label . ': ' . (string) $value;
            }
        }
        $appliedKeys = (array) self::arrGet($finalResult, 'applied_keys', array());
        if ($appliedKeys) {
            $parts[] = 'Keys: ' . implode(', ', $appliedKeys);
        }
        if (!$parts) {
            $uri = trim((string) self::arrGet($group, 'request_uri', ''));
            if ($uri !== '') {
                $parts[] = $uri;
            }
        }
        return implode(' • ', $parts);
    }

    protected static function buildAuditResultSummary($group)
    {
        $finalEvent = (string) self::arrGet($group, 'final_event_type', '');
        $finalResult = (array) self::arrGet($group, 'final_result', array());
        $finalPayload = (array) self::arrGet($group, 'final_payload', array());

        if ($finalEvent === 'auth_failed') {
            $reason = (string) self::arrGet($finalPayload, 'reason', 'auth_failed');
            $summary = 'Authentication failed: ' . $reason;
        } elseif ($finalEvent === 'rate_limited') {
            $summary = 'Rate limit triggered';
        } elseif ($finalEvent === 'bridge_error') {
            $error = (string) self::arrGet($finalResult, 'error', 'bridge_error');
            $summary = 'Bridge error: ' . $error;
        } elseif ($finalEvent === 'read_endpoint_called') {
            $summary = 'Read request completed';
        } elseif ($finalEvent === 'proposal_approved') {
            $summary = 'Proposal approved and executed';
        } elseif ($finalEvent === 'proposal_rejected') {
            $summary = 'Proposal rejected';
        } elseif ($finalEvent === 'proposal_expired_manually') {
            $summary = 'Proposal expired manually';
        } elseif ($finalEvent !== '') {
            $summary = ucwords(str_replace('_', ' ', $finalEvent));
        } elseif (self::arrGet($finalResult, 'ok', null) === true) {
            $summary = 'Completed successfully';
        } elseif (self::arrGet($finalResult, 'ok', null) === false) {
            $summary = 'Completed with error';
        } else {
            $summary = 'Recorded in audit log';
        }

        $httpStatus = self::resolveAuditHttpStatus($group);
        $duration = self::resolveAuditDurationMs($group);
        $suffix = array();
        if ($httpStatus !== null) {
            $suffix[] = 'HTTP ' . (int) $httpStatus;
        }
        if ($duration !== null) {
            $suffix[] = (int) $duration . ' ms';
        }
        if ($suffix) {
            $summary .= ' • ' . implode(' • ', $suffix);
        }
        return $summary;
    }


    protected static function filterAuditConnectionGroups($groups, $filters)
    {
        $status = trim((string) self::arrGet($filters, 'status', 'all'));
        if ($status === '') {
            $status = 'all';
        }
        $q = strtolower(trim((string) self::arrGet($filters, 'q', '')));
        $items = array();
        foreach ((array) $groups as $group) {
            if ($status !== 'all' && (string) self::arrGet($group, 'status', 'info') !== $status) {
                continue;
            }
            if ($q !== '') {
                $haystack = strtolower(implode(' | ', array(
                    (string) self::arrGet($group, 'request_id', ''),
                    (string) self::arrGet($group, 'task', ''),
                    (string) self::arrGet($group, 'actor', ''),
                    (string) self::arrGet($group, 'ip', ''),
                    (string) self::arrGet($group, 'target_summary', ''),
                    (string) self::arrGet($group, 'result_summary', ''),
                    (string) self::arrGet($group, 'request_uri', ''),
                )));
                if (strpos($haystack, $q) === false) {
                    continue;
                }
            }
            $items[] = $group;
        }
        return $items;
    }


    protected static function classifyAuditEventStatus($row)
    {
        $eventType = (string) self::arrGet($row, 'event_type', '');
        $result = (array) self::arrGet($row, 'result', array());
        if (in_array($eventType, array('auth_failed', 'bridge_error', 'rate_limited', 'live_write_denied'), true)) {
            return 'error';
        }
        if (in_array($eventType, array('proposal_rejected', 'proposal_expired', 'proposal_expired_manually'), true)) {
            return 'warning';
        }
        if (self::arrGet($result, 'ok', null) === true) {
            return 'success';
        }
        if (self::arrGet($result, 'ok', null) === false) {
            return 'error';
        }
        return 'info';
    }

    protected static function buildEventSummary($row)
    {
        $eventType = (string) self::arrGet($row, 'event_type', '');
        $payload = (array) self::arrGet($row, 'payload', array());
        $result = (array) self::arrGet($row, 'result', array());
        switch ($eventType) {
            case 'auth_ok':
                return 'Authenticated request accepted';
            case 'auth_failed':
                return 'Authentication failed: ' . (string) self::arrGet($payload, 'reason', 'unknown');
            case 'read_endpoint_called':
                return 'Read endpoint completed';
            case 'proposal_created':
                return 'Proposal created: ' . (string) self::arrGet($result, 'proposal_id', '');
            case 'proposal_approved':
                return 'Proposal approved and executed';
            case 'proposal_rejected':
                return 'Proposal rejected';
            case 'proposal_expired_manually':
                return 'Proposal expired manually';
            case 'task_created':
            case 'followup_draft_created':
            case 'campaign_draft_created':
            case 'internal_note_created':
                return 'Task or draft created';
            case 'task_updated':
                return 'Task updated';
            case 'task_duplicated':
                return 'Task duplicated';
            case 'article_patch_applied':
                return 'Article patch applied';
            case 'module_patch_applied':
                return 'Module patch applied';
            case 'component_config_patch_applied':
                return 'Component config patch applied';
            case 'buyer_tag_added':
                return 'Buyer tag added';
            case 'buyer_tag_removed':
                return 'Buyer tag removed';
            case 'admin_self_check':
                return 'Admin audit write test completed';
        }
        $error = trim((string) self::arrGet($result, 'error', ''));
        if ($error !== '') {
            return $error;
        }
        return $eventType !== '' ? str_replace('_', ' ', $eventType) : 'Bridge event';
    }

    protected static function previewData($value, $maxLen)
    {
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        }
        $value = trim((string) $value);
        if ($value === '') {
            return '';
        }
        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            return mb_strlen($value) > $maxLen ? mb_substr($value, 0, $maxLen - 1) . '…' : $value;
        }
        return strlen($value) > $maxLen ? substr($value, 0, $maxLen - 1) . '…' : $value;
    }

    protected static function resolveAuditDurationMs($group)
    {
        $finalResult = (array) self::arrGet($group, 'final_result', array());
        if (isset($finalResult['duration_ms']) && $finalResult['duration_ms'] !== null && $finalResult['duration_ms'] !== '') {
            return (int) $finalResult['duration_ms'];
        }
        $start = self::toTimestamp(self::arrGet($group, 'started_at', ''));
        $end = self::toTimestamp(self::arrGet($group, 'last_at', ''));
        if ($start > 0 && $end >= $start) {
            return max(0, (int) round(($end - $start) * 1000));
        }
        return null;
    }

    protected static function resolveAuditHttpStatus($group)
    {
        $finalResult = (array) self::arrGet($group, 'final_result', array());
        if (isset($finalResult['status_code']) && $finalResult['status_code'] !== null && $finalResult['status_code'] !== '') {
            return (int) $finalResult['status_code'];
        }
        $status = (string) self::arrGet($group, 'status', 'info');
        if ($status === 'success') {
            return 200;
        }
        if ($status === 'warning') {
            return 409;
        }
        if ($status === 'error') {
            return 500;
        }
        return null;
    }

    protected static function toTimestamp($value)
    {
        $value = trim((string) $value);
        if ($value === '') {
            return 0;
        }
        $ts = @strtotime($value);
        return $ts ? (int) $ts : 0;
    }

    protected static function sortAuditEventsByTsAsc($a, $b)
    {
        return strcmp((string) self::arrGet($a, 'ts', ''), (string) self::arrGet($b, 'ts', ''));
    }

    protected static function sortAuditConnectionsByLastAtDesc($a, $b)
    {
        return strcmp((string) self::arrGet($b, 'last_at', ''), (string) self::arrGet($a, 'last_at', ''));
    }

    protected static function normalizeTimestamp($timestamp)
    {
        if (ctype_digit((string) $timestamp)) {
            return (int) $timestamp;
        }
        $parsed = strtotime((string) $timestamp);
        return $parsed ? (int) $parsed : 0;
    }

    protected static function buildRequestId()
    {
        return 'br_' . gmdate('YmdHis') . '_' . substr(sha1(uniqid('', true)), 0, 10);
    }

    protected static function buildItemId($prefix)
    {
        return $prefix . '_' . gmdate('YmdHis') . '_' . substr(sha1(uniqid('', true)), 0, 8);
    }

    protected static function normalizeLimit($limit)
    {
        return max(1, min(500, (int) $limit));
    }

    protected static function currentTask()
    {
        return JFactory::getApplication()->input->getCmd('task', '');
    }

    protected static function currentQueryForAudit()
    {
        $input = JFactory::getApplication()->input;
        return array(
            'limit' => $input->getInt('limit', 0),
            'bucket' => $input->getCmd('bucket', ''),
            'state' => $input->getString('state', ''),
            'type' => $input->getCmd('type', ''),
            'segment' => $input->getCmd('segment', ''),
            'min_age_hours' => $input->getInt('min_age_hours', 0),
            'buyer_email' => $input->getString('buyer_email', ''),
            'article_id' => $input->getInt('article_id', 0),
            'module_id' => $input->getInt('module_id', 0),
            'task_id' => $input->getString('task_id', ''),
            'proposal_id' => $input->getString('proposal_id', ''),
            'event_type' => $input->getCmd('event_type', ''),
            'status' => $input->getCmd('status', ''),
            'owner' => $input->getString('owner', ''),
            'q' => $input->getString('q', ''),
        );
    }

    protected static function auditPayload($payload)
    {
        if (!is_array($payload)) {
            return array();
        }
        $copy = $payload;
        if (isset($copy['draft_body']) && is_string($copy['draft_body']) && strlen($copy['draft_body']) > 500) {
            $copy['draft_body'] = substr($copy['draft_body'], 0, 500) . '…';
        }
        if (isset($copy['body']) && is_string($copy['body']) && strlen($copy['body']) > 500) {
            $copy['body'] = substr($copy['body'], 0, 500) . '…';
        }
        return $copy;
    }

    protected static function arrGet($array, $key, $default)
    {
        return (is_array($array) && array_key_exists($key, $array)) ? $array[$key] : $default;
    }

    protected static function trimField($payload, $key, $default = '')
    {
        return trim((string) self::arrGet($payload, $key, $default));
    }

    protected static function optionalEmail($payload, $key)
    {
        $email = strtolower(trim((string) self::arrGet($payload, $key, '')));
        if ($email === '') {
            return '';
        }
        if (!JMailHelper::isEmailAddress($email)) {
            throw new RuntimeException($key . '_invalid', 422);
        }
        return $email;
    }

    protected static function mustEmail($payload, $key)
    {
        $email = self::optionalEmail($payload, $key);
        if ($email === '') {
            throw new RuntimeException($key . '_required', 422);
        }
        return $email;
    }

    protected static function mustIn($payload, $key, $allowed)
    {
        $value = trim((string) self::arrGet($payload, $key, ''));
        if (!in_array($value, (array) $allowed, true)) {
            throw new RuntimeException($key . '_invalid', 422);
        }
        return $value;
    }

    protected static function buyerKey($email)
    {
        return strtolower(trim((string) $email));
    }

    protected static function paidWhere($alias)
    {
        $alias = trim((string) $alias);
        if ($alias !== '') {
            $alias .= '.';
        }
        return "({$alias}status='paid' OR {$alias}payment_status='confirmed') AND {$alias}paid_at_utc IS NOT NULL";
    }

    protected static function extractPrimaryState($statesJson)
    {
        $statesJson = trim((string) $statesJson);
        if ($statesJson === '') {
            return '';
        }
        $decoded = json_decode($statesJson, true);
        if (is_array($decoded)) {
            foreach ($decoded as $value) {
                $value = strtoupper(trim((string) $value));
                if ($value !== '') {
                    return $value;
                }
            }
        }
        return '';
    }

    protected static function isProposalExpired($proposal)
    {
        $expiresAt = trim((string) self::arrGet($proposal, 'expires_at', ''));
        if ($expiresAt === '') {
            return false;
        }
        $ts = strtotime($expiresAt . ' UTC');
        if (!$ts) {
            $ts = strtotime($expiresAt);
        }
        return $ts && $ts < time();
    }

    protected static function sortEventsByCreatedAtDesc($a, $b)
    {
        return strcmp((string) self::arrGet($b, 'created_at', ''), (string) self::arrGet($a, 'created_at', ''));
    }

    protected static function sortProposalsByCreatedAtDesc($a, $b)
    {
        return strcmp((string) self::arrGet($b, 'created_at', ''), (string) self::arrGet($a, 'created_at', ''));
    }

    protected static function allowedProposalTypes()
    {
        return array(
            'followup_draft',
            'campaign_draft',
            'buyer_tag_change',
            'buyer_tag_remove',
            'homepage_cta_draft',
            'landing_content_draft',
            'reactivation_draft',
            'checkout_experiment_draft',
            'discount_code_draft',
            'article_patch',
            'module_patch',
            'component_config_patch',
            'internal_task',
            'internal_note',
        );
    }

    protected static function loadTaskItems()
    {
        $items = array();
        foreach ((array) glob(self::storagePath('tasks/*.json')) as $file) {
            $row = self::loadJson($file, array());
            if (is_array($row) && !empty($row['id'])) {
                $items[] = $row;
            }
        }
        return $items;
    }

    protected static function loadProposalItems()
    {
        $items = array();
        foreach ((array) glob(self::storagePath('proposals/*.json')) as $file) {
            $row = self::loadJson($file, array());
            if (is_array($row) && !empty($row['id'])) {
                $items[] = $row;
            }
        }
        return $items;
    }

    protected static function loadTagMap()
    {
        $all = self::loadJson(self::storagePath('tags/buyer_tags.json'), array());
        return is_array($all) ? $all : array();
    }

    protected static function getComponentVersion()
    {
        $manifest = JPATH_COMPONENT_ADMINISTRATOR . '/com_leadmarket.xml';
        if (!JFile::exists($manifest)) {
            return '';
        }
        $xml = @simplexml_load_file($manifest);
        if ($xml && isset($xml->version)) {
            return trim((string) $xml->version);
        }
        return '';
    }

    protected static function sortBuyerRowsByActivityDesc($a, $b)
    {
        $aDate = (string) self::arrGet($a, 'last_activity_at', self::arrGet($a, 'last_purchase_at', self::arrGet($a, 'created_at', '')));
        $bDate = (string) self::arrGet($b, 'last_activity_at', self::arrGet($b, 'last_purchase_at', self::arrGet($b, 'created_at', '')));
        return strcmp($bDate, $aDate);
    }

    protected static function sortByUpdatedAtDesc($a, $b)
    {
        $aDate = (string) self::arrGet($a, 'updated_at', self::arrGet($a, 'created_at', ''));
        $bDate = (string) self::arrGet($b, 'updated_at', self::arrGet($b, 'created_at', ''));
        return strcmp($bDate, $aDate);
    }

    protected static function server($key, $default)
    {
        return isset($_SERVER[$key]) ? $_SERVER[$key] : $default;
    }
}
