<?php
defined('_JEXEC') or die;
function LeadmarketBuildRoute(&$query){return array();}
function LeadmarketParseRoute($segments){return array();}
