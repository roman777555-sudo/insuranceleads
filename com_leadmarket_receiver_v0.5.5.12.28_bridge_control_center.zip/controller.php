<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketController extends JControllerLegacy
{
  protected $default_view = 'leads';

  public function __construct($config = array())
  {
    parent::__construct($config);
    $this->registerTask('cronverify', 'cronVerify');
    $this->registerTask('croncheckpayments', 'cronVerify');
    $this->registerTask('crondigest', 'cronDigest');
    $this->registerTask('crondailydigest', 'cronDigest');
    $this->registerTask('widget.market', 'widgetMarket');
    $this->registerTask('widget.marketmini', 'widgetMarketMini');
    $this->registerTask('widget.marketMini', 'widgetMarketMini');
    $this->registerTask('widgetmarket', 'widgetMarket');
    $this->registerTask('widgetmarketmini', 'widgetMarketMini');
    $this->registerTask('batchcheckoutsummary', 'batchCheckoutSummary');
    $this->registerTask('startbatchcheckout', 'startBatchCheckout');
    $this->registerTask('batchipaid', 'batchIPaid');
    $this->registerTask('cancelbatch', 'cancelBatch');
    $this->registerTask('checkbatchsummaryemail', 'checkBatchSummaryEmail');
    $this->registerTask('batchsummarysubmit', 'batchSummarySubmit');
    $this->registerTask('resendbatchaccesslinks', 'resendBatchAccessLinks');
    $this->registerTask('sample.view', 'sampleView');
    $this->registerTask('sampleview', 'sampleView');
    $this->registerTask('subscribe.add', 'subscribeAdd');
    $this->registerTask('subscribe.save', 'subscribeAdd');
    $this->registerTask('subscribe', 'subscribeAdd');
    $this->registerTask('freetest.unlock', 'freeTestUnlock');
    $this->registerTask('freetestunlock', 'freeTestUnlock');
    $this->registerTask('freetest.marketplaceClick', 'freeTestMarketplaceClick');
    $this->registerTask('freetestmarketplaceclick', 'freeTestMarketplaceClick');
    $this->registerTask('lead.buy', 'buy');
    $this->registerTask('lead.ipaid', 'ipaid');
    $this->registerTask('lead.cancelorder', 'cancelorder');
    $this->registerTask('access.requestlink', 'accessRequestLink');
    $this->registerTask('applypromo', 'applyPromo');
    $this->registerTask('accessrequestlink', 'accessRequestLink');
    $this->registerTask('dashboardhide', 'dashboardHide');
    $this->registerTask('creditrequest.submit', 'creditRequestSubmit');
    $this->registerTask('creditrequestsubmit', 'creditRequestSubmit');
    $this->registerTask('topup.create', 'createTopup');
    $this->registerTask('createtopup', 'createTopup');
    $this->registerTask('topup.ipaid', 'topupIPaid');
    $this->registerTask('topupipaid', 'topupIPaid');
    $this->registerTask('topup.cancel', 'topupCancel');
    $this->registerTask('topupcancel', 'topupCancel');
    $this->registerTask('topupstatus', 'topupStatus');
    $this->registerTask('topup.moneygramsubmit', 'topupMoneygramSubmit');
    $this->registerTask('topupmoneygramsubmit', 'topupMoneygramSubmit');
    $this->registerTask('topup.westernunionsubmit', 'topupMoneygramSubmit');
    $this->registerTask('topupwesternunionsubmit', 'topupMoneygramSubmit');
    $this->registerTask('paypalcreateorder', 'paypalCreateOrder');
    $this->registerTask('paypal.createorder', 'paypalCreateOrder');
    $this->registerTask('paypalcaptureorder', 'paypalCaptureOrder');
    $this->registerTask('paypal.captureorder', 'paypalCaptureOrder');
    $this->registerTask('paypalwebhook', 'paypalWebhook');
    $this->registerTask('paypal.webhook', 'paypalWebhook');
    $this->registerTask('leadunlockbalance', 'leadUnlockBalance');
    $this->registerTask('leadcreatelinkedtopup', 'leadCreateLinkedTopup');
    $this->registerTask('batchunlockbalance', 'batchUnlockBalance');
    $this->registerTask('batchcreatelinkedtopup', 'batchCreateLinkedTopup');
    LeadMarketHelper::ensureSchema();
  }



  protected function getLeadmarketAllowedCorsOrigin()
  {
    $app = JFactory::getApplication();
    $input = $app->input;
    $origin = trim((string)$input->server->getString('HTTP_ORIGIN', ''));
    if ($origin === '') {
      return '';
    }

    $allowed = array(
      'https://insuranceleads.co',
      'https://www.insuranceleads.co',
      'http://insuranceleads.co',
      'http://www.insuranceleads.co',
      'https://insureleadsus.com',
      'https://www.insureleadsus.com',
      'http://insureleadsus.com',
      'http://www.insureleadsus.com',
    );

    if (in_array($origin, $allowed, true)) {
      return $origin;
    }

    // subscribe.add is a public opt-in endpoint. Allowing any valid http/https
    // origin here lets future wrapper domains reuse the same AJAX flow without
    // another component rebuild, while still keeping the response origin-specific.
    $task = strtolower(trim((string)$input->getCmd('task', '')));
    if (in_array($task, array('subscribe.add', 'subscribe.save', 'subscribe'), true)) {
      $parts = @parse_url($origin);
      $scheme = isset($parts['scheme']) ? strtolower((string)$parts['scheme']) : '';
      $host = isset($parts['host']) ? trim((string)$parts['host']) : '';
      if (($scheme === 'https' || $scheme === 'http') && $host !== '') {
        return $origin;
      }
    }

    return '';
  }

  protected function sendLeadmarketSubscribeCorsHeaders()
  {
    $origin = $this->getLeadmarketAllowedCorsOrigin();
    if ($origin !== '' && !headers_sent()) {
      header('Access-Control-Allow-Origin: ' . $origin);
      header('Vary: Origin');
      header('Access-Control-Allow-Methods: POST, OPTIONS');
      header('Access-Control-Allow-Headers: Content-Type, X-Requested-With, Accept');
      header('Access-Control-Max-Age: 600');
    }

    return $origin;
  }

  protected function closeLeadmarketJsonResponse($payload, $statusCode = 200)
  {
    $app = JFactory::getApplication();
    $this->sendLeadmarketSubscribeCorsHeaders();
    if (!headers_sent()) {
      header('Content-Type: application/json; charset=utf-8');
      if ((int)$statusCode !== 200) {
        header('HTTP/1.1 ' . (int)$statusCode);
      }
    }
    echo json_encode($payload);
    $app->close();
  }


  protected function getAllRequestHeadersCompat()
  {
    if (function_exists('getallheaders')) {
      $headers = getallheaders();
      if (is_array($headers)) return $headers;
    }
    $headers = array();
    foreach ($_SERVER as $key => $value) {
      if (strpos($key, 'HTTP_') === 0) {
        $name = str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($key, 5)))));
        $headers[$name] = $value;
      }
    }
    if (isset($_SERVER['CONTENT_TYPE'])) $headers['Content-Type'] = $_SERVER['CONTENT_TYPE'];
    if (isset($_SERVER['CONTENT_LENGTH'])) $headers['Content-Length'] = $_SERVER['CONTENT_LENGTH'];
    return $headers;
  }

  protected function closeLeadmarketTextResponse($text, $statusCode = 200)
  {
    $app = JFactory::getApplication();
    if (!headers_sent()) {
      header('Content-Type: text/plain; charset=utf-8');
      header('HTTP/1.1 ' . (int) $statusCode);
    }
    echo (string) $text;
    $app->close();
  }

  protected function paypalFindTopupForWebhook($payload)
  {
    $event = is_array($payload) ? $payload : array();
    $resource = (array) ($event['resource'] ?? array());
    $orderId = trim((string) (($resource['supplementary_data']['related_ids']['order_id'] ?? '')));
    $topup = null;
    if ($orderId !== '') {
      $topup = LeadMarketHelper::loadTopupByPayPalOrderId($orderId);
    }
    if (!$topup) {
      $customId = '';
      if (!empty($resource['custom_id'])) $customId = (string) $resource['custom_id'];
      elseif (!empty($resource['purchase_units'][0]['custom_id'])) $customId = (string) $resource['purchase_units'][0]['custom_id'];
      $topupId = LeadMarketHelper::paypalParseTopupIdFromCustomId($customId);
      if ($topupId > 0) $topup = LeadMarketHelper::loadTopupById($topupId);
    }
    return $topup ?: null;
  }

  protected function paypalMarkTopupPaidFromPayload($topup, $payload, $source, $eventId = '')
  {
    $row = is_array($topup) ? $topup : (array) $topup;
    $topupId = (int) ($row['id'] ?? 0);
    if ($topupId <= 0) return array('ok' => false, 'message' => 'Invalid top-up.');
    $resource = (array) (($payload['resource'] ?? array()));
    $orderId = trim((string) (($resource['supplementary_data']['related_ids']['order_id'] ?? ($row['paypal_order_id'] ?? ''))));
    $captureId = trim((string) ($resource['id'] ?? ''));
    $paypalStatus = strtoupper(trim((string) ($resource['status'] ?? ($payload['summary'] ?? 'COMPLETED'))));
    $amountNode = (array) ($resource['amount'] ?? array());
    $currency = strtoupper(trim((string) ($amountNode['currency_code'] ?? 'USD')));
    $amount = (float) ($amountNode['value'] ?? 0);
    $expected = (float) (($row['requested_topup_amount_usd'] ?? 0) > 0 ? ($row['requested_topup_amount_usd'] ?? 0) : ($row['topup_amount_usd'] ?? 0));
    if ($currency !== 'USD') {
      return array('ok' => false, 'message' => 'Unexpected PayPal currency: ' . $currency);
    }
    if ($amount <= 0 || abs($amount - $expected) > 0.01) {
      return array('ok' => false, 'message' => 'PayPal amount mismatch. Expected ' . number_format($expected, 2, '.', '') . ' USD.');
    }
    $payerEmail = trim((string) (($payload['resource']['payer']['email_address'] ?? ($payload['payer']['email_address'] ?? ($row['paypal_payer_email'] ?? '')))));
    LeadMarketHelper::storeTopupPayPalMeta($topupId, array(
      'paypal_order_id' => $orderId !== '' ? $orderId : null,
      'paypal_capture_id' => $captureId !== '' ? $captureId : null,
      'paypal_payer_email' => $payerEmail !== '' ? $payerEmail : null,
      'paypal_status' => $paypalStatus !== '' ? $paypalStatus : null,
      'paypal_webhook_event_id' => $eventId !== '' ? $eventId : null,
      'paypal_payload_json' => json_encode($payload),
    ));
    if (strtolower((string) ($row['status'] ?? 'pending')) === 'paid') {
      return array('ok' => true, 'message' => 'Top-up already paid.');
    }
    $result = LeadMarketHelper::markTopupPaid($topupId, $source, array(
      'actor_type' => 'system',
      'credit_note' => 'PayPal payment completed',
      'verify_note' => 'PayPal payment captured. Order ' . $orderId . ', capture ' . $captureId . '.',
      'last_verify_result' => 'paypal_capture_completed',
      'last_verify_message' => 'PayPal capture completed successfully.',
      'payment_detected_utc' => gmdate('Y-m-d H:i:s'),
      'paypal_order_id' => $orderId,
      'paypal_capture_id' => $captureId,
      'paypal_payer_email' => $payerEmail,
      'paypal_status' => $paypalStatus,
      'paypal_webhook_event_id' => $eventId,
      'paypal_payload_json' => json_encode($payload),
    ));
    return is_array($result) ? $result : array('ok' => false, 'message' => 'Could not finalize PayPal top-up.');
  }


  public function applyPromo()
  {
    $app = JFactory::getApplication();
    if (strtoupper($app->input->server->getString('REQUEST_METHOD', 'GET')) === 'OPTIONS') {
      $this->sendLeadmarketSubscribeCorsHeaders();
      if (!headers_sent()) header('HTTP/1.1 204 No Content');
      $app->close();
    }
    JSession::checkToken('post') or $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Invalid token.'), 403);
    LeadMarketHelper::ensureSchema();
    $input = $app->input;
    $contextType = strtolower(trim((string) $input->post->getCmd('context_type', 'single')));
    LeadMarketHelper::trackEvent('promo_apply_attempt', array('page_name' => 'promo', 'context_type' => $contextType));
    $buyerEmail = LeadMarketHelper::resolveBuyerEmail((string) $input->post->getString('buyer_email', ''));
    $promoCode = (string) $input->post->getString('promo_code', '');
    if ($contextType === 'batch') {
      $csv = trim((string) $input->post->getString('selected_ids_csv', ''));
      $ids = array_values(array_unique(array_filter(array_map('intval', preg_split('/\s*,\s*/', $csv)))));
      $result = LeadMarketHelper::validateBatchPromoCode($promoCode, $ids, $buyerEmail);
    } else {
      $leadId = (int) $input->post->getInt('lead_id', 0);
      $saleMode = strtolower(trim((string) $input->post->getCmd('sale_mode', 'shared')));
      if (!in_array($saleMode, array('shared','exclusive'), true)) $saleMode = 'shared';
      $result = LeadMarketHelper::validateLeadPromoCode($promoCode, $leadId, $buyerEmail, $saleMode);
    }
    if (empty($result['ok'])) {
      LeadMarketHelper::trackEvent('promo_apply_fail', array('page_name' => 'promo', 'context_type' => $contextType, 'buyer_email' => $buyerEmail, 'lead_id' => isset($leadId)?(int)$leadId:0, 'props' => array('message' => (string) ($result['message'] ?? ''))));
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => (string) ($result['message'] ?? 'Promo code could not be applied.')));
    }
    $promo = (array) ($result['promo'] ?? array());
    $label = strtolower((string) ($result['discount_type'] ?? 'fixed')) === 'percent'
      ? rtrim(rtrim(number_format((float) ($result['discount_value'] ?? 0), 2, '.', ''), '0'), '.') . '% off'
      : '$' . number_format((float) ($result['discount_amount'] ?? 0), 2, '.', '') . ' off';
    LeadMarketHelper::trackEvent('promo_apply_success', array('page_name' => 'promo', 'context_type' => $contextType, 'buyer_email' => $buyerEmail, 'lead_id' => isset($leadId)?(int)$leadId:0, 'props' => array('promo_code' => (string) ($result['promo_code'] ?? ''), 'subtotal' => (float) ($result['subtotal'] ?? 0), 'final_total' => (float) ($result['final_total'] ?? 0))));
    $this->closeLeadmarketJsonResponse(array(
      'ok' => true,
      'promo_code' => (string) ($result['promo_code'] ?? LeadMarketHelper::normalizePromoCode($promoCode)),
      'promo_id' => (int) ($result['promo_id'] ?? 0),
      'discount_type' => (string) ($result['discount_type'] ?? ''),
      'discount_value' => (float) ($result['discount_value'] ?? 0),
      'discount_amount' => (float) ($result['discount_amount'] ?? 0),
      'subtotal' => (float) ($result['subtotal'] ?? 0),
      'final_total' => (float) ($result['final_total'] ?? 0),
      'label' => $label,
      'message' => (string) ($result['message'] ?? 'Discount added.')
    ));
  }

  public function cronVerify()
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();
    $params = LeadMarketHelper::params();
    if ((int)$params->get('background_verify_enabled', 0) !== 1) {
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(array('ok'=>false,'message'=>'BACKGROUND_VERIFY_DISABLED'));
      $app->close();
    }
    $secret = trim((string)$params->get('background_verify_secret', ''));
    $provided = trim((string)$app->input->getString('key', ''));
    if ($secret === '' || !hash_equals($secret, $provided)) {
      header('HTTP/1.1 403 Forbidden');
      header('Content-Type: application/json; charset=utf-8');
      echo json_encode(array('ok'=>false,'message'=>'FORBIDDEN'));
      $app->close();
    }
    $limit = (int)$app->input->getInt('limit', 0);
    $summary = LeadMarketHelper::runBackgroundVerify($limit > 0 ? $limit : null, 'cron');
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($summary);
    $app->close();
  }


  public function cronDigest()
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();
    $params = LeadMarketHelper::params();

    header('Content-Type: text/plain; charset=utf-8');

    if ((int)$params->get('daily_enabled', 1) !== 1) {
      echo 'daily_disabled';
      $app->close();
    }

    $secret = trim((string)$params->get('cron_key', ''));
    $provided = trim((string)$app->input->getString('key', ''));
    if ($secret === '' || !hash_equals($secret, $provided)) {
      header('HTTP/1.1 403 Forbidden');
      echo 'forbidden';
      $app->close();
    }

    try {
      $db = JFactory::getDbo();
      $now = LeadMarketHelper::nowUtc();

      $force = (int)$app->input->getInt('force', 0) === 1;
      $dailyTime = trim((string)$params->get('daily_time_utc', '10:00'));
      if (!preg_match('/^(\d{1,2}):(\d{2})$/', $dailyTime, $m)) {
        $dailyTime = '10:00';
        $m = array(0, '10', '00');
      }
      $targetHour = max(0, min(23, (int)$m[1]));
      $targetMinute = max(0, min(59, (int)$m[2]));
      if (!$force && ((int)$now->format('G') !== $targetHour || (int)$now->format('i') !== $targetMinute)) {
        echo 'digest_waiting_for_utc_time=' . sprintf('%02d:%02d', $targetHour, $targetMinute);
        $app->close();
      }

      $start = clone $now;
      $start->modify('-24 hours');

      $db->setQuery('SELECT * FROM #__leadmarket_lists');
      $lists = (array) $db->loadObjectList();
      $sent = 0;

      foreach ($lists as $list) {
        if (!is_object($list)) {
          continue;
        }

        if ((string)$list->name === 'General') {
          $q = $db->getQuery(true)
            ->select('*')->from('#__leadmarket_leads')
            ->where('uploaded_at_utc >= ' . $db->q($start->format('Y-m-d H:i:s')))
            ->where('lead_status IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')')
            ->where('COALESCE(is_sample,0)=0')
            ->order('uploaded_at_utc DESC, id DESC');
        } else {
          $state = strtoupper((string)$list->state);
          if ($state === '') {
            continue;
          }
          $q = $db->getQuery(true)
            ->select('*')->from('#__leadmarket_leads')
            ->where('uploaded_at_utc >= ' . $db->q($start->format('Y-m-d H:i:s')))
            ->where('state=' . $db->q($state))
            ->where('lead_status IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')')
            ->where('COALESCE(is_sample,0)=0')
            ->order('uploaded_at_utc DESC, id DESC');
        }

        $db->setQuery($q);
        $leads = (array) $db->loadAssocList();
        if (!$leads) {
          continue;
        }

        $byType = array('auto' => array(), 'home' => array());
        foreach ($leads as $lead) {
          $t = strtolower((string)$lead['type']);
          if (isset($byType[$t])) {
            $byType[$t][] = $lead;
          }
        }

        foreach (array('auto', 'home') as $t) {
          if (empty($byType[$t])) {
            continue;
          }

          $recipients = (array) LeadMarketHelper::getRecipientsForListIdFiltered((int)$list->id, $t, 'daily');
          if (!$recipients) {
            continue;
          }

          $cards = '';
          foreach ($byType[$t] as $lead) {
            $masked = LeadMarketHelper::buildMaskedPreview($lead);
            $leadUrl = JUri::root() . 'index.php?option=com_leadmarket&view=lead&id=' . (int)$lead['id'];
            $availabilityText = LeadMarketHelper::availabilityEmailText($lead);
            $saleOptions = LeadMarketHelper::buildSaleOptions($lead);
            $sharedPriceUsd = (string)($saleOptions['shared']['price_usd'] ?? number_format((float)$lead['price_usd'], 2, '.', ''));
            $exclusiveAvailable = !empty($saleOptions['exclusive']['enabled']);
            $exclusiveTeaserText = $exclusiveAvailable
              ? LeadMarketHelper::getExclusiveUpgradeTeaser($lead)
              : 'Exclusive access may be limited or unavailable for this lead.';
            $cards .= '<div style="border:1px solid #ddd;border-radius:10px;padding:12px;margin:10px 0;background:#fff">'
              . '<div style="font-size:17px;margin-bottom:6px;"><b>' . htmlspecialchars($masked['state']) . ' ' . htmlspecialchars($masked['type']) . ' lead</b></div>'
              . '<div style="color:#666;font-size:13px;">' . htmlspecialchars($masked['city']) . ' ' . htmlspecialchars($masked['state']) . ' ' . htmlspecialchars($masked['zip']) . ' • ' . htmlspecialchars($masked['phone_masked']) . '</div>'
              . '<ul style="margin:10px 0 0 18px;line-height:1.7;">'
              . '<li><b>Shared price:</b> from $' . htmlspecialchars($sharedPriceUsd) . ' (Pay in USDT TRC20)</li>'
              . '<li><b>Exclusive option:</b> ' . htmlspecialchars($exclusiveTeaserText) . '</li>'
              . '<li><b>Availability:</b> ' . htmlspecialchars($availabilityText) . '</li>'
              . '</ul>'
              . '<div style="margin-top:12px;"><a rel="nofollow" href="' . htmlspecialchars($leadUrl) . '" style="display:inline-block;padding:10px 14px;background:#0c5585;color:#fff;text-decoration:none;border-radius:8px;">Review Lead</a></div>'
              . '</div>';
          }

          foreach ($recipients as $toEmail) {
            $context = array(
              'headline' => (($list->state ? strtoupper((string)$list->state) : 'ALL') . ' ' . ($t === 'home' ? 'Home' : 'Auto') . ' Leads Digest'),
              'now_utc' => $now->format('Y-m-d H:i') . ' UTC',
              'leads_html' => $cards,
              'state' => $list->state ? strtoupper($list->state) : 'ALL',
              'type' => strtoupper($t),
              'type_label' => ($t === 'home' ? 'Home' : 'Auto'),
              'count' => (string)count($byType[$t]),
              'list_name' => $list->name,
              'market_url' => LeadMarketHelper::getMarketplaceUrl(true),
              'unsubscribe_url' => LeadMarketHelper::buildUnsubscribeUrl($toEmail),
            );

            $rendered = LeadMarketHelper::renderEmail('daily', $context);
            $mailer = LeadMarketHelper::getMailer();
            $mailer->clearAllRecipients();
            $mailer->addRecipient($toEmail);
            $mailer->setSubject($rendered['subject']);
            $mailer->setBody($rendered['body']);

            try {
              $ok = $mailer->Send();
              if ($ok === true) {
                LeadMarketHelper::logEmail(0, (int)$list->id, $toEmail, $rendered['subject'], 'sent', '');
                $sent++;
              } else {
                LeadMarketHelper::logEmail(0, (int)$list->id, $toEmail, $rendered['subject'], 'error', is_object($ok) && isset($ok->message) ? $ok->message : 'send failed');
              }
            } catch (Exception $mailEx) {
              LeadMarketHelper::logEmail(0, (int)$list->id, $toEmail, $rendered['subject'], 'error', $mailEx->getMessage());
            }
          }
        }
      }

      echo 'digest_sent=' . (int)$sent;
    } catch (Exception $e) {
      header('HTTP/1.1 500 Internal Server Error');
      echo 'digest_error: ' . $e->getMessage();
    } catch (Error $e) {
      header('HTTP/1.1 500 Internal Server Error');
      echo 'digest_error: ' . $e->getMessage();
    }

    $app->close();
  }


  public function batchCheckoutSummary()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    $input = $app->input;
    $ids = array();
    if (isset($_POST['selected_ids'])) {
      $raw = $_POST['selected_ids'];
      if (is_array($raw)) {
        $ids = $raw;
      } elseif (is_string($raw) && $raw !== '') {
        $ids = preg_split('/\s*,\s*/', $raw);
      }
    }
    if (!$ids) {
      $csv = '';
      if (isset($_POST['selected_ids_csv'])) {
        $csv = trim((string)$_POST['selected_ids_csv']);
      }
      if ($csv === '') {
        $csv = trim((string)$input->post->getString('selected_ids_csv', ''));
      }
      if ($csv !== '') {
        $ids = preg_split('/\s*,\s*/', $csv);
      }
    }
    if (!$ids) {
      $ids = (array)$input->post->get('selected_ids', array(), 'array');
    }
    $ids = array_values(array_unique(array_filter(array_map('intval', (array)$ids))));
    $session = JFactory::getSession();
    $session->set('lm.shared_selection_ids', $ids, 'com_leadmarket');
    LeadMarketHelper::trackEvent('batch_summary_view', array('page_name' => 'batch_summary', 'props' => array('selected_count' => count($ids))));
    if (!$ids) {
      $app->enqueueMessage('Please select at least one shared lead before continuing.', 'error');
      $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
      return false;
    }
    $this->setRedirect(LeadMarketHelper::buildBatchSummaryUrl($ids));
    return true;
  }



  protected function redirectBatchSummaryWithState($ids, $buyerEmail, $notice = '', $tone = 'warn', $showResend = 0)
  {
    $extra = array();
    if ($notice !== '') $extra['summary_notice'] = $notice;
    if ($tone !== '') $extra['summary_tone'] = $tone;
    if ((int)$showResend === 1) $extra['show_resend'] = '1';
    $this->setRedirect(LeadMarketHelper::buildBatchSummaryUrl($ids, $buyerEmail, $extra));
    return false;
  }

  public function batchSummarySubmit()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    LeadMarketHelper::cleanupExpiredOrders();
    LeadMarketHelper::cleanupExpiredBatches();

    $buyerEmail = trim((string)$app->input->post->getString('buyer_email', ''));
    $session = JFactory::getSession();
    $csv = trim((string)$app->input->post->getString('selected_ids_csv', ''));
    $ids = array();
    if ($csv !== '') {
      $ids = array_values(array_unique(array_filter(array_map('intval', preg_split('/\s*,\s*/', $csv)))));
    }
    if (!$ids) {
      $ids = (array)$session->get('lm.shared_selection_ids', array(), 'com_leadmarket');
      $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    }
    $session->set('lm.shared_selection_ids', $ids, 'com_leadmarket');
    $session->set('lm.batch_buyer_email', $buyerEmail, 'com_leadmarket');
    $session->set('lm.batch_promo_code', trim((string)$app->input->post->getString('promo_code', '')), 'com_leadmarket');

    if (!$ids) {
      $session->set('lm.batch_error_notice', 'Please select at least one shared lead before continuing.', 'com_leadmarket');
      $session->set('lm.batch_error_tone', 'error', 'com_leadmarket');
      return $this->redirectBatchSummaryWithState($ids, $buyerEmail, 'Please select at least one shared lead before continuing.', 'error');
    }
    if (!filter_var($buyerEmail, FILTER_VALIDATE_EMAIL)) {
      $session->set('lm.batch_error_notice', 'Please enter a valid buyer email before continuing.', 'com_leadmarket');
      $session->set('lm.batch_error_tone', 'error', 'com_leadmarket');
      return $this->redirectBatchSummaryWithState($ids, $buyerEmail, 'Please enter a valid buyer email before continuing.', 'error');
    }

    $summary = LeadMarketHelper::getSharedBatchEmailEligibilitySummary($ids, $buyerEmail);
    if (!empty($summary['all_purchased'])) {
      $session->set('lm.batch_error_notice', 'You already purchased all selected leads with this buyer email. Use the button below to resend access links if needed.', 'com_leadmarket');
      $session->set('lm.batch_error_tone', 'error', 'com_leadmarket');
      return $this->redirectBatchSummaryWithState($ids, $buyerEmail, 'You already purchased all selected leads with this buyer email. Use the button below to resend access links if needed.', 'error', 1);
    }
    if (!empty($summary['disable_submit']) && (int)($summary['eligible_count'] ?? 0) <= 0) {
      $notice = (string)($summary['message'] ?? 'No eligible leads remain for this buyer email.');
      $tone = (string)($summary['tone'] ?? 'warn');
      $session->set('lm.batch_error_notice', $notice, 'com_leadmarket');
      $session->set('lm.batch_error_tone', $tone, 'com_leadmarket');
      return $this->redirectBatchSummaryWithState($ids, $buyerEmail, $notice, $tone);
    }

    return $this->startBatchCheckout();
  }

  public function resendBatchAccessLinks()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    $buyerEmail = trim((string)$app->input->post->getString('buyer_email', ''));
    $csv = trim((string)$app->input->post->getString('selected_ids_csv', ''));
    $ids = array_values(array_unique(array_filter(array_map('intval', preg_split('/\s*,\s*/', $csv)))));
    $session = JFactory::getSession();
    $session->set('lm.shared_selection_ids', $ids, 'com_leadmarket');
    $session->set('lm.batch_buyer_email', $buyerEmail, 'com_leadmarket');

    $result = LeadMarketHelper::sendSelectedLeadAccessLinksAgain($ids, $buyerEmail);
    if (!empty($result['ok'])) {
      $notice = 'Access links were sent again to ' . $buyerEmail . '.';
      $tone = 'success';
      $session->set('lm.batch_error_notice', $notice, 'com_leadmarket');
      $session->set('lm.batch_error_tone', $tone, 'com_leadmarket');
      return $this->redirectBatchSummaryWithState($ids, $buyerEmail, $notice, $tone, 1);
    }
    $notice = (string)($result['message'] ?? 'We could not resend access links for this email.');
    $tone = 'error';
    $session->set('lm.batch_error_notice', $notice, 'com_leadmarket');
    $session->set('lm.batch_error_tone', $tone, 'com_leadmarket');
    return $this->redirectBatchSummaryWithState($ids, $buyerEmail, $notice, $tone, 1);
  }

  public function startBatchCheckout()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    LeadMarketHelper::cleanupExpiredOrders();
    LeadMarketHelper::cleanupExpiredBatches();
    $buyerEmail = trim((string)$app->input->post->getString('buyer_email', ''));
    $session = JFactory::getSession();
    $csv = trim((string)$app->input->post->getString('selected_ids_csv', ''));
    $ids = array();
    if ($csv !== '') {
      $ids = array_values(array_unique(array_filter(array_map('intval', preg_split('/\s*,\s*/', $csv)))));
    }
    if (!$ids) {
      $ids = (array)$session->get('lm.shared_selection_ids', array(), 'com_leadmarket');
      $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    }
    $session->set('lm.shared_selection_ids', $ids, 'com_leadmarket');
    $session->set('lm.batch_buyer_email', $buyerEmail, 'com_leadmarket');
    $promoCode = trim((string)$app->input->post->getString('promo_code', ''));
    if ($promoCode === '') { $promoCode = trim((string)$session->get('lm.batch_promo_code', '', 'com_leadmarket')); }
    $promoPayload = array();
    if ($promoCode !== '') {
      $promoCheck = LeadMarketHelper::validateBatchPromoCode($promoCode, $ids, $buyerEmail);
      if (!empty($promoCheck['ok'])) {
        $promoPayload = array('promo_code' => (string) ($promoCheck['promo_code'] ?? $promoCode), 'promo_id' => (int) ($promoCheck['promo_id'] ?? 0), 'discount_type' => (string) ($promoCheck['discount_type'] ?? ''), 'discount_value' => (float) ($promoCheck['discount_value'] ?? 0), 'discount_amount' => (float) ($promoCheck['discount_amount'] ?? 0), 'subtotal' => (float) ($promoCheck['subtotal'] ?? 0), 'final_total' => (float) ($promoCheck['final_total'] ?? 0));
      }
    }
    $res = LeadMarketHelper::createSharedBatchCheckout($ids, $buyerEmail, $promoPayload);
    if (empty($res['ok'])) {
      $ap = (int)($res['already_purchased_count'] ?? 0);
      $ac = (int)($res['active_checkout_count'] ?? 0);
      $rv = (int)($res['reserved_count'] ?? 0);
      $ne = (int)($res['not_eligible_count'] ?? 0);
      $requested = (int)($res['requested_count'] ?? count($ids));
      $message = (string)($res['message'] ?? 'Unable to create shared checkout.');
      $tone = 'warn';
      if ($requested > 0 && $ap === $requested && $ac === 0 && $rv === 0 && $ne === 0) {
        $message = 'You already purchased all selected leads with this buyer email. No new shared checkout is needed.';
        $tone = 'error';
      } elseif ($requested > 0 && $ac === $requested && $ap === 0 && $rv === 0 && $ne === 0) {
        $message = 'All selected leads are already inside an unfinished checkout for this buyer email.';
        $tone = 'warn';
      } elseif (stripos($message, 'valid buyer email') !== false) {
        $tone = 'error';
      }
      $session->set('lm.batch_error_notice', $message, 'com_leadmarket');
      $session->set('lm.batch_error_tone', $tone, 'com_leadmarket');
      if ($ap > 0 || $ac > 0 || $rv > 0 || $ne > 0) {
        $bits = array();
        if ($requested > 0 && $ap === $requested && $ac === 0 && $rv === 0 && $ne === 0) {
          $bits[] = 'all selected leads are already available for this buyer email';
        } else {
          if ($ap > 0) $bits[] = $ap . ' already available for this buyer email';
          if ($ac > 0) $bits[] = $ac . ' already in an unfinished checkout';
          if ($rv > 0) $bits[] = $rv . ' protected by an exclusive access window';
          if ($ne > 0) $bits[] = $ne . ' no longer eligible for shared checkout';
        }
        $session->set('lm.batch_removed_notice', 'Selection review: ' . implode('; ', $bits) . '.', 'com_leadmarket');
      }
      return $this->redirectBatchSummaryWithState($ids, $buyerEmail, $message, $tone, ($requested > 0 && $ap === $requested && $ac === 0 && $rv === 0 && $ne === 0) ? 1 : 0);
    }
    if (!empty($res['removed_count'])) {
      $notice = '';
      $ap = (int)($res['already_purchased_count'] ?? 0);
      $ac = (int)($res['active_checkout_count'] ?? 0);
      $rv = (int)($res['reserved_count'] ?? 0);
      $ne = (int)($res['not_eligible_count'] ?? 0);
      if ($ap > 0 && $ac > 0 && $rv > 0 && $ne > 0) {
        $notice = $ap . ' selected lead(s) already had access for this buyer email, ' . $ac . ' are already inside an unfinished checkout, ' . $rv . ' are protected during an exclusive access window, and ' . $ne . ' more lead(s) are no longer eligible for shared checkout.';
      } elseif ($ap > 0 && $ac > 0) {
        $notice = $ap . ' selected lead(s) already had access for this buyer email, and ' . $ac . ' more lead(s) are already inside an unfinished checkout.';
      } elseif ($ac > 0 && $rv > 0) {
        $notice = $ac . ' selected lead(s) are already inside an unfinished checkout, and ' . $rv . ' more lead(s) are protected during an exclusive access window.';
      } elseif ($ac > 0 && $ne > 0) {
        $notice = $ac . ' selected lead(s) are already inside an unfinished checkout, and ' . $ne . ' more lead(s) were removed because they are no longer eligible for shared checkout.';
      } elseif ($ap > 0 && $rv > 0 && $ne > 0) {
        $notice = $ap . ' selected lead(s) already had access for this buyer email, ' . $rv . ' are protected during an exclusive access window, and ' . $ne . ' more lead(s) are no longer eligible for shared checkout.';
      } elseif ($ap > 0 && $rv > 0) {
        $notice = $ap . ' selected lead(s) already had access for this buyer email, and ' . $rv . ' more lead(s) are protected during an exclusive access window.';
      } elseif ($ap > 0 && $ne > 0) {
        $notice = $ap . ' selected lead(s) already had access for this buyer email, and ' . $ne . ' more lead(s) were removed because they are no longer eligible for shared checkout.';
      } elseif ($rv > 0 && $ne > 0) {
        $notice = $rv . ' selected lead(s) are protected during an exclusive access window, and ' . $ne . ' more lead(s) are no longer eligible for shared checkout.';
      } elseif ($ap > 0) {
        $notice = $ap . ' selected lead(s) were removed because access is already available for this buyer email.';
      } elseif ($ac > 0) {
        $notice = $ac . ' selected lead(s) were removed because they are already inside an unfinished checkout for this buyer email.';
      } elseif ($rv > 0) {
        $notice = $rv . ' selected lead(s) were removed because they are protected during an exclusive access window.';
      } else {
        $notice = (int)$res['removed_count'] . ' selected lead(s) were removed because they are no longer eligible for shared checkout.';
      }
      $session->set('lm.batch_removed_notice', $notice, 'com_leadmarket');
    } else {
      $session->clear('lm.batch_removed_notice', 'com_leadmarket');
    }
    $session->set('lm.batch_adjustment_data', array(
      'requested_count' => (int)($res['requested_count'] ?? count($ids)),
      'removed_count' => (int)($res['removed_count'] ?? 0),
      'already_purchased_count' => (int)($res['already_purchased_count'] ?? 0),
      'active_checkout_count' => (int)($res['active_checkout_count'] ?? 0),
      'reserved_count' => (int)($res['reserved_count'] ?? 0),
      'not_eligible_count' => (int)($res['not_eligible_count'] ?? 0),
      'requested_eligible_total_usd' => (float)($res['requested_eligible_total_usd'] ?? 0),
      'final_total_usd' => (float)($res['final_total_usd'] ?? 0),
      'buyer_balance_before_usd' => (float)($res['buyer_balance_before_usd'] ?? 0),
      'wallet_amount_used_usd' => (float)($res['wallet_amount_used_usd'] ?? 0),
      'remaining_shortage_usd' => (float)($res['remaining_shortage_usd'] ?? 0),
      'exact_transfer_amount_usd' => (float)($res['exact_transfer_amount_usd'] ?? 0),
      'wallet_left_after_unlock_usd' => (float)($res['wallet_left_after_unlock_usd'] ?? 0),
      'included_preview' => (array)($res['included_preview'] ?? array()),
      'removed_preview' => (array)($res['removed_preview'] ?? array()),
    ), 'com_leadmarket');
    $session->clear('lm.shared_selection_ids', 'com_leadmarket');
    $session->clear('lm.batch_error_notice', 'com_leadmarket');
    $session->clear('lm.batch_buyer_email', 'com_leadmarket');
    $url = LeadMarketHelper::buildBatchUrl((int)$res['batch_id'], (string)$res['token']);
    $this->setRedirect(JRoute::_($url, false));
    return true;
  }


  public function checkBatchSummaryEmail()
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();
    LeadMarketHelper::cleanupExpiredOrders();
    LeadMarketHelper::cleanupExpiredBatches();

    $buyerEmail = trim((string)$app->input->getString('buyer_email', ''));
    $csv = trim((string)$app->input->getString('selected_ids_csv', ''));
    $session = JFactory::getSession();
    $ids = array();
    if ($csv !== '') {
      $ids = array_values(array_unique(array_filter(array_map('intval', preg_split('/\s*,\s*/', $csv)))));
    }
    if (!$ids) {
      $ids = (array)$session->get('lm.shared_selection_ids', array(), 'com_leadmarket');
      $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
    }

    $data = LeadMarketHelper::getSharedBatchEmailEligibilitySummary($ids, $buyerEmail);

    @header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    $app->close();
  }

  public function batchIPaid()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    $batchId = (int)$app->input->post->getInt('batch_id', 0);
    $token = trim((string)$app->input->post->getString('token', ''));
    if ($batchId <= 0) {
      $app->enqueueMessage('Invalid shared checkout request.', 'error');
      $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
      return false;
    }
    $batch = LeadMarketHelper::loadBatchById($batchId);
    if (!$batch || !LeadMarketHelper::canAccessBatch($batch, $token)) {
      $app->enqueueMessage('Access denied.', 'error');
      $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
      return false;
    }
    $status = strtolower((string)($batch['status'] ?? 'pending'));
    if (in_array($status, array('paid','cancelled','failed','expired'), true)) {
      $session = JFactory::getSession();
      $session->set('lm.batch_removed_notice', 'This shared checkout can no longer be updated.', 'com_leadmarket');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildBatchUrl($batchId, $token), false));
      return true;
    }
    $db = JFactory::getDbo();
    $now = gmdate('Y-m-d H:i:s');
    $q = $db->getQuery(true)
      ->update('#__leadmarket_batches')
      ->set('status=' . $db->q('submitted'))
      ->set('payment_status=' . $db->q('checking'))
      ->set('submitted_at_utc=' . $db->q($now))
      ->set('checking_started_utc=' . $db->q($now))
      ->set('verify_note=' . $db->q('Buyer clicked I Paid at ' . $now . ' UTC'))
      ->where('id=' . (int)$batchId);
    $db->setQuery($q)->execute();
    LeadMarketHelper::logBatchEvent($batchId, 'buyer_marked_paid', 'Buyer clicked I Paid for shared batch checkout.', array(), 'buyer', (string)($batch['buyer_email'] ?? ''));
    $session = JFactory::getSession();
    $session->set('lm.batch_removed_notice', 'Payment has been marked as sent. We are checking the batch transfer now.', 'com_leadmarket');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildBatchUrl($batchId, $token), false));
    return true;
  }

  public function cancelBatch()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    $batchId = (int)$app->input->post->getInt('batch_id', 0);
    $token = trim((string)$app->input->post->getString('token', ''));
    if ($batchId <= 0) {
      $app->enqueueMessage('Invalid shared checkout request.', 'error');
      $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
      return false;
    }
    $batch = LeadMarketHelper::loadBatchById($batchId);
    if (!$batch || !LeadMarketHelper::canAccessBatch($batch, $token)) {
      $app->enqueueMessage('Access denied.', 'error');
      $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
      return false;
    }
    LeadMarketHelper::cancelSharedBatch($batch);
    $app->enqueueMessage('Shared checkout cancelled. Reserved leads were released if they were still pending.', 'message');
    $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
    return true;
  }


  public function widgetMarket()
  {
    $this->renderMarketWidget(false);
  }

  public function widgetMarketMini()
  {
    $this->renderMarketWidget(true);
  }

  protected function renderMarketWidget($forceMini = false)
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();
    $params = LeadMarketHelper::params();
    $input = $app->input;
    $layout = strtolower((string)$input->getCmd('layout', $forceMini ? 'mini' : 'full'));
    $mini = $forceMini || $layout === 'mini';
    $limitDefault = $mini ? max(1, (int)$params->get('mini_widget_limit', 5)) : 10;
    $hoursDefault = max(1, (int)$params->get('mini_widget_hours', 25));
    $embed = (int)$input->getInt('embed', 0) === 1;
    $linkTarget = $embed ? '_top' : '';
    $linkTargetAttr = $embed ? ' target="_top"' : '';
    $limit = (int)$input->getInt('limit', $limitDefault);
    $hours = (int)$input->getInt('hours', $hoursDefault);
    $limit = max(1, min($mini ? 12 : 50, $limit));
    $hours = max(1, min(168, $hours));
    $titleDefault = trim((string)$params->get('mini_widget_title', 'Latest Lead Activity'));
    if ($titleDefault === '') $titleDefault = 'Latest Lead Activity';
    $title = trim((string)$input->getString('title', $titleDefault));
    if ($title === '') $title = $titleDefault;

    $marketUrl = LeadMarketHelper::getMarketplaceUrl(false);
    header('Content-Type: text/html; charset=utf-8');

    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    echo '<style>';
    echo 'body{margin:0;font-family:Arial,sans-serif;background:#f6f9fc;color:#13232f}';
    echo '.lm-wrap{padding:' . ($mini ? '12px' : '18px') . ';box-sizing:border-box;position:relative}';
    echo '.lm-head{display:flex;justify-content:space-between;align-items:center;gap:12px;margin:0 0 10px}';
    echo '.lm-title{font-size:' . ($mini ? '20px' : '24px') . ';font-weight:700;color:#0c5585;margin:0}';
    echo '.lm-meta{font-size:12px;color:#607080}';
    echo '.lm-offer{display:flex;align-items:center;gap:8px;flex-wrap:wrap;background:#fff8ef;border:1px solid #eadfc7;border-radius:12px;padding:' . ($mini ? '8px 10px' : '9px 12px') . ';margin:0 0 12px;color:#6a5621;line-height:1.5;font-size:' . ($mini ? '12px' : '13px') . ';font-weight:600}';
    echo '.lm-offer__badge{display:inline-block;background:#fff;border:1px solid #eadfc7;color:#9a6711;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.03em}';
    echo '.lm-loading{display:flex;align-items:flex-start;gap:12px;background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:' . ($mini ? '12px' : '16px') . ';box-shadow:0 4px 16px rgba(12,85,133,.06);margin:0 0 ' . ($mini ? '8px' : '12px') . '}';
    echo '.lm-loading__spinner{width:18px;height:18px;border-radius:50%;border:2px solid #cfe0ec;border-top-color:#0c5585;animation:lmspin .8s linear infinite;flex:0 0 auto;margin-top:2px}';
    echo '.lm-loading__text{min-width:0}';
    echo '.lm-loading__title{font-size:' . ($mini ? '13px' : '15px') . ';font-weight:800;color:#0c5585;margin:0 0 5px}';
    echo '.lm-loading__sub{font-size:12px;color:#61717f;line-height:1.5;margin:0 0 10px}';
    echo '.lm-skeleton{display:grid;grid-template-columns:1fr;gap:8px}';
    echo '.lm-skeleton__line{height:10px;border-radius:999px;background:linear-gradient(90deg,#eef4f8 20%,#dfeaf2 50%,#eef4f8 80%);background-size:200% 100%;animation:lmshine 1.3s ease-in-out infinite}';
    echo '.lm-skeleton__line--short{width:42%}';
    echo '.lm-skeleton__line--mid{width:68%}';
    echo '.lm-skeleton__cards{display:grid;grid-template-columns:1fr;gap:' . ($mini ? '8px' : '10px') . ';margin-top:10px}';
    echo '.lm-skeleton__card{background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:' . ($mini ? '12px' : '14px') . ';box-shadow:0 3px 10px rgba(12,85,133,.04)}';
    echo '@keyframes lmspin{to{transform:rotate(360deg)}}';
    echo '@keyframes lmshine{0%{background-position:200% 0}100%{background-position:-200% 0}}';
    echo '.lm-list{display:grid;grid-template-columns:1fr;gap:10px}';
    echo '.lm-card{background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:' . ($mini ? '12px' : '14px') . ';box-shadow:0 3px 10px rgba(12,85,133,.04)}';
    echo '.lm-row{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}';
    echo '.lm-name{font-size:' . ($mini ? '17px' : '20px') . ';font-weight:700;margin:0 0 6px;color:#13232f}';
    echo '.lm-sub{font-size:13px;color:#61717f;margin:0 0 8px}';
    echo '.lm-badge{display:inline-block;background:#eef7fd;color:#0c5585;border-radius:999px;padding:5px 9px;font-size:12px;font-weight:700;white-space:nowrap}';
    echo '.lm-points{margin:0;padding-left:18px;color:#253744;line-height:1.6;font-size:' . ($mini ? '13px' : '14px') . '}';
    echo '.lm-footer{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-top:12px}';
    echo '.lm-btn{display:inline-block;background:#0c5585;color:#fff;text-decoration:none;border-radius:9px;padding:' . ($mini ? '9px 12px' : '10px 14px') . ';font-size:14px;font-weight:700}';
    echo '.lm-link{font-size:13px;color:#0c5585;text-decoration:none;font-weight:700}';
    echo '.lm-empty{background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:18px;color:#50616d}';
    echo '</style></head><body>';
    echo '<div class="lm-wrap">';
    echo '<div id="lm-widget-loader" class="lm-loading"><div class="lm-loading__spinner" aria-hidden="true"></div><div class="lm-loading__text"><div class="lm-loading__title">Loading recent leads…</div><div class="lm-loading__sub">Fetching the latest masked marketplace activity.</div><div class="lm-skeleton"><div class="lm-skeleton__line"></div><div class="lm-skeleton__line lm-skeleton__line--mid"></div><div class="lm-skeleton__line lm-skeleton__line--short"></div></div><div class="lm-skeleton__cards"><div class="lm-skeleton__card"><div class="lm-skeleton"><div class="lm-skeleton__line"></div><div class="lm-skeleton__line lm-skeleton__line--mid"></div><div class="lm-skeleton__line lm-skeleton__line--short"></div></div></div>' . ($mini ? '' : '<div class="lm-skeleton__card"><div class="lm-skeleton"><div class="lm-skeleton__line"></div><div class="lm-skeleton__line lm-skeleton__line--mid"></div><div class="lm-skeleton__line lm-skeleton__line--short"></div></div></div>') . '</div></div></div>';
    echo str_repeat(' ', 8192);
    if (function_exists('flush')) { @flush(); }
    if (function_exists('ob_flush')) { @ob_flush(); }
    $db = JFactory::getDbo();
    $start = LeadMarketHelper::nowUtc();
    $start->modify('-' . $hours . ' hours');

    $q = $db->getQuery(true)
      ->select('*')
      ->from('#__leadmarket_leads')
      ->where('uploaded_at_utc >= ' . $db->q($start->format('Y-m-d H:i:s')))
      ->where('lead_status IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')')
      ->where('COALESCE(is_sample,0)=0')
      ->order('uploaded_at_utc DESC, id DESC');
    $db->setQuery($q, 0, $limit);
    $leads = (array)$db->loadAssocList();
    echo LeadMarketHelper::renderOpeningPromoBar('lm-offer', 'lm-offer__badge');
    echo '<div class="lm-head"><div><h1 class="lm-title">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h1><div class="lm-meta">Latest masked leads from the last ' . (int)$hours . ' hours</div></div>';
    if (!$mini) echo '<a class="lm-link" href="' . htmlspecialchars($marketUrl, ENT_QUOTES, 'UTF-8') . '">Open marketplace</a>';
    echo '</div>';

    if (!$leads) {
      echo '<div class="lm-empty">No recent masked leads available right now.</div>';
    } else {
      echo '<div class="lm-list">';
      foreach ($leads as $lead) {
        $masked = LeadMarketHelper::buildMaskedPreview($lead);
        $saleOptions = LeadMarketHelper::buildSaleOptions($lead);
        $sharedPriceUsd = (string)($saleOptions['shared']['price_usd'] ?? number_format((float)$lead['price_usd'], 2, '.', ''));
        $availabilityText = LeadMarketHelper::availabilityEmailText($lead);
        $leadUrl = JUri::root() . 'index.php?option=com_leadmarket&view=lead&id=' . (int)$lead['id'];
        $tier = LeadMarketHelper::stateTierLabel((string)($lead['state'] ?? ''));
        $typeLabel = strtoupper((string)$masked['state']) . ' ' . strtoupper((string)$masked['type']) . ' lead';
        $loc = trim($masked['city'] . ' ' . $masked['state'] . ' ' . $masked['zip']);
        $exclusiveLine = !empty($saleOptions['exclusive']['enabled'])
          ? LeadMarketHelper::getExclusiveUpgradeTeaser($lead)
          : 'Exclusive access may be limited or unavailable.';
        echo '<div class="lm-card">';
        echo '<div class="lm-row"><div><div class="lm-name">' . htmlspecialchars($typeLabel, ENT_QUOTES, 'UTF-8') . '</div><div class="lm-sub">' . htmlspecialchars($loc, ENT_QUOTES, 'UTF-8') . ' • ' . htmlspecialchars($masked['phone_masked'], ENT_QUOTES, 'UTF-8') . '</div></div><span class="lm-badge">' . htmlspecialchars($tier, ENT_QUOTES, 'UTF-8') . '</span></div>';
        echo '<ul class="lm-points">';
        echo '<li><b>Shared price:</b> from $' . htmlspecialchars($sharedPriceUsd, ENT_QUOTES, 'UTF-8') . '</li>';
        if (!$mini) echo '<li><b>Exclusive:</b> ' . htmlspecialchars($exclusiveLine, ENT_QUOTES, 'UTF-8') . '</li>';
        echo '<li><b>Availability:</b> ' . htmlspecialchars($availabilityText, ENT_QUOTES, 'UTF-8') . '</li>';
        $freshnessLabel = LeadMarketHelper::getLeadFreshnessLabel($lead);
        if ($freshnessLabel !== '') echo '<li><b>Freshness:</b> ' . htmlspecialchars($freshnessLabel, ENT_QUOTES, 'UTF-8') . '</li>';
        echo '</ul>';
        echo '<div class="lm-footer"><a class="lm-btn" rel="nofollow" href="' . htmlspecialchars($leadUrl, ENT_QUOTES, 'UTF-8') . '">Review Lead</a>';
        if ($mini) echo '<a class="lm-link" href="' . htmlspecialchars($marketUrl, ENT_QUOTES, 'UTF-8') . '">More leads</a>';
        echo '</div>';
        echo '</div>';
      }
      echo '</div>';
    }

    echo '<script>(function(){var loader=document.getElementById("lm-widget-loader");if(loader){loader.style.display="none";}})();</script>';
    echo '</div></body></html>';
    $app->close();
  }



  public function sampleView()
  {
    $app = JFactory::getApplication();
    $input = $app->input;
    $type = strtolower(trim((string)$input->getCmd('type', 'auto')));
    if ($type !== 'auto' && $type !== 'home') $type = 'auto';

    LeadMarketHelper::ensureSchema();
    $lead = LeadMarketHelper::getSampleLeadByType($type);
    if (!$lead || empty($lead['id'])) {
      $marketUrl = JRoute::_('index.php?option=com_leadmarket&view=leads', false);
      if (!headers_sent()) {
        header('Content-Type: text/html; charset=utf-8');
        header('X-Robots-Tag: noindex, nofollow', true);
      }
      echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex, nofollow"><title>Sample Lead</title><style>body{font-family:Arial,sans-serif;background:#f6f9fc;color:#13232f;padding:30px}.box{max-width:760px;margin:0 auto;background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:24px;box-shadow:0 14px 32px rgba(16,54,82,.08)}a{color:#0c5585;text-decoration:none}</style></head><body><div class="box"><h1 style="margin:0 0 12px;color:#0c5585">Sample Lead Not Available</h1><p>No active sample lead was found for this category.</p><p><a href="' . htmlspecialchars($marketUrl, ENT_QUOTES, 'UTF-8') . '">Open Marketplace</a></p></div></body></html>';
      $app->close();
      return;
    }

    $url = JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$lead['id'] . '&sample=1', false);
    $app->redirect($url);
    $app->close();
  }

  public function subscribeAdd()
  {
    $app = JFactory::getApplication();
    $input = $app->input;
    LeadMarketHelper::ensureSchema();

    $isAjax = ((int)$input->getInt('ajax', 0) === 1)
      || (strtolower(trim((string)$input->server->getString('HTTP_X_REQUESTED_WITH', ''))) === 'xmlhttprequest')
      || (stripos((string)$input->server->getString('HTTP_ACCEPT', ''), 'application/json') !== false);

    if (strtoupper(trim((string)$input->server->getString('REQUEST_METHOD', 'GET'))) === 'OPTIONS') {
      $this->sendLeadmarketSubscribeCorsHeaders();
      if (!headers_sent()) {
        header('HTTP/1.1 204 No Content');
      }
      $app->close();
    }

    if ($isAjax) {
      $this->sendLeadmarketSubscribeCorsHeaders();
    }

    $email = trim((string)$input->getString('email', ''));
    if ($email === '') $email = trim((string)$input->post->getString('buyer_email', ''));
    if ($email === '' && isset($_POST['email'])) $email = trim((string)$_POST['email']);

    $returnUrl = trim((string)$input->get('return', '', 'raw'));
    if ($returnUrl === '') $returnUrl = trim((string)$input->server->getString('HTTP_REFERER', ''));
    if ($returnUrl === '') $returnUrl = LeadMarketHelper::getMarketplaceUrl(false);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      if ($isAjax) {
        $this->closeLeadmarketJsonResponse(array(
          'ok' => false,
          'message' => 'Please enter a valid email address.',
          'code' => 'INVALID_EMAIL',
        ), 400);
      }
      $app->enqueueMessage('Please enter a valid email address.', 'error');
      $this->setRedirect($returnUrl);
      return false;
    }

    $mode = strtolower(trim((string)$input->getString('mode', '')));
    if ($mode === '') $mode = strtolower(trim((string)$input->getString('delivery_mode', '')));
    if ($mode === '') $mode = strtolower(trim((string)$input->getString('frequency', '')));
    if (!in_array($mode, array('instant','daily','both'), true)) $mode = 'both';

    $leadType = strtolower(trim((string)$input->getString('lead_type', '')));
    if ($leadType === '') $leadType = strtolower(trim((string)$input->getString('type', '')));
    if (!in_array($leadType, array('auto','home','both','all'), true)) $leadType = 'both';

    $states = array();
    foreach (array('state','state_code') as $key) {
      $val = strtoupper(trim((string)$input->getString($key, '')));
      if ($val !== '') $states[] = $val;
    }
    foreach (array('states','state_codes') as $key) {
      $vals = (array)$input->get($key, array(), 'array');
      foreach ($vals as $val) {
        $val = strtoupper(trim((string)$val));
        if ($val !== '') $states[] = $val;
      }
      $raw = trim((string)$input->get($key, '', 'raw'));
      if ($raw !== '') {
        foreach (preg_split('/[\s,;]+/', $raw) as $val) {
          $val = strtoupper(trim((string)$val));
          if ($val !== '') $states[] = $val;
        }
      }
    }
    $states = array_values(array_unique(array_filter($states, function($s){ return (bool)preg_match('/^[A-Z]{2}$/', $s); })));

    try {
      $db = JFactory::getDbo();
      $db->setQuery('SELECT * FROM #__leadmarket_subscribers WHERE email=' . $db->q($email), 0, 1);
      $subscriber = (array)$db->loadAssoc();
      $alreadySubscribed = !empty($subscriber);
      $now = LeadMarketHelper::nowUtc()->format('Y-m-d H:i:s');
      $token = substr(md5($email . '|' . $now . '|' . mt_rand()), 0, 32);
      if ($alreadySubscribed) {
        $subscriberId = (int)$subscriber['id'];
        $q = $db->getQuery(true)
          ->update('#__leadmarket_subscribers')
          ->set('mode=' . $db->q($mode))
          ->set('lead_type=' . $db->q($leadType))
          ->set('is_active=1')
          ->where('id=' . (int)$subscriberId);
        $db->setQuery($q)->execute();
      } else {
        $q = $db->getQuery(true)
          ->insert('#__leadmarket_subscribers')
          ->columns(array('email','mode','lead_type','is_active','cooldown_minutes','unsubscribe_token','created_at'))
          ->values($db->q($email) . ',' . $db->q($mode) . ',' . $db->q($leadType) . ',1,5,' . $db->q($token) . ',' . $db->q($now));
        $db->setQuery($q)->execute();
        $subscriberId = (int)$db->insertid();
      }

      $listIds = array();
      if ($states) {
        foreach ($states as $state) {
          $listIds[] = (int)LeadMarketHelper::ensureList('State: ' . $state, $state);
        }
      } else {
        $listIds[] = (int)LeadMarketHelper::ensureList('General', null);
      }
      $listIds = array_values(array_unique(array_filter(array_map('intval', $listIds))));

      $db->setQuery('DELETE FROM #__leadmarket_subscriber_lists WHERE subscriber_id=' . (int)$subscriberId)->execute();
      foreach ($listIds as $listId) {
        $q = $db->getQuery(true)
          ->insert('#__leadmarket_subscriber_lists')
          ->columns(array('subscriber_id','list_id'))
          ->values((int)$subscriberId . ',' . (int)$listId);
        $db->setQuery($q)->execute();
      }

      $scope = $states ? ('state alerts for ' . implode(', ', $states)) : 'marketplace alerts';
      $message = $alreadySubscribed
        ? ('This email is already subscribed. Preferences were updated for ' . $email . ' (' . $scope . ').')
        : ('Subscription saved for ' . $email . ' (' . $scope . ').');

      if ($isAjax) {
        $this->closeLeadmarketJsonResponse(array(
          'ok' => true,
          'message' => $message,
          'already_subscribed' => $alreadySubscribed,
          'email' => $email,
          'scope' => $scope,
          'mode' => $mode,
          'lead_type' => $leadType,
          'states' => $states,
        ));
      }

      $app->enqueueMessage($message, 'message');
    } catch (Exception $e) {
      $message = 'Subscription could not be saved: ' . $e->getMessage();
      if ($isAjax) {
        $this->closeLeadmarketJsonResponse(array(
          'ok' => false,
          'message' => $message,
          'code' => 'SAVE_FAILED',
        ), 500);
      }
      $app->enqueueMessage($message, 'error');
    } catch (Error $e) {
      $message = 'Subscription could not be saved: ' . $e->getMessage();
      if ($isAjax) {
        $this->closeLeadmarketJsonResponse(array(
          'ok' => false,
          'message' => $message,
          'code' => 'SAVE_FAILED',
        ), 500);
      }
      $app->enqueueMessage($message, 'error');
    }

    $this->setRedirect($returnUrl);
    return true;
  }


  public function freeTestUnlock()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();

    $settings = LeadMarketHelper::getFreeTestSettings();
    $returnUrl = trim((string) $app->input->post->get('return', '', 'raw'));
    if ($returnUrl === '') $returnUrl = LeadMarketHelper::getFreeTestPageUrl(false);
    if (empty($settings['enabled'])) {
      $app->enqueueMessage('Free test leads are not enabled right now.', 'warning');
      $this->setRedirect($returnUrl);
      return false;
    }

    $email = trim((string) $app->input->post->getString('email', ''));
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $app->enqueueMessage('Please enter a valid email address.', 'error');
      $this->setRedirect($returnUrl);
      return false;
    }

    // Free test access always includes instant alerts. Keep backend authoritative
    // even if the frontend is bypassed or tampered with.
    $alertsOptin = 1;

    $leadType = LeadMarketHelper::normalizeFreeTestLeadType((string) $app->input->post->getCmd('lead_type', 'both'));
    $states = array();
    $stateCode = strtoupper(trim((string) $app->input->post->getString('state_code', '')));
    if ($stateCode !== '' && $stateCode !== 'ALL') $states[] = $stateCode;
    $states = LeadMarketHelper::normalizeFreeTestStates($states);
    $mode = 'instant';

    try {
      $db = JFactory::getDbo();
      $db->setQuery('SELECT * FROM #__leadmarket_subscribers WHERE email=' . $db->q($email), 0, 1);
      $subscriber = (array) $db->loadAssoc();
      $alreadySubscribed = !empty($subscriber);
      $now = LeadMarketHelper::nowUtc()->format('Y-m-d H:i:s');
      $token = substr(md5($email . '|' . $now . '|' . mt_rand()), 0, 32);
      if ($alreadySubscribed) {
        $subscriberId = (int) $subscriber['id'];
        $q = $db->getQuery(true)
          ->update('#__leadmarket_subscribers')
          ->set('mode=' . $db->q($mode))
          ->set('lead_type=' . $db->q($leadType))
          ->set('is_active=1')
          ->where('id=' . (int) $subscriberId);
        $db->setQuery($q)->execute();
      } else {
        $q = $db->getQuery(true)
          ->insert('#__leadmarket_subscribers')
          ->columns(array('email','mode','lead_type','is_active','cooldown_minutes','unsubscribe_token','created_at'))
          ->values($db->q($email) . ',' . $db->q($mode) . ',' . $db->q($leadType) . ',1,5,' . $db->q($token) . ',' . $db->q($now));
        $db->setQuery($q)->execute();
        $subscriberId = (int) $db->insertid();
      }

      $listIds = array();
      if ($states) {
        foreach ($states as $state) {
          $listIds[] = (int) LeadMarketHelper::ensureList('State: ' . $state, $state);
        }
      } else {
        $listIds[] = (int) LeadMarketHelper::ensureList('General', null);
      }
      $listIds = array_values(array_unique(array_filter(array_map('intval', $listIds))));
      $db->setQuery('DELETE FROM #__leadmarket_subscriber_lists WHERE subscriber_id=' . (int) $subscriberId)->execute();
      foreach ($listIds as $listId) {
        $q = $db->getQuery(true)
          ->insert('#__leadmarket_subscriber_lists')
          ->columns(array('subscriber_id','list_id'))
          ->values((int) $subscriberId . ',' . (int) $listId);
        $db->setQuery($q)->execute();
      }

      $access = LeadMarketHelper::createOrRefreshTrialAccess($email, $subscriberId, $leadType, $states, 'free_test_leads', $mode);
      if (!$access || empty($access['access_token'])) {
        throw new Exception('Could not create trial access.');
      }
      LeadMarketHelper::sendFreeTestWelcomeEmail($email, $access);
      $message = $alreadySubscribed
        ? 'Your alert preferences were updated and your free test leads are unlocked.'
        : 'Your free test leads are unlocked. Check your inbox for instant lead alerts.';
      $app->enqueueMessage($message, 'message');
      $redirect = LeadMarketHelper::getFreeTestPageUrl(false);
      $redirect .= (strpos($redirect, '?') === false ? '?' : '&') . 'trial_token=' . urlencode((string) $access['access_token']);
      $this->setRedirect($redirect);
      return true;
    } catch (Exception $e) {
      $app->enqueueMessage('Free test leads could not be unlocked: ' . $e->getMessage(), 'error');
      $this->setRedirect($returnUrl);
      return false;
    }
  }


  public function freeTestMarketplaceClick()
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();
    $token = trim((string) $app->input->getString('trial_token', ''));
    if ($token !== '') {
      LeadMarketHelper::touchTrialMarketplaceClick($token);
    }
    $target = trim((string) $app->input->get('target', '', 'raw'));
    if ($target === '') {
      $settings = LeadMarketHelper::getFreeTestSettings();
      $target = trim((string) ($settings['market_cta_url'] ?? ''));
    }
    if ($target === '') {
      $target = LeadMarketHelper::getMarketplaceUrl(false);
    }
    $siteRoot = rtrim((string) JUri::root(), '/');
    if (preg_match('~^https?://~i', $target)) {
      if (stripos($target, $siteRoot) === 0) {
        $target = substr($target, strlen($siteRoot));
        if ($target === '') $target = '/';
      } else {
        $target = LeadMarketHelper::getMarketplaceUrl(false);
      }
    }
    if ($target === '' || strpos($target, 'javascript:') === 0) {
      $target = LeadMarketHelper::getMarketplaceUrl(false);
    }
    $this->setRedirect($target);
    return true;
  }

  public function buy()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    $input = $app->input;
    $leadId = (int)$input->post->getInt('lead_id', 0);
    $buyerEmail = LeadMarketHelper::resolveBuyerEmail((string)$input->post->getString('buyer_email', ''));
    $saleMode = strtolower(trim((string)$input->post->getString('sale_mode', 'shared')));
    if (!in_array($saleMode, array('shared','exclusive'), true)) $saleMode = 'shared';
    $checkoutAction = strtolower(trim((string)$input->post->getCmd('checkout_action', 'instructions')));
    if (!in_array($checkoutAction, array('instructions','balance','topup'), true)) $checkoutAction = 'instructions';
    $promoCode = trim((string)$input->post->getString('promo_code', ''));
    $promoPayload = array();
    if ($leadId <= 0 || !filter_var($buyerEmail, FILTER_VALIDATE_EMAIL)) {
      $app->enqueueMessage('Please enter a valid email.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId, false));
      return false;
    }
    LeadMarketHelper::setActiveBuyerContext($buyerEmail, 'lead_checkout');
    if ($promoCode !== '') {
      $promoCheck = LeadMarketHelper::validateLeadPromoCode($promoCode, $leadId, $buyerEmail, $saleMode);
      if (!empty($promoCheck['ok'])) {
        $promoPayload = array('promo_code' => (string) ($promoCheck['promo_code'] ?? $promoCode), 'promo_id' => (int) ($promoCheck['promo_id'] ?? 0), 'discount_type' => (string) ($promoCheck['discount_type'] ?? ''), 'discount_value' => (float) ($promoCheck['discount_value'] ?? 0), 'discount_amount' => (float) ($promoCheck['discount_amount'] ?? 0), 'subtotal' => (float) ($promoCheck['subtotal'] ?? 0), 'final_total' => (float) ($promoCheck['final_total'] ?? 0));
      } else {
        $promoCode = '';
      }
    }
    LeadMarketHelper::trackEvent('checkout_start', array('page_name' => 'lead_checkout', 'buyer_email' => $buyerEmail, 'lead_id' => $leadId, 'props' => array('mode' => 'single', 'sale_mode' => $saleMode, 'checkout_action' => $checkoutAction)));
    if ($checkoutAction === 'balance') {
      $result = LeadMarketHelper::unlockLeadUsingBalance($leadId, $buyerEmail, $saleMode, !empty($promoPayload['final_total']) ? (float) $promoPayload['final_total'] : null, $promoPayload);
      if (!empty($result['ok']) && !empty($result['order']['id'])) {
        $order = $result['order'];
        $token = LeadMarketHelper::ensureOrderToken($order);
        $app->enqueueMessage((string)$result['message'], 'message');
        $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$order['id'], $token), false));
        return true;
      }
      $app->enqueueMessage(trim((string)($result['message'] ?? 'Wallet balance unlock failed.')), 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return false;
    }
    if ($checkoutAction === 'topup') {
      LeadMarketHelper::cleanupExpiredOrders();
      $lead = LeadMarketHelper::loadLeadById($leadId);
      if (!$lead) { $app->enqueueMessage('Lead not found.', 'error'); $this->setRedirect(JUri::root()); return false; }
    if (!LeadMarketHelper::isLeadSellable($lead)) { $app->enqueueMessage('Sample leads are for demonstration only and cannot be purchased.', 'warning'); $this->setRedirect(JUri::root()); return false; }
      if (!LeadMarketHelper::isLeadSellable($lead)) { $app->enqueueMessage('Sample leads are for demonstration only and cannot be purchased.', 'warning'); $this->setRedirect(JUri::root()); return false; }
      $saleOptions = LeadMarketHelper::getSaleModeOptions($lead);
      if (empty($saleOptions[$saleMode]['enabled'])) {
        $reason = trim((string)($saleOptions[$saleMode]['reason'] ?? 'This checkout option is not available.'));
        $app->enqueueMessage($reason !== '' ? $reason : 'This checkout option is not available.', 'error');
        $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
        return false;
      }
      $route = LeadMarketHelper::determinePurchaseRoute('lead', $leadId, $buyerEmail, $saleMode, !empty($promoPayload['final_total']) ? (float) $promoPayload['final_total'] : null);
      if (!empty($route['already_unlocked'])) {
        $app->enqueueMessage('This lead is already unlocked for this buyer email.', 'message');
        $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
        return true;
      }
      if (!empty($route['balance_allowed'])) {
        $app->enqueueMessage('Your wallet already covers this lead. Use Unlock Using Balance instead.', 'message');
        $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
        return true;
      }
      $priceUsd = (float) ($route['target_price'] ?? $saleOptions[$saleMode]['price_usd']);
      $balance = (float) ($route['current_balance'] ?? LeadMarketHelper::getBuyerBalance($buyerEmail));
      $requestedTopup = (float)$input->post->getString('topup_amount_usd', '0');
      $paymentMethod = LeadMarketHelper::normalizeTopupPaymentMethod((string) $input->post->getCmd('payment_method', 'crypto'));
      if ($paymentMethod === 'paypal') {
        $missingAmount = max(0, LeadMarketHelper::roundMoney($priceUsd - $balance));
        $topupAmount = $requestedTopup > 0 ? LeadMarketHelper::roundMoney($requestedTopup) : $missingAmount;
        if (!LeadMarketHelper::isPaypalAllowedForAmount($topupAmount)) {
          $app->enqueueMessage('PayPal is available for top-ups up to $' . number_format(LeadMarketHelper::paypalTopupMaxUsd(), 2, '.', ',') . '.', 'error');
          $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
          return false;
        }
        if ($topupAmount + $balance + 0.0001 < $priceUsd) {
          $app->enqueueMessage('The PayPal top-up is too low for this lead. Choose a higher amount or another payment method.', 'error');
          $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
          return false;
        }
      } else {
        $topupAmount = LeadMarketHelper::normalizeRequestedTopupAmount($requestedTopup, $priceUsd, $balance, 'lead');
      }
      LeadMarketHelper::trackEvent('insufficient_balance', array('page_name' => 'lead_checkout', 'buyer_email' => $buyerEmail, 'lead_id' => $leadId, 'props' => array('required_amount' => $priceUsd, 'wallet_balance' => $balance, 'missing_amount' => max(0, $priceUsd - $balance))));
      if ($topupAmount <= 0) {
        $app->enqueueMessage('Your wallet already has enough balance. Use Unlock Using Balance instead.', 'message');
        $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
        return true;
      }
      $note = ucfirst($saleMode) . ' lead unlock top-up';
      $autoApply = true;
      LeadMarketHelper::trackEvent('topup_method_selected', array('page_name' => 'lead_checkout', 'buyer_email' => $buyerEmail, 'lead_id' => $leadId, 'props' => array('method' => $paymentMethod, 'amount' => $topupAmount)));
      $created = LeadMarketHelper::createTopup($buyerEmail, $topupAmount, 'lead', $leadId, $priceUsd, $autoApply, $note, $promoPayload, $paymentMethod);
      if (empty($created['ok']) || empty($created['topup']['id'])) {
        $app->enqueueMessage((string)($created['message'] ?? 'Could not create top-up.'), 'error');
        $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
        return false;
      }
      $topup = $created['topup'];
      LeadMarketHelper::trackEvent('topup_created', array('page_name' => 'lead_checkout', 'buyer_email' => $buyerEmail, 'lead_id' => (int) $leadId, 'topup_id' => (int) ($topup['id'] ?? 0), 'props' => array('method' => $paymentMethod, 'amount' => $topupAmount, 'target_type' => 'lead', 'linked_order_id' => (int) ($topup['linked_order_id'] ?? 0))));
      $token = LeadMarketHelper::ensureTopupToken($topup);
      if (!empty($created['reused'])) {
        $app->enqueueMessage('An active linked top-up already exists. Continue on its secure page.', 'message');
      } elseif ($paymentMethod === 'paypal') {
        $app->enqueueMessage('PayPal top-up created. Open the secure top-up page and complete the payment there.', 'message');
      } else {
        $app->enqueueMessage('Linked top-up created. Complete payment and it will be applied to this lead after confirmation.', 'message');
      }
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl((int)$topup['id'], $token), false));
      return true;
    }
    LeadMarketHelper::cleanupExpiredOrders();
    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_leads WHERE id=' . (int)$leadId);
    $lead = $db->loadAssoc();
    if (!$lead) { $app->enqueueMessage('Lead not found.', 'error'); $this->setRedirect(JUri::root()); return false; }
    if (strtolower((string)$lead['lead_status']) === 'archived' && !LeadMarketHelper::isArchivedLeadVisibleInMarket($lead)) { $app->enqueueMessage('This lead is no longer available.', 'error'); $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false)); return false; }
    $saleOptions = LeadMarketHelper::getSaleModeOptions($lead);
    if (empty($saleOptions[$saleMode]['enabled'])) {
      $reason = trim((string)($saleOptions[$saleMode]['reason'] ?? 'This checkout option is not available.'));
      $app->enqueueMessage($reason !== '' ? $reason : 'This checkout option is not available.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return false;
    }
    $route = LeadMarketHelper::determinePurchaseRoute('lead', $leadId, $buyerEmail, $saleMode, !empty($promoPayload['final_total']) ? (float) $promoPayload['final_total'] : null);
    if (!empty($route['already_unlocked'])) {
      $existingPaidQ = $db->getQuery(true)->select('*')->from('#__leadmarket_orders')->where('lead_id=' . (int)$leadId)->where('buyer_email=' . $db->q($buyerEmail))->where("status='paid'")->order('created_at_utc DESC, id DESC');
      $db->setQuery($existingPaidQ, 0, 1); $existingPaid = $db->loadAssoc();
      if ($existingPaid) {
        $token = LeadMarketHelper::ensureOrderToken($existingPaid);
        $app->enqueueMessage('This lead is already unlocked for this buyer email.', 'message');
        $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$existingPaid['id'], $token), false));
        return true;
      }
    }
    if (($route['route'] ?? '') === 'balance_only') {
      $result = LeadMarketHelper::unlockLeadUsingBalance($leadId, $buyerEmail, $saleMode, !empty($promoPayload['final_total']) ? (float) $promoPayload['final_total'] : null, $promoPayload);
      $app->enqueueMessage((string)($result['message'] ?? 'Wallet balance unlock failed.'), !empty($result['ok']) ? 'message' : 'error');
      if (!empty($result['ok']) && !empty($result['order']['id'])) {
        $order = $result['order'];
        $token = LeadMarketHelper::ensureOrderToken($order);
        $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$order['id'], $token), false));
        return true;
      }
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return !empty($result['ok']);
    }
    if (($route['route'] ?? '') === 'topup_required' && empty($route['direct_allowed'])) {
      $requestedTopup = (float) $input->post->getString('topup_amount_usd', '0');
      $validatedTopup = LeadMarketHelper::validateRequestedTopupAmount($requestedTopup, (float) ($route['target_price'] ?? 0), (float) ($route['current_balance'] ?? LeadMarketHelper::getBuyerBalance($buyerEmail)), 'lead');
      if (!empty($validatedTopup['ok'])) {
        $topupAmount = (float) ($validatedTopup['amount'] ?? 0);
      } else {
        $topupAmount = (float) (($route['suggested_topups']['recommended_amount'] ?? 0));
      }
      $note = ucfirst($saleMode) . ' lead unlock top-up';
      $autoApply = true;
      $created = LeadMarketHelper::createTopup($buyerEmail, $topupAmount, 'lead', $leadId, (float) ($route['target_price'] ?? 0), $autoApply, $note, $promoPayload, (string) $input->post->getCmd('payment_method', 'crypto'));
      if (!empty($created['ok']) && !empty($created['topup']['id'])) {
        $topup = $created['topup'];
        $token = LeadMarketHelper::ensureTopupToken($topup);
        $app->enqueueMessage('Your wallet balance will be applied first, and the linked top-up covers the remaining shortage. Any unused amount stays in the wallet.', 'message');
        $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl((int) $topup['id'], $token), false));
        return true;
      }
      $app->enqueueMessage((string) ($created['message'] ?? 'Could not create a linked top-up.'), 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return false;
    }
    $existingQ = $db->getQuery(true)->select('*')->from('#__leadmarket_orders')->where('lead_id=' . (int)$leadId)->where('buyer_email=' . $db->q($buyerEmail))->where("status IN ('pending','submitted','paid')")->order('created_at_utc DESC, id DESC');
    $db->setQuery($existingQ, 0, 1); $existing = $db->loadAssoc();
    if ($existing) {
      $token = LeadMarketHelper::ensureOrderToken($existing);
      $msg = strtolower($existing['status']) === 'paid' ? 'Access is already available for this buyer email.' : 'An active checkout already exists for this buyer email. Continue with the existing payment instructions.';
      $app->enqueueMessage($msg, 'message');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$existing['id'], $token), false));
      return true;
    }
    $baseUsd = !empty($promoPayload['final_total']) ? (float) $promoPayload['final_total'] : (float)$saleOptions[$saleMode]['price_usd'];
    $subtotalBeforeDiscount = !empty($promoPayload['subtotal']) ? (float) $promoPayload['subtotal'] : $baseUsd;
    $buyerBalanceUsd = LeadMarketHelper::getBuyerBalance($buyerEmail);
    $minimumTopupUsd = LeadMarketHelper::minimumTopupUsd();
    if ($baseUsd < $minimumTopupUsd && $buyerBalanceUsd < $baseUsd) {
      $requestedTopup = (float) $input->post->getString('topup_amount_usd', '0');
      $topupAmount = LeadMarketHelper::normalizeRequestedTopupAmount($requestedTopup, $baseUsd, $buyerBalanceUsd, 'lead');
      $note = ucfirst($saleMode) . ' lead unlock top-up';
      $autoApply = true;
      $created = LeadMarketHelper::createTopup($buyerEmail, $topupAmount, 'lead', $leadId, $baseUsd, $autoApply, $note, $promoPayload, (string) $input->post->getCmd('payment_method', 'crypto'));
      if (!empty($created['ok']) && !empty($created['topup']['id'])) {
        $topup = $created['topup'];
        $token = LeadMarketHelper::ensureTopupToken($topup);
        $remaining = max(0, LeadMarketHelper::roundMoney($topupAmount - $baseUsd));
        $app->enqueueMessage('This lead costs $' . number_format($baseUsd, 2, '.', ',') . ', but the minimum transfer amount is $' . number_format($minimumTopupUsd, 2, '.', ',') . '. We opened a linked top-up for $' . number_format($topupAmount, 2, '.', ',') . '. After payment confirmation, the lead can unlock automatically and the remaining $' . number_format($remaining, 2, '.', ',') . ' stays in the buyer wallet.', 'message');
        $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl((int) $topup['id'], $token), false));
        return true;
      }
      $app->enqueueMessage((string) ($created['message'] ?? 'Could not create a linked top-up.'), 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return false;
    }
    $appliedFromWallet = LeadMarketHelper::calculateAppliedFromWallet($baseUsd, $buyerBalanceUsd);
    $shortageUsd = LeadMarketHelper::roundMoney(max(0, $baseUsd - $appliedFromWallet));
    if ($appliedFromWallet > 0 && LeadMarketHelper::allowPartialWalletUsage() && LeadMarketHelper::allowDirectPaymentWhenWalletInsufficient() && $shortageUsd >= $minimumTopupUsd) {
      $hybrid = LeadMarketHelper::createHybridLeadOrder($leadId, $buyerEmail, $saleMode, $baseUsd, $promoPayload);
      if (!empty($hybrid['ok']) && !empty($hybrid['order']['id'])) {
        $order = $hybrid['order'];
        $token = LeadMarketHelper::ensureOrderToken($order);
        $app->enqueueMessage('We applied $' . number_format((float) ($hybrid['balance_applied'] ?? 0), 2, '.', ',') . ' from the buyer wallet. Only the remaining $' . number_format((float) ($hybrid['shortage'] ?? 0), 2, '.', ',') . ' needs to be paid externally.', 'message');
        $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$order['id'], $token), false));
        return true;
      }
      if (!empty($hybrid['message'])) {
        $app->enqueueMessage((string) $hybrid['message'], 'error');
        $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
        return false;
      }
    }
    $now = new DateTime('now', new DateTimeZone('UTC'));
    $reserveMinutes = max(5, (int) LeadMarketHelper::params()->get('reserve_minutes', 30));
    $expires = clone $now; $expires->modify('+' . $reserveMinutes . ' minutes');
    $accessToken = LeadMarketHelper::generateAccessToken();
    $wallet = LeadMarketHelper::cryptoWalletAddress();
    $expectedExternal = $baseUsd;
    $paymentType = 'direct';
    $walletAmountUsedUsd = 0.0;
    if ($appliedFromWallet > 0 && LeadMarketHelper::allowPartialWalletUsage() && LeadMarketHelper::allowDirectPaymentWhenWalletInsufficient() && $shortageUsd >= $minimumTopupUsd) {
      $expectedExternal = $shortageUsd;
      $paymentType = 'hybrid';
      $walletAmountUsedUsd = $appliedFromWallet;
    }
    $amountUsdt = (float) LeadMarketHelper::buildUniqueExpectedAmount((float)$expectedExternal, $wallet, null, $buyerEmail . '|direct|' . $leadId . '|' . $saleMode . '|' . microtime(true));
    if ($amountUsdt > 0 && abs($amountUsdt - (float) $expectedExternal) < 0.001) {
      $amountUsdt = (float) LeadMarketHelper::buildUniqueExpectedAmount((float)$expectedExternal, $wallet, null, $buyerEmail . '|direct-retry|' . $leadId . '|' . $saleMode . '|' . microtime(true));
    }
    if ($amountUsdt <= 0 || abs($amountUsdt - (float) $expectedExternal) < 0.001) {
      $amountUsdt = LeadMarketHelper::roundMoney((float) $expectedExternal + 0.01);
    }
    $q = $db->getQuery(true)->insert('#__leadmarket_orders')->columns(array('lead_id','buyer_email','kind','amount_usd','amount_usdt','expected_amount','expected_currency','expected_network','wallet_address','status','payment_status','payment_type','wallet_amount_used_usd','external_amount_used_usd','expires_at_utc','access_token','token_created_utc','created_at_utc','promo_code','promo_id','promo_discount_type','promo_discount_value','promo_discount_amount','subtotal_before_discount','total_after_discount'))
      ->values((int)$leadId . ',' . $db->q($buyerEmail) . ',' . $db->q($saleMode) . ',' . $db->q(number_format($baseUsd, 2, '.', '')) . ',' . $db->q(number_format($amountUsdt, 2, '.', '')) . ',' . $db->q(number_format($amountUsdt, 2, '.', '')) . ',' . $db->q('USDT') . ',' . $db->q('TRC20') . ',' . $db->q($wallet) . ',' . $db->q('pending') . ',' . $db->q('unverified') . ',' . $db->q($paymentType) . ',' . $db->q(number_format($walletAmountUsedUsd, 2, '.', '')) . ',' . $db->q(number_format($expectedExternal, 2, '.', '')) . ',' . $db->q($expires->format('Y-m-d H:i:s')) . ',' . $db->q($accessToken) . ',' . $db->q($now->format('Y-m-d H:i:s')) . ',' . $db->q($now->format('Y-m-d H:i:s')) . ',' . (!empty($promoPayload['promo_code']) ? $db->q((string) $promoPayload['promo_code']) : 'NULL') . ',' . (!empty($promoPayload['promo_id']) ? (int) $promoPayload['promo_id'] : 'NULL') . ',' . (!empty($promoPayload['discount_type']) ? $db->q((string) $promoPayload['discount_type']) : 'NULL') . ',' . (!empty($promoPayload['discount_value']) ? $db->q(number_format((float) $promoPayload['discount_value'], 2, '.', '')) : 'NULL') . ',' . $db->q(number_format((float) ($promoPayload['discount_amount'] ?? 0), 2, '.', '')) . ',' . $db->q(number_format((float) $subtotalBeforeDiscount, 2, '.', '')) . ',' . $db->q(number_format((float) $baseUsd, 2, '.', '')));
    $db->setQuery($q)->execute();
    $orderId = (int)$db->insertid();
    LeadMarketHelper::logOrderEvent($orderId, (int)$leadId, 'order_created', $paymentType === 'hybrid' ? 'Hybrid order created and slot reserved.' : 'Order created and slot reserved.', array('buyer_email'=>$buyerEmail,'expected_amount'=>number_format($amountUsdt,2,'.',''),'sale_mode'=>$saleMode,'wallet_amount_used_usd'=>number_format($walletAmountUsedUsd,2,'.',''),'external_amount_used_usd'=>number_format($expectedExternal,2,'.','')), 'buyer', $buyerEmail);
    LeadMarketHelper::logOrderEvent($orderId, (int)$leadId, 'payment_instructions_created', 'Payment instructions created.', array('wallet_address'=>$wallet), 'system', 'checkout');
    if ($paymentType === 'hybrid') {
      $app->enqueueMessage('We will apply $' . number_format($walletAmountUsedUsd, 2, '.', ',') . ' from the buyer wallet after payment confirmation. Pay only the remaining $' . number_format($expectedExternal, 2, '.', ',') . ' externally.', 'message');
    } elseif ($saleMode === 'exclusive') {
      $exclusiveHours = LeadMarketHelper::getExclusiveHoursForLead($lead);
      $app->enqueueMessage('Protected first-contact checkout reserved for ' . $exclusiveHours . ' hours. Complete payment to activate the protected contact window and pause distribution during this period.', 'message');
    } else {
      $app->enqueueMessage('Shared checkout reserved. Complete payment to unlock the lead.', 'message');
    }
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$orderId, $accessToken), false));
    return true;
  }

  public function ipaid()
  {
    $app = JFactory::getApplication();
    $input = $app->input;
    $orderId = (int)$input->post->getInt('order_id', 0);
    $leadId = (int)$input->post->getInt('lead_id', 0);
    $token = trim((string)$input->post->getString('token', ''));
    if ($orderId <= 0 || $leadId <= 0) { $app->enqueueMessage('Invalid order request.', 'error'); $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId, false)); return false; }
    LeadMarketHelper::cleanupExpiredOrders();
    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_orders WHERE id=' . (int)$orderId . ' AND lead_id=' . (int)$leadId);
    $order = $db->loadAssoc();
    if (!$order || !LeadMarketHelper::canAccessOrder($order, $token)) { $app->enqueueMessage('Access denied.', 'error'); $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&order_id=' . (int)$orderId, false)); return false; }
    $refundWallet = trim((string)$input->post->getString('refund_wallet_address', ''));
    $refundNote = trim((string)$input->post->getString('refund_note', ''));
    $orderStatus = strtolower((string)$order['status']);
    if (in_array($orderStatus, array('paid','failed','cancelled'), true)) { $app->enqueueMessage('Order status cannot be changed.', 'message'); $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$orderId, $token), false)); return true; }
    $now = gmdate('Y-m-d H:i:s');
    if ($orderStatus === 'expired') {
      $sets = array('payment_status=' . $db->q('checking'),'submitted_at_utc=' . $db->q($now),'checking_started_utc=' . $db->q($now),'late_payment_declared=1','late_payment_declared_utc=' . $db->q($now),'verify_note=' . $db->q('Buyer reported late payment at ' . $now . ' UTC'));
      if ($refundWallet !== '') $sets[] = 'refund_wallet_address=' . $db->q($refundWallet);
      if ($refundNote !== '') $sets[] = 'refund_note=' . $db->q(substr($refundNote,0,65535));
      $q = $db->getQuery(true)->update('#__leadmarket_orders')->set($sets)->where('id=' . (int)$orderId); $db->setQuery($q)->execute();
      LeadMarketHelper::logOrderEvent((int)$orderId, (int)$leadId, 'buyer_marked_paid_after_expiry', 'Buyer reported payment after expiry.', array('refund_wallet'=>$refundWallet), 'buyer', (string)$order['buyer_email']);
      $app->enqueueMessage('Late payment reported. We are reviewing the transfer and will unlock access if the payment still matches an available slot.', 'message');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$orderId, $token), false));
      return true;
    }
    $q = $db->getQuery(true)->update('#__leadmarket_orders')->set('status=' . $db->q('submitted'))->set('payment_status=' . $db->q('checking'))->set('submitted_at_utc=' . $db->q($now))->set('checking_started_utc=' . $db->q($now))->set('late_payment_declared=0')->set('late_payment_declared_utc=NULL')->set('verify_note=' . $db->q('Buyer clicked I Paid at ' . $now . ' UTC'))->where('id=' . (int)$orderId);
    $db->setQuery($q)->execute();
    LeadMarketHelper::logOrderEvent((int)$orderId, (int)$leadId, 'buyer_marked_paid', 'Buyer clicked I Paid.', array(), 'buyer', (string)$order['buyer_email']);
    $app->enqueueMessage('Payment marked as sent. We are now checking the transfer.', 'message');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$orderId, $token), false));
    return true;
  }

  public function cancelorder()
  {
    $app = JFactory::getApplication();
    $input = $app->input; $orderId = (int)$input->post->getInt('order_id', 0); $leadId = (int)$input->post->getInt('lead_id', 0); $token = trim((string)$input->post->getString('token', ''));
    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_orders WHERE id=' . (int)$orderId . ' AND lead_id=' . (int)$leadId); $order = $db->loadAssoc();
    if (!$order || !LeadMarketHelper::canAccessOrder($order, $token)) { $app->enqueueMessage('Access denied.', 'error'); $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$leadId . '&order_id=' . (int)$orderId, false)); return false; }
    $status = strtolower((string)$order['status']);
    if (in_array($status, array('paid','failed','cancelled','expired'), true)) { $app->enqueueMessage('This order cannot be cancelled.', 'message'); $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$orderId, $token), false)); return true; }
    $now = gmdate('Y-m-d H:i:s');
    $q = $db->getQuery(true)->update('#__leadmarket_orders')->set('status=' . $db->q('cancelled'))->set('cancelled_at_utc=' . $db->q($now))->set('verify_note=' . $db->q('Cancelled by buyer at ' . $now . ' UTC'))->where('id=' . (int)$orderId); $db->setQuery($q)->execute();
    LeadMarketHelper::logOrderEvent((int)$orderId, (int)$leadId, 'order_cancelled', 'Order cancelled by buyer.', array(), 'buyer', (string)$order['buyer_email']);
    LeadMarketHelper::logOrderEvent((int)$orderId, (int)$leadId, 'hold_released', 'Reservation hold released after buyer cancellation.', array(), 'system', 'checkout');
    $app->enqueueMessage('Checkout cancelled. The reservation has been released.', 'message');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int)$leadId, (int)$orderId, $token), false));
    return true;
  }


  public function leadUnlockBalance()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    $leadId = (int) $app->input->post->getInt('lead_id', 0);
    $buyerEmail = LeadMarketHelper::resolveBuyerEmail((string) $app->input->post->getString('buyer_email', ''));
    $saleMode = strtolower(trim((string) $app->input->post->getString('sale_mode', 'shared')));
    if (!in_array($saleMode, array('shared','exclusive'), true)) $saleMode = 'shared';
    $result = LeadMarketHelper::unlockLeadUsingBalance($leadId, $buyerEmail, $saleMode);
    $msgType = !empty($result['ok']) ? 'message' : 'error';
    $app->enqueueMessage((string) ($result['message'] ?? 'Could not unlock this lead using balance.'), $msgType);
    if (!empty($result['ok']) && !empty($result['order']['id']) && !empty($result['order']['access_token'])) {
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildLeadUrl((int) $leadId, (int) $result['order']['id'], (string) $result['order']['access_token']), false));
      return true;
    }
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
    return !empty($result['ok']);
  }

  public function leadCreateLinkedTopup()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    $leadId = (int) $app->input->post->getInt('lead_id', 0);
    $buyerEmail = LeadMarketHelper::normalizeEmail((string) $app->input->post->getString('buyer_email', ''));
    $saleMode = strtolower(trim((string) $app->input->post->getString('sale_mode', 'shared')));
    if (!in_array($saleMode, array('shared','exclusive'), true)) $saleMode = 'shared';
    $lead = LeadMarketHelper::loadLeadById($leadId);
    if (!$lead || $buyerEmail === '' || !filter_var($buyerEmail, FILTER_VALIDATE_EMAIL)) {
      $app->enqueueMessage('Valid buyer email and lead are required.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId, false));
      return false;
    }
    $saleOptions = LeadMarketHelper::getSaleModeOptions($lead);
    if (empty($saleOptions[$saleMode]['enabled'])) {
      $app->enqueueMessage(trim((string) ($saleOptions[$saleMode]['reason'] ?? 'This checkout option is not available.')), 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return false;
    }
    $route = LeadMarketHelper::determinePurchaseRoute('lead', $leadId, $buyerEmail, $saleMode);
    if (!empty($route['already_unlocked'])) {
      $app->enqueueMessage('This lead is already unlocked for this buyer email.', 'message');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return true;
    }
    if (!empty($route['balance_allowed'])) {
      $app->enqueueMessage('Your wallet already covers this lead. Use Unlock Using Balance instead.', 'message');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return true;
    }
    $priceUsd = (float) ($route['target_price'] ?? ($saleOptions[$saleMode]['price_usd'] ?? 0));
    $currentBalance = (float) ($route['current_balance'] ?? LeadMarketHelper::getBuyerBalance($buyerEmail));
    $requested = (float) $app->input->post->getString('topup_amount_usd', '0');
    $validatedTopup = LeadMarketHelper::validateRequestedTopupAmount($requested, $priceUsd, $currentBalance, 'lead');
    if (empty($validatedTopup['ok'])) {
      $app->enqueueMessage((string) ($validatedTopup['message'] ?? 'Please review the top-up amount.'), 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return false;
    }
    $amountUsd = (float) ($validatedTopup['amount'] ?? 0);
    $autoApply = true;
    $created = LeadMarketHelper::createTopup($buyerEmail, $amountUsd, 'lead', $leadId, $priceUsd, $autoApply, ucfirst($saleMode) . ' lead linked top-up', array(), (string) $app->input->post->getCmd('payment_method', 'crypto'));
    if (empty($created['ok']) || empty($created['topup']['id'])) {
      $app->enqueueMessage((string) ($created['message'] ?? 'Could not create linked top-up.'), 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int) $leadId . '&buyer_email=' . urlencode($buyerEmail), false));
      return false;
    }
    $topup = $created['topup'];
    LeadMarketHelper::trackEvent('topup_created', array('page_name' => 'lead_checkout', 'buyer_email' => $buyerEmail, 'lead_id' => (int) $leadId, 'topup_id' => (int) ($topup['id'] ?? 0), 'props' => array('method' => (string) $app->input->post->getCmd('payment_method', 'crypto'), 'amount' => $amountUsd, 'target_type' => 'lead', 'linked_order_id' => (int) ($topup['linked_order_id'] ?? 0))));
    $token = LeadMarketHelper::ensureTopupToken($topup);
    $app->enqueueMessage('Linked top-up created for this lead. After payment confirmation, the credited balance stays available for this and future purchases.', 'message');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl((int) $topup['id'], $token), false));
    return true;
  }

  public function batchUnlockBalance()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    $batchId = (int) $app->input->post->getInt('batch_id', 0);
    $token = trim((string) $app->input->post->getString('token', ''));
    $batch = LeadMarketHelper::loadBatchById($batchId);
    if (!$batch || !LeadMarketHelper::canAccessBatch($batch, $token)) {
      $app->enqueueMessage('Access denied.', 'error');
      $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
      return false;
    }
    $buyerEmail = LeadMarketHelper::normalizeEmail((string) ($batch['buyer_email'] ?? ''));
    LeadMarketHelper::trackEvent('checkout_start', array('page_name' => 'batch_checkout', 'buyer_email' => $buyerEmail, 'batch_id' => $batchId, 'props' => array('mode' => 'batch', 'checkout_action' => 'balance')));
    $result = LeadMarketHelper::unlockBatchUsingBalance($batchId, $buyerEmail);
    $app->enqueueMessage((string) ($result['message'] ?? 'Could not unlock this batch using balance.'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildBatchUrl($batchId, $token), false));
    return !empty($result['ok']);
  }

  public function batchCreateLinkedTopup()
  {
    $app = JFactory::getApplication();
    JSession::checkToken('post') or jexit('Invalid Token');
    LeadMarketHelper::ensureSchema();
    $batchId = (int) $app->input->post->getInt('batch_id', 0);
    $token = trim((string) $app->input->post->getString('token', ''));
    $batch = LeadMarketHelper::loadBatchById($batchId);
    if (!$batch || !LeadMarketHelper::canAccessBatch($batch, $token)) {
      $app->enqueueMessage('Access denied.', 'error');
      $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(false));
      return false;
    }
    $buyerEmail = LeadMarketHelper::normalizeEmail((string) ($batch['buyer_email'] ?? ''));
    LeadMarketHelper::trackEvent('checkout_start', array('page_name' => 'batch_checkout', 'buyer_email' => $buyerEmail, 'batch_id' => $batchId, 'props' => array('mode' => 'batch', 'checkout_action' => 'topup')));
    $route = LeadMarketHelper::determinePurchaseRoute('batch', $batchId, $buyerEmail);
    if (!empty($route['already_unlocked'])) {
      $app->enqueueMessage('All remaining leads in this batch are already unlocked for this buyer email.', 'message');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildBatchUrl($batchId, $token), false));
      return true;
    }
    if (!empty($route['balance_allowed'])) {
      $app->enqueueMessage('Your wallet already covers this batch. Use Unlock Batch Using Balance instead.', 'message');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildBatchUrl($batchId, $token), false));
      return true;
    }
    $priceUsd = (float) ($route['target_price'] ?? ($batch['amount_usd'] ?? 0));
    $currentBalance = (float) ($route['current_balance'] ?? LeadMarketHelper::getBuyerBalance($buyerEmail));
    $requested = (float) $app->input->post->getString('topup_amount_usd', '0');
    $validatedTopup = LeadMarketHelper::validateRequestedTopupAmount($requested, $priceUsd, $currentBalance, 'batch');
    LeadMarketHelper::trackEvent('insufficient_balance', array('page_name' => 'batch_checkout', 'buyer_email' => $buyerEmail, 'batch_id' => $batchId, 'props' => array('required_amount' => $priceUsd, 'wallet_balance' => $currentBalance, 'missing_amount' => max(0, $priceUsd - $currentBalance))));
    if (empty($validatedTopup['ok'])) {
      $app->enqueueMessage((string) ($validatedTopup['message'] ?? 'Please review the top-up amount.'), 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildBatchUrl($batchId, $token), false));
      return false;
    }
    $amountUsd = (float) ($validatedTopup['amount'] ?? 0);
    $autoApply = ((int) LeadMarketHelper::params()->get('topup_auto_apply_on_paid', 0) === 1);
    $created = LeadMarketHelper::createTopup($buyerEmail, $amountUsd, 'batch', $batchId, $priceUsd, $autoApply, 'Shared batch linked top-up', array(), (string) $app->input->post->getCmd('payment_method', 'crypto'));
    if (empty($created['ok']) || empty($created['topup']['id'])) {
      $app->enqueueMessage((string) ($created['message'] ?? 'Could not create linked top-up.'), 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildBatchUrl($batchId, $token), false));
      return false;
    }
    $topup = $created['topup'];
    LeadMarketHelper::trackEvent('topup_created', array('page_name' => 'batch_checkout', 'buyer_email' => $buyerEmail, 'batch_id' => (int) $batchId, 'topup_id' => (int) ($topup['id'] ?? 0), 'props' => array('method' => (string) ($app->input->post->getCmd('payment_method', 'crypto')), 'amount' => $amountUsd, 'target_type' => 'batch', 'linked_order_id' => (int) ($topup['linked_order_id'] ?? 0))));
    $topupToken = LeadMarketHelper::ensureTopupToken($topup);
    $app->enqueueMessage('Linked top-up created for this batch. After payment confirmation, the batch can unlock automatically and any remaining balance stays in the buyer wallet.', 'message');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl((int) $topup['id'], $topupToken), false));
    return true;
  }

  public function createTopup()
  {
    $app = JFactory::getApplication();
    if (!JSession::checkToken('post')) {
      $app->enqueueMessage('Invalid session token. Please try again.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    LeadMarketHelper::ensureSchema();
    $amountUsd = (float) $app->input->post->getString('topup_amount_usd', '0');
    $buyerToken = LeadMarketHelper::readBuyerActionTokenFromRequest('buyer_token');
    $buyerEmail = LeadMarketHelper::normalizeEmail((string) $app->input->post->getString('buyer_email', ''));
    $accessRow = LeadMarketHelper::validateBuyerAccessToken($buyerToken);

    $targetType = '';
    $targetId = 0;
    $targetPriceUsd = 0.0;
    $note = 'Manual buyer wallet top-up';
    $redirectUrl = LeadMarketHelper::getBuyerAccessRequestUrl();

    if ($accessRow && $buyerEmail !== '' && $buyerEmail === LeadMarketHelper::normalizeEmail((string) $accessRow['buyer_email'])) {
      $redirectUrl = LeadMarketHelper::buildBuyerAccessUrl($buyerToken);
    } else {
      $orderId = (int) $app->input->post->getInt('order_id', 0);
      $leadId = (int) $app->input->post->getInt('lead_id', 0);
      $orderToken = trim((string) $app->input->post->getString('order_token', ''));
      if ($orderToken === '') $orderToken = LeadMarketHelper::readBuyerActionTokenFromRequest('token');
      if ($orderId > 0 && $leadId > 0 && $orderToken !== '') {
        $db = JFactory::getDbo();
        $db->setQuery('SELECT * FROM #__leadmarket_orders WHERE id=' . (int) $orderId . ' AND lead_id=' . (int) $leadId);
        $order = $db->loadAssoc();
        if ($order && LeadMarketHelper::canAccessOrder($order, $orderToken)) {
          $buyerEmail = LeadMarketHelper::normalizeEmail((string) ($order['buyer_email'] ?? ''));
          $targetType = 'lead';
          $targetId = (int) $leadId;
          $targetPriceUsd = (float) ($order['amount_usd'] ?? 0);
          $note = 'Linked top-up for lead checkout #' . (int) $orderId;
          $redirectUrl = LeadMarketHelper::buildLeadUrl($leadId, $orderId, $orderToken);
        }
      }

      if ($buyerEmail === '') {
        $batchId = (int) $app->input->post->getInt('batch_id', 0);
        $batchToken = trim((string) $app->input->post->getString('batch_token', ''));
        if ($batchToken === '') $batchToken = LeadMarketHelper::readBuyerActionTokenFromRequest('token');
        if ($batchId > 0 && $batchToken !== '') {
          $batch = LeadMarketHelper::loadBatchById($batchId);
          if ($batch && LeadMarketHelper::canAccessBatch($batch, $batchToken)) {
            $buyerEmail = LeadMarketHelper::normalizeEmail((string) ($batch['buyer_email'] ?? ''));
            $targetType = 'batch';
            $targetId = (int) $batchId;
            $targetPriceUsd = (float) ($batch['amount_usd'] ?? 0);
            $note = 'Linked top-up for batch checkout #' . (int) $batchId;
            $redirectUrl = LeadMarketHelper::buildBatchUrl($batchId, $batchToken);
          }
        }
      }
    }

    if ($buyerEmail !== '') LeadMarketHelper::setActiveBuyerContext($buyerEmail, 'manual_topup');
    if ($buyerEmail === '') {
      $app->enqueueMessage('We could not open a valid buyer or checkout session for this top-up.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    $minimum = LeadMarketHelper::minimumTopupUsd();
    $paymentMethod = (string) $app->input->post->getCmd('payment_method', 'crypto');
    $paymentMethod = LeadMarketHelper::normalizeTopupPaymentMethod($paymentMethod);
    if ($amountUsd <= 0) {
      if ($paymentMethod === 'paypal') {
        $amountUsd = $targetPriceUsd > 0 ? min(LeadMarketHelper::paypalTopupMaxUsd(), (float) $targetPriceUsd) : min(LeadMarketHelper::paypalTopupMaxUsd(), $minimum);
      } else {
        $amountUsd = $targetPriceUsd > 0 ? max($minimum, (float) $targetPriceUsd) : $minimum;
      }
    }
    $currentBalance = LeadMarketHelper::getBuyerBalance($buyerEmail);
    if ($paymentMethod === 'paypal') {
      $amountUsd = LeadMarketHelper::roundMoney($amountUsd);
      if (!LeadMarketHelper::isPaypalAllowedForAmount($amountUsd)) {
        $app->enqueueMessage('PayPal is available for top-ups up to $' . number_format(LeadMarketHelper::paypalTopupMaxUsd(), 2, '.', ',') . '.', 'error');
        $this->setRedirect(JRoute::_($redirectUrl, false));
        return false;
      }
      if ($targetPriceUsd > 0 && ($currentBalance + $amountUsd + 0.0001) < $targetPriceUsd) {
        $needed = max(0, LeadMarketHelper::roundMoney($targetPriceUsd - $currentBalance));
        $app->enqueueMessage('The PayPal top-up is too low for this purchase. You need at least $' . number_format($needed, 2, '.', ',') . ' or use another payment method.', 'error');
        $this->setRedirect(JRoute::_($redirectUrl, false));
        return false;
      }
    } else {
      $validatedTopup = LeadMarketHelper::validateRequestedTopupAmount($amountUsd, $targetPriceUsd, $currentBalance, $targetType === '' ? 'manual' : $targetType);
      if (empty($validatedTopup['ok'])) {
        $app->enqueueMessage((string) ($validatedTopup['message'] ?? 'Please review the top-up amount.'), 'error');
        $this->setRedirect(JRoute::_($redirectUrl, false));
        return false;
      }
      $amountUsd = (float) ($validatedTopup['amount'] ?? 0);
    }

    $autoApply = ($targetType === 'lead') ? true : ((((int) LeadMarketHelper::params()->get('topup_auto_apply_on_paid', 0) === 1) && in_array($targetType, array('lead','batch'), true)) ? true : false);
    LeadMarketHelper::trackEvent('topup_method_selected', array('page_name' => 'topup_create', 'buyer_email' => $buyerEmail, 'lead_id' => $targetType === 'lead' ? (int) $targetId : 0, 'batch_id' => $targetType === 'batch' ? (int) $targetId : 0, 'props' => array('method' => $paymentMethod, 'amount' => $amountUsd)));
    $created = LeadMarketHelper::createTopup($buyerEmail, $amountUsd, $targetType, $targetId, $targetPriceUsd, $autoApply, $note, array(), $paymentMethod);
    if (empty($created['ok']) || empty($created['topup']['id'])) {
      $app->enqueueMessage((string) ($created['message'] ?? 'Could not create top-up.'), 'error');
      $this->setRedirect(JRoute::_($redirectUrl, false));
      return false;
    }

    $topup = $created['topup'];
    $token = LeadMarketHelper::ensureTopupToken($topup);
    $createdMethod = LeadMarketHelper::normalizeTopupPaymentMethod((string) ($topup['payment_method'] ?? $paymentMethod));
    LeadMarketHelper::trackEvent('topup_created', array('page_name' => 'topup_create', 'buyer_email' => $buyerEmail, 'lead_id' => $targetType === 'lead' ? (int) $targetId : 0, 'batch_id' => $targetType === 'batch' ? (int) $targetId : 0, 'topup_id' => (int) ($topup['id'] ?? 0), 'props' => array('method' => $createdMethod, 'amount' => $amountUsd, 'target_type' => $targetType, 'linked_order_id' => (int) ($topup['linked_order_id'] ?? 0))));
    if ($createdMethod === 'moneygram') {
      $app->enqueueMessage('Western Union request created. Use the secure top-up page to view the receiver details and submit the MTCN / reference number after sending the transfer.', 'message');
    } elseif ($createdMethod === 'paypal') {
      $app->enqueueMessage('PayPal top-up created. Open the secure top-up page and complete the payment there.', 'message');
    } else {
      $app->enqueueMessage($targetType === 'lead' ? 'Linked top-up created. Because the minimum transfer is $' . number_format(LeadMarketHelper::minimumTopupUsd(), 2, '.', ',') . ', use this top-up flow for smaller lead purchases. After payment is confirmed, the linked lead can be unlocked automatically.' : 'Top-up created. Use the secure top-up page to complete payment.', 'message');
    }
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl((int) $topup['id'], $token), false));
    return true;
  }


  public function paypalCreateOrder()
  {
    $app = JFactory::getApplication();
    if (strtoupper($app->input->server->getString('REQUEST_METHOD', 'GET')) !== 'POST') {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Method not allowed.'), 405);
    }
    if (!JSession::checkToken('post')) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Invalid token.'), 403);
    }
    LeadMarketHelper::ensureSchema();
    $topupId = (int) $app->input->post->getInt('topup_id', 0);
    $token = trim((string) $app->input->post->getString('token', ''));
    $topup = LeadMarketHelper::loadTopupById($topupId);
    if (!$topup || !LeadMarketHelper::canAccessTopup($topup, $token)) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Access denied.'), 403);
    }
    if (LeadMarketHelper::normalizeTopupPaymentMethod((string) ($topup['payment_method'] ?? 'crypto')) !== 'paypal') {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'This top-up is not configured for PayPal.'), 400);
    }
    if (!LeadMarketHelper::isPaypalAllowedForAmount((float) (($topup['requested_topup_amount_usd'] ?? 0) > 0 ? ($topup['requested_topup_amount_usd'] ?? 0) : ($topup['topup_amount_usd'] ?? 0)))) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'PayPal is available for top-ups up to $' . number_format(LeadMarketHelper::paypalTopupMaxUsd(), 2, '.', ',') . '.'), 400);
    }
    $status = strtolower((string) ($topup['status'] ?? 'pending'));
    if (!in_array($status, array('pending', 'checking'), true)) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'This top-up is no longer payable.'), 400);
    }
    $existingOrderId = trim((string) ($topup['paypal_order_id'] ?? ''));
    if ($existingOrderId !== '' && strtolower((string) ($topup['paypal_status'] ?? '')) !== 'completed') {
      $this->closeLeadmarketJsonResponse(array('ok' => true, 'id' => $existingOrderId));
    }
    $created = LeadMarketHelper::paypalCreateOrderForTopup($topup);
    if (empty($created['ok']) || empty($created['order_id'])) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => (string) ($created['message'] ?? 'PayPal order creation failed.')), 400);
    }
    $this->closeLeadmarketJsonResponse(array('ok' => true, 'id' => (string) $created['order_id']));
  }

  public function paypalCaptureOrder()
  {
    $app = JFactory::getApplication();
    if (strtoupper($app->input->server->getString('REQUEST_METHOD', 'GET')) !== 'POST') {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Method not allowed.'), 405);
    }
    if (!JSession::checkToken('post')) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Invalid token.'), 403);
    }
    LeadMarketHelper::ensureSchema();
    $topupId = (int) $app->input->post->getInt('topup_id', 0);
    $token = trim((string) $app->input->post->getString('token', ''));
    $paypalOrderId = trim((string) $app->input->post->getString('paypal_order_id', ''));
    $topup = LeadMarketHelper::loadTopupById($topupId);
    if (!$topup || !LeadMarketHelper::canAccessTopup($topup, $token)) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Access denied.'), 403);
    }
    if (LeadMarketHelper::normalizeTopupPaymentMethod((string) ($topup['payment_method'] ?? 'crypto')) !== 'paypal') {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'This top-up is not configured for PayPal.'), 400);
    }
    if ($paypalOrderId === '') $paypalOrderId = trim((string) ($topup['paypal_order_id'] ?? ''));
    if ($paypalOrderId === '') {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'Missing PayPal order ID.'), 400);
    }
    $capture = LeadMarketHelper::paypalCaptureOrder($paypalOrderId);
    if (empty($capture['ok']) || empty($capture['data'])) {
      $message = (string) ($capture['message'] ?? 'PayPal capture failed.');
      $data = (array) ($capture['data'] ?? array());
      if (strtolower((string) ($data['name'] ?? '')) === 'unprocessable_entity' && strtolower((string) ($data['details'][0]['issue'] ?? '')) === 'order_already_captured') {
        $topupLatest = LeadMarketHelper::loadTopupByPayPalOrderId($paypalOrderId);
        if ($topupLatest && strtolower((string) ($topupLatest['status'] ?? '')) === 'paid') {
          $this->closeLeadmarketJsonResponse(array('ok' => true, 'redirect_url' => JRoute::_(LeadMarketHelper::buildTopupUrl((int) $topupLatest['id'], (string) ($topupLatest['access_token'] ?? $token)), false)));
        }
      }
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => $message), 400);
    }
    $payload = (array) $capture['data'];
    $purchaseUnit = (array) ($payload['purchase_units'][0] ?? array());
    $captures = (array) (($purchaseUnit['payments']['captures'] ?? array()));
    $captureNode = isset($captures[0]) && is_array($captures[0]) ? $captures[0] : array();
    if (!$captureNode) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => 'PayPal capture response did not include capture details.'), 400);
    }
    $eventPayload = array(
      'id' => '',
      'event_type' => 'PAYMENT.CAPTURE.COMPLETED',
      'resource' => $captureNode,
      'payer' => (array) ($payload['payer'] ?? array()),
      'summary' => (string) ($captureNode['status'] ?? 'COMPLETED'),
    );
    $result = $this->paypalMarkTopupPaidFromPayload($topup, $eventPayload, 'paypal:capture');
    if (empty($result['ok'])) {
      $this->closeLeadmarketJsonResponse(array('ok' => false, 'message' => (string) ($result['message'] ?? 'Could not credit PayPal payment.')), 400);
    }
    $fresh = LeadMarketHelper::loadTopupById($topupId);
    $this->closeLeadmarketJsonResponse(array(
      'ok' => true,
      'message' => 'PayPal payment completed.',
      'redirect_url' => JRoute::_(LeadMarketHelper::buildTopupUrl($topupId, (string) ($fresh['access_token'] ?? $token)), false),
    ));
  }

  public function paypalWebhook()
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();
    $raw = file_get_contents('php://input');
    $payload = json_decode((string) $raw, true);
    if (!is_array($payload)) {
      $this->closeLeadmarketTextResponse('Invalid payload', 400);
    }
    $headers = $this->getAllRequestHeadersCompat();
    $verify = LeadMarketHelper::verifyPayPalWebhookSignature($headers, $payload);
    if (empty($verify['ok'])) {
      LeadMarketHelper::writeRuntimeLog('paypal_webhook_verify_failed', array('message' => (string) ($verify['message'] ?? ''), 'payload' => $payload));
      $this->closeLeadmarketTextResponse('Webhook verification failed', 400);
    }
    $eventType = strtoupper(trim((string) ($payload['event_type'] ?? '')));
    $eventId = trim((string) ($payload['id'] ?? ''));
    if ($eventType === 'PAYMENT.CAPTURE.COMPLETED') {
      $topup = $this->paypalFindTopupForWebhook($payload);
      if ($topup) {
        $result = $this->paypalMarkTopupPaidFromPayload($topup, $payload, 'paypal:webhook', $eventId);
        if (empty($result['ok'])) {
          LeadMarketHelper::writeRuntimeLog('paypal_webhook_mark_failed', array('message' => (string) ($result['message'] ?? ''), 'event_type' => $eventType, 'event_id' => $eventId, 'payload' => $payload));
        }
      } else {
        LeadMarketHelper::writeRuntimeLog('paypal_webhook_topup_missing', array('event_type' => $eventType, 'event_id' => $eventId, 'payload' => $payload));
      }
    } elseif ($eventType === 'CHECKOUT.ORDER.APPROVED') {
      $topup = $this->paypalFindTopupForWebhook($payload);
      if ($topup) {
        LeadMarketHelper::storeTopupPayPalMeta((int) ($topup['id'] ?? 0), array(
          'paypal_order_id' => (string) (($payload['resource']['id'] ?? ($topup['paypal_order_id'] ?? ''))),
          'paypal_status' => 'APPROVED',
          'paypal_webhook_event_id' => $eventId,
          'paypal_payload_json' => json_encode($payload),
        ));
      }
    }
    $this->closeLeadmarketTextResponse('OK', 200);
  }

  public function topupCancel()
  {
    $app = JFactory::getApplication();
    if (!JSession::checkToken('post')) {
      $app->enqueueMessage('Invalid session token. Please try again.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    LeadMarketHelper::ensureSchema();
    $topupId = (int) $app->input->post->getInt('topup_id', 0);
    $token = trim((string) $app->input->post->getString('token', ''));
    $topup = LeadMarketHelper::loadTopupById($topupId);
    if (!$topup || !LeadMarketHelper::canAccessTopup($topup, $token)) {
      $app->enqueueMessage('Access denied.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    LeadMarketHelper::trackEvent('topup_cancelled', array('page_name' => 'topup', 'buyer_email' => (string) ($topup['buyer_email'] ?? ''), 'topup_id' => $topupId, 'lead_id' => (int) ($topup['target_type'] === 'lead' ? $topup['target_id'] : 0), 'batch_id' => (int) ($topup['target_type'] === 'batch' ? $topup['target_id'] : 0)));
    $result = LeadMarketHelper::markTopupCancelled($topupId, '', array('actor_type' => 'buyer'));
    $app->enqueueMessage((string) ($result['message'] ?? 'Done'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl($topupId, $token), false));
    return !empty($result['ok']);
  }

  public function topupIPaid()
  {
    $app = JFactory::getApplication();
    if (!JSession::checkToken('post')) {
      $app->enqueueMessage('Invalid session token. Please try again.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    LeadMarketHelper::ensureSchema();
    $topupId = (int) $app->input->post->getInt('topup_id', 0);
    $token = trim((string) $app->input->post->getString('token', ''));
    $topup = LeadMarketHelper::loadTopupById($topupId);
    if (!$topup || !LeadMarketHelper::canAccessTopup($topup, $token)) {
      $app->enqueueMessage('Access denied.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    $topupMethod = LeadMarketHelper::normalizeTopupPaymentMethod((string) ($topup['payment_method'] ?? 'crypto'));
    if ($topupMethod === 'moneygram') {
      $app->enqueueMessage('Submit the Western Union MTCN / reference number from the secure top-up page.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl($topupId, $token), false));
      return false;
    }
    if ($topupMethod === 'paypal') {
      $app->enqueueMessage('Use the PayPal button on the secure top-up page to complete payment.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl($topupId, $token), false));
      return false;
    }

    LeadMarketHelper::trackEvent('topup_reference_submitted', array('page_name' => 'topup', 'buyer_email' => (string) ($topup['buyer_email'] ?? ''), 'topup_id' => $topupId, 'props' => array('method' => 'crypto')));
    $result = LeadMarketHelper::markTopupChecking($topupId);
    $app->enqueueMessage((string) ($result['message'] ?? 'Done'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl($topupId, $token), false));
    return !empty($result['ok']);
  }

  public function topupMoneygramSubmit()
  {
    $app = JFactory::getApplication();
    if (!JSession::checkToken('post')) {
      $app->enqueueMessage('Invalid session token. Please try again.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    LeadMarketHelper::ensureSchema();
    $topupId = (int) $app->input->post->getInt('topup_id', 0);
    $token = trim((string) $app->input->post->getString('token', ''));
    $topup = LeadMarketHelper::loadTopupById($topupId);
    if (!$topup || !LeadMarketHelper::canAccessTopup($topup, $token)) {
      $app->enqueueMessage('Access denied.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    $reference = trim((string) $app->input->post->getString('manual_reference', ''));
    $senderName = trim((string) $app->input->post->getString('manual_sender_name', ''));
    $senderCountry = trim((string) $app->input->post->getString('manual_sender_country', ''));
    $reviewNote = trim((string) $app->input->post->getString('manual_review_note', ''));
    LeadMarketHelper::trackEvent('topup_reference_submitted', array('page_name' => 'topup', 'buyer_email' => (string) ($topup['buyer_email'] ?? ''), 'topup_id' => $topupId, 'props' => array('method' => 'western_union')));
    $result = LeadMarketHelper::submitMoneygramTopup($topupId, $reference, $senderName, $senderCountry, $reviewNote);
    $app->enqueueMessage((string) ($result['message'] ?? 'Done'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_(LeadMarketHelper::buildTopupUrl($topupId, $token), false));
    return !empty($result['ok']);
  }


  public function topupStatus()
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();
    $topupId = (int) $app->input->getInt('topup_id', 0);
    $token = LeadMarketHelper::readBuyerAccessTokenFromRequest();
    $topup = LeadMarketHelper::loadTopupById($topupId);
    header('Content-Type: application/json; charset=utf-8');
    if (!$topup || !LeadMarketHelper::canAccessTopup($topup, $token)) {
      echo json_encode(array('ok' => false, 'message' => 'Access denied.'));
      $app->close();
    }
    echo json_encode(LeadMarketHelper::getTopupStatusPayload($topup, $token));
    $app->close();
  }


  public function dashboardHide()
  {
    $app = JFactory::getApplication();
    $input = $app->input;
    JSession::checkToken() or jexit('Invalid Token');
    $token = LeadMarketHelper::readBuyerActionTokenFromRequest('buyer_token');
    $itemType = strtolower(trim((string) $input->getCmd('item_type', '')));
    $itemId = (int) $input->getInt('item_id', 0);
    $returnUrl = trim((string) $input->get('return_url', '', 'raw'));
    if ($returnUrl === '' && isset($_POST['return_url'])) {
      $returnUrl = trim((string) $_POST['return_url']);
    }
    $access = LeadMarketHelper::validateBuyerAccessToken($token);
    if (!$access || $itemId <= 0 || !in_array($itemType, array('lead','batch','topup'), true)) {
      $app->enqueueMessage('We could not hide this item right now.', 'error');
      $redirect = $returnUrl !== '' ? $returnUrl : LeadMarketHelper::getBuyerAccessActionUrl('');
      $this->setRedirect(JRoute::_($redirect, false));
      return;
    }
    $buyerEmail = (string) ($access['buyer_email'] ?? '');
    LeadMarketHelper::rememberBuyerDashboardHiddenItem($buyerEmail, $itemType, $itemId);
    $app->enqueueMessage('Item hidden from this list.', 'message');
    $redirect = $returnUrl !== '' ? $returnUrl : ('index.php?option=com_leadmarket&view=buyeraccess&token=' . urlencode($token));
    $redirectTarget = preg_match('#^https?://#i', $redirect) ? $redirect : JRoute::_($redirect, false);
    $this->setRedirect($redirectTarget);
  }



  public function creditRequestSubmit()
  {
    $app = JFactory::getApplication();
    $input = $app->input;
    JSession::checkToken() or jexit('Invalid Token');

    $root = rtrim(JUri::root(), '/');

    $buildFallbackRedirect = function ($token, $orderId = 0) use ($root) {
      $token = trim((string) $token);
      $orderId = (int) $orderId;
      $url = $token !== '' ? LeadMarketHelper::buildAbsoluteBuyerAccessUrl($token) : LeadMarketHelper::getBuyerAccessActionAbsoluteUrl('');
      if ($url === '') {
        $url = $root . '/index.php?option=com_leadmarket&view=buyeraccess';
      }
      $params = array('section' => 'leads');
      if ($orderId > 0) {
        $params['credit_order'] = $orderId;
      }
      $fragment = $orderId > 0 ? '#credit-box-' . $orderId : '';
      $sep = strpos($url, '?') !== false ? '&' : '?';
      return $url . $sep . http_build_query($params) . $fragment;
    };

    $normalizeRedirectUrl = function ($url, $fallback) use ($root) {
      $fallback = trim((string) $fallback);
      if ($fallback === '') {
        $fallback = $root . '/index.php?option=com_leadmarket&view=buyeraccess';
      }

      $url = html_entity_decode(trim((string) $url), ENT_QUOTES, 'UTF-8');
      $url = str_replace(array("\r", "\n"), '', $url);
      if ($url === '') {
        return $fallback;
      }

      if (preg_match('#^https?://#i', $url)) {
        $targetHost = strtolower((string) parse_url($url, PHP_URL_HOST));
        $siteHost = strtolower((string) parse_url(JUri::root(), PHP_URL_HOST));
        if ($targetHost !== '' && $siteHost !== '' && $targetHost !== $siteHost) {
          return $fallback;
        }
        return $url;
      }

      if (strpos($url, '//') === 0 || stripos($url, 'javascript:') === 0 || stripos($url, 'data:') === 0) {
        return $fallback;
      }

      if (strpos($url, '?option=com_leadmarket') === 0) {
        return $root . '/index.php' . $url;
      }

      if (strpos($url, 'index.php?option=com_leadmarket') === 0) {
        return $root . '/' . ltrim($url, '/');
      }

      if (strpos($url, '/index.php?option=com_leadmarket') === 0) {
        return $root . $url;
      }

      if ($url[0] === '/') {
        return $root . $url;
      }

      return $root . '/' . ltrim($url, '/');
    };

    $redirectNow = function ($targetUrl, $statusCode = 303) use ($app) {
      $targetUrl = trim((string) $targetUrl);
      if ($targetUrl === '') {
        $targetUrl = rtrim(JUri::root(), '/') . '/';
      }

      while (ob_get_level()) {
        @ob_end_clean();
      }

      if (!headers_sent()) {
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0', true);
        header('Pragma: no-cache', true);
        header('Expires: 0', true);
        header('Location: ' . $targetUrl, true, (int) $statusCode > 0 ? (int) $statusCode : 303);
      } else {
        echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=' . htmlspecialchars($targetUrl, ENT_QUOTES, 'UTF-8') . '"><script>window.location.replace(' . json_encode($targetUrl) . ');</script></head><body></body></html>';
      }

      $app->close();
    };

    $token = '';
    $orderId = 0;
    $returnUrlRaw = '';

    try {
      $token = LeadMarketHelper::readBuyerActionTokenFromRequest('buyer_token');
      $orderId = (int) $input->post->getInt('order_id', $input->getInt('order_id', 0));
      $reason = trim((string) $input->post->get('reason_code', $input->get('reason_code', '', 'raw'), 'raw'));
      $note = trim((string) $input->post->get('buyer_note', $input->get('buyer_note', '', 'raw'), 'raw'));
      $returnUrlRaw = trim((string) $input->post->get('return_url', $input->get('return_url', '', 'raw'), 'raw'));
      if ($returnUrlRaw === '' && isset($_POST['return_url'])) {
        $returnUrlRaw = trim((string) $_POST['return_url']);
      }

      $fallbackRedirect = $buildFallbackRedirect($token, $orderId);
      $redirectTarget = $normalizeRedirectUrl($returnUrlRaw, $fallbackRedirect);

      $access = LeadMarketHelper::validateBuyerAccessToken($token);
      if (!$access || $orderId <= 0) {
        LeadMarketHelper::writeRuntimeLog('credit_request_submit_invalid_context', array(
          'order_id' => $orderId,
          'buyer_token_present' => $token !== '' ? 1 : 0,
          'return_url' => $returnUrlRaw,
        ));
        $app->enqueueMessage('We could not submit your credit request right now.', 'error');
        $redirectNow($redirectTarget);
        return false;
      }

      $buyerEmail = (string) ($access['buyer_email'] ?? '');
      $requestIp = !empty($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
      $userAgent = !empty($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';

      try {
        LeadMarketHelper::trackEvent('credit_request_submitted', array(
          'page_name' => 'credit_request',
          'buyer_email' => $buyerEmail,
          'order_id' => $orderId,
          'props' => array('reason' => $reason),
        ));
      } catch (Throwable $ignore) {
      }

      try {
        $result = LeadMarketHelper::submitCreditRequest($orderId, $buyerEmail, $reason, $note, $requestIp, $userAgent);
      } catch (Throwable $e) {
        LeadMarketHelper::writeRuntimeLog('credit_request_submit_inner_throwable', array(
          'order_id' => $orderId,
          'buyer_email' => $buyerEmail,
          'message' => $e->getMessage(),
          'file' => $e->getFile(),
          'line' => (int) $e->getLine(),
        ));
        $result = array('ok' => false, 'message' => 'Could not submit your credit request right now.');
      }

      $app->enqueueMessage((string) ($result['message'] ?? 'Done.'), !empty($result['ok']) ? 'message' : 'error');
      $redirectNow($redirectTarget);
      return !empty($result['ok']);
    } catch (Throwable $e) {
      LeadMarketHelper::writeRuntimeLog('credit_request_submit_throwable', array(
        'order_id' => $orderId,
        'buyer_token_present' => $token !== '' ? 1 : 0,
        'return_url' => $returnUrlRaw,
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => (int) $e->getLine(),
      ));
      $app->enqueueMessage('Could not submit your credit request right now.', 'error');
      $fallbackRedirect = $buildFallbackRedirect($token, $orderId);
      $redirectNow($normalizeRedirectUrl($returnUrlRaw, $fallbackRedirect));
      return false;
    }
  }


  public function accessOpen()
  {
    $app = JFactory::getApplication();
    LeadMarketHelper::ensureSchema();

    $input = $app->input;
    $section = trim((string) $input->getCmd('section', ''));
    $creditOrder = (int) $input->getInt('credit_order', 0);

    $appendBuyerAccessState = function ($url) use ($section, $creditOrder) {
      $url = (string) $url;
      if ($url === '') return $url;
      $params = array();
      if ($section !== '') $params['section'] = $section;
      if ($creditOrder > 0) $params['credit_order'] = $creditOrder;
      if (!$params) return $url;
      $fragment = '';
      $hashPos = strpos($url, '#');
      if ($hashPos !== false) {
        $fragment = substr($url, $hashPos);
        $url = substr($url, 0, $hashPos);
      }
      $sep = strpos($url, '?') !== false ? '&' : '?';
      return $url . $sep . http_build_query($params) . $fragment;
    };

    $token = LeadMarketHelper::getRememberedBuyerAccessToken();
    if ($token !== '' && LeadMarketHelper::validateBuyerAccessToken($token)) {
      $this->setRedirect($appendBuyerAccessState(LeadMarketHelper::buildAbsoluteBuyerAccessUrl($token)));
      return true;
    }

    $buyerEmail = LeadMarketHelper::normalizeBuyerEmail(trim((string) $app->input->getString('buyer_email', '')));
    if ($buyerEmail === '' || !filter_var($buyerEmail, FILTER_VALIDATE_EMAIL)) {
      $app->enqueueMessage('We could not open buyer access right now. Request a fresh access link.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }

    $requestIp = !empty($_SERVER['REMOTE_ADDR']) ? (string) $_SERVER['REMOTE_ADDR'] : '';
    $userAgent = !empty($_SERVER['HTTP_USER_AGENT']) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';

    try {
      $created = LeadMarketHelper::createBuyerAccessRequest($buyerEmail, $requestIp, $userAgent);
      $tokenRow = null;
      if (is_array($created) && !empty($created['ok']) && !empty($created['token_row']['access_token'])) {
        $tokenRow = $created['token_row'];
      } elseif (is_array($created) && !empty($created['access_token'])) {
        $tokenRow = $created;
      }
      if (!$tokenRow || empty($tokenRow['access_token'])) {
        $app->enqueueMessage('We could not open buyer access right now. Request a fresh access link.', 'error');
        $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
        return false;
      }
      $token = (string) $tokenRow['access_token'];
      LeadMarketHelper::rememberBuyerAccessToken($token);
      LeadMarketHelper::setActiveBuyerContext($buyerEmail, 'buyer_access_open', $token);
      $this->setRedirect($appendBuyerAccessState(LeadMarketHelper::buildAbsoluteBuyerAccessUrl($token)));
      return true;
    } catch (Exception $e) {
      LeadMarketHelper::writeRuntimeLog('buyer_access_open_failed', array('buyer_email' => $buyerEmail, 'message' => $e->getMessage()));
      $app->enqueueMessage('We could not open buyer access right now. Request a fresh access link.', 'error');
      $this->setRedirect(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl(), false));
      return false;
    }
  }

  public function accessRequestLink()
  {
    $app = JFactory::getApplication();
    $input = $app->input;
    $returnUrlRaw = trim((string)$input->post->getString('return_url', ''));
    $fallbackReturn = LeadMarketHelper::getBuyerAccessRequestUrl();
    $redirectAfter = $fallbackReturn;
    if ($returnUrlRaw !== '' && (strpos($returnUrlRaw, 'index.php?option=com_leadmarket') === 0 || strpos($returnUrlRaw, '/index.php?option=com_leadmarket') === 0 || strpos($returnUrlRaw, '?option=com_leadmarket') === 0)) {
      $redirectAfter = $returnUrlRaw;
    }

    $requestedFormat = strtolower(trim((string) $input->getCmd('format', '')));
    $requestedWith = '';
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH'])) $requestedWith = strtolower(trim((string) $_SERVER['HTTP_X_REQUESTED_WITH']));
    $isAjax = ((int) $input->post->getInt('ajax', 0) === 1) || $requestedWith === 'xmlhttprequest' || $requestedFormat === 'raw';

    $appendStatusParams = function ($url, $params) {
      $url = (string) $url;
      $params = is_array($params) ? $params : array();
      if ($url === '' || !$params) return $url;
      $fragment = '';
      $hashPos = strpos($url, '#');
      if ($hashPos !== false) {
        $fragment = substr($url, $hashPos);
        $url = substr($url, 0, $hashPos);
      }
      $sep = strpos($url, '?') !== false ? '&' : '?';
      return $url . $sep . http_build_query($params) . $fragment;
    };

    $respond = function ($ok, $message, $tone, $redirectUrl, $statusCode) use ($app, $isAjax) {
      $payload = array(
        'ok' => !empty($ok),
        'message' => (string) $message,
        'tone' => (string) ($tone !== '' ? $tone : (!empty($ok) ? 'success' : 'error')),
        'redirect_url' => (string) $redirectUrl,
      );
      if ($isAjax) {
        if (!headers_sent()) {
          http_response_code((int) $statusCode);
          header('Content-Type: application/json; charset=utf-8');
        }
        echo json_encode($payload);
        $app->close();
      }
      return !empty($ok);
    };

    if (!JSession::checkToken('post')) {
      $message = 'Invalid session token. Please refresh the page and try again.';
      $app->enqueueMessage($message, 'error');
      $this->setRedirect(JRoute::_($appendStatusParams($redirectAfter, array('lm_access_status' => 'invalid_token')), false));
      return $respond(false, $message, 'error', JRoute::_($redirectAfter, false), 403);
    }

    LeadMarketHelper::ensureSchema();
    $emailRaw = trim((string)$input->post->getString('buyer_email', ''));
    $email = LeadMarketHelper::normalizeBuyerEmail($emailRaw);
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
      $message = 'Enter a valid buyer email and try again.';
      $this->setRedirect(JRoute::_($appendStatusParams($redirectAfter, array('lm_access_status' => 'invalid_email')), false));
      return $respond(false, $message, 'error', JRoute::_($redirectAfter, false), 422);
    }

    $requestIp = '';
    if (!empty($_SERVER['REMOTE_ADDR'])) $requestIp = (string)$_SERVER['REMOTE_ADDR'];
    $userAgent = '';
    if (!empty($_SERVER['HTTP_USER_AGENT'])) $userAgent = (string)$_SERVER['HTTP_USER_AGENT'];

    try {
      $created = LeadMarketHelper::createBuyerAccessRequest($email, $requestIp, $userAgent);
      $tokenRow = null;
      if (is_array($created) && array_key_exists('ok', $created)) {
        if (!empty($created['ok']) && !empty($created['token_row'])) {
          $tokenRow = $created['token_row'];
        } else {
          LeadMarketHelper::writeRuntimeLog('buyer_access_request_using_stateless_fallback', array(
            'buyer_email' => $email,
            'error' => (string) ($created['error'] ?? 'link_failed'),
            'message' => (string) ($created['message'] ?? ''),
          ));
        }
      } elseif (is_array($created) && !empty($created['access_token'])) {
        $tokenRow = $created;
      }
      if (!$tokenRow) {
        $message = 'We could not create a secure buyer access link right now. Please try again in a moment.';
        $app->enqueueMessage($message, 'error');
        $this->setRedirect(JRoute::_($appendStatusParams($redirectAfter, array('lm_access_status' => 'link_failed')), false));
        return $respond(false, $message, 'error', JRoute::_($redirectAfter, false), 500);
      }
      $sent = LeadMarketHelper::sendBuyerAccessMagicLink($email, $tokenRow);
      if (!$sent) {
        $message = 'We could not send a buyer access link right now. Please try again in a moment.';
        $app->enqueueMessage($message, 'error');
        $this->setRedirect(JRoute::_($appendStatusParams($redirectAfter, array('lm_access_status' => 'mail_failed')), false));
        return $respond(false, $message, 'error', JRoute::_($redirectAfter, false), 500);
      }
      $message = 'Buyer access link sent to ' . $email . '.';
      $app->enqueueMessage($message, 'message');
      $this->setRedirect(JRoute::_($appendStatusParams($redirectAfter, array('lm_access_status' => 'sent', 'lm_access_email' => $email)), false));
      return $respond(true, $message, 'success', JRoute::_($redirectAfter, false), 200);
    } catch (Throwable $e) {
      LeadMarketHelper::writeRuntimeLog('buyer_access_request_failed', array('buyer_email' => $email, 'message' => $e->getMessage()));
      $message = 'We could not create a buyer access link right now. Please try again in a moment.';
      $app->enqueueMessage($message, 'error');
      $this->setRedirect(JRoute::_($appendStatusParams($redirectAfter, array('lm_access_status' => 'link_failed')), false));
      return $respond(false, $message, 'error', JRoute::_($redirectAfter, false), 500);
    }
  }

}
