<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketModelLeads extends JModelList
{
  protected function populateState($ordering = 'id', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    parent::populateState($ordering, $direction);
    $this->setState('filter.state_code', strtoupper(trim((string)$app->input->getString('state_code', ''))));
    $this->setState('filter.lead_type', strtolower(trim((string)$app->input->getString('lead_type', ''))));
    $this->setState('filter.tier', strtolower(trim((string)$app->input->getString('tier', ''))));
    $this->setState('filter.availability', strtolower(trim((string)$app->input->getString('availability', ''))));
    $this->setState('list.limit', max(1, min(48, (int)$app->input->getInt('limit', 20))));
    $this->setState('list.start', max(0, (int)$app->input->getInt('limitstart', 0)));
    $sort = strtolower(trim((string)$app->input->getString('sort', 'newest')));
    $this->setState('list.sort_mode', $sort ?: 'newest');
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();
    $showUnsoldOlder = LeadMarketHelper::showArchivedUnsoldInMarket();
    $showSoldOlder = LeadMarketHelper::showArchivedSoldInMarket();

    $visibilityParts = array(
      $db->qn('lead_status') . ' IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')'
    );
    $olderParts = array();
    if ($showUnsoldOlder) {
      $olderParts[] = '(' . $db->qn('lead_status') . '=' . $db->q('archived') . ' AND COALESCE(' . $db->qn('sold_count') . ',0)=0)';
    }
    if ($showSoldOlder) {
      $olderParts[] = '(' . $db->qn('lead_status') . '=' . $db->q('archived') . ' AND COALESCE(' . $db->qn('sold_count') . ',0)>0)';
    }
    if (!empty($olderParts)) {
      $visibilityParts[] = '(' . implode(' OR ', $olderParts) . ')';
    }

    $query = $db->getQuery(true)
      ->select('*')
      ->from($db->qn('#__leadmarket_leads'))
      ->where('(' . implode(' OR ', $visibilityParts) . ')')
      ->where('COALESCE(' . $db->qn('is_sample') . ',0)=0');

    $state = $this->getState('filter.state_code');
    if ($state !== '') $query->where($db->qn('state') . '=' . $db->q($state));

    $leadType = $this->getState('filter.lead_type');
    if (in_array($leadType, array('auto', 'home'), true)) {
      $query->where('LOWER(' . $db->qn('type') . ')=' . $db->q($leadType));
    }

    $priorityExpr = 'CASE WHEN ' . $db->qn('lead_status') . '=' . $db->q('fresh') . ' THEN 0 WHEN ' . $db->qn('lead_status') . '=' . $db->q('aged') . ' THEN 1 ELSE 2 END';
    $sortMode = $this->getState('list.sort_mode', 'newest');
    switch ($sortMode) {
      case 'price_asc':
        $query->order($priorityExpr . ' ASC, ' . $db->qn('price_usd') . ' ASC, ' . $db->qn('uploaded_at_utc') . ' DESC, ' . $db->qn('id') . ' DESC');
        break;
      case 'price_desc':
        $query->order($priorityExpr . ' ASC, ' . $db->qn('price_usd') . ' DESC, ' . $db->qn('uploaded_at_utc') . ' DESC, ' . $db->qn('id') . ' DESC');
        break;
      case 'state_asc':
        $query->order($priorityExpr . ' ASC, ' . $db->qn('state') . ' ASC, ' . $db->qn('uploaded_at_utc') . ' DESC, ' . $db->qn('id') . ' DESC');
        break;
      default:
        $query->order($priorityExpr . ' ASC, ' . $db->qn('uploaded_at_utc') . ' DESC, ' . $db->qn('id') . ' DESC');
    }
    return $query;
  }

  public function getItems()
  {
    $items = (array) parent::getItems();
    $tierFilter = $this->getState('filter.tier');
    $availabilityFilter = $this->getState('filter.availability');
    $out = array();
    foreach ($items as $it) {
      $row = (array)$it;
      $tier = strtolower(LeadMarketHelper::getBuyerTierLabel($row));
      $availability = strtolower(LeadMarketHelper::getBuyerAvailabilityLabel($row));
      if ($tierFilter && $tierFilter !== 'all' && $tier !== strtolower($tierFilter)) continue;
      if ($availabilityFilter && $availabilityFilter !== 'all') {
        if ($availabilityFilter === 'available' && !in_array($availability, array('ready to buy','shared access','exclusive only'), true)) continue;
        if ($availabilityFilter === 'limited' && $availability !== 'limited availability') continue;
      }
      $out[] = $it;
    }
    return $out;
  }
}
