<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketViewFreetestleads extends JViewLegacy
{
  public $items = array();
  public $teaserItems = array();
  public $settings = array();
  public $marketUrl = '';
  public $freeTestUrl = '';
  public $stateOptions = array();
  public $trialToken = '';
  public $trialAccess = array();
  public $selectedLeadType = 'both';
  public $selectedStates = array();
  public $fallbackUsed = false;

  protected function applyTechnicalSeoProtection($allowIndex)
  {
    $robots = $allowIndex ? 'index, follow' : 'noindex, nofollow';
    $doc = JFactory::getDocument();
    if ($doc && method_exists($doc, 'setMetaData')) {
      $doc->setMetaData('robots', $robots);
    }
    $app = JFactory::getApplication();
    try { $app->setHeader('X-Robots-Tag', $robots, true); } catch (Exception $e) {}
    if (!headers_sent()) header('X-Robots-Tag: ' . $robots, true);
  }

  public function display($tpl = null)
  {
    LeadMarketHelper::ensureSchema();
    $app = JFactory::getApplication();
    $input = $app->input;
    $trialTokenRaw = trim((string) $input->getString('trial_token', ''));
    $this->applyTechnicalSeoProtection($trialTokenRaw === '');
    $this->settings = LeadMarketHelper::getFreeTestSettings();
    $this->marketUrl = LeadMarketHelper::getMarketplaceUrl(false);
    $this->freeTestUrl = LeadMarketHelper::getFreeTestPageUrl(false);
    $this->stateOptions = LeadMarketHelper::getMarketplaceStateOptions('');
    $this->teaserItems = LeadMarketHelper::getFreeTestTeaserLeads(6);
    $this->trialToken = $trialTokenRaw;
    if ($this->trialToken !== '') {
      $access = LeadMarketHelper::getTrialAccessByToken($this->trialToken);
      if ($access && LeadMarketHelper::isValidTrialAccess($this->trialToken)) {
        LeadMarketHelper::touchTrialAccessView($this->trialToken);
        $this->trialAccess = (array) $access;
        $this->selectedLeadType = LeadMarketHelper::normalizeFreeTestLeadType((string) ($access['lead_type'] ?? 'both'));
        $statesJson = (string) ($access['states_json'] ?? '');
        $states = json_decode($statesJson, true);
        if (!is_array($states)) $states = array();
        $this->selectedStates = LeadMarketHelper::normalizeFreeTestStates($states);
        $this->items = LeadMarketHelper::getFreeTestLeads(array('lead_type' => $this->selectedLeadType, 'states' => $this->selectedStates));
        if (!$this->items) {
          $this->items = LeadMarketHelper::getFreeTestLeads(array(), 0);
          $this->fallbackUsed = true;
        }
      }
    }
    $doc = JFactory::getDocument();
    if ($doc) {
      $doc->setTitle((string) ($this->settings['title'] ?? 'Free Test Leads'));
      $doc->setDescription((string) ($this->settings['subtitle'] ?? ''));
    }
    parent::display($tpl);
  }
}
