<?php defined('_JEXEC') or die; ?>
<?php require_once JPATH_COMPONENT . '/helpers/leadmarket.php'; ?>
<?php
$settings = is_array($this->settings ?? null) ? $this->settings : array();
$badgeText = (string) ($settings['badge_text'] ?? 'Free Buyer Trial');
$title = (string) ($settings['title'] ?? 'Unlock Real Insurance Test Leads');
$subtitle = (string) ($settings['subtitle'] ?? '');
$buttonText = (string) ($settings['button_text'] ?? 'Unlock My Free Test Leads');
$successTitle = (string) ($settings['success_title'] ?? 'Your free test leads are unlocked');
$successText = (string) ($settings['success_text'] ?? '');
$marketCtaText = (string) ($settings['market_cta_text'] ?? 'Open Live Marketplace');
$marketCtaUrl = trim((string) ($settings['market_cta_url'] ?? $this->marketUrl));
if ($marketCtaUrl === '') $marketCtaUrl = $this->marketUrl;
$trialAccess = is_array($this->trialAccess ?? null) ? $this->trialAccess : array();
$isUnlocked = !empty($trialAccess);
$trackedMarketCtaUrl = $isUnlocked ? LeadMarketHelper::buildFreeTestMarketplaceClickUrl((string)($this->trialToken ?? ''), $marketCtaUrl) : $marketCtaUrl;
$previewCount = count((array) ($this->teaserItems ?? array()));
$selectedLeadType = (string) ($this->selectedLeadType ?? 'both');
$selectedStates = is_array($this->selectedStates ?? null) ? $this->selectedStates : array();
$selectedState = !empty($selectedStates) ? (string) $selectedStates[0] : 'ALL';
$app = JFactory::getApplication();
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<style>
.lm-ft-wrap{max-width:1160px;margin:24px auto;padding:0 16px;font-family:Arial,sans-serif;color:#13232f}.lm-ft-hero{background:linear-gradient(135deg,#f6fbff 0%,#eef7fd 100%);border:1px solid #d8e7f3;border-radius:24px;padding:26px;box-shadow:0 14px 32px rgba(16,54,82,.08)}
.lm-ft-badge{display:inline-block;padding:7px 12px;border-radius:999px;background:#eef6fb;border:1px solid #d8e8f3;color:#0c5585;font-size:12px;font-weight:800;margin-bottom:12px}.lm-ft-title{margin:0 0 10px;font-size:42px;line-height:1.05;color:#0c5585}.lm-ft-copy{margin:0;color:#44545e;line-height:1.75;max-width:760px}.lm-ft-trust{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}.lm-ft-chip{display:inline-block;background:#fff;border:1px solid #dbe6ef;border-radius:999px;padding:7px 11px;font-size:12px;font-weight:800;color:#24475d}
.lm-ft-grid{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(300px,.9fr);gap:18px;margin-top:18px}.lm-ft-panel{background:#fff;border:1px solid #dbe6ef;border-radius:18px;padding:18px;box-shadow:0 8px 24px rgba(16,54,82,.05)}.lm-ft-form label{display:block;font-size:13px;font-weight:800;color:#22313b;margin:0 0 6px}.lm-ft-form input[type=email],.lm-ft-form select{display:block;width:100%;min-height:48px;border:1px solid #cfd9e3;border-radius:12px;padding:0 14px;box-sizing:border-box;background:#fff}.lm-ft-form .lm-ft-check{display:flex;gap:10px;align-items:flex-start;margin-top:12px;color:#44545e;line-height:1.6}.lm-ft-form .lm-ft-check--locked{opacity:1}.lm-ft-form .lm-ft-check--locked input[disabled]{accent-color:#0c5585;cursor:not-allowed;pointer-events:none}.lm-ft-form button{display:inline-flex;align-items:center;justify-content:center;min-height:48px;padding:0 18px;border-radius:12px;background:#0c5585;color:#fff;border:0;font-weight:800;cursor:pointer;margin-top:14px}.lm-ft-cols{display:grid;grid-template-columns:1fr 1fr;gap:12px}.lm-ft-steps{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:0 0 14px}.lm-ft-step{background:#f8fbfd;border:1px solid #e5edf5;border-radius:14px;padding:14px}.lm-ft-step__kicker{display:inline-block;font-size:11px;font-weight:800;letter-spacing:.03em;text-transform:uppercase;color:#607080;margin-bottom:6px}.lm-ft-step strong{display:block;color:#13232f;font-size:16px;margin-bottom:4px}.lm-ft-step p{margin:0;color:#44545e;line-height:1.65;font-size:14px}.lm-ft-miniTrust{margin-top:10px;font-size:13px;line-height:1.7;color:#61717f;font-weight:700}.lm-ft-note{margin-top:10px;font-size:13px;line-height:1.7;color:#61717f}.lm-ft-why{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:18px}.lm-ft-whybox{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(16,54,82,.05)}.lm-ft-whybox strong{display:block;margin-bottom:6px;color:#0c5585;font-size:15px}.lm-ft-whybox p{margin:0;color:#44545e;line-height:1.7}.lm-ft-section{margin-top:18px}.lm-ft-section h2{margin:0 0 8px;color:#0c5585;font-size:30px}.lm-ft-section p{margin:0 0 12px;color:#44545e;line-height:1.7}.lm-ft-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.lm-ft-card{background:#fff;border:1px solid #dbe6ef;border-radius:18px;padding:16px;box-shadow:0 8px 24px rgba(16,54,82,.05)}.lm-ft-card__head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.lm-ft-card__title{margin:0 0 6px;font-size:24px;color:#13232f;font-weight:800}.lm-ft-card__meta{color:#61717f;line-height:1.6}.lm-ft-card__badge{display:inline-block;background:#edf8f1;color:#1f6a3c;border:1px solid #cfe7d8;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:800}.lm-ft-card__grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}.lm-ft-card__box{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px}.lm-ft-card__label{display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}.lm-ft-card__value{font-size:16px;color:#13232f;font-weight:800}.lm-ft-card__copy{margin-top:10px;color:#44545e;line-height:1.65}.lm-ft-card__actions{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-top:14px}.lm-ft-btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 14px;border-radius:12px;background:#0c5585;color:#fff;text-decoration:none;font-weight:800}.lm-ft-link{color:#0c5585;text-decoration:none;font-weight:800}.lm-ft-lock{margin-top:12px;padding:10px 12px;border-radius:12px;background:#fff8ef;border:1px solid #eadfc7;color:#7a5c1e;line-height:1.6;font-size:13px}.lm-ft-success{margin-top:16px;padding:14px 16px;border-radius:14px;background:#eefaf0;border:1px solid #cfe5d4;color:#1f6b35;line-height:1.7}.lm-ft-sidebarStat{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px;margin-top:10px}.lm-ft-sidebarStat strong{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:#607080;margin-bottom:4px}.lm-ft-sidebarStat span{font-size:16px;color:#13232f;font-weight:800}.lm-ft-faq{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px}.lm-ft-faqbox{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:16px;box-shadow:0 8px 24px rgba(16,54,82,.05)}.lm-ft-faqbox strong{display:block;margin-bottom:6px;color:#0c5585}.lm-ft-faqbox p{margin:0;color:#44545e;line-height:1.7}
@media(max-width:960px){.lm-ft-grid,.lm-ft-list,.lm-ft-faq,.lm-ft-steps{grid-template-columns:1fr}.lm-ft-why{grid-template-columns:1fr}.lm-ft-cols{grid-template-columns:1fr}.lm-ft-title{font-size:34px}}
</style>
<div class="lm-ft-wrap">
  <div class="lm-ft-hero">
    <span class="lm-ft-badge"><?php echo htmlspecialchars($badgeText, ENT_QUOTES, 'UTF-8'); ?></span>
    <h1 class="lm-ft-title"><?php echo htmlspecialchars($title, ENT_QUOTES, 'UTF-8'); ?></h1>
    <p class="lm-ft-copy"><?php echo htmlspecialchars($subtitle, ENT_QUOTES, 'UTF-8'); ?></p>
    <div class="lm-ft-trust"><span class="lm-ft-chip">Real leads</span><span class="lm-ft-chip">No payment required</span><span class="lm-ft-chip">Instant alerts</span></div>
    <?php echo LeadMarketHelper::renderOpeningPromoBar('lm-launchbar', 'lm-launchbar__badge', 'lm-launchbar__copy'); ?>
  </div>

  <div class="lm-ft-grid">
    <div class="lm-ft-panel">
      <?php if ($isUnlocked): ?>
        <div class="lm-ft-success"><strong><?php echo htmlspecialchars($successTitle, ENT_QUOTES, 'UTF-8'); ?></strong><br><?php echo htmlspecialchars($successText, ENT_QUOTES, 'UTF-8'); ?><?php if (!empty($this->fallbackUsed)): ?><br>No exact matches were in the current free pool, so the full trial set is shown below.<?php endif; ?></div>
      <?php else: ?>
        <h2 style="margin:0 0 8px;color:#0c5585;font-size:28px;">Start in 2 quick steps</h2>
        <p style="margin:0 0 14px;color:#44545e;line-height:1.7;">Enter your email, choose your lead type and state focus, then unlock the curated free test pool and activate instant alerts for matching incoming leads.</p>
        <div class="lm-ft-steps">
          <div class="lm-ft-step"><span class="lm-ft-step__kicker">Step 1</span><strong>Enter your email and preferences</strong><p>Tell us which lead type and state focus you want so your alerts start with the right inventory.</p></div>
          <div class="lm-ft-step"><span class="lm-ft-step__kicker">Step 2</span><strong>Unlock free test leads instantly</strong><p>Click the button below to open the full trial set and start receiving instant email alerts automatically.</p></div>
        </div>
        <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=freetestunlock'), ENT_QUOTES, 'UTF-8'); ?>" method="post" class="lm-ft-form">
          <input type="hidden" name="return" value="<?php echo htmlspecialchars($this->freeTestUrl, ENT_QUOTES, 'UTF-8'); ?>">
          <div><label>Email address</label><input type="email" name="email" value="" required></div>
          <div class="lm-ft-cols">
            <div><label>Lead type</label><select name="lead_type"><option value="both">All</option><option value="auto">Auto</option><option value="home">Home</option></select></div>
            <div><label>State</label><select name="state_code"><option value="ALL">All states</option><?php foreach ((array)$this->stateOptions as $stateCode): ?><option value="<?php echo htmlspecialchars((string)$stateCode, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string)$stateCode, ENT_QUOTES, 'UTF-8'); ?></option><?php endforeach; ?></select></div>
          </div>
          <input type="hidden" name="alerts_optin" value="1">
          <label class="lm-ft-check lm-ft-check--locked"><input type="checkbox" checked disabled aria-hidden="true"> <span>By unlocking free test leads, you agree to receive instant email alerts for matching leads.</span></label>
          <button type="submit"><?php echo htmlspecialchars($buttonText, ENT_QUOTES, 'UTF-8'); ?></button>
          <div class="lm-ft-miniTrust">Takes less than 30 seconds • No payment required • Instant alerts included</div>
          <div class="lm-ft-note">Free test access includes instant lead alerts. You can unsubscribe at any time from any email.</div>
          <?php echo JHtml::_('form.token'); ?>
        </form>
      <?php endif; ?>
    </div>
    <div class="lm-ft-panel">
      <strong style="display:block;color:#0c5585;font-size:18px;margin-bottom:8px;">Why buyers start here</strong>
      <div class="lm-ft-sidebarStat"><strong>Lead quality</strong><span>Preview real lead details before buying</span></div>
      <div class="lm-ft-sidebarStat"><strong>Alert setup</strong><span><?php echo !empty($selectedStates) ? htmlspecialchars(implode(', ', $selectedStates), ENT_QUOTES, 'UTF-8') : 'All states'; ?> • <?php echo htmlspecialchars($selectedLeadType === 'both' ? 'All lead types' : ucfirst($selectedLeadType), ENT_QUOTES, 'UTF-8'); ?></span></div>
      <div class="lm-ft-sidebarStat"><strong>Next step</strong><span>Use instant alerts to catch new inventory first</span></div>
      <div style="margin-top:14px;"><a class="lm-ft-btn" href="<?php echo htmlspecialchars($trackedMarketCtaUrl, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($marketCtaText, ENT_QUOTES, 'UTF-8'); ?></a></div>
    </div>
  </div>

  <div class="lm-ft-why">
    <div class="lm-ft-whybox"><strong>See real lead quality</strong><p>Review the same kinds of lead details your buyers will work with in the live marketplace.</p></div>
    <div class="lm-ft-whybox"><strong>Get instant alerts</strong><p>Stay ready for fresh incoming inventory in the states and lead types you actually want.</p></div>
    <div class="lm-ft-whybox"><strong>Preview the workflow</strong><p>Understand the lead format, freshness, and protected first-contact timing before spending money.</p></div>
  </div>

  <?php if ($isUnlocked): ?>
    <div class="lm-ft-section"><h2>Your free test pool</h2><p>These leads were hand-picked for trial access. Open any card below to review the full details without checkout.</p>
      <div class="lm-ft-list">
        <?php foreach ((array)$this->items as $lead): $leadRow = (array) $lead; $masked = LeadMarketHelper::buildMaskedPreview($leadRow); $saleOptions = LeadMarketHelper::getSaleModeOptions($leadRow); $location = trim((string)$masked['city']); if (trim((string)$masked['state']) !== '') $location .= ($location !== '' ? ', ' : '') . trim((string)$masked['state']); if (trim((string)$masked['zip']) !== '') $location .= ($location !== '' ? ' ' : '') . trim((string)$masked['zip']); ?>
        <article class="lm-ft-card">
          <div class="lm-ft-card__head"><div><div class="lm-ft-card__title"><?php echo htmlspecialchars(LeadMarketHelper::getBuyerLeadTitle($leadRow), ENT_QUOTES, 'UTF-8'); ?></div><div class="lm-ft-card__meta"><?php echo htmlspecialchars($location, ENT_QUOTES, 'UTF-8'); ?> • <?php echo htmlspecialchars((string)$masked['phone_masked'], ENT_QUOTES, 'UTF-8'); ?></div></div><span class="lm-ft-card__badge">Free Test Lead</span></div>
          <div class="lm-ft-card__grid"><div class="lm-ft-card__box"><span class="lm-ft-card__label">Shared price</span><div class="lm-ft-card__value">from $<?php echo htmlspecialchars(number_format((float)($saleOptions['shared']['price_usd'] ?? $leadRow['price_usd'] ?? 0), 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?></div></div><div class="lm-ft-card__box"><span class="lm-ft-card__label">Exclusive option</span><div class="lm-ft-card__value"><?php echo htmlspecialchars((string)LeadMarketHelper::getBuyerExclusiveText($leadRow), ENT_QUOTES, 'UTF-8'); ?></div></div></div>
          <div class="lm-ft-card__copy">Freshness: <strong><?php echo htmlspecialchars((string) LeadMarketHelper::getLeadFreshnessLabel($leadRow), ENT_QUOTES, 'UTF-8'); ?></strong><br>Availability: <strong><?php echo htmlspecialchars((string) LeadMarketHelper::getBuyerAvailabilityLabel($leadRow), ENT_QUOTES, 'UTF-8'); ?></strong></div>
          <div class="lm-ft-card__actions"><a class="lm-ft-btn" href="<?php echo htmlspecialchars(LeadMarketHelper::buildFreeTestLeadUrl((int)$leadRow['id'], (string)$this->trialToken), ENT_QUOTES, 'UTF-8'); ?>">Open details</a><a class="lm-ft-link" href="<?php echo htmlspecialchars(LeadMarketHelper::buildFreeTestMarketplaceClickUrl((string)$this->trialToken, $this->marketUrl), ENT_QUOTES, 'UTF-8'); ?>">Live marketplace</a></div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  <?php else: ?>
    <div class="lm-ft-section"><h2>Preview <?php echo (int) $previewCount; ?> leads from the current free test pool</h2><p>These are preview cards only. Enter your email and click the unlock button to open the full curated set and start receiving instant alerts for matching leads.</p>
      <div class="lm-ft-list">
        <?php foreach ((array)$this->teaserItems as $lead): $leadRow = (array) $lead; $masked = LeadMarketHelper::buildMaskedPreview($leadRow); $saleOptions = LeadMarketHelper::getSaleModeOptions($leadRow); $location = trim((string)$masked['city']); if (trim((string)$masked['state']) !== '') $location .= ($location !== '' ? ', ' : '') . trim((string)$masked['state']); if (trim((string)$masked['zip']) !== '') $location .= ($location !== '' ? ' ' : '') . trim((string)$masked['zip']); ?>
        <article class="lm-ft-card">
          <div class="lm-ft-card__head"><div><div class="lm-ft-card__title"><?php echo htmlspecialchars(LeadMarketHelper::getBuyerLeadTitle($leadRow), ENT_QUOTES, 'UTF-8'); ?></div><div class="lm-ft-card__meta"><?php echo htmlspecialchars($location, ENT_QUOTES, 'UTF-8'); ?> • <?php echo htmlspecialchars((string)$masked['phone_masked'], ENT_QUOTES, 'UTF-8'); ?></div></div><span class="lm-ft-card__badge">Locked preview</span></div>
          <div class="lm-ft-card__grid"><div class="lm-ft-card__box"><span class="lm-ft-card__label">Shared price</span><div class="lm-ft-card__value">from $<?php echo htmlspecialchars(number_format((float)($saleOptions['shared']['price_usd'] ?? $leadRow['price_usd'] ?? 0), 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?></div></div><div class="lm-ft-card__box"><span class="lm-ft-card__label">Protected window</span><div class="lm-ft-card__value"><?php echo (int)($saleOptions['exclusive']['hours'] ?? LeadMarketHelper::getExclusiveHoursForLead($leadRow)); ?>h</div></div></div>
          <div class="lm-ft-lock">Unlock signup required before opening the full contact details for this lead.</div>
        </article>
        <?php endforeach; ?>
      </div>
    </div>
  <?php endif; ?>

  <div class="lm-ft-section"><h2>FAQ</h2><div class="lm-ft-faq"><div class="lm-ft-faqbox"><strong>Are these real leads?</strong><p>Yes. The free test pool is built from real leads you selected for trial access.</p></div><div class="lm-ft-faqbox"><strong>Do I need to pay to view them?</strong><p>No. Unlocking the trial pool only requires an email signup for instant lead alerts.</p></div><div class="lm-ft-faqbox"><strong>Will I receive alerts after signup?</strong><p>Yes. The signup form turns on instant matching lead alerts for your chosen state and lead type.</p></div><div class="lm-ft-faqbox"><strong>Can I unsubscribe later?</strong><p>Yes. Every alert email includes an unsubscribe link and you can update your preferences anytime.</p></div></div></div>
</div>
