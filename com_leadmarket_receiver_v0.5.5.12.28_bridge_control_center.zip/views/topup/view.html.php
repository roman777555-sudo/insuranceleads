<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketViewTopup extends JViewLegacy
{
  public $topup = null;
  public $token = '';
  public $isValid = false;
  public $buyerEmail = '';
  public $linkedLeadContext = null;
  public $linkedBatchLinks = array();

  protected function applyTechnicalSeoProtection()
  {
    $robots = 'noindex, nofollow';
    $doc = JFactory::getDocument();
    if ($doc && method_exists($doc, 'setMetaData')) {
      $doc->setMetaData('robots', $robots);
    }
    if (!headers_sent()) {
      header('X-Robots-Tag: ' . $robots, true);
    }
    try { JFactory::getApplication()->setHeader('X-Robots-Tag', $robots, true); } catch (Exception $e) {}
  }

  public function display($tpl = null)
  {
    LeadMarketHelper::trackPageView('topup_view', array('page_name' => 'topup'));
    $this->applyTechnicalSeoProtection();
    LeadMarketHelper::ensureSchema();

    $app = JFactory::getApplication();
    $id = (int) $app->input->getInt('id', 0);
    $this->token = trim((string) $app->input->getString('token', ''));

    $topup = null;
    if ($id > 0) $topup = LeadMarketHelper::loadTopupById($id);
    if (!$topup && $this->token !== '') $topup = LeadMarketHelper::loadTopupByToken($this->token);

    $this->topup = $topup;
    $this->isValid = ($topup && LeadMarketHelper::canAccessTopup($topup, $this->token));
    if ($this->isValid) {
      $this->buyerEmail = (string) ($topup['buyer_email'] ?? '');
      LeadMarketHelper::setActiveBuyerContext($this->buyerEmail, 'topup', $this->token);
      $this->linkedLeadContext = LeadMarketHelper::getLinkedTopupLeadContext($topup);
      $this->linkedBatchLinks = LeadMarketHelper::getTopupBatchLeadLinks($topup);
    }

    parent::display($tpl);
  }
}
