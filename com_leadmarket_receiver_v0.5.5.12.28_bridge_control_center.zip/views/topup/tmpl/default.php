<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

$topup = is_array($this->topup) ? $this->topup : array();
$isValid = !empty($this->isValid);
$buyerEmail = (string) $this->buyerEmail;
$linkedLeadContext = is_array($this->linkedLeadContext) ? $this->linkedLeadContext : null;
$linkedBatchLinks = is_array($this->linkedBatchLinks) ? $this->linkedBatchLinks : array();
$topupPayload = (!empty($topup) && !empty($topup['access_token'])) ? LeadMarketHelper::getTopupStatusPayload($topup, (string) $topup['access_token']) : array();
$status = strtolower((string) ($topup['status'] ?? ''));
$resultStatus = strtolower((string) ($topup['result_status'] ?? ''));
$minimumTopup = (float) LeadMarketHelper::minimumTopupUsd();
$targetPrice = (float) ($topup['target_price_usd'] ?? 0);
$selectedTopupAmount = (float) (($topup['requested_topup_amount_usd'] ?? 0) > 0 ? $topup['requested_topup_amount_usd'] : ($topup['topup_amount_usd'] ?? 0));
$topupAmount = (float) ($topup['expected_amount_usdt'] ?? ($topup['expected_amount'] ?? 0));
$balanceBefore = (float) ($topup['balance_before'] ?? 0);
$appliedFromBalance = ($targetPrice > 0) ? min($balanceBefore, $targetPrice) : 0.0;
$amountStillNeeded = ($targetPrice > 0) ? max(0, LeadMarketHelper::roundMoney($targetPrice - $appliedFromBalance)) : 0.0;
$balanceAfterCredit = LeadMarketHelper::roundMoney($balanceBefore + $selectedTopupAmount);
$remainingAfterUnlock = null;
if ($targetPrice > 0) {
  $remainingAfterUnlock = max(0, LeadMarketHelper::roundMoney($selectedTopupAmount + $balanceBefore - $targetPrice));
}
$secureLeadUrl = '';
$secureBatchUrl = '';
$resolvedBatchId = 0;
$batchUnlockSummary = array('unlocked_count' => 0, 'total_count' => 0);
if (!empty($topupPayload['ok'])) {
  $status = strtolower((string) ($topupPayload['status'] ?? $status));
  $resultStatus = strtolower((string) ($topupPayload['result_status'] ?? $resultStatus));
  if (isset($topupPayload['target_price'])) $targetPrice = (float) $topupPayload['target_price'];
  if (isset($topupPayload['selected_topup_amount'])) $selectedTopupAmount = (float) $topupPayload['selected_topup_amount'];
  if (isset($topupPayload['applied_from_balance'])) $appliedFromBalance = (float) $topupPayload['applied_from_balance'];
  if (!empty($topupPayload['secure_lead_url'])) $secureLeadUrl = (string) $topupPayload['secure_lead_url'];
  if (!empty($topupPayload['secure_batch_url'])) $secureBatchUrl = (string) $topupPayload['secure_batch_url'];
  if (!empty($topupPayload['unlocked_batch_id'])) $resolvedBatchId = (int) $topupPayload['unlocked_batch_id'];
  if (isset($topupPayload['unlocked_leads_count'])) $batchUnlockSummary['unlocked_count'] = (int) $topupPayload['unlocked_leads_count'];
  if (isset($topupPayload['total_leads_count'])) $batchUnlockSummary['total_count'] = (int) $topupPayload['total_leads_count'];
}
if ($secureLeadUrl === '' && !empty($topup['unlocked_order_id'])) {
  $order = LeadMarketHelper::loadOrderById((int) $topup['unlocked_order_id']);
  if ($order) {
    $lead = LeadMarketHelper::loadLeadById((int) ($order['lead_id'] ?? 0));
    if ($lead) {
      $secureLeadUrl = LeadMarketHelper::getSecureOrderUrl($order, $lead);
    }
  }
}
if ($secureLeadUrl === '' && (($topup['target_type'] ?? '') === 'lead') && !empty($topup['target_id']) && $buyerEmail !== '') {
  $existingUnlockedOrder = LeadMarketHelper::findBuyerPaidOrderForLead((int) $topup['target_id'], $buyerEmail);
  if ($existingUnlockedOrder) {
    $lead = LeadMarketHelper::loadLeadById((int) ($existingUnlockedOrder['lead_id'] ?? 0));
    if ($lead) {
      $secureLeadUrl = LeadMarketHelper::getSecureOrderUrl($existingUnlockedOrder, $lead);
    }
  }
}
if ($resolvedBatchId <= 0 && !empty($topup['unlocked_batch_id'])) {
  $resolvedBatchId = (int) $topup['unlocked_batch_id'];
} elseif ($resolvedBatchId <= 0 && ((($topup['target_type'] ?? '') === 'batch') && !empty($topup['target_id']) && $buyerEmail !== '')) {
  $candidateBatch = LeadMarketHelper::loadBatchById((int) $topup['target_id']);
  if ($candidateBatch && LeadMarketHelper::normalizeEmail((string) ($candidateBatch['buyer_email'] ?? '')) === LeadMarketHelper::normalizeEmail($buyerEmail)) {
    $candidateStatus = strtolower((string) ($candidateBatch['status'] ?? 'pending'));
    $candidatePricing = LeadMarketHelper::getBatchPricingForBuyer((int) ($candidateBatch['id'] ?? 0), $buyerEmail);
    if ($candidateStatus === 'paid' || (int) ($candidatePricing['remaining_count'] ?? 0) <= 0) {
      $resolvedBatchId = (int) ($candidateBatch['id'] ?? 0);
    }
  }
}
if ($resolvedBatchId > 0) {
  $resolvedBatch = LeadMarketHelper::loadBatchById($resolvedBatchId);
  if ($resolvedBatch) {
    if ($secureBatchUrl === '') {
      $secureBatchUrl = LeadMarketHelper::buildAbsoluteBatchUrl($resolvedBatchId, LeadMarketHelper::ensureBatchToken($resolvedBatch));
    }
    $batchUnlockSummary = LeadMarketHelper::getBatchUnlockSummary($resolvedBatchId, $buyerEmail);
  }
}
$isLeadUnlocked = ($secureLeadUrl !== '' && $resultStatus === 'lead_unlocked');
$isBatchUnlocked = ($secureBatchUrl !== '' && $resultStatus === 'batch_unlocked');
$batchUnlockedCount = (int) ($batchUnlockSummary['unlocked_count'] ?? 0);
$batchTotalCount = (int) ($batchUnlockSummary['total_count'] ?? 0);
$topupDisplayMessage = (string) (!empty($topupPayload['result_message']) ? $topupPayload['result_message'] : ($topup['result_message'] ?? 'Awaiting payment confirmation.'));
$linkedTargetNoun = ((string) ($topup['target_type'] ?? '') === 'batch') ? 'batch' : 'lead';
$linkedTargetPlural = ((string) ($topup['target_type'] ?? '') === 'batch') ? 'future purchases' : 'the next lead';
$buyerAccessUrl = LeadMarketHelper::getBuyerAccessActionAbsoluteUrl($buyerEmail);
$paymentMethod = LeadMarketHelper::normalizeTopupPaymentMethod((string) ($topup['payment_method'] ?? ($topupPayload['payment_method'] ?? 'crypto')));
$methodMeta = LeadMarketHelper::topupPaymentMethodMeta($paymentMethod, $selectedTopupAmount);
$isMoneygram = ($paymentMethod === 'moneygram');
$moneygramSubmitted = in_array($status, array('pending_review','paid'), true);
$isPaypal = ($paymentMethod === 'paypal');
$paypalClientId = (string) ($methodMeta['paypal_client_id'] ?? '');
$paypalCreateUrl = JRoute::_('index.php?option=com_leadmarket&task=paypalcreateorder&format=raw', false);
$paypalCaptureUrl = JRoute::_('index.php?option=com_leadmarket&task=paypalcaptureorder&format=raw', false);
$paypalSdkUrl = $paypalClientId !== '' ? ('https://www.paypal.com/sdk/js?client-id=' . rawurlencode($paypalClientId) . '&currency=USD&intent=capture&locale=en_US&disable-funding=paylater,venmo') : '';
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderIframeBreakoutScript(); ?>
<style>
.lm-topup-grid{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:18px;align-items:start}
.lm-topup-panel{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:20px;box-shadow:0 4px 16px rgba(12,85,133,.05)}
.lm-topup-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}
.lm-topup-kpi{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:14px}
.lm-topup-kpi__label{font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}
.lm-topup-kpi__value{font-size:27px;font-weight:800;color:#13232f;line-height:1.2;word-break:break-word}
.lm-topup-badge{display:inline-block;padding:7px 11px;border-radius:999px;background:#eef6fb;border:1px solid #d8e8f3;color:#0c5585;font-size:12px;font-weight:800}
.lm-topup-badge--ok{background:#eefaf0;border-color:#cfe5d4;color:#1f6b35}
.lm-topup-badge--warn{background:#fff8ef;border-color:#eadfc7;color:#7a5c1e}
.lm-topup-badge--bad{background:#fff5f5;border-color:#efd5d5;color:#7a2b2b}
.lm-topup-meta{color:#55646f;line-height:1.7;word-break:break-word}
.lm-topup-list{margin:0;padding-left:18px;line-height:1.8;color:#44545e}
.lm-topup-panel h2,.lm-topup-panel h3{margin-top:0}
.lm-topup-why{margin-top:14px;padding:14px;border-radius:12px;background:#f8fbfd;border:1px solid #e3edf5;color:#44545e;line-height:1.7}
.lm-topup-why strong{color:#13232f}
.lm-checking-row{display:flex;align-items:center;gap:10px;margin-bottom:8px}
.lm-checking-spinner{width:18px;height:18px;border-radius:50%;border:3px solid #d7e8f3;border-top-color:#0c5585;animation:lmspin .9s linear infinite;display:inline-block}
.lm-checking-dots span{display:inline-block;width:6px;height:6px;border-radius:50%;background:#0c5585;opacity:.25;animation:lmdots 1.2s infinite}
.lm-checking-dots span:nth-child(2){animation-delay:.2s}.lm-checking-dots span:nth-child(3){animation-delay:.4s}
@keyframes lmspin{to{transform:rotate(360deg)}}
@keyframes lmdots{0%,80%,100%{opacity:.25;transform:translateY(0)}40%{opacity:1;transform:translateY(-2px)}}
@media (max-width:960px){.lm-topup-grid{grid-template-columns:1fr}}
.lm-paypal-buttons{margin-top:14px}
.lm-paypal-buttons > div{min-height:44px}
@media (max-width:640px){.lm-topup-kpis{grid-template-columns:1fr}.lm-public-btn{width:100%}}
</style>
<div class="lm-public-wrap">
  <div class="lm-public-hero">
    <span class="lm-public-hero__eyebrow">Top-up access</span>
    <h1 class="lm-public-hero__title"><?php echo $isValid ? 'Review and complete your top-up' : 'Secure top-up link required'; ?></h1>
    <p class="lm-public-hero__copy"><?php echo $isValid ? ($isMoneygram ? 'Review the amount, send the Western Union transfer, and submit the MTCN / reference number here for manual review.' : ($isPaypal ? 'Review the amount and complete the secure PayPal checkout below. After the payment is captured, the wallet is credited automatically and the linked purchase can finish.' : 'Review the amount, send the transfer, and keep this page open while payment is checked automatically.')) : 'This top-up link is invalid, missing, or no longer active.'; ?></p>
    <div class="lm-public-hero__actions">
      <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Opening buyer dashboard..." href="<?php echo htmlspecialchars($buyerAccessUrl, ENT_QUOTES, 'UTF-8'); ?>">Open buyer access</a>
      <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Browse marketplace</a>
    </div>
  </div>

  <?php if (!$isValid): ?>
    <div class="lm-topup-panel" style="max-width:760px;margin:0 auto;">
      <h2>Top-up link not valid</h2>
      <p class="lm-topup-meta">Open the secure top-up page using the link that was created from buyer access or checkout, or request a fresh buyer access magic link.</p>
    </div>
  <?php else: ?>
    <?php
      $badgeClass = 'lm-topup-badge--warn';
      if ($status === 'paid') $badgeClass = 'lm-topup-badge--ok';
      elseif (in_array($status, array('cancelled','expired'), true)) $badgeClass = 'lm-topup-badge--bad';
    ?>
    <div class="lm-topup-grid" id="lmTopupRoot" data-topup-id="<?php echo (int) ($topup['id'] ?? 0); ?>" data-topup-token="<?php echo htmlspecialchars((string) ($topup['access_token'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" data-payment-method="<?php echo htmlspecialchars($paymentMethod, ENT_QUOTES, 'UTF-8'); ?>" data-form-token-name="<?php echo htmlspecialchars(JSession::getFormToken(), ENT_QUOTES, 'UTF-8'); ?>" data-paypal-create-url="<?php echo htmlspecialchars($paypalCreateUrl, ENT_QUOTES, 'UTF-8'); ?>" data-paypal-capture-url="<?php echo htmlspecialchars($paypalCaptureUrl, ENT_QUOTES, 'UTF-8'); ?>" data-topup-status-url="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=topupstatus&topup_id=' . (int) ($topup['id'] ?? 0) . "&token=" . urlencode((string) ($topup['access_token'] ?? '')), false), ENT_QUOTES, 'UTF-8'); ?>">
      <div>
        <div class="lm-topup-panel">
          <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap;">
            <div>
              <h2 style="margin-bottom:8px;">Top-up #<?php echo (int) ($topup['id'] ?? 0); ?></h2>
              <div class="lm-topup-meta">Buyer: <b><?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?></b></div>
              <div class="lm-topup-meta">Created: <?php echo htmlspecialchars((string) ($topup['created_at_utc'] ?? ''), ENT_QUOTES, 'UTF-8'); ?> UTC</div>
            </div>
            <span class="lm-topup-badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars((string) ($topup['status'] ?? 'pending'), ENT_QUOTES, 'UTF-8'); ?></span>
          </div>
          <div class="lm-topup-kpis" style="margin-top:16px;">
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Selected top-up amount</div><div class="lm-topup-kpi__value">$<?php echo number_format($selectedTopupAmount, 2, '.', ','); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Target price</div><div class="lm-topup-kpi__value"><?php echo $targetPrice > 0 ? '$' . number_format($targetPrice, 2, '.', ',') : '—'; ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Balance before</div><div class="lm-topup-kpi__value">$<?php echo number_format($balanceBefore, 2, '.', ','); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Applied from balance</div><div class="lm-topup-kpi__value"><?php echo $targetPrice > 0 ? '$' . number_format((float) $appliedFromBalance, 2, '.', ',') : '—'; ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Balance after credit</div><div class="lm-topup-kpi__value">$<?php echo number_format((float) $balanceAfterCredit, 2, '.', ','); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Wallet left after unlock</div><div class="lm-topup-kpi__value"><?php echo $remainingAfterUnlock !== null ? '$' . number_format((float) $remainingAfterUnlock, 2, '.', ',') : '—'; ?></div></div>
          </div>


          <?php if ($status === 'checking' || $status === 'pending'): ?>
          <div id="lmTopupCheckingBox" class="lm-topup-why" style="margin-top:16px;">
            <div class="lm-checking-row">
              <span class="lm-checking-spinner" aria-hidden="true"></span>
              <strong><?php echo $status === 'checking' ? ($isPaypal ? 'We are finalizing your PayPal payment' : 'We are checking your transfer automatically') : ($isPaypal ? 'Top-up is waiting for PayPal payment' : 'Top-up is waiting for payment'); ?></strong>
              <span class="lm-checking-dots" aria-hidden="true"><span></span> <span></span> <span></span></span>
            </div>
            <div id="lmTopupResultText"><?php echo htmlspecialchars((string) ($topup['result_message'] ?? 'Awaiting payment confirmation.'), ENT_QUOTES, 'UTF-8'); ?></div>
            <div style="margin-top:8px;color:#607080;"><?php echo $isPaypal ? 'Keep this page open until PayPal confirms the capture.' : 'Keep this page open while payment is checked.'; ?></div><div id="lmTopupPollMeta" style="margin-top:6px;color:#7a8a95;font-size:13px;"><?php echo $isPaypal ? 'Status refresh: every 10 seconds while PayPal confirmation completes.' : 'Automatic re-check: every 10 seconds.'; ?></div>
            <div class="lm-public-actions" style="margin-top:14px;">
              <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=topupcancel'); ?>" method="post" style="margin:0;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="topup_id" value="<?php echo (int) ($topup['id'] ?? 0); ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars((string) ($topup['access_token'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                <button class="lm-public-btn lm-public-btn--ghost" type="submit">Cancel top-up</button>
              </form>
            </div>
          </div>
          <?php endif; ?>
          <div class="lm-topup-why">
            <strong>Why this amount</strong>
            <?php if ($targetPrice > 0 && $topupAmount > $targetPrice): ?>
              This amount is above the <?php echo htmlspecialchars($linkedTargetNoun, ENT_QUOTES, 'UTF-8'); ?> price because the minimum transfer is <b>$<?php echo number_format($minimumTopup, 2, '.', ','); ?></b>. The rest stays in the buyer wallet.
            <?php elseif ($targetPrice > 0): ?>
              This top-up matches the linked target price.
            <?php else: ?>
              This is a general wallet top-up. The credit stays available for future purchases.
            <?php endif; ?>
          </div>
        </div>

        <?php if ($isLeadUnlocked): ?>
        <div class="lm-topup-panel" style="margin-top:18px;border-color:#cfe5d4;background:#f8fff9;">
          <h3 style="margin-top:0;color:#1f6b35;">Top-up paid and linked lead unlocked</h3>
          <div class="lm-topup-kpis">
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Lead price</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) $targetPrice, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Applied from existing balance</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) $appliedFromBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Remaining wallet balance</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) ($topup['balance_after_unlock'] ?? $remainingAfterUnlock ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
          </div>
          <div class="lm-public-actions" style="margin-top:14px;">
            <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($secureLeadUrl, ENT_QUOTES, 'UTF-8'); ?>">Open unlocked lead</a>
            <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Opening buyer dashboard..." href="<?php echo htmlspecialchars($buyerAccessUrl, ENT_QUOTES, 'UTF-8'); ?>">Open buyer access</a>
          </div>
        </div>
        <?php endif; ?>

        <?php if ($isBatchUnlocked): ?>
        <div class="lm-topup-panel" style="margin-top:18px;border-color:#cfe5d4;background:#f8fff9;">
          <h3 style="margin-top:0;color:#1f6b35;">Top-up paid and linked batch unlocked</h3>
          <div class="lm-topup-kpis">
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Batch total</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) $targetPrice, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Unlocked leads</div><div class="lm-topup-kpi__value"><?php echo htmlspecialchars((string) $batchUnlockedCount, ENT_QUOTES, 'UTF-8'); ?><?php if ($batchTotalCount > 0): ?>/<?php echo htmlspecialchars((string) $batchTotalCount, ENT_QUOTES, 'UTF-8'); ?><?php endif; ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Applied from existing balance</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) $appliedFromBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Remaining wallet balance</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) ($topup['balance_after_unlock'] ?? $remainingAfterUnlock ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
          </div>
          <div class="lm-public-actions" style="margin-top:14px;">
            <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($secureBatchUrl, ENT_QUOTES, 'UTF-8'); ?>">Open unlocked batch</a>
            <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Opening buyer dashboard..." href="<?php echo htmlspecialchars($buyerAccessUrl, ENT_QUOTES, 'UTF-8'); ?>">Open buyer access</a>
          </div>
        </div>
        <?php endif; ?>

        <?php if ($status === 'paid' && $resultStatus === 'failed_manual_review'): ?>
        <div class="lm-topup-panel" style="margin-top:18px;border-color:#f0d2d2;background:#fff7f7;">
          <h3 style="margin-top:0;color:#9b2d2d;">Top-up paid and held for manual review</h3>
          <div class="lm-topup-kpis">
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Top-up credited</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) $selectedTopupAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
            <div class="lm-topup-kpi"><div class="lm-topup-kpi__label">Wallet after credit</div><div class="lm-topup-kpi__value">$<?php echo htmlspecialchars(number_format((float) ($topup['balance_after_credit'] ?? $balanceAfterCredit), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
          </div>
          <p class="lm-topup-meta" style="margin-top:14px;">The payment was matched and the wallet credit is preserved, but the linked <?php echo htmlspecialchars($linkedTargetNoun, ENT_QUOTES, 'UTF-8'); ?> needs manual review before access can be reopened safely.</p>
          <div class="lm-public-actions" style="margin-top:14px;">
            <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Opening buyer dashboard..." href="<?php echo htmlspecialchars($buyerAccessUrl, ENT_QUOTES, 'UTF-8'); ?>">Open buyer access</a>
          </div>
        </div>
        <?php endif; ?>

        <div class="lm-topup-panel" style="margin-top:18px;">
          <h3>This top-up</h3>
          <?php if (($topup['target_type'] ?? '') === 'lead' && $linkedLeadContext): ?>
            <p class="lm-topup-meta"><b><?php echo htmlspecialchars((string) $linkedLeadContext['title'], ENT_QUOTES, 'UTF-8'); ?></b></p>
            <p class="lm-topup-meta">Lead #<?php echo (int) ($topup['target_id'] ?? 0); ?><?php if (!empty($linkedLeadContext['location'])): ?>&nbsp;•&nbsp;<?php echo htmlspecialchars((string) $linkedLeadContext['location'], ENT_QUOTES, 'UTF-8'); ?><?php endif; ?></p>
          <?php elseif (($topup['target_type'] ?? '') === 'batch'): ?>
            <p class="lm-topup-meta"><b>Batch #<?php echo (int) ($topup['target_id'] ?? 0); ?></b></p>
            <p class="lm-topup-meta">Linked to a batch purchase.</p>
          <?php else: ?>
            <p class="lm-topup-meta">General wallet top-up. Not linked to a specific lead or batch.</p>
          <?php endif; ?>

          <ul class="lm-topup-list" style="margin-top:10px;">
            <li>Top-up amount: <b>$<?php echo htmlspecialchars(number_format((float) $selectedTopupAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>.</li>
            <?php if ($isMoneygram): ?>
              <li>Funding method: <b>Western Union manual deposit</b>.</li>
              <li>Send exactly: <b><?php echo htmlspecialchars(number_format((float) ($topup['expected_amount'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> USD</b>.</li>
              <li>Receiver country: <b><?php echo htmlspecialchars((string) ($methodMeta['receiver_country'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></b>.</li>
              <li>After sending, submit the <b>Western Union MTCN / reference number</b> below.</li>
              <li>This request is reviewed manually before the balance is credited.</li>
            <?php elseif ($isPaypal): ?>
              <li>Funding method: <b>PayPal</b>.</li>
              <li>Pay exactly: <b><?php echo htmlspecialchars(number_format((float) ($topup['requested_topup_amount_usd'] ?? $selectedTopupAmount), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> USD</b>.</li>
              <li>Complete the payment using the PayPal button on this page.</li>
              <li>The wallet is credited automatically after PayPal capture completes.</li>
            <?php else: ?>
              <li><span style="display:inline-block;padding:8px 10px;border-radius:10px;background:#fff8e8;border:1px solid #f0c36d;color:#7a4b00;font-weight:800;">Exact transfer amount: <?php echo htmlspecialchars(number_format((float) ($topup['expected_amount_usdt'] ?? $topup['expected_amount'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> <?php echo htmlspecialchars((string) ($topup['expected_currency'] ?? 'USDT'), ENT_QUOTES, 'UTF-8'); ?></span></li>
              <li>Network: <b><?php echo htmlspecialchars((string) ($topup['expected_network'] ?? 'TRC20'), ENT_QUOTES, 'UTF-8'); ?></b>.</li>
              <li>After payment, click <b>I sent payment</b>.</li>
              <li>Payment is matched automatically.</li>
            <?php endif; ?>
          </ul>

          <p class="lm-topup-meta" style="margin-top:14px;"><?php echo htmlspecialchars((string) $topupDisplayMessage, ENT_QUOTES, 'UTF-8'); ?></p><?php if ($isLeadUnlocked): ?><div class="lm-topup-why" style="border-color:#cfe5d4;background:#f8fff9;margin-top:14px;"><strong style="color:#1f6b35;display:block;margin-bottom:8px;">Top-up paid and linked lead unlocked</strong><div>Lead price: <b>$<?php echo number_format((float) $targetPrice, 2, '.', ','); ?></b></div><div>Applied from existing balance: <b>$<?php echo number_format((float) $appliedFromBalance, 2, '.', ','); ?></b></div><div>Top-up credited: <b>$<?php echo number_format((float) $selectedTopupAmount, 2, '.', ','); ?></b></div><div>Used for this lead: <b>$<?php echo number_format((float) $targetPrice, 2, '.', ','); ?></b></div><div>Final wallet balance: <b>$<?php echo number_format((float) ($topup['balance_after_unlock'] ?? $remainingAfterUnlock ?? 0), 2, '.', ','); ?></b></div></div><?php endif; ?>

          <div class="lm-public-actions">
            <?php if ($status === 'pending' && !$isMoneygram && !$isPaypal): ?>
              <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=topupipaid'); ?>" method="post" style="margin:0;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="topup_id" value="<?php echo (int) ($topup['id'] ?? 0); ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars((string) ($topup['access_token'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                <button class="lm-public-btn lm-public-btn--main" type="submit">I sent payment</button>
              </form>
            <?php elseif ($status === 'checking'): ?>
              <span class="lm-public-btn lm-public-btn--ghost" style="cursor:default;display:inline-flex;align-items:center;gap:10px;"><span class="lm-checking-spinner" aria-hidden="true"></span><span>Automatic payment check in progress</span></span>
            <?php elseif ($status === 'pending_review'): ?>
              <span class="lm-public-btn lm-public-btn--ghost" style="cursor:default;display:inline-flex;align-items:center;gap:10px;"><span>Western Union reference received · Waiting for review</span></span>
            <?php endif; ?>
            <?php if (in_array($status, array('pending','checking','pending_review'), true)): ?>
              <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=topupcancel'); ?>" method="post" style="margin:0;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="topup_id" value="<?php echo (int) ($topup['id'] ?? 0); ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars((string) ($topup['access_token'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                <button class="lm-public-btn lm-public-btn--ghost" type="submit">Cancel top-up</button>
              </form>
            <?php endif; ?>
            <?php if ($isLeadUnlocked): ?>
              <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($secureLeadUrl, ENT_QUOTES, 'UTF-8'); ?>">Open unlocked lead</a>
            <?php endif; ?>
            <?php if ($isBatchUnlocked): ?>
              <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($secureBatchUrl, ENT_QUOTES, 'UTF-8'); ?>">Open unlocked batch</a>
            <?php endif; ?>
            <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Opening buyer dashboard..." href="<?php echo htmlspecialchars($buyerAccessUrl, ENT_QUOTES, 'UTF-8'); ?>">Open buyer access</a>
          </div>

          <?php if ($linkedBatchLinks): ?>
            <div style="margin-top:14px;">
              <div style="font-weight:800;margin-bottom:8px;color:#13232f;">Unlocked batch leads</div>
              <ul class="lm-topup-list">
                <?php foreach ($linkedBatchLinks as $batchLink): ?>
                  <li><a href="<?php echo htmlspecialchars((string) ($batchLink['url'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string) ($batchLink['title'] ?? 'Lead'), ENT_QUOTES, 'UTF-8'); ?></a></li>
                <?php endforeach; ?>
              </ul>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <aside>
        <div class="lm-topup-panel">
          <?php if ($isMoneygram): ?>
            <h3>Western Union instructions</h3>
            <p class="lm-topup-meta">Funding method: <b>Western Union manual deposit</b></p>
            <p class="lm-topup-meta">Send amount: <b>$<?php echo htmlspecialchars(number_format((float) ($topup['expected_amount'] ?? $selectedTopupAmount), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b></p>
            <p class="lm-topup-meta">Receiver name: <b><?php echo htmlspecialchars((string) ($methodMeta['receiver_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></b></p>
            <p class="lm-topup-meta">Receiver country: <b><?php echo htmlspecialchars((string) ($methodMeta['receiver_country'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></b></p>
            <div class="lm-topup-why" style="margin-top:12px;"><?php echo nl2br(htmlspecialchars((string) ($methodMeta['instructions'] ?? ''), ENT_QUOTES, 'UTF-8')); ?></div>
            <?php if (!empty($topup['expires_at_utc'])): ?><p class="lm-topup-meta" style="margin-top:12px;">Request expires: <b><?php echo htmlspecialchars((string) $topup['expires_at_utc'], ENT_QUOTES, 'UTF-8'); ?> UTC</b></p><?php endif; ?>
            <?php if ($status === 'pending'): ?>
              <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=topupwesternunionsubmit'); ?>" method="post" style="margin-top:12px;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="topup_id" value="<?php echo (int) ($topup['id'] ?? 0); ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars((string) ($topup['access_token'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>">
                <label style="display:block;margin:0 0 6px;font-weight:700;" for="manual_reference">MTCN / reference number</label>
                <input id="manual_reference" name="manual_reference" type="text" value="<?php echo htmlspecialchars((string) ($topup['manual_reference'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" required style="display:block;width:100%;min-height:44px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
                <label style="display:block;margin:10px 0 6px;font-weight:700;" for="manual_sender_name">Sender full name</label>
                <input id="manual_sender_name" name="manual_sender_name" type="text" value="<?php echo htmlspecialchars((string) ($topup['manual_sender_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" required style="display:block;width:100%;min-height:44px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
                <label style="display:block;margin:10px 0 6px;font-weight:700;" for="manual_sender_country">Country sent from</label>
                <input id="manual_sender_country" name="manual_sender_country" type="text" value="<?php echo htmlspecialchars((string) ($topup['manual_sender_country'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>" style="display:block;width:100%;min-height:44px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
                <label style="display:block;margin:10px 0 6px;font-weight:700;" for="manual_review_note">Note (optional)</label>
                <textarea id="manual_review_note" name="manual_review_note" rows="3" style="display:block;width:100%;padding:10px 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;"></textarea>
                <button class="lm-public-btn lm-public-btn--main" type="submit" style="margin-top:12px;width:100%;">Submit Western Union reference</button>
              </form>
            <?php elseif ($status === 'pending_review'): ?>
              <div class="lm-topup-why" style="margin-top:12px;border-color:#eadfc7;background:#fff8ef;">
                <strong>Reference submitted</strong><br>
                Reference: <b><?php echo htmlspecialchars((string) ($topup['manual_reference'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></b><br>
                Sender: <b><?php echo htmlspecialchars((string) ($topup['manual_sender_name'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></b><?php if (!empty($topup['manual_sender_country'])): ?> · <?php echo htmlspecialchars((string) $topup['manual_sender_country'], ENT_QUOTES, 'UTF-8'); ?><?php endif; ?><br>
                Waiting for manual review before the wallet is credited.
              </div>
            <?php endif; ?>
          <?php elseif ($isPaypal): ?>
            <h3>Pay with PayPal</h3>
            <p class="lm-topup-meta">Funding method: <b>PayPal or debit / credit card</b></p>
            <p class="lm-topup-meta">Top-up amount: <b>$<?php echo htmlspecialchars(number_format((float) ($topup['requested_topup_amount_usd'] ?? $selectedTopupAmount), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b></p>
            <p class="lm-topup-meta">This option is active for top-ups up to <b>$<?php echo htmlspecialchars(number_format((float) ($methodMeta['paypal_max'] ?? 10), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>.</p>
            <?php if (!empty($topup['expires_at_utc'])): ?><p class="lm-topup-meta" style="margin-top:12px;">Expires: <b><?php echo htmlspecialchars((string) $topup['expires_at_utc'], ENT_QUOTES, 'UTF-8'); ?> UTC</b></p><?php endif; ?>
            <?php if ($status !== 'paid'): ?>
              <?php if ($paypalClientId !== ''): ?>
                <div class="lm-topup-why" style="margin-top:12px;">
                  <strong>How to complete this payment</strong><br>
                  1. Click the <b>PayPal</b> button to pay with PayPal, or click <b>Debit or Credit Card</b> to pay directly by card.<br>
                  2. Finish the secure checkout popup.<br>
                  3. Keep this page open for a few seconds while the payment is confirmed and your wallet is credited automatically.
                </div>
                <div id="lmPaypalButtons" class="lm-paypal-buttons"></div>
                <div id="lmPaypalMessage" class="lm-topup-meta" style="margin-top:10px;"></div>
              <?php else: ?>
                <div class="lm-topup-why" style="margin-top:12px;border-color:#efd5d5;background:#fff5f5;">PayPal is not configured yet on this site. Please choose another method or contact support.</div>
              <?php endif; ?>
            <?php else: ?>
              <div class="lm-topup-why" style="margin-top:12px;border-color:#cfe5d4;background:#f8fff9;">PayPal payment completed. The credited wallet balance is shown on this page.</div>
            <?php endif; ?>
          <?php else: ?>
            <h3>Send payment</h3>
            <p class="lm-topup-meta">Currency: <b><?php echo htmlspecialchars((string) ($topup['expected_currency'] ?? 'USDT'), ENT_QUOTES, 'UTF-8'); ?></b></p>
            <p class="lm-topup-meta">Network: <b><?php echo htmlspecialchars((string) ($topup['expected_network'] ?? 'TRC20'), ENT_QUOTES, 'UTF-8'); ?></b></p>
            <p class="lm-topup-meta">Selected top-up amount: <b>$<?php echo htmlspecialchars(number_format((float) $selectedTopupAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b></p>
            <div style="margin:8px 0 12px;padding:14px 16px;border:2px solid #f0c36d;border-radius:12px;background:#fff8e8;color:#7a4b00;"><div style="font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;margin:0 0 4px;">Exact transfer amount</div><div style="font-size:28px;font-weight:900;line-height:1.1;"><?php echo htmlspecialchars(number_format((float) ($topup['expected_amount_usdt'] ?? $topup['expected_amount'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div><div style="margin-top:4px;font-size:13px;">Send this exact amount for automatic matching.</div></div>
            <p class="lm-topup-meta">Wallet address:</p>
            <div style="padding:12px 14px;border-radius:12px;background:#f8fbfd;border:1px solid #dbe7ef;color:#22313b;word-break:break-all;font-family:monospace;line-height:1.6;" id="lmTopupWalletAddress"><?php echo htmlspecialchars((string) ($topup['wallet_address'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
            <?php if (!empty($topup['expires_at_utc'])): ?><p class="lm-topup-meta" style="margin-top:12px;">Expires: <b><?php echo htmlspecialchars((string) $topup['expires_at_utc'], ENT_QUOTES, 'UTF-8'); ?> UTC</b></p><?php endif; ?>
            <?php if ($status !== 'paid'): ?>
            <div class="lm-public-actions" style="margin-top:12px;">
              <button type="button" class="lm-public-btn lm-public-btn--ghost" onclick="navigator.clipboard&&navigator.clipboard.writeText(document.getElementById('lmTopupWalletAddress').textContent);this.innerHTML='Copied address';">Copy address</button>
              <button type="button" class="lm-public-btn lm-public-btn--ghost" onclick="navigator.clipboard&&navigator.clipboard.writeText('<?php echo addslashes(number_format((float) ($topup['expected_amount_usdt'] ?? $topup['expected_amount'] ?? 0), 2, '.', '')); ?>');this.innerHTML='Copied amount';">Copy amount</button>
            </div>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </aside>
    <?php if ($isPaypal && $status !== 'paid' && $paypalSdkUrl !== ''): ?><script src="<?php echo htmlspecialchars($paypalSdkUrl, ENT_QUOTES, 'UTF-8'); ?>"></script><?php endif; ?>
<script>
(function(){
  var root=document.getElementById('lmTopupRoot');
  if(!root) return;
  var statusUrl=root.getAttribute('data-topup-status-url');
  if(!statusUrl) return;
  var badge=root.querySelector('.lm-topup-badge');
  var resultText=document.getElementById('lmTopupResultText');
  var paymentMethod=root.getAttribute('data-payment-method') || 'crypto';
  var topupId=root.getAttribute('data-topup-id') || '';
  var topupToken=root.getAttribute('data-topup-token') || '';
  var formTokenName=root.getAttribute('data-form-token-name') || '';
  var paypalCreateUrl=root.getAttribute('data-paypal-create-url') || '';
  var paypalCaptureUrl=root.getAttribute('data-paypal-capture-url') || '';
  var paypalMsg=document.getElementById('lmPaypalMessage');
  var paypalButtonsHost=document.getElementById('lmPaypalButtons');
  function setPaypalMessage(message, isError){
    if(!paypalMsg) return;
    paypalMsg.textContent=message || '';
    paypalMsg.style.color=isError ? '#9b2d2d' : '#55646f';
  }
  function applyState(data){
    if(!data||!data.ok) return;
    if(badge && data.status){ badge.textContent=data.status; }
    if(resultText && data.result_message){ resultText.textContent=data.result_message; }
    var meta=document.getElementById('lmTopupPollMeta'); if(meta){ meta.textContent='Last checked: ' + new Date().toLocaleTimeString() + ' • Next automatic check in ~10 seconds'; }
    if(data.status==='paid' || data.result_status==='lead_unlocked' || data.result_status==='batch_unlocked'){ window.location.reload(); return; }
  }
  function poll(){
    var xhr=new XMLHttpRequest();
    xhr.open('GET', statusUrl + (statusUrl.indexOf('?')>=0?'&':'?') + '_lmts=' + Date.now(), true);
    xhr.onreadystatechange=function(){
      if(xhr.readyState!==4) return;
      if(xhr.status>=200 && xhr.status<300){ try{ applyState(JSON.parse(xhr.responseText)); }catch(e){} }
    };
    xhr.send();
  }
  if(paymentMethod !== 'moneygram'){ setInterval(poll, 10000); }
  if(paymentMethod === 'paypal' && paypalButtonsHost && window.paypal && paypalCreateUrl && paypalCaptureUrl){
    paypal.Buttons({
      createOrder: function(){
        var fd=new FormData();
        fd.append('topup_id', topupId);
        fd.append('token', topupToken);
        if(formTokenName) fd.append(formTokenName, '1');
        return fetch(paypalCreateUrl, {method:'POST', body:fd, credentials:'same-origin', headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}})
          .then(function(r){ return r.json(); })
          .then(function(data){
            if(!data || !data.ok || !data.id){ throw new Error((data && data.message) ? data.message : 'Could not create PayPal order.'); }
            return data.id;
          });
      },
      onApprove: function(data){
        setPaypalMessage('Finalizing your payment... Please keep this page open for a few seconds.', false);
        var fd=new FormData();
        fd.append('topup_id', topupId);
        fd.append('token', topupToken);
        fd.append('paypal_order_id', data.orderID || '');
        if(formTokenName) fd.append(formTokenName, '1');
        return fetch(paypalCaptureUrl, {method:'POST', body:fd, credentials:'same-origin', headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}})
          .then(function(r){ return r.json(); })
          .then(function(resp){
            if(!resp || !resp.ok){ throw new Error((resp && resp.message) ? resp.message : 'PayPal capture failed.'); }
            if(resp.redirect_url){ window.location.href = resp.redirect_url; return; }
            window.location.reload();
          })
          .catch(function(err){ setPaypalMessage(err && err.message ? err.message : 'PayPal capture failed.', true); });
      },
      onError: function(err){
        setPaypalMessage((err && err.message) ? err.message : 'PayPal checkout could not be started. Please try again or disable the popup blocker for this site.', true);
      },
      onCancel: function(){
        setPaypalMessage('PayPal checkout was cancelled before completion.', true);
      }
    }).render('#lmPaypalButtons');
  }
})();
</script>
</div>
  <?php endif; ?>
</div>

<script>
(function(){
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-open-state')).forEach(function(link){
    link.addEventListener('click', function(){
      link.textContent = link.getAttribute('data-loading-text') || 'Opening...';
      link.style.pointerEvents = 'none';
      link.style.opacity = '0.85';
    });
  });
})();
</script>
