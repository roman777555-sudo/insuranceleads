<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketViewBuyeraccess extends JViewLegacy
{
  public $token = '';
  public $accessRow = null;
  public $buyerEmail = '';
  public $orders = array();
  public $batches = array();
  public $summary = array();
  public $walletBalance = 0.0;
  public $walletActivity = array();
  public $recentTopups = array();
  public $pendingLinkedPurchases = array();
  public $paidOrders = array();
  public $paidBatches = array();
  public $purchasedLeadRows = array();
  public $orderTimeline = array();
  public $recoveryItems = array();
  public $creditRequestMap = array();
  public $isValid = false;
  public $isExpired = false;
  public $templateSafeMode = false;
  public $loadErrorMessage = '';
  public $inlineCreditSubmitResult = null;
  public $focusCreditOrderId = 0;

  protected function safeDashboardLoad($context, $defaultValue, $callback)
  {
    try {
      return call_user_func($callback);
    } catch (Throwable $e) {
      LeadMarketHelper::writeRuntimeLog('buyeraccess_dashboard_load_failed', array(
        'context' => (string) $context,
        'buyer_email' => (string) $this->buyerEmail,
        'token' => (string) $this->token,
        'message' => $e->getMessage(),
      ));
      return $defaultValue;
    }
  }


  protected function buildOrderTimeline($orders, $batches)
  {
    $rows = array();
    foreach ((array) $orders as $row) {
      $statusMeta = is_array($row['status_meta'] ?? null) ? $row['status_meta'] : LeadMarketHelper::getBuyerDashboardStatusMeta('lead', $row);
      $rows[] = array(
        'item_type' => 'lead',
        'item_id' => (int) ($row['id'] ?? 0),
        'title' => (string) ($row['title_label'] ?? ('Lead order #' . (int) ($row['id'] ?? 0))),
        'meta' => trim((string) ($row['location_label'] ?? '') . ((string) ($row['location_label'] ?? '') !== '' ? ' • ' : '') . (string) ($row['date_label'] ?? '')),
        'amount_usd' => (float) ($row['amount_usd'] ?? 0),
        'status_meta' => $statusMeta,
        'secure_url' => (string) ($row['secure_url'] ?? '#'),
        'primary_action_label' => (string) ($row['primary_action_label'] ?? 'Open order'),
        'date_sort' => (string) (!empty($row['paid_at_utc']) ? $row['paid_at_utc'] : (!empty($row['submitted_at_utc']) ? $row['submitted_at_utc'] : (string) ($row['created_at_utc'] ?? ''))),
      );
    }
    foreach ((array) $batches as $row) {
      $statusMeta = is_array($row['status_meta'] ?? null) ? $row['status_meta'] : LeadMarketHelper::getBuyerDashboardStatusMeta('batch', $row);
      $rows[] = array(
        'item_type' => 'batch',
        'item_id' => (int) ($row['id'] ?? 0),
        'title' => 'Shared batch #' . (int) ($row['id'] ?? 0),
        'meta' => trim(((int) ($row['items_count'] ?? 0)) . ' leads • ' . (string) ($row['date_label'] ?? '')),
        'amount_usd' => (float) ($row['amount_usd'] ?? 0),
        'status_meta' => $statusMeta,
        'secure_url' => (string) ($row['secure_url'] ?? '#'),
        'primary_action_label' => (string) ($row['primary_action_label'] ?? 'Open batch'),
        'date_sort' => (string) (!empty($row['paid_at_utc']) ? $row['paid_at_utc'] : (!empty($row['submitted_at_utc']) ? $row['submitted_at_utc'] : (string) ($row['created_at_utc'] ?? ''))),
      );
    }
    usort($rows, function ($a, $b) {
      return strcmp((string) ($b['date_sort'] ?? ''), (string) ($a['date_sort'] ?? ''));
    });
    return $rows;
  }

  protected function inferTopupLeadSaleMode($topup)
  {
    $saleMode = strtolower(trim((string) ($topup['sale_mode'] ?? '')));
    if (in_array($saleMode, array('shared', 'exclusive'), true)) return $saleMode;
    $note = strtolower((string) ($topup['note'] ?? ''));
    if (strpos($note, 'exclusive') !== false) return 'exclusive';
    return 'shared';
  }

  protected function buildRecoveryItems($rows, $walletBalance, $buyerEmail)
  {
    $out = array();
    foreach ((array) $rows as $row) {
      $statusMeta = LeadMarketHelper::getBuyerDashboardStatusMeta('topup', $row);
      $method = LeadMarketHelper::normalizeTopupPaymentMethod((string) ($row['payment_method'] ?? 'crypto'));
      $targetType = strtolower((string) ($row['target_type'] ?? ''));
      $targetId = (int) ($row['target_id'] ?? 0);
      $targetPrice = (float) ($row['target_price_usd'] ?? 0);
      $title = 'Wallet top-up';
      $meta = (string) LeadMarketHelper::formatUtcForBuyer((string) (!empty($row['manual_submitted_utc']) ? $row['manual_submitted_utc'] : (!empty($row['created_at_utc']) ? $row['created_at_utc'] : '')));
      if ($targetType === 'lead' && $targetId > 0) {
        $ctx = LeadMarketHelper::getLinkedTopupLeadContext($row);
        if ($ctx && !empty($ctx['title'])) {
          $title = (string) $ctx['title'];
          if (!empty($ctx['location'])) $meta = trim((string) $ctx['location'] . ' • ' . $meta);
        } else {
          $title = 'Lead checkout #' . $targetId;
        }
      } elseif ($targetType === 'batch' && $targetId > 0) {
        $title = 'Shared batch #' . $targetId;
      }
      $item = array(
        'id' => (int) ($row['id'] ?? 0),
        'title' => $title,
        'meta' => $meta,
        'target_type' => $targetType,
        'target_id' => $targetId,
        'target_price_usd' => $targetPrice,
        'missing_amount_usd' => max(0.0, $targetPrice - (float) $walletBalance),
        'status_meta' => $statusMeta,
        'method_label' => ($method === 'moneygram' ? 'Western Union' : 'Crypto'),
        'continue_url' => (string) ($row['secure_url'] ?? '#'),
        'continue_label' => ($method === 'moneygram' ? 'Continue with Western Union' : 'Continue with crypto'),
        'can_complete_balance' => false,
        'complete_mode' => '',
        'complete_payload' => array(),
      );
      if ($targetPrice > 0 && ((float) $walletBalance + 0.0001) >= $targetPrice) {
        if ($targetType === 'lead' && $targetId > 0) {
          $item['can_complete_balance'] = true;
          $item['complete_mode'] = 'lead';
          $item['complete_payload'] = array(
            'lead_id' => $targetId,
            'buyer_email' => (string) $buyerEmail,
            'sale_mode' => $this->inferTopupLeadSaleMode($row),
          );
        } elseif ($targetType === 'batch' && $targetId > 0) {
          $batch = LeadMarketHelper::loadBatchById($targetId);
          if ($batch) {
            $item['can_complete_balance'] = true;
            $item['complete_mode'] = 'batch';
            $item['complete_payload'] = array(
              'batch_id' => $targetId,
              'token' => LeadMarketHelper::ensureBatchToken($batch),
            );
          }
        }
      }
      $item['date_sort'] = (string) (!empty($row['created_at_utc']) ? $row['created_at_utc'] : '');
      $out[] = $item;
    }
    usort($out, function ($a, $b) {
      return strcmp((string) ($b['date_sort'] ?? ''), (string) ($a['date_sort'] ?? ''));
    });
    return $out;
  }

  protected function buildPurchasedLeadRows($buyerEmail, $paidOrders, $paidBatches)
  {
    $rows = array();
    $seen = array();
    foreach ((array) $paidOrders as $row) {
      $orderId = (int) ($row['id'] ?? 0);
      if ($orderId <= 0 || isset($seen[$orderId])) continue;
      $rows[] = $row;
      $seen[$orderId] = true;
    }
    foreach ((array) $paidBatches as $batch) {
      $batchId = (int) ($batch['id'] ?? 0);
      if ($batchId <= 0) continue;
      foreach ((array) LeadMarketHelper::getBatchItems($batchId) as $item) {
        $orderId = (int) ($item['id'] ?? 0);
        if ($orderId <= 0 || isset($seen[$orderId])) continue;
        if (strtolower((string) ($item['status'] ?? '')) !== 'paid') continue;
        $item['access_token'] = LeadMarketHelper::ensureOrderToken($item);
        $leadId = (int) ($item['lead_id'] ?? 0);
        $item['secure_url'] = LeadMarketHelper::buildAbsoluteLeadUrl($leadId, $orderId, (string) ($item['access_token'] ?? ''));
        $item['status_meta'] = array('label' => 'Unlocked', 'tone' => 'ok');
        $city = trim((string) ($item['lead_city'] ?? $item['city'] ?? ''));
        $state = trim((string) ($item['lead_state'] ?? $item['state'] ?? ''));
        $zip = trim((string) ($item['zip'] ?? ''));
        $item['location_label'] = trim($city . ($city !== '' ? ', ' : '') . $state . ($zip !== '' ? ' ' . $zip : ''));
        $leadType = trim((string) ($item['lead_type'] ?? $item['type'] ?? 'AUTO'));
        $item['title_label'] = trim(strtoupper($state) . ' ' . strtoupper($leadType) . ' lead');
        $item['date_label'] = LeadMarketHelper::formatUtcForBuyer(!empty($item['paid_at_utc']) ? $item['paid_at_utc'] : (!empty($item['submitted_at_utc']) ? $item['submitted_at_utc'] : (string) ($item['created_at_utc'] ?? '')));
        $item['primary_action_label'] = 'Open unlocked lead';
        $item['allow_hide'] = false;
        $rows[] = $item;
        $seen[$orderId] = true;
      }
    }
    return LeadMarketHelper::sortBuyerDashboardRows($rows);
  }

  protected function applyTechnicalSeoProtection()
  {
    $robots = 'noindex, nofollow';
    $doc = JFactory::getDocument();
    if ($doc && method_exists($doc, 'setMetaData')) {
      $doc->setMetaData('robots', $robots);
    }
    if (!headers_sent()) {
      header('X-Robots-Tag: ' . $robots, true);
    }
    try { JFactory::getApplication()->setHeader('X-Robots-Tag', $robots, true); } catch (Exception $e) {}
  }

  public function display($tpl = null)
  {
    LeadMarketHelper::trackPageView('buyer_dashboard_view', array('page_name' => 'buyeraccess'));
    $this->applyTechnicalSeoProtection();
    try {
      LeadMarketHelper::ensureSchema();
      LeadMarketHelper::cleanupExpiredOrders();
      LeadMarketHelper::cleanupExpiredBatches();
      LeadMarketHelper::cleanupExpiredTopups();
      $app = JFactory::getApplication();
      $this->token = LeadMarketHelper::readBuyerAccessTokenFromRequest();
      if ($this->token === '') {
        $this->token = LeadMarketHelper::getRememberedBuyerAccessToken();
      }
      $inlineCredit = LeadMarketHelper::handleInlineCreditRequestPost();
      if (!empty($inlineCredit['handled'])) {
        $this->inlineCreditSubmitResult = $inlineCredit;
        $this->focusCreditOrderId = (int) ($inlineCredit['order_id'] ?? 0);
        if ($this->token === '' && !empty($inlineCredit['buyer_token'])) {
          $this->token = (string) $inlineCredit['buyer_token'];
        }
      }
      $raw = LeadMarketHelper::loadBuyerAccessRequestByToken($this->token);
      $valid = LeadMarketHelper::validateBuyerAccessToken($this->token);
      $this->accessRow = $valid;
      $this->isValid = !empty($valid);
      $this->isExpired = (!$valid && !empty($raw));
      if (!$valid && !empty($raw['buyer_email'])) {
        $this->buyerEmail = (string) $raw['buyer_email'];
      }
      if ($valid) {
        LeadMarketHelper::touchBuyerAccessToken($valid);
        $this->buyerEmail = (string)$valid['buyer_email'];
        LeadMarketHelper::setActiveBuyerContext($this->buyerEmail, 'buyeraccess', $this->token);
        LeadMarketHelper::rememberBuyerAccessToken($this->token);
        $this->orders = $this->safeDashboardLoad('orders', array(), function () {
          return LeadMarketHelper::getBuyerDashboardOrders($this->buyerEmail, 40);
        });
        $this->batches = $this->safeDashboardLoad('batches', array(), function () {
          return LeadMarketHelper::getBuyerDashboardBatches($this->buyerEmail, 20);
        });
        $this->summary = $this->safeDashboardLoad('summary', array(), function () {
          return LeadMarketHelper::getBuyerDashboardSummary($this->buyerEmail);
        });
        $this->walletBalance = (float) $this->safeDashboardLoad('wallet_balance', 0.0, function () {
          return LeadMarketHelper::getBuyerBalance($this->buyerEmail);
        });
        $this->walletActivity = $this->safeDashboardLoad('wallet_activity', array(), function () {
          return LeadMarketHelper::getWalletActivity($this->buyerEmail, 12);
        });
        $this->recentTopups = $this->safeDashboardLoad('recent_topups', array(), function () {
          return LeadMarketHelper::getBuyerDashboardTopups($this->buyerEmail, 20);
        });
        $this->pendingLinkedPurchases = $this->safeDashboardLoad('pending_linked_purchases', array(), function () {
          return LeadMarketHelper::getBuyerPendingLinkedPurchases($this->buyerEmail, 12);
        });
        $this->paidOrders = $this->safeDashboardLoad('paid_orders', array(), function () {
          return LeadMarketHelper::getBuyerPaidOrders($this->buyerEmail, 30);
        });
        $this->paidBatches = $this->safeDashboardLoad('paid_batches', array(), function () {
          return LeadMarketHelper::getBuyerPaidBatches($this->buyerEmail, 20);
        });
        $this->purchasedLeadRows = $this->safeDashboardLoad('purchased_lead_rows', array(), function () {
          return $this->buildPurchasedLeadRows($this->buyerEmail, $this->paidOrders, $this->paidBatches);
        });
        $this->orderTimeline = $this->buildOrderTimeline($this->orders, $this->batches);
        $this->recoveryItems = $this->buildRecoveryItems($this->pendingLinkedPurchases, $this->walletBalance, $this->buyerEmail);
        $orderIds = array();
        foreach ((array) $this->orders as $orderRow) { $orderIds[] = (int) ($orderRow['id'] ?? 0); }
        foreach ((array) $this->paidOrders as $orderRow) { $orderIds[] = (int) ($orderRow['id'] ?? 0); }
        foreach ((array) $this->purchasedLeadRows as $orderRow) { $orderIds[] = (int) ($orderRow['id'] ?? 0); }
        $orderIds = array_values(array_unique(array_filter(array_map('intval', $orderIds))));
        $this->creditRequestMap = $this->safeDashboardLoad('credit_request_map', array(), function () use ($orderIds) {
          return LeadMarketHelper::getBuyerCreditRequestMap($orderIds, $this->buyerEmail);
        });
      }
      parent::display($tpl);
      return;
    } catch (Throwable $e) {
      LeadMarketHelper::writeRuntimeLog('buyeraccess_display_failed', array(
        'buyer_email' => (string) $this->buyerEmail,
        'token' => (string) $this->token,
        'message' => $e->getMessage(),
        'file' => $e->getFile(),
        'line' => (int) $e->getLine(),
      ));
      if ($this->buyerEmail === '' && $this->token !== '') {
        $raw = LeadMarketHelper::loadBuyerAccessRequestByToken($this->token);
        if (!empty($raw['buyer_email'])) $this->buyerEmail = (string) $raw['buyer_email'];
      }
      $this->accessRow = null;
      $this->isValid = false;
      $this->isExpired = false;
      $this->orders = array();
      $this->batches = array();
      $this->summary = array();
      $this->walletBalance = 0.0;
      $this->walletActivity = array();
      $this->recentTopups = array();
      $this->pendingLinkedPurchases = array();
      $this->paidOrders = array();
      $this->paidBatches = array();
      $this->purchasedLeadRows = array();
      $this->orderTimeline = array();
      $this->recoveryItems = array();
      $this->creditRequestMap = array();
      $this->templateSafeMode = true;
      $this->loadErrorMessage = 'We could not open this buyer link fully right now. Request a fresh link or try again in a moment.';
      parent::display($tpl);
      return;
    }
  }
}
