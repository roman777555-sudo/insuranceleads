<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';
if (!empty($this->templateSafeMode)) {
  $safeBuyerEmail = trim((string) ($this->buyerEmail ?? ''));
  $safeRequestUrl = htmlspecialchars(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl($safeBuyerEmail), false), ENT_QUOTES, 'UTF-8');
  $safeMarketplaceUrl = htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8');
  $safeMessage = trim((string) ($this->loadErrorMessage ?? 'We could not open this buyer link fully right now.'));
  echo LeadMarketHelper::renderPublicSurfaceStyles();
  echo LeadMarketHelper::renderIframeBreakoutScript();
  ?>
  <div class="lm-public-wrap">
    <div class="lm-public-hero">
      <span class="lm-public-hero__eyebrow">Buyer dashboard</span>
      <h1 class="lm-public-hero__title">Open a fresh secure link</h1>
      <p class="lm-public-hero__copy">This buyer link could not be opened safely right now. Request a fresh access link and try again.</p>
      <div class="lm-public-hero__actions">
        <a class="lm-public-btn lm-public-btn--main lm-js-open-state" data-loading-text="Opening access recovery..." href="<?php echo $safeRequestUrl; ?>">Request new link</a>
        <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Returning to marketplace..." href="<?php echo $safeMarketplaceUrl; ?>">Back to Marketplace</a>
      </div>
    </div>
    <div class="lm-buyer-panel" style="max-width:760px;margin:0 auto;">
      <div class="lm-state lm-state--error" style="margin:0 0 16px;"><?php echo htmlspecialchars($safeMessage, ENT_QUOTES, 'UTF-8'); ?></div>
      <?php if ($safeBuyerEmail !== ''): ?>
        <div class="lm-state lm-state--info" style="margin:0;">Buyer email: <strong><?php echo htmlspecialchars($safeBuyerEmail, ENT_QUOTES, 'UTF-8'); ?></strong></div>
      <?php endif; ?>
    </div>
  </div>
  <script>
  (function(){
    Array.prototype.slice.call(document.querySelectorAll('.lm-js-open-state')).forEach(function(link){
      link.addEventListener('click', function(){ window.lmTrackEvent('lead_open_click', {page_name:'buyeraccess'});
        link.textContent = link.getAttribute('data-loading-text') || 'Opening...';
        link.style.pointerEvents = 'none';
        link.style.opacity = '0.85';
      });
    });
  })();
  </script>
  <?php
  return;
}
$isValid = !empty($this->isValid);

$isExpired = !empty($this->isExpired);
$buyerEmail = (string)$this->buyerEmail;
$buyerToken = !empty($this->accessRow['access_token']) ? (string)$this->accessRow['access_token'] : (string)$this->token;
$orders = is_array($this->orders) ? $this->orders : array();
$purchasedLeadRows = is_array($this->purchasedLeadRows) ? $this->purchasedLeadRows : array();
$creditRequestMap = is_array($this->creditRequestMap) ? $this->creditRequestMap : array();
$creditReasonOptions = LeadMarketHelper::getCreditRequestReasonOptions();
$creditWindowHours = (int) LeadMarketHelper::creditRequestWindowHours();
$batches = is_array($this->batches) ? $this->batches : array();
$summary = is_array($this->summary) ? $this->summary : array('leads_count'=>0,'batches_count'=>0,'topups_count'=>0,'unlocked_count'=>0,'active_count'=>0,'total_paid_usd'=>0.0);
$walletBalance = isset($this->walletBalance) ? (float) $this->walletBalance : 0.0;
$walletActivity = is_array($this->walletActivity) ? $this->walletActivity : array();
$recentTopups = is_array($this->recentTopups) ? $this->recentTopups : array();
$paidOrders = is_array($this->paidOrders) ? $this->paidOrders : array();
$purchasedBatchRows = is_array($this->paidBatches) ? $this->paidBatches : array();
$paidBatches = is_array($this->paidBatches) ? $this->paidBatches : array();
$orderTimeline = is_array($this->orderTimeline) ? $this->orderTimeline : array();
$recoveryItems = is_array($this->recoveryItems) ? $this->recoveryItems : array();
$minimumTopup = (float) LeadMarketHelper::minimumTopupUsd();
$moneygramEnabled = LeadMarketHelper::moneygramEnabled();
$moneygramMin = (float) LeadMarketHelper::moneygramMinimumUsd();
$buyerTopupPresets = LeadMarketHelper::getTopupPresets();
$buyerTopupDefault = LeadMarketHelper::getDefaultTopupPreset();
$buyerAllowCustomTopup = LeadMarketHelper::isCustomTopupAllowed();
$buyerCustomTopupMin = LeadMarketHelper::topupCustomMinimumUsd();
$dashboardUrl = htmlspecialchars(LeadMarketHelper::buildAbsoluteBuyerAccessUrl($buyerToken), ENT_QUOTES, 'UTF-8');
$dashboardReturnUrl = 'index.php?option=com_leadmarket&view=buyeraccess&token=' . urlencode($buyerToken);
$dashboardAbsoluteBaseUrl = LeadMarketHelper::buildAbsoluteBuyerAccessUrl($buyerToken);
$dashboardCurrentUrl = JUri::getInstance()->toString(array('scheme','host','port','path','query'));
if ($dashboardCurrentUrl === '') $dashboardCurrentUrl = html_entity_decode($dashboardAbsoluteBaseUrl, ENT_QUOTES, 'UTF-8');
$inlineCreditSubmitResult = is_array($this->inlineCreditSubmitResult ?? null) ? $this->inlineCreditSubmitResult : null;
$postedFocusCreditOrderId = (int) ($this->focusCreditOrderId ?? 0);
$requestNewLinkUrl = htmlspecialchars(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl($buyerEmail), false), ENT_QUOTES, 'UTF-8');
$totalPurchases = (int) (($summary['leads_count'] ?? 0) + ($summary['batches_count'] ?? 0));
$totalOrdersCount = count($orderTimeline);
$paidPurchasesCount = count($paidOrders) + count($paidBatches);
$awaitingTopupCount = count($recoveryItems);
$completedTopupsCount = 0;
foreach ($recentTopups as $__recentTopup) { if (strtolower((string)($__recentTopup['status'] ?? '')) === 'paid') $completedTopupsCount++; }
unset($__recentTopup);

if (!function_exists('lmBuyerAccessActivityTitle')) {
  function lmBuyerAccessActivityTitle($row)
  {
    $entryType = strtolower((string) ($row->entry_type ?? 'adjust'));
    $direction = strtolower((string) ($row->direction ?? 'credit'));
    if ($entryType === 'topup' && $direction === 'credit') return 'Top-up credited';
    if ($entryType === 'purchase' && $direction === 'debit') return 'Lead paid from wallet';
    if ($entryType === 'batch_purchase' && $direction === 'debit') return 'Batch paid from wallet';
    if ($entryType === 'refund' && $direction === 'credit') return 'Refund credited';
    if ($direction === 'debit') return 'Balance deducted';
    if ($direction === 'credit') return 'Balance credited';
    return 'Balance adjustment';
  }
}
if (!function_exists('lmBuyerBadgeClass')) {
  function lmBuyerBadgeClass($tone)
  {
    $tone = strtolower((string) $tone);
    if ($tone === 'ok') return 'lm-buyer-badge lm-buyer-badge--ok';
    if ($tone === 'bad') return 'lm-buyer-badge lm-buyer-badge--bad';
    return 'lm-buyer-badge lm-buyer-badge--warn';
  }
}
if (!function_exists('lmBuyerCreditReasonLabel')) {
  function lmBuyerCreditReasonLabel($code, $options)
  {
    $code = strtolower(trim((string) $code));
    return isset($options[$code]) ? (string) $options[$code] : ucfirst(str_replace('_', ' ', $code));
  }
}
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderIframeBreakoutScript(); ?>
<style>
.lm-buyer-grid{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:18px;align-items:start}
.lm-buyer-panel{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:22px;box-shadow:0 4px 16px rgba(12,85,133,.05)}
.lm-buyer-panel + .lm-buyer-panel{margin-top:18px}
.lm-buyer-title{margin:0 0 10px;font-size:28px;color:#0c5585;line-height:1.2}
.lm-buyer-copy{margin:0;color:#44545e;line-height:1.7}
.lm-buyer-summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.lm-buyer-stat{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:14px;min-width:0}
.lm-buyer-stat__label{font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}
.lm-buyer-stat__value{font-size:28px;font-weight:800;color:#13232f;line-height:1.2;word-break:break-word}
.lm-buyer-item{border:1px solid #e5edf4;border-radius:14px;padding:16px;background:#fff}
.lm-buyer-item + .lm-buyer-item{margin-top:12px}
.lm-buyer-item__top{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap}
.lm-buyer-item__title{font-size:20px;font-weight:800;color:#13232f;line-height:1.25;word-break:break-word}
.lm-buyer-item__meta{margin-top:6px;color:#61717f;line-height:1.55;word-break:break-word}
.lm-buyer-item__amount{font-size:18px;font-weight:800;color:#0c5585;white-space:nowrap}
.lm-buyer-item__chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.lm-buyer-chip{display:inline-flex;align-items:center;min-height:30px;padding:0 10px;border-radius:999px;border:1px solid #d7e4ee;background:#f7fbff;color:#35556b;font-size:12px;font-weight:800}
.lm-buyer-chip--muted{background:#fff;border-color:#e4edf4;color:#607080}
.lm-buyer-item__actions{margin-top:14px;display:flex;gap:10px;flex-wrap:wrap}
.lm-buyer-item__actions .lm-public-btn{min-width:220px}
.lm-buyer-empty{border:1px dashed #d9e4ec;border-radius:12px;padding:18px;background:#fbfdff}
.lm-buyer-empty__title{font-size:18px;font-weight:800;color:#13232f;margin:0 0 6px}
.lm-buyer-empty__copy{margin:0;color:#61717f;line-height:1.6}
.lm-buyer-aside{position:sticky;top:18px}
.lm-buyer-email{word-break:break-word}
.lm-buyer-balance{font-size:34px;font-weight:800;line-height:1.1;color:#13232f;word-break:break-word}
.lm-buyer-balance-note{margin-top:8px;color:#61717f;line-height:1.6}
.lm-wallet-activity{display:flex;flex-direction:column;gap:12px}
.lm-wallet-row{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;padding:14px 0;border-top:1px solid #edf2f7}
.lm-wallet-row:first-child{border-top:0;padding-top:0}
.lm-wallet-row__title{font-size:16px;font-weight:800;color:#13232f;line-height:1.35}
.lm-wallet-row__meta{margin-top:4px;color:#61717f;line-height:1.6;font-size:14px;word-break:break-word}
.lm-wallet-row__amount{font-size:18px;font-weight:800;white-space:nowrap}
.lm-wallet-row__amount--credit{color:#167446}
.lm-wallet-row__amount--debit{color:#a33d2f}
.lm-buyer-badge{display:inline-block;padding:7px 10px;border-radius:999px;font-size:12px;font-weight:800;border:1px solid #d8e8f3;background:#eef6fb;color:#0c5585}
.lm-buyer-badge--ok{background:#eefaf0;border-color:#cfe5d4;color:#1f6b35}
.lm-buyer-badge--warn{background:#fff8ef;border-color:#eadfc7;color:#7a5c1e}
.lm-buyer-badge--bad{background:#fff5f5;border-color:#efd5d5;color:#7a2b2b}
.lm-buyer-form label{display:block;font-size:13px;font-weight:800;color:#44545e;margin:0 0 6px}
.lm-buyer-form input{display:block;width:100%;max-width:100%;box-sizing:border-box;border:1px solid #c5d0d8;border-radius:10px;background:#fff;color:#22313b;font-size:16px;min-height:48px;height:48px;padding:0 14px;line-height:48px;box-shadow:inset 0 1px 2px rgba(0,0,0,.03)}
.lm-buyer-form textarea,.lm-buyer-form select{display:block;width:100%;max-width:100%;box-sizing:border-box;border:1px solid #c5d0d8;border-radius:10px;background:#fff;color:#22313b;font-size:15px;padding:10px 12px;box-shadow:inset 0 1px 2px rgba(0,0,0,.03)}
.lm-buyer-form select{min-height:48px !important;height:48px !important;padding:0 42px 0 14px !important;line-height:normal !important;appearance:auto;-webkit-appearance:menulist;background-position:right 12px center}
.lm-buyer-form textarea{min-height:96px !important;height:auto !important;padding:12px 14px !important;line-height:1.5 !important;resize:vertical;overflow:auto}
.lm-credit-box .lm-buyer-form textarea,.lm-credit-box .lm-buyer-form select{max-width:100% !important}
.lm-credit-box{margin-top:12px;padding:14px;border:1px solid #e5edf4;border-radius:12px;background:#fbfdff}
.lm-credit-box[hidden]{display:none !important}
.lm-credit-box__summary{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 8px}
.lm-credit-box__hint{font-size:12px;color:#61717f;line-height:1.45}
.lm-credit-box__title{font-size:14px;font-weight:800;color:#13232f;margin:0 0 8px}
.lm-credit-box__copy{margin:0 0 10px;color:#61717f;line-height:1.6;font-size:13px}
.lm-credit-status{margin-top:10px}
.lm-buyer-note{margin-top:10px;color:#61717f;line-height:1.6;font-size:14px}
.lm-buyer-split{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap;margin-top:12px}
.lm-buyer-mini{font-size:13px;color:#61717f;line-height:1.5}
.lm-topup-presets{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}
.lm-topup-preset{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 14px;border-radius:999px;border:1px solid #d5e3ee;background:#fff;color:#0c5585;font-weight:800;cursor:pointer}
.lm-topup-preset.is-active{background:#0c5585;color:#fff;border-color:#0c5585}
.lm-dash-filters{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}
.lm-dash-filter{display:inline-flex;align-items:center;justify-content:center;min-height:40px;padding:0 14px;border-radius:999px;border:1px solid #d5e3ee;background:#fff;color:#0c5585;font-weight:800;cursor:pointer}
.lm-dash-filter.is-active{background:#0c5585;color:#fff;border-color:#0c5585}
.lm-dash-section{scroll-margin-top:20px}
.lm-dash-section[hidden]{display:none !important}
.lm-dash-subtitle{margin:0 0 14px;color:#61717f;line-height:1.6}
.lm-credit-box{scroll-margin-top:18px}
.lm-credit-box.is-pulse{animation:lmCreditPulse 1.1s ease;border-color:#9cc5de;box-shadow:0 0 0 4px rgba(12,85,133,.08)}
.lm-batch-lead-list{margin-top:14px;padding-top:12px;border-top:1px solid #edf2f7;display:flex;flex-direction:column;gap:10px}
.lm-batch-lead-row{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap}
.lm-batch-lead-row__meta{color:#61717f;font-size:14px;line-height:1.5}
.lm-batch-lead-card{margin-top:14px;padding:12px;border:1px solid #e8eef4;border-radius:12px;background:#fbfdff}
.lm-batch-lead-card__title{font-size:13px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin:0 0 10px}
.lm-batch-lead-row + .lm-batch-lead-row{padding-top:10px;border-top:1px solid #edf2f7}
.lm-batch-lead-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
.lm-batch-lead-actions .lm-public-btn{min-width:0;padding:0 12px;min-height:38px}
@keyframes lmCreditPulse{0%{transform:translateY(0);box-shadow:0 0 0 0 rgba(12,85,133,.14)}45%{transform:translateY(-1px);box-shadow:0 0 0 8px rgba(12,85,133,.08)}100%{transform:translateY(0);box-shadow:0 0 0 0 rgba(12,85,133,0)}}
@media (max-width:960px){.lm-buyer-grid{grid-template-columns:1fr}.lm-buyer-aside{position:static}}
@media (max-width:640px){
  .lm-buyer-panel{padding:18px}
  .lm-buyer-title{font-size:24px}
  .lm-buyer-summary{grid-template-columns:1fr 1fr}
  .lm-buyer-item__title{font-size:18px}
  .lm-buyer-item__top,.lm-wallet-row{display:block}
  .lm-buyer-item__amount,.lm-wallet-row__amount{display:block;margin-top:10px;white-space:normal}
  .lm-buyer-balance{font-size:30px}
  .lm-buyer-item__actions .lm-public-btn,.lm-buyer-aside .lm-public-btn,.lm-public-hero__actions .lm-public-btn,.lm-dash-filter{width:100%;min-width:0}
}
</style>
<div class="lm-public-wrap">
  <div class="lm-public-hero">
    <span class="lm-public-hero__eyebrow">Buyer dashboard</span>
    <h1 class="lm-public-hero__title"><?php echo $isValid ? 'My purchases' : 'Secure link required'; ?></h1>
    <p class="lm-public-hero__copy"><?php echo $isValid ? 'Open past purchases, continue active payments, and manage your wallet from one place.' : 'This secure buyer access link is missing, invalid, or expired. Request a new magic link to continue.'; ?></p>
    <div class="lm-public-hero__actions">
      <a class="lm-public-btn lm-public-btn--main lm-js-open-state" data-loading-text="Opening buyer access help..." href="<?php echo $requestNewLinkUrl; ?>">Request new link</a>
      <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Returning to marketplace..." href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Back to Marketplace</a>
      <?php if ($isValid): ?><a class="lm-public-btn lm-public-btn--ghost" href="#lm-topup-balance">Top up balance</a><?php endif; ?>
    </div>
  </div>

  <?php if (!$isValid): ?>
    <div class="lm-buyer-panel" style="max-width:760px;margin:0 auto;">
      <h2 class="lm-buyer-title"><?php echo $isExpired ? 'Link expired' : 'Secure link required'; ?></h2>
      <p class="lm-buyer-copy"><?php echo $isExpired ? 'Your buyer access link expired. Request a fresh magic link using the buyer email from checkout.' : 'Open the buyer access page from the secure link sent to your email, or request a new one.'; ?></p>
      <?php if ($buyerEmail !== ''): ?>
      <form class="lm-buyer-form" action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin-top:16px;max-width:420px;">
        <?php echo JHtml::_('form.token'); ?>
        <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>">
        <button type="submit" class="lm-public-btn lm-public-btn--main lm-js-submit-state" data-loading-text="Sending fresh access link...">Send a new link to <?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?></button>
      </form>
      <?php else: ?>
      <div class="lm-public-actions" style="margin-top:16px;">
        <a class="lm-public-btn lm-public-btn--main lm-js-open-state" data-loading-text="Opening access recovery..." href="<?php echo $requestNewLinkUrl; ?>">Request magic link</a>
      </div>
      <?php endif; ?>
    </div>
  <?php else: ?>
    <div class="lm-buyer-panel" style="margin-bottom:18px;">
      <div class="lm-buyer-summary">
        <div class="lm-buyer-stat"><div class="lm-buyer-stat__label">Total orders</div><div class="lm-buyer-stat__value"><?php echo (int) $totalOrdersCount; ?></div></div>
        <div class="lm-buyer-stat"><div class="lm-buyer-stat__label">Paid purchases</div><div class="lm-buyer-stat__value"><?php echo (int) $paidPurchasesCount; ?></div></div>
        <div class="lm-buyer-stat"><div class="lm-buyer-stat__label">Awaiting top-up</div><div class="lm-buyer-stat__value"><?php echo (int) $awaitingTopupCount; ?></div></div>
        <div class="lm-buyer-stat"><div class="lm-buyer-stat__label">Completed top-ups</div><div class="lm-buyer-stat__value"><?php echo (int) $completedTopupsCount; ?></div></div>
        <div class="lm-buyer-stat"><div class="lm-buyer-stat__label">Wallet</div><div class="lm-buyer-stat__value">$<?php echo htmlspecialchars(number_format($walletBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div></div>
      </div>
      <div class="lm-buyer-note" style="margin-top:12px;">Buyer email: <strong class="lm-buyer-email"><?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?></strong></div>
      <div class="lm-dash-filters" role="tablist" aria-label="Dashboard filters">
        <button type="button" class="lm-dash-filter is-active" data-section="all">All</button>
        <button type="button" class="lm-dash-filter" data-section="orders">My Orders</button>
        <button type="button" class="lm-dash-filter" data-section="recovery">Awaiting Top-up</button>
        <button type="button" class="lm-dash-filter" data-section="leads">Purchased Leads</button>
        <button type="button" class="lm-dash-filter" data-section="batches">Batches</button>
        <button type="button" class="lm-dash-filter" data-section="topups">Top-up History</button>
      </div>
    </div>

    <div class="lm-buyer-grid">
      <div>
        <div class="lm-buyer-panel lm-dash-section" data-dash-section="orders">
          <h2 class="lm-buyer-title">My Orders</h2>
          <p class="lm-dash-subtitle">See every lead and batch order with its current status and the next action.</p>
          <?php if (!$orderTimeline): ?>
            <div class="lm-buyer-empty">
              <div class="lm-buyer-empty__title">No orders yet</div>
              <p class="lm-buyer-empty__copy">Your lead and batch orders will appear here after checkout starts.</p>
              <div class="lm-public-actions" style="margin-top:12px;"><a class="lm-public-btn lm-public-btn--ghost" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Browse leads</a></div>
            </div>
          <?php else: foreach ($orderTimeline as $entry): ?>
            <?php $statusMeta = is_array($entry['status_meta'] ?? null) ? $entry['status_meta'] : array('label' => 'Pending', 'tone' => 'warn'); ?>
            <div class="lm-buyer-item">
              <div class="lm-buyer-item__top">
                <div>
                  <div class="lm-buyer-item__title"><?php echo htmlspecialchars((string) ($entry['title'] ?? 'Order'), ENT_QUOTES, 'UTF-8'); ?></div>
                  <div class="lm-buyer-item__meta"><?php echo htmlspecialchars((string) ($entry['meta'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div class="lm-buyer-item__amount">$<?php echo htmlspecialchars(number_format((float) ($entry['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
              </div>
              <div class="lm-buyer-item__chips">
                <span class="<?php echo lmBuyerBadgeClass($statusMeta['tone'] ?? 'warn'); ?>"><?php echo htmlspecialchars((string) ($statusMeta['label'] ?? 'Pending'), ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="lm-buyer-chip lm-buyer-chip--muted"><?php echo htmlspecialchars(strtoupper((string) ($entry['item_type'] ?? 'order')), ENT_QUOTES, 'UTF-8'); ?></span>
              </div>
              <div class="lm-buyer-item__actions">
                <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars((string) ($entry['secure_url'] ?? '#'), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string) ($entry['primary_action_label'] ?? 'Open order'), ENT_QUOTES, 'UTF-8'); ?></a>
                <?php $entryStatus = strtolower((string) ($entry['status'] ?? '')); $entryType = strtolower((string) ($entry['item_type'] ?? 'order')); ?>
                <?php if ($entryStatus === 'paid' && $entryType === 'order'): ?>
                  <?php $entryCreditTarget = 'credit-box-' . (int) ($entry['id'] ?? 0); ?>
                  <button type="button" class="lm-public-btn lm-public-btn--ghost lm-js-credit-toggle" data-target="<?php echo htmlspecialchars($entryCreditTarget, ENT_QUOTES, 'UTF-8'); ?>" aria-expanded="false">Review / request credit</button>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>

        <div class="lm-buyer-panel lm-dash-section" data-dash-section="leads">
          <h2 class="lm-buyer-title">Purchased Leads</h2>
          <p class="lm-dash-subtitle">Open unlocked lead purchases, resend a fresh buyer access link, or submit a lead review request when a purchased lead qualifies.</p>
          <?php if (!$purchasedLeadRows): ?>
            <div class="lm-buyer-empty">
              <div class="lm-buyer-empty__title">No lead purchases yet</div>
              <p class="lm-buyer-empty__copy">When you unlock a lead, it will appear here for quick access.</p>
              <div class="lm-public-actions" style="margin-top:12px;"><a class="lm-public-btn lm-public-btn--ghost" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Browse leads</a></div>
            </div>
          <?php else: foreach ($purchasedLeadRows as $order): ?>
            <?php $statusMeta = is_array($order['status_meta'] ?? null) ? $order['status_meta'] : array('label' => 'Pending', 'tone' => 'warn'); ?>
            <div class="lm-buyer-item">
              <div class="lm-buyer-item__top">
                <div>
                  <div class="lm-buyer-item__title"><?php echo htmlspecialchars((string) ($order['title_label'] ?? 'Lead purchase'), ENT_QUOTES, 'UTF-8'); ?></div>
                  <div class="lm-buyer-item__meta">
                    <?php if (!empty($order['location_label'])): ?><?php echo htmlspecialchars((string) $order['location_label'], ENT_QUOTES, 'UTF-8'); ?>&nbsp;•&nbsp;<?php endif; ?>
                    <?php echo htmlspecialchars((string) ($order['date_label'] ?? ''), ENT_QUOTES, 'UTF-8'); ?>
                  </div>
                </div>
                <div class="lm-buyer-item__amount">$<?php echo htmlspecialchars(number_format((float) ($order['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
              </div>
              <div class="lm-buyer-item__chips">
                <span class="<?php echo lmBuyerBadgeClass($statusMeta['tone'] ?? 'warn'); ?>"><?php echo htmlspecialchars((string) ($statusMeta['label'] ?? 'Pending'), ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="lm-buyer-chip lm-buyer-chip--muted">Lead</span>
              </div>
              <?php $creditOrderId = (int) ($order['id'] ?? 0); $hasCreditMeta = array_key_exists($creditOrderId, $creditRequestMap); $creditMeta = $hasCreditMeta ? $creditRequestMap[$creditOrderId] : array(); $creditReturnUrl = $dashboardCurrentUrl . (strpos($dashboardCurrentUrl, '?') !== false ? '&' : '?') . 'section=leads&credit_order=' . (int) $creditOrderId . '#credit-box-' . (int) $creditOrderId; ?>
              <div class="lm-buyer-item__actions">
                <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars((string) ($order['secure_url'] ?? '#'), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string) ($order['primary_action_label'] ?? 'Open lead'), ENT_QUOTES, 'UTF-8'); ?></a>
                <?php $leadIsPaid = strtolower((string) ($order['status'] ?? '')) === 'paid'; ?>
                <?php if ($leadIsPaid || !empty($creditMeta)): ?>
                <?php $creditJumpTarget = 'credit-box-' . (int) ($order['id'] ?? 0); ?>
                <button type="button" class="lm-public-btn lm-public-btn--ghost lm-js-credit-toggle" data-target="<?php echo htmlspecialchars($creditJumpTarget, ENT_QUOTES, 'UTF-8'); ?>" aria-expanded="false">Review / request credit</button>
                <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;">
                  <?php echo JHtml::_('form.token'); ?>
                  <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>">
                  <button type="submit" class="lm-public-btn lm-public-btn--ghost lm-js-submit-state" data-loading-text="Sending fresh access link...">Send fresh access link</button>
                </form>
                <?php endif; ?>
                <?php if (!empty($order['allow_hide'])): ?>
                <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=dashboardhide'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;">
                  <?php echo JHtml::_('form.token'); ?>
                  <input type="hidden" name="buyer_token" value="<?php echo htmlspecialchars($buyerToken, ENT_QUOTES, 'UTF-8'); ?>">
                  <input type="hidden" name="item_type" value="lead">
                  <input type="hidden" name="item_id" value="<?php echo (int) ($order['id'] ?? 0); ?>">
                  <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($creditReturnUrl, ENT_QUOTES, 'UTF-8'); ?>">
                  <button type="submit" class="lm-public-btn lm-public-btn--ghost">Hide from list</button>
                </form>
                <?php endif; ?>
              </div>
              <div class="lm-credit-box" id="credit-box-<?php echo (int) ($order['id'] ?? 0); ?>" hidden>
                <div class="lm-credit-box__summary">
                  <div class="lm-credit-box__title">Lead review / credit request</div>
                  <div class="lm-credit-box__hint">Opens only when needed</div>
                </div>
                <p class="lm-credit-box__copy">Use this only for verified data-quality issues. The review window is limited to <?php echo (int) $creditWindowHours; ?> hours after purchase.</p>
                <?php if (!empty($creditMeta['existing'])): ?>
                  <?php $req = $creditMeta['existing']; $reqStatus = $creditMeta['status_meta'] ?? array('label' => 'Submitted', 'tone' => 'warn'); ?>
                  <div class="lm-credit-status">
                    <span class="<?php echo lmBuyerBadgeClass($reqStatus['tone'] ?? 'warn'); ?>"><?php echo htmlspecialchars((string) ($reqStatus['label'] ?? 'Submitted'), ENT_QUOTES, 'UTF-8'); ?></span>
                    <div class="lm-buyer-note" style="margin-top:8px;">Reason: <?php echo htmlspecialchars(lmBuyerCreditReasonLabel((string) ($req['reason_code'] ?? ''), $creditReasonOptions), ENT_QUOTES, 'UTF-8'); ?><?php if ((string) ($req['status'] ?? '') === 'approved' && (float) ($req['approved_amount'] ?? 0) > 0): ?> · Approved — $<?php echo htmlspecialchars(number_format((float) ($req['approved_amount'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> credited to your balance<?php endif; ?></div>
                    <?php if (!empty($req['buyer_note'])): ?><div class="lm-buyer-note">Your note: <?php echo nl2br(htmlspecialchars((string) $req['buyer_note'], ENT_QUOTES, 'UTF-8')); ?></div><?php endif; ?>
                    <?php if (!empty($req['admin_note']) && (string) ($req['status'] ?? '') === 'declined'): ?><div class="lm-buyer-note">Review note: <?php echo nl2br(htmlspecialchars((string) $req['admin_note'], ENT_QUOTES, 'UTF-8')); ?></div><?php endif; ?>
                  </div>
                <?php elseif (!empty($creditMeta['can_request'])): ?>
                  <form class="lm-buyer-form lm-js-credit-submit-form" action="<?php echo htmlspecialchars($dashboardCurrentUrl, ENT_QUOTES, 'UTF-8'); ?>" method="post">
                    <?php echo JHtml::_('form.token'); ?>
                    <input type="hidden" name="lm_inline_credit_submit" value="1">
                    <input type="hidden" name="buyer_token" value="<?php echo htmlspecialchars($buyerToken, ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="hidden" name="order_id" value="<?php echo (int) ($order['id'] ?? 0); ?>">
                    <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($creditReturnUrl, ENT_QUOTES, 'UTF-8'); ?>">
                    <label for="credit-reason-<?php echo (int) ($order['id'] ?? 0); ?>">Reason</label>
                    <select id="credit-reason-<?php echo (int) ($order['id'] ?? 0); ?>" name="reason_code" required>
                      <?php foreach ($creditReasonOptions as $reasonCode => $reasonLabel): ?>
                        <option value="<?php echo htmlspecialchars($reasonCode, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($reasonLabel, ENT_QUOTES, 'UTF-8'); ?></option>
                      <?php endforeach; ?>
                    </select>
                    <label for="credit-note-<?php echo (int) ($order['id'] ?? 0); ?>">Comment</label>
                    <textarea id="credit-note-<?php echo (int) ($order['id'] ?? 0); ?>" name="buyer_note" rows="3" placeholder="Add a short explanation for the review team."></textarea>
                    <div class="lm-public-actions" style="margin-top:10px;">
                      <button type="submit" class="lm-public-btn lm-public-btn--ghost">Request Credit</button>
                    </div>
                  </form>
                <?php else: ?>
                  <div class="lm-buyer-note"><?php echo htmlspecialchars((string) ($hasCreditMeta ? ($creditMeta['message'] ?? ('Review window closed. Credit requests must be submitted within ' . (int) $creditWindowHours . ' hours of purchase.')) : 'Review availability is loading. Refresh the dashboard or open the lead page and try again.'), ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>

        <div class="lm-buyer-panel lm-dash-section" data-dash-section="batches">
          <h2 class="lm-buyer-title">Batches</h2>
          <p class="lm-dash-subtitle">Open unlocked shared batches and resend a fresh buyer access link when you need a new secure access email.</p>
          <?php if (!$purchasedBatchRows): ?>
            <div class="lm-buyer-empty">
              <div class="lm-buyer-empty__title">No batch purchases yet</div>
              <p class="lm-buyer-empty__copy">Shared lead batch checkouts will appear here once you start one.</p>
              <div class="lm-public-actions" style="margin-top:12px;"><a class="lm-public-btn lm-public-btn--ghost" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Browse leads</a></div>
            </div>
          <?php else: foreach ($purchasedBatchRows as $batch): ?>
            <?php $statusMeta = is_array($batch['status_meta'] ?? null) ? $batch['status_meta'] : array('label' => 'Pending', 'tone' => 'warn'); ?>
            <div class="lm-buyer-item">
              <div class="lm-buyer-item__top">
                <div>
                  <div class="lm-buyer-item__title">Shared lead batch #<?php echo (int) ($batch['id'] ?? 0); ?></div>
                  <div class="lm-buyer-item__meta"><?php echo (int) ($batch['items_count'] ?? 0); ?> leads&nbsp;•&nbsp;<?php echo htmlspecialchars((string) ($batch['date_label'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div class="lm-buyer-item__amount">$<?php echo htmlspecialchars(number_format((float) ($batch['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
              </div>
              <div class="lm-buyer-item__chips">
                <span class="<?php echo lmBuyerBadgeClass($statusMeta['tone'] ?? 'warn'); ?>"><?php echo htmlspecialchars((string) ($statusMeta['label'] ?? 'Pending'), ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="lm-buyer-chip lm-buyer-chip--muted"><?php echo (int) ($batch['items_count'] ?? 0); ?> leads</span>
              </div>
              <div class="lm-buyer-item__actions">
                <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars((string) ($batch['secure_url'] ?? '#'), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string) ($batch['primary_action_label'] ?? 'Open batch'), ENT_QUOTES, 'UTF-8'); ?></a>
                <?php if (($batch['status_meta']['label'] ?? '') === 'Unlocked'): ?>
                <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;">
                  <?php echo JHtml::_('form.token'); ?>
                  <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>">
                  <button type="submit" class="lm-public-btn lm-public-btn--ghost lm-js-submit-state" data-loading-text="Sending fresh access link...">Send fresh access link</button>
                </form>
                <?php endif; ?>
                <?php if (!empty($batch['allow_hide'])): ?>
                <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=dashboardhide'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;">
                  <?php echo JHtml::_('form.token'); ?>
                  <input type="hidden" name="buyer_token" value="<?php echo htmlspecialchars($buyerToken, ENT_QUOTES, 'UTF-8'); ?>">
                  <input type="hidden" name="item_type" value="batch">
                  <input type="hidden" name="item_id" value="<?php echo (int) ($batch['id'] ?? 0); ?>">
                  <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($dashboardReturnUrl, ENT_QUOTES, 'UTF-8'); ?>">
                  <button type="submit" class="lm-public-btn lm-public-btn--ghost">Hide from list</button>
                </form>
                <?php endif; ?>
              </div>
              <?php $batchChildOrders = (array) LeadMarketHelper::getBatchItems((int) ($batch['id'] ?? 0)); ?>
              <?php $paidBatchChildOrders = array(); foreach ($batchChildOrders as $__childOrder) { if (strtolower((string) ($__childOrder['status'] ?? '')) === 'paid' && (int) ($__childOrder['lead_id'] ?? 0) > 0 && (int) ($__childOrder['id'] ?? 0) > 0) $paidBatchChildOrders[] = $__childOrder; } unset($__childOrder); ?>
              <?php if ($paidBatchChildOrders): ?>
              <div class="lm-batch-lead-card">
                <div class="lm-batch-lead-card__title">Batch lead actions</div>
                <div class="lm-batch-lead-list">
                <?php foreach ($paidBatchChildOrders as $childOrder): ?>
                  <?php $childOrderId = (int) ($childOrder['id'] ?? 0); $childLeadId = (int) ($childOrder['lead_id'] ?? 0); ?>
                  <?php $childLeadTitle = LeadMarketHelper::formatLeadTitle($childOrder); $childCreditTarget = 'credit-box-' . $childOrderId; $childLeadUrl = JRoute::_(LeadMarketHelper::buildLeadUrl($childLeadId, $childOrderId, LeadMarketHelper::ensureOrderToken($childOrder)), false); $childCreditUrl = htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&view=buyeraccess&token=' . urlencode($buyerToken) . '&section=leads&credit_order=' . $childOrderId . '#'.$childCreditTarget, false), ENT_QUOTES, 'UTF-8'); ?>
                  <div class="lm-batch-lead-row">
                    <div>
                      <div style="font-weight:800;color:#13232f;"><?php echo htmlspecialchars($childLeadTitle, ENT_QUOTES, 'UTF-8'); ?></div>
                      <div class="lm-batch-lead-row__meta">Open the lead or request a credit review.</div>
                      <div class="lm-batch-lead-actions">
                        <a class="lm-public-btn lm-public-btn--ghost" rel="nofollow" href="<?php echo htmlspecialchars($childLeadUrl, ENT_QUOTES, 'UTF-8'); ?>">Open lead</a>
                        <a class="lm-public-btn lm-public-btn--ghost" rel="nofollow" href="<?php echo $childCreditUrl; ?>">Request credit</a>
                      </div>
                    </div>
                  </div>
                <?php endforeach; ?>
                </div>
              </div>
              <?php endif; ?>
            </div>
          <?php endforeach; endif; ?>
        </div>

        <div class="lm-buyer-panel lm-dash-section" data-dash-section="recovery">
          <h2 class="lm-buyer-title">Awaiting Top-up</h2>
          <p class="lm-dash-subtitle">Continue linked payments, review manual transfer status, or complete a purchase from balance when enough funds are available.</p>
          <?php if (!$recoveryItems): ?>
            <div class="lm-buyer-empty">
              <div class="lm-buyer-empty__title">Nothing is waiting for top-up</div>
              <p class="lm-buyer-empty__copy">Active recovery actions will appear here when a checkout still needs funding.</p>
            </div>
          <?php else: foreach ($recoveryItems as $recovery): ?>
            <?php $statusMeta = is_array($recovery['status_meta'] ?? null) ? $recovery['status_meta'] : array('label' => 'Pending', 'tone' => 'warn'); ?>
            <div class="lm-buyer-item">
              <div class="lm-buyer-item__top">
                <div>
                  <div class="lm-buyer-item__title"><?php echo htmlspecialchars((string) ($recovery['title'] ?? 'Awaiting top-up'), ENT_QUOTES, 'UTF-8'); ?></div>
                  <div class="lm-buyer-item__meta"><?php echo htmlspecialchars((string) ($recovery['meta'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div class="lm-buyer-item__amount">$<?php echo htmlspecialchars(number_format((float) ($recovery['target_price_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
              </div>
              <div class="lm-buyer-item__chips">
                <span class="<?php echo lmBuyerBadgeClass($statusMeta['tone'] ?? 'warn'); ?>"><?php echo htmlspecialchars((string) ($statusMeta['label'] ?? 'Pending'), ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="lm-buyer-chip lm-buyer-chip--muted"><?php echo htmlspecialchars((string) ($recovery['method_label'] ?? 'Top-up'), ENT_QUOTES, 'UTF-8'); ?></span>
              </div>
              <div class="lm-buyer-split">
                <div class="lm-buyer-mini">Current wallet: <strong>$<?php echo htmlspecialchars(number_format($walletBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
                <div class="lm-buyer-mini">Missing now: <strong>$<?php echo htmlspecialchars(number_format((float) ($recovery['missing_amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
              </div>
              <div class="lm-buyer-item__actions">
                <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars((string) ($recovery['continue_url'] ?? '#'), ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string) ($recovery['continue_label'] ?? 'Continue payment'), ENT_QUOTES, 'UTF-8'); ?></a>
                <?php if (!empty($recovery['can_complete_balance']) && ($recovery['complete_mode'] ?? '') === 'lead'): ?>
                <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=leadunlockbalance'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;">
                  <?php echo JHtml::_('form.token'); ?>
                  <input type="hidden" name="lead_id" value="<?php echo (int) (($recovery['complete_payload']['lead_id'] ?? 0)); ?>">
                  <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars((string) (($recovery['complete_payload']['buyer_email'] ?? $buyerEmail)), ENT_QUOTES, 'UTF-8'); ?>">
                  <input type="hidden" name="sale_mode" value="<?php echo htmlspecialchars((string) (($recovery['complete_payload']['sale_mode'] ?? 'shared')), ENT_QUOTES, 'UTF-8'); ?>">
                  <button type="submit" class="lm-public-btn lm-public-btn--ghost lm-js-submit-state" data-loading-text="Completing from balance...">Complete from balance</button>
                </form>
                <?php elseif (!empty($recovery['can_complete_balance']) && ($recovery['complete_mode'] ?? '') === 'batch'): ?>
                <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=batchunlockbalance'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;">
                  <?php echo JHtml::_('form.token'); ?>
                  <input type="hidden" name="batch_id" value="<?php echo (int) (($recovery['complete_payload']['batch_id'] ?? 0)); ?>">
                  <input type="hidden" name="token" value="<?php echo htmlspecialchars((string) (($recovery['complete_payload']['token'] ?? '')), ENT_QUOTES, 'UTF-8'); ?>">
                  <button type="submit" class="lm-public-btn lm-public-btn--ghost lm-js-submit-state" data-loading-text="Completing from balance...">Complete from balance</button>
                </form>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>

        <div class="lm-buyer-panel lm-dash-section" data-dash-section="topups">
          <h2 class="lm-buyer-title">Top-up History</h2>
          <p class="lm-dash-subtitle">Track wallet funding, linked top-ups, payment method, and what each payment unlocked.</p>
          <?php if (!$recentTopups): ?>
            <div class="lm-buyer-empty">
              <div class="lm-buyer-empty__title">No top-ups yet</div>
              <p class="lm-buyer-empty__copy">Balance top-ups and linked top-ups will show here once created.</p>
              <div class="lm-public-actions" style="margin-top:12px;"><a class="lm-public-btn lm-public-btn--ghost" href="#lm-topup-balance">Top up balance</a></div>
            </div>
          <?php else: foreach ($recentTopups as $tp): ?>
            <?php $statusMeta = is_array($tp['status_meta'] ?? null) ? $tp['status_meta'] : array('label' => 'Pending', 'tone' => 'warn'); ?>
            <div class="lm-buyer-item">
              <div class="lm-buyer-item__top">
                <div>
                  <div class="lm-buyer-item__title">Top-up #<?php echo (int) ($tp['id'] ?? 0); ?></div>
                  <div class="lm-buyer-item__meta"><?php echo htmlspecialchars((string) ($tp['date_label'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
                <div class="lm-buyer-item__amount">$<?php echo htmlspecialchars(number_format((float) ($tp['topup_amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
              </div>
              <div class="lm-buyer-item__chips">
                <span class="<?php echo lmBuyerBadgeClass($statusMeta['tone'] ?? 'warn'); ?>"><?php echo htmlspecialchars((string) ($statusMeta['label'] ?? 'Pending'), ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="lm-buyer-chip lm-buyer-chip--muted"><?php echo htmlspecialchars(LeadMarketHelper::getTopupPaymentMethodLabel((string) ($tp['payment_method'] ?? 'crypto')), ENT_QUOTES, 'UTF-8'); ?></span>
                <span class="lm-buyer-chip lm-buyer-chip--muted"><?php echo htmlspecialchars((string) ($tp['related_target_label'] ?? 'Wallet top-up'), ENT_QUOTES, 'UTF-8'); ?></span>
              </div>
              <div class="lm-buyer-item__actions">
                <?php $topupActionUrl = !empty($tp['related_target_url']) ? (string) $tp['related_target_url'] : (string) ($tp['secure_url'] ?? '#'); ?>
                <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($topupActionUrl, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string) ($tp['primary_action_label'] ?? 'Open top-up'), ENT_QUOTES, 'UTF-8'); ?></a>
                <?php if (!empty($tp['allow_hide'])): ?>
                <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=dashboardhide'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;">
                  <?php echo JHtml::_('form.token'); ?>
                  <input type="hidden" name="buyer_token" value="<?php echo htmlspecialchars($buyerToken, ENT_QUOTES, 'UTF-8'); ?>">
                  <input type="hidden" name="item_type" value="topup">
                  <input type="hidden" name="item_id" value="<?php echo (int) ($tp['id'] ?? 0); ?>">
                  <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($dashboardReturnUrl, ENT_QUOTES, 'UTF-8'); ?>">
                  <button type="submit" class="lm-public-btn lm-public-btn--ghost">Hide from list</button>
                </form>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; endif; ?>
        </div>

        <div class="lm-buyer-panel">
          <h2 class="lm-buyer-title">Wallet activity</h2>
          <?php if (!$walletActivity): ?>
            <p class="lm-buyer-copy">No wallet activity for this buyer email yet.</p>
          <?php else: ?>
            <div class="lm-wallet-activity">
              <?php foreach ($walletActivity as $row): ?>
                <?php $direction = strtolower((string) ($row->direction ?? 'credit')); ?>
                <div class="lm-wallet-row">
                  <div>
                    <div class="lm-wallet-row__title"><?php echo htmlspecialchars(lmBuyerAccessActivityTitle($row), ENT_QUOTES, 'UTF-8'); ?></div>
                    <div class="lm-wallet-row__meta"><?php echo htmlspecialchars(LeadMarketHelper::formatUtcForBuyer((string) ($row->created_at_utc ?? '')), ENT_QUOTES, 'UTF-8'); ?></div>
                  </div>
                  <div class="lm-wallet-row__amount <?php echo $direction === 'debit' ? 'lm-wallet-row__amount--debit' : 'lm-wallet-row__amount--credit'; ?>"><?php echo $direction === 'debit' ? '-' : '+'; ?>$<?php echo htmlspecialchars(number_format((float) ($row->amount_usd ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <aside class="lm-buyer-aside">
        <div class="lm-buyer-panel">
          <div style="font-size:22px;font-weight:800;color:#13232f;margin-bottom:8px;line-height:1.25;">Current buyer balance</div>
          <div class="lm-buyer-balance">$<?php echo htmlspecialchars(number_format($walletBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
          <p class="lm-buyer-balance-note">Use your wallet to unlock future leads or batches when enough balance is available.</p>
        </div>
        <div class="lm-buyer-panel" id="lm-topup-balance">
          <div style="font-size:22px;font-weight:800;color:#13232f;margin-bottom:8px;line-height:1.25;">Top up balance</div>
          <p class="lm-buyer-copy" style="margin-bottom:12px;">Choose a quick amount or enter a custom amount. Any unused balance stays in your wallet.</p>
          <form class="lm-buyer-form" action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=createtopup'); ?>" method="post">
            <?php echo JHtml::_('form.token'); ?>
            <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" name="buyer_token" value="<?php echo htmlspecialchars($buyerToken, ENT_QUOTES, 'UTF-8'); ?>">
            <label>Quick top-up options</label>
            <div class="lm-topup-presets">
              <?php foreach ($buyerTopupPresets as $preset): ?>
                <button type="button" class="lm-topup-preset" data-target="#lm_topup_amount_usd" data-amount="<?php echo htmlspecialchars(number_format((float) $preset, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">$<?php echo htmlspecialchars(number_format((float) $preset, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></button>
              <?php endforeach; ?>
            </div>
            <label for="lm_topup_amount_usd">Top-up amount (USD)</label>
            <input id="lm_topup_amount_usd" type="number" step="0.01" min="0.01" name="topup_amount_usd" value="<?php echo htmlspecialchars(number_format($buyerTopupDefault, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" <?php echo !$buyerAllowCustomTopup ? 'readonly="readonly"' : ''; ?> required>
            <input type="hidden" name="payment_method" id="lm_buyer_topup_payment_method" value="<?php echo LeadMarketHelper::isPaypalAllowedForAmount((float) $buyerTopupDefault) ? 'paypal' : 'crypto'; ?>">
            <div class="lm-buyer-note">Crypto minimum: $<?php echo htmlspecialchars(number_format($minimumTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?>. Western Union minimum: $<?php echo htmlspecialchars(number_format($moneygramMin, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?>. PayPal can be used for top-ups up to $<?php echo htmlspecialchars(number_format($paypalTopupMax, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?>.</div>
            <div style="margin-top:14px;font-weight:800;color:#13232f;font-size:16px;">Step 2. Select funding method</div>
            <div style="margin-top:6px;color:#61717f;line-height:1.6;">These buttons only select how you want to pay. To continue, use the main button below.</div>
            <div class="lm-topup-methods" data-lm-method-group="buyer" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
              <?php if ($paypalEnabled): ?><button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="paypal">Use PayPal</button><?php endif; ?>
              <button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="crypto">Use Crypto</button>
              <?php if ($moneygramEnabled): ?><button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="moneygram">Use Western Union</button><?php endif; ?>
            </div>
            <div id="lmBuyerTopupMethodNote" class="lm-buyer-note" style="margin-top:10px;padding:10px 12px;border:1px solid #dbe6ef;border-radius:10px;background:#f8fbfd;">Selected method: <b>Crypto</b>. The next page will show the wallet address and exact amount.</div>
            <div class="lm-public-actions"><button type="submit" id="lmBuyerTopupSubmit" class="lm-public-btn lm-public-btn--main" style="width:100%;justify-content:center;font-size:16px;min-height:50px;">Continue to crypto payment</button></div>
          </form>
        </div>
        <div class="lm-buyer-panel">
          <div style="font-size:22px;font-weight:800;color:#13232f;margin-bottom:8px;line-height:1.25;">Need a new link?</div>
          <p class="lm-buyer-copy" style="margin-bottom:12px;">Request a fresh magic link anytime using the buyer email from checkout.</p>
          <a class="lm-public-btn lm-public-btn--ghost" href="<?php echo htmlspecialchars(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl()), ENT_QUOTES, 'UTF-8'); ?>">Request another link</a>
        </div>
      </aside>
    </div>
  <?php endif; ?>
<script>
(function(){
  var paypalEnabled=<?php echo $paypalEnabled ? 'true' : 'false'; ?>;
  var paypalTopupMax=<?php echo json_encode((float) $paypalTopupMax); ?>;
  var moneygramEnabled=<?php echo $moneygramEnabled ? 'true' : 'false'; ?>;
  var moneygramMin=<?php echo json_encode((float) $moneygramMin); ?>;
  var cryptoMin=<?php echo json_encode((float) $minimumTopup); ?>;
  function isPaypalAllowedAmount(amount){ var n=parseFloat(amount||0); return paypalEnabled && isFinite(n) && n > 0 && n <= paypalTopupMax + 0.0001; }
  function isMoneygramAllowedAmount(amount){ var n=parseFloat(amount||0); return moneygramEnabled && isFinite(n) && n + 0.0001 >= moneygramMin; }
  function syncBuyerTopupMethods(){
    var wrap=document.querySelector('[data-lm-method-group="buyer"]');
    var input=document.getElementById('lm_topup_amount_usd');
    var hidden=document.getElementById('lm_buyer_topup_payment_method');
    var note=document.getElementById('lmBuyerTopupMethodNote');
    var submit=document.getElementById('lmBuyerTopupSubmit');
    if(!wrap || !input || !hidden) return;
    var amount=parseFloat(input.value||0); if(!isFinite(amount)||amount<=0) amount=0;
    var paypalBtn=wrap.querySelector('[data-lm-method="paypal"]');
    var moneygramBtn=wrap.querySelector('[data-lm-method="moneygram"]');
    var current=hidden.value || 'crypto';
    var paypalAllowed=isPaypalAllowedAmount(amount);
    var moneygramAllowed=isMoneygramAllowedAmount(amount);
    if(current==='paypal' && !paypalAllowed){ current='crypto'; hidden.value='crypto'; }
    if(current==='moneygram' && !moneygramAllowed){ current='crypto'; hidden.value='crypto'; }
    wrap.querySelectorAll('[data-lm-method]').forEach(function(btn){
      var method=btn.getAttribute('data-lm-method')||'crypto';
      var allowed=(method==='paypal') ? paypalAllowed : (method==='moneygram' ? moneygramAllowed : true);
      var active=method===current;
      if(!btn.getAttribute('data-base-label')){ btn.setAttribute('data-base-label', (btn.textContent||'').trim()); }
      var baseLabel=btn.getAttribute('data-base-label') || (btn.textContent||'').trim();
      if(method==='paypal' && !allowed) btn.textContent='Use PayPal · up to $'+paypalTopupMax.toFixed(2);
      else if(method==='moneygram' && !allowed) btn.textContent='Use Western Union · from $'+moneygramMin.toFixed(2);
      else btn.textContent=baseLabel;
      btn.classList.toggle('is-active', active);
      btn.disabled=!allowed;
      btn.setAttribute('aria-disabled', allowed ? 'false' : 'true');
      btn.title = allowed ? '' : (method==='paypal' ? 'Available up to $'+paypalTopupMax.toFixed(2) : 'Available from $'+moneygramMin.toFixed(2));
      btn.style.background=!allowed ? '#eef2f6' : (active ? '#0c5585' : '#fff');
      btn.style.color=!allowed ? '#7f8e9c' : (active ? '#fff' : '#0c5585');
      btn.style.borderColor=!allowed ? '#d6dde5' : (active ? '#0c5585' : '#cfe0eb');
      btn.style.cursor=!allowed ? 'not-allowed' : 'pointer';
      btn.style.opacity=!allowed ? '0.48' : '1';
      btn.style.filter=!allowed ? 'grayscale(0.15)' : 'none';
      btn.style.boxShadow=!allowed ? 'none' : '';
      if(!allowed) btn.classList.remove('is-active');
      btn.onclick=function(){ var method=btn.getAttribute('data-lm-method')||'crypto'; if(method==='paypal' && !paypalAllowed) return; if(method==='moneygram' && !moneygramAllowed) return; hidden.value=method; syncBuyerTopupMethods(); };
    });
    if(note){
      if(current==='paypal') note.innerHTML='Selected method: <b>PayPal</b>. The next step opens a secure PayPal checkout where the buyer can pay with PayPal or an eligible card.';
      else if(current==='moneygram') note.innerHTML='Selected method: <b>Western Union</b>. The next step opens your secure instruction page with receiver details and the MTCN form. Western Union is available from <b>$'+moneygramMin.toFixed(2)+'</b>.';
      else note.innerHTML='Selected method: <b>Crypto</b>. The next step opens your secure payment page with the wallet address and exact amount. Crypto minimum is <b>$'+cryptoMin.toFixed(2)+'</b>.';
      if(!paypalAllowed && paypalBtn){ note.innerHTML += ' <span style="display:block;margin-top:6px;color:#7a5c1e;">PayPal becomes available when the amount is $'+paypalTopupMax.toFixed(2)+' or less.</span>'; }
      if(!moneygramAllowed && moneygramBtn){ note.innerHTML += ' <span style="display:block;margin-top:6px;color:#7a5c1e;">Western Union becomes available from $'+moneygramMin.toFixed(2)+'. Increase the amount to use it.</span>'; }
    }
    if(submit){
      if(current==='paypal') submit.textContent='Continue to PayPal checkout';
      else if(current==='moneygram') submit.textContent='Continue to Western Union instructions';
      else submit.textContent='Continue to crypto payment';
    }
  }
  var presetButtons=document.querySelectorAll('.lm-topup-preset');
  presetButtons.forEach(function(btn){
    btn.addEventListener('click', function(){
      var target=document.querySelector(btn.getAttribute('data-target'));
      if(!target) return;
      target.value=btn.getAttribute('data-amount') || '';
      presetButtons.forEach(function(other){ other.classList.remove('is-active'); });
      btn.classList.add('is-active');
      try{ target.focus(); }catch(e){}
    });
  });

  var buyerTopupInput=document.getElementById('lm_topup_amount_usd');
  if(buyerTopupInput){ buyerTopupInput.addEventListener('input', syncBuyerTopupMethods); }
  syncBuyerTopupMethods();

  var filters=document.querySelectorAll('.lm-dash-filter');
  var sections=document.querySelectorAll('[data-dash-section]');
  filters.forEach(function(btn){
    btn.addEventListener('click', function(){
      var target=btn.getAttribute('data-section') || 'all';
      filters.forEach(function(other){ other.classList.remove('is-active'); });
      btn.classList.add('is-active');
      sections.forEach(function(section){
        var name=section.getAttribute('data-dash-section');
        section.hidden = !(target === 'all' || target === name);
      });
    });
  });
  function lmOpenCreditBox(targetId, preferredSection){
    if(!targetId) return;
    var el = document.getElementById(targetId);
    if(!el) return;
    var filterName = preferredSection || 'leads';
    var leadsFilter = document.querySelector('.lm-dash-filter[data-section="' + filterName + '"]') || document.querySelector('.lm-dash-filter[data-section="leads"]');
    if (leadsFilter && !leadsFilter.classList.contains('is-active')) { leadsFilter.click(); }
    el.hidden = false;
    Array.prototype.slice.call(document.querySelectorAll('.lm-js-credit-toggle[data-target="' + targetId + '"]')).forEach(function(btn){ btn.setAttribute('aria-expanded', 'true'); });
    setTimeout(function(){
      try { el.scrollIntoView({behavior:'smooth', block:'center'}); } catch(e) { location.hash = '#'+targetId; }
      el.classList.remove('is-pulse');
      setTimeout(function(){ el.classList.add('is-pulse'); }, 20);
      setTimeout(function(){ el.classList.remove('is-pulse'); }, 1400);
    }, 40);
  }
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-credit-toggle')).forEach(function(btn){
    btn.addEventListener('click', function(ev){
      ev.preventDefault();
      var targetId = btn.getAttribute('data-target') || '';
      var el = document.getElementById(targetId);
      if(!el) return;
      var isHidden = el.hidden;
      el.hidden = !isHidden;
      btn.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
      if(isHidden){ window.lmTrackEvent('credit_request_opened', {page_name:'buyeraccess', order_id: parseInt((targetId||'').replace('credit-box-',''),10)||0, source:'buyer_dashboard'}); lmOpenCreditBox(targetId, 'leads'); }
    });
  });
  var params = new URLSearchParams(window.location.search || '');
  var focusCreditOrder = params.get('credit_order') || '';
  var focusSection = params.get('section') || 'leads';
  var hashTarget = (window.location.hash || '').replace('#','');
  var postedCreditOrder = <?php echo (int) $postedFocusCreditOrderId; ?>;
  var deepTarget = hashTarget || (focusCreditOrder ? ('credit-box-' + focusCreditOrder) : (postedCreditOrder ? ('credit-box-' + postedCreditOrder) : ''));
  if (deepTarget) { lmOpenCreditBox(deepTarget, focusSection); }
})();
</script>
</div>

<script>
(function(){
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-open-state')).forEach(function(link){
    link.addEventListener('click', function(){ window.lmTrackEvent('lead_open_click', {page_name:'buyeraccess'});
      link.textContent = link.getAttribute('data-loading-text') || 'Opening...';
      link.style.pointerEvents = 'none';
      link.style.opacity = '0.85';
    });
  });
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-credit-submit-form')).forEach(function(form){
    form.addEventListener('submit', function(){
      try {
        form.action = window.location.href.split('#')[0] || form.action;
      } catch(e) {}
    });
  });
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-submit-state')).forEach(function(btn){
    var form = btn.closest('form');
    if (!form) return;
    form.addEventListener('submit', function(){
      btn.disabled = true;
      btn.textContent = btn.getAttribute('data-loading-text') || 'Working...';
    });
  });
})();
</script>
