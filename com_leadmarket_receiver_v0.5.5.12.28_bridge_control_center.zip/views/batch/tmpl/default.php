<?php defined('_JEXEC') or die; ?>
<?php require_once JPATH_COMPONENT . '/helpers/leadmarket.php'; ?>
<?php
$mode = $this->mode;
$batch = $this->batch;
$items = (array)$this->items;
$selection = (array)$this->selectionLeads;
$token = (string)$this->token;
$address = (string)$this->address;
$sessionNotice = (string)$this->sessionNotice;
$errorNotice = (string)$this->errorNotice;
$eligibilityNotice = (string)$this->eligibilityNotice;
$buyerEmailValue = (string)$this->buyerEmailValue;
$repeatPurchaseNotice = (string)$this->repeatPurchaseNotice;
$repeatPurchaseTone = (string)$this->repeatPurchaseTone;
$allSelectedAlreadyPurchased = !empty($this->allSelectedAlreadyPurchased);
$showResendAccess = !empty($this->showResendAccess);
$disableSharedCheckout = !empty($this->disableSharedCheckout);
$errorTone = (string)($this->errorTone ?? 'warn');
$batchAdjustmentData = (array)($this->batchAdjustmentData ?? array());
$inlineCreditSubmitResult = is_array($this->inlineCreditSubmitResult ?? null) ? $this->inlineCreditSubmitResult : null;
$showCreditOrder = (int) JFactory::getApplication()->input->getInt('show_credit_order', 0);
if ($showCreditOrder <= 0) $showCreditOrder = (int) ($this->focusCreditOrderId ?? 0);
function lmBuyerCardMini($lead, $price){
  $masked = LeadMarketHelper::buildMaskedPreview($lead);
  $title = LeadMarketHelper::formatLeadTitle($lead);
  $loc = trim($masked['city'] . ', ' . $masked['state'] . ' ' . $masked['zip']);
  $saleOptions = LeadMarketHelper::getSaleModeOptions($lead);
  $sharedReason = trim((string)($saleOptions['shared']['reason'] ?? ''));
  echo '<div class="lm-batch-mini">';
  echo '<div class="lm-batch-mini__title">' . htmlspecialchars($title,ENT_QUOTES,'UTF-8') . '</div>';
  echo '<div class="lm-batch-mini__meta">' . htmlspecialchars($loc,ENT_QUOTES,'UTF-8') . ' • ' . htmlspecialchars((string)$masked['phone_masked'],ENT_QUOTES,'UTF-8') . '</div>';
  echo '<div class="lm-batch-mini__grid">';
  echo '<div class="lm-batch-mini__box"><div class="lm-batch-mini__label">Shared price</div><strong style="font-size:18px;color:#13232f">from $' . htmlspecialchars(number_format((float)$price,2,'.',''),ENT_QUOTES,'UTF-8') . '</strong></div>';
  echo '<div class="lm-batch-mini__box"><div class="lm-batch-mini__label">Availability</div><span>' . htmlspecialchars(LeadMarketHelper::getBuyerAvailabilityLabel($lead),ENT_QUOTES,'UTF-8') . '</span></div>';
  echo '</div>';
  if ($sharedReason !== '') echo '<div class="lm-batch-mini__reason">' . htmlspecialchars($sharedReason, ENT_QUOTES, 'UTF-8') . '</div>';
  echo '</div>';
}
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderBatchPromoFallbackScript(); ?>
<style>
.lm-batch-checking{margin:0 0 12px;padding:14px 16px;border-radius:14px;background:#f8fbfd;border:1px solid #dbe6ef;color:#22313b}
.lm-batch-checking__row{display:flex;align-items:center;gap:12px;margin-bottom:10px}
.lm-batch-checking__spinner{width:20px;height:20px;border-radius:50%;border:3px solid #d7e8f3;border-top-color:#0c5585;animation:lmspin .9s linear infinite;display:inline-block;flex:0 0 auto}
.lm-batch-checking__title{font-size:17px;font-weight:800;color:#13232f}
.lm-batch-checking__copy{color:#55646f;line-height:1.7;margin:0 0 10px}
.lm-batch-checking__steps{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px;margin:0;padding:0;list-style:none}
.lm-batch-checking__steps li{background:#fff;border:1px solid #e3edf5;border-radius:12px;padding:12px 12px 12px 38px;position:relative;color:#44545e;line-height:1.5;min-height:48px}
.lm-batch-checking__steps li:before{content:'';position:absolute;left:14px;top:16px;width:12px;height:12px;border-radius:50%;background:#d7e8f3;animation:lmpulse 1.2s infinite}
.lm-batch-checking__steps li.is-active:before{background:#0c5585}
.lm-batch-checking__meta{margin-top:10px;font-size:12px;color:#607080}
.lm-spinner-inline{display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.45);border-top-color:#fff;border-radius:50%;animation:lmspin .8s linear infinite;margin-right:8px;vertical-align:-2px}
@keyframes lmspin{to{transform:rotate(360deg)}}
@keyframes lmpulse{0%,100%{opacity:.35;transform:scale(.92)}50%{opacity:1;transform:scale(1.08)}}
@media (max-width:640px){.lm-batch-checking__steps{grid-template-columns:1fr}}
.lm-batch-mini{border:1px solid #dbe6ef;border-radius:14px;padding:14px;background:#fff;margin-bottom:12px;box-shadow:0 4px 16px rgba(12,85,133,.05)}
.lm-batch-mini__title{font-size:22px;font-weight:800;color:#13232f;margin:0 0 6px}
.lm-batch-mini__meta{color:#61717f;line-height:1.6;margin:0 0 10px}
.lm-batch-mini__grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.lm-batch-mini__box{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px}
.lm-batch-mini__label{font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}
.lm-batch-mini__reason{margin-top:10px;padding:10px 12px;border-radius:12px;background:#fff8ef;border:1px solid #eadfc7;color:#7a5c1e;line-height:1.6;font-size:13px}
.lm-batch-aside{position:sticky;top:16px}
.lm-batch-aside__helper{margin:0 0 12px;color:#51626d;line-height:1.7;font-size:14px}
.lm-batch-inline-actions{display:grid;gap:10px}
.lm-batch-inline-actions .lm-public-btn,.lm-batch-inline-actions button{width:100%}
.lm-batch-credit-box{margin-top:12px;padding:14px;border:1px solid #e5edf4;border-radius:12px;background:#fbfdff}
.lm-batch-credit-box[hidden]{display:none !important}
.lm-batch-credit-box__summary{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 8px}
.lm-batch-credit-box__hint{font-size:12px;color:#61717f;line-height:1.45}
.lm-batch-credit-box__title{font-size:14px;font-weight:800;color:#13232f;margin:0 0 8px}
.lm-batch-credit-box__copy{margin:0 0 10px;color:#61717f;line-height:1.6;font-size:13px}
.lm-batch-credit-box .lm-buyer-form select{min-height:48px !important;height:48px !important;padding:0 42px 0 14px !important;line-height:normal !important;appearance:auto;-webkit-appearance:menulist}
.lm-batch-credit-box .lm-buyer-form textarea{min-height:96px !important;height:auto !important;padding:12px 14px !important;line-height:1.5 !important;resize:vertical;overflow:auto}
.lm-promo-inline{margin-top:12px;padding:12px;border:1px solid #dbe6ef;border-radius:14px;background:linear-gradient(135deg,#fbfdff 0%,#f4faf7 100%)}.lm-promo-inline--always{padding:12px;border:1px solid #dbe6ef;border-radius:14px;background:linear-gradient(135deg,#fbfdff 0%,#f4faf7 100%)}.lm-promo-inline__microtitle{display:block;margin:0 0 6px;color:#18384b;font-size:13px;font-weight:800}.lm-promo-inline__helper{margin-top:8px;color:#607080;font-size:12px;line-height:1.6}
.lm-promo-inline__controls{display:flex;flex-wrap:wrap;align-items:center;gap:10px}
.lm-promo-inline__toggle{display:inline-flex;align-items:center;justify-content:center;min-height:38px;padding:0 14px;border-radius:999px;border:1px solid #cfe0eb;background:#fff;color:#0c5585;font-weight:800;cursor:pointer;transition:background .18s ease,color .18s ease,border-color .18s ease}
.lm-promo-inline__toggle.is-applied{background:#f3f5f7;border-color:#d8e0e7;color:#7a8894}
.lm-promo-inline__check{display:none;align-items:center;gap:6px;font-size:13px;font-weight:800;color:#1f6a3c;width:100%;margin-top:2px}
.lm-promo-inline__check.is-visible{display:inline-flex}
.lm-promo-inline__checkmark{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:50%;background:#1f6a3c;color:#fff;font-size:12px;line-height:1;flex:0 0 18px}
.lm-promo-inline__panel{display:none;margin-top:10px}
.lm-promo-inline__panel.is-open{display:block}
.lm-promo-inline__label{display:block;margin:0 0 6px;font-weight:700;color:#18384b}
.lm-promo-inline__row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.lm-promo-inline__input{flex:1 1 160px;min-height:40px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;background:#fff;color:#18384b}
.lm-promo-inline__input.is-applied{background:#f3f5f7;border-color:#d8e0e7;color:#7a8894}
.lm-promo-inline__apply,.lm-promo-inline__remove{display:inline-flex;align-items:center;justify-content:center;min-height:40px;padding:0 14px;border-radius:10px;font-weight:700;cursor:pointer}
.lm-promo-inline__apply{border:1px solid #0c5585;background:#fff;color:#0c5585}
.lm-promo-inline__remove{border:1px solid #d7e2eb;background:#fff;color:#425561}.lm-promo-inline__apply.lm-ajax-btn.is-loading:after,.lm-promo-inline__apply.is-loading:after{border-color:rgba(12,85,133,.22);border-top-color:#0c5585}.lm-promo-inline__apply.is-loading{position:relative;padding-right:34px;pointer-events:none;opacity:.92}.lm-promo-inline__apply.is-loading:after{content:"";position:absolute;right:12px;top:50%;width:15px;height:15px;margin-top:-8px;border-radius:50%;border:2px solid rgba(12,85,133,.22);border-top-color:#0c5585;animation:lmspin .8s linear infinite}
.lm-promo-inline__status{display:none;margin-top:8px;padding:10px 12px;border-radius:12px;font-size:13px;line-height:1.6}
.lm-promo-inline__status--success{border:1px solid #cfe5d4;background:#eefaf0;color:#1f6b35}
.lm-promo-inline__status--error{border:1px solid #ebc9c9;background:#fff4f4;color:#8a2d2d}
.lm-promo-inline__status--info{border:1px solid #d5e6f1;background:#eef6fb;color:#24475d}
.lm-promo-summary{margin-top:10px;display:none;border:1px solid #dbe6ef;border-radius:12px;background:#fff;padding:12px}
.lm-promo-summary.is-visible{display:block}
.lm-promo-summary__head{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 8px}
.lm-promo-badge{display:inline-block;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:800;border:1px solid #cfe7d8;background:#edf8f1;color:#1f6a3c}
.lm-promo-badge--soft{border-color:#d8e8f3;background:#eef6fb;color:#0c5585}
.lm-promo-summary__grid{display:flex;flex-direction:column;gap:8px;font-size:14px;line-height:1.4}
.lm-promo-summary__grid > div{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 12px;border:1px solid #edf2f7;border-radius:10px;background:#f8fbfd;color:#607080;font-size:12px;font-weight:800;letter-spacing:.03em;text-transform:uppercase}
.lm-promo-summary__grid strong{display:block;margin-left:auto;color:#13232f;font-size:15px;font-weight:800;text-align:right;letter-spacing:normal;text-transform:none}
.lm-promo-order-summary{margin:0 0 12px;padding:12px 14px;border:1px solid #d8e7f3;border-radius:12px;background:#f6fbff}
.lm-promo-order-summary__grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}
.lm-promo-inline__checkout-meta{margin-top:10px;background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px}
.lm-promo-order-summary__box{background:#fff;border:1px solid #e3edf5;border-radius:12px;padding:12px}
.lm-promo-order-summary__label{display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}
.lm-pay-methods{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin-top:12px}.lm-pay-method{border:1px solid #d5e3ee;border-radius:12px;padding:12px;background:#fff;cursor:pointer}.lm-pay-method.is-active{border-color:#0c5585;box-shadow:0 0 0 2px rgba(12,85,133,.08)}.lm-pay-method.is-disabled{opacity:.55;cursor:not-allowed;background:#fafcfe}.lm-pay-method__title{display:block;font-size:14px;font-weight:800;color:#13232f;margin-bottom:4px}.lm-pay-method__meta{display:block;font-size:12px;color:#607080;line-height:1.6}.lm-pay-method-note{margin-top:8px;color:#607080;font-size:12px;line-height:1.6}
@media (max-width:640px){.lm-batch-mini__grid{grid-template-columns:1fr}.lm-promo-order-summary__grid{grid-template-columns:1fr}.lm-promo-summary__grid > div{padding:10px}}
</style>
<div class="lm-public-wrap">
<div style="max-width:1080px;color:#13232f">
<?php if ($mode === 'summary'): ?>
  <div class="lm-public-hero">
    <span class="lm-public-hero__eyebrow">Shared multi-lead checkout</span>
    <h1 class="lm-public-hero__title">Shared Checkout Summary</h1>
    <p class="lm-public-hero__copy">Review your selected leads below, confirm the combined shared total, and create one secure checkout set for your buyer email. Exclusive access remains available only on individual lead pages.</p>
    <div class="lm-public-hero__actions">
      <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Return to Marketplace</a>
    </div>
  </div>
  <div class="lm-public-note"><strong>Shared checkout reminder</strong>Batch checkout is for shared lead access only. Use individual lead pages when you want to review or purchase exclusive access.</div>
  <?php if ($errorNotice !== ''): ?>
    <div style="<?php echo LeadMarketHelper::getBuyerNoticeBoxStyle($errorTone !== '' ? $errorTone : 'warn'); ?>"><strong>Checkout update.</strong> <?php echo htmlspecialchars($errorNotice, ENT_QUOTES, 'UTF-8'); ?></div>
  <?php endif; ?>
  <?php if ($eligibilityNotice !== ''): ?>
    <div style="<?php echo LeadMarketHelper::getBuyerNoticeBoxStyle('warn'); ?>"><?php echo htmlspecialchars($eligibilityNotice, ENT_QUOTES, 'UTF-8'); ?></div>
  <?php endif; ?>
  <?php if ($sessionNotice !== ''): ?>
    <div style="<?php echo LeadMarketHelper::getBuyerNoticeBoxStyle('warn'); ?>"><?php echo htmlspecialchars($sessionNotice, ENT_QUOTES, 'UTF-8'); ?></div>
  <?php endif; ?>
  <?php if ($repeatPurchaseNotice !== ''): ?>
    <div style="<?php echo LeadMarketHelper::getBuyerNoticeBoxStyle($repeatPurchaseTone !== '' ? $repeatPurchaseTone : 'warn'); ?>"><?php echo htmlspecialchars($repeatPurchaseNotice, ENT_QUOTES, 'UTF-8'); ?></div>
  <?php endif; ?>
  <div style="display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:18px;margin-top:18px;align-items:start">
    <div>
      <?php if (!$selection): ?>
        <div style="background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:20px;color:#50616d">No shared leads are selected right now. Please return to the marketplace and choose at least one lead.</div>
      <?php else: ?>
        <?php $sum=0; foreach ($selection as $row): $sum += (float)$row['price']; lmBuyerCardMini($row['lead'], $row['price']); endforeach; ?>
      <?php endif; ?>
    </div>
    <aside class="lm-public-panel lm-batch-aside">
      <h3 style="margin:0 0 8px;font-size:20px;color:#0c5585">Checkout set</h3>
      <p class="lm-batch-aside__helper">Shared-only batch checkout combines selected leads into one payment set. Exclusive access remains on individual lead pages.</p>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 12px">
        <div style="background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Selected leads</span><strong style="font-size:18px;color:#13232f"><?php echo count($selection); ?></strong></div>
        <div style="background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Estimated total</span><strong id="lmBatchEstimateTotal" style="font-size:18px;color:#13232f">$<?php echo number_format(isset($sum)?$sum:0,2,'.',''); ?></strong></div>
      </div>
      <?php if ($selection): ?>
      <?php $batchStartUrl = htmlspecialchars(JUri::root() . 'index.php', ENT_QUOTES, 'UTF-8'); ?>
      <?php $selectionIdsCsv = htmlspecialchars(implode(',', array_map(function($row){ return (int)($row['lead']['id'] ?? 0); }, $selection)), ENT_QUOTES, 'UTF-8'); ?>
      <?php $buyerAccessRequestUrl = htmlspecialchars(JUri::root() . 'index.php', ENT_QUOTES, 'UTF-8'); ?>
      <?php $buyerAccessReturn = htmlspecialchars('index.php?option=com_leadmarket&view=batch&selected=' . urlencode(implode(',', array_map(function($row){ return (int)($row['lead']['id'] ?? 0); }, $selection))) . ($buyerEmailValue !== '' ? '&buyer_email=' . urlencode($buyerEmailValue) : ''), ENT_QUOTES, 'UTF-8'); ?>
      <div id="lmBatchSummaryBox" class="lm-public-form" data-action="<?php echo $batchStartUrl; ?>" data-selected="<?php echo $selectionIdsCsv; ?>" data-token-name="<?php echo JSession::getFormToken(); ?>" data-subtotal="<?php echo htmlspecialchars(number_format(isset($sum)?$sum:0,2,'.',''), ENT_QUOTES, "UTF-8"); ?>">
        <label for="batch_buyer_email">Buyer email</label>
        <input id="batch_buyer_email" name="buyer_email" type="email" value="<?php echo htmlspecialchars($buyerEmailValue !== "" ? $buyerEmailValue : trim((string)(isset($_GET['buyer_email']) ? $_GET['buyer_email'] : "")), ENT_QUOTES, "UTF-8"); ?>" required>
        <div style="margin-top:10px;">
          <button type="button" id="lmBatchPromoToggle" style="background:none;border:0;padding:0;color:#0c5585;font-weight:700;text-decoration:underline;cursor:pointer;">Have a promo code?</button>
          <input type="hidden" id="batch_promo_code_hidden" name="promo_code" value="">
          <div id="lmBatchPromoPanel" class="lm-promo-inline" style="display:none;margin-top:10px;">
            <label class="lm-promo-inline__label" for="batch_promo_code">Promo code</label>
            <div class="lm-promo-inline__helper" style="margin-top:6px;margin-bottom:8px;">Apply a promo before creating the shared checkout.</div>
            <div class="lm-promo-inline__row">
              <input id="batch_promo_code" class="lm-promo-inline__input" type="text" value="" placeholder="Enter promo code">
              <button type="button" id="lmBatchApplyPromo" class="lm-promo-inline__apply lm-js-submit-state" data-loading-text="Applying...">Apply</button>
              <button type="button" id="lmBatchRemovePromo" class="lm-promo-inline__remove lm-hidden">Remove</button>
            </div>
            <div id="lmBatchPromoMessage" class="lm-promo-inline__status"></div>
            <div id="lmBatchPromoSummary" class="lm-promo-summary">
              <div class="lm-promo-summary__head">
                <span class="lm-promo-badge">Discount summary</span>
              </div>
              <div class="lm-promo-summary__grid">
                <div>Code<strong id="lmBatchPromoCodeText">—</strong></div>
                <div>Discount<strong id="lmBatchPromoDiscountText">$0.00</strong></div>
                <div>Final total<strong id="lmBatchPromoTotalText">$<?php echo number_format(isset($sum)?$sum:0,2,'.',''); ?></strong></div>
              </div>
            </div>
          </div>
          <div style="margin-top:10px;background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px;">
            <div style="display:flex;justify-content:space-between;gap:10px;font-size:14px;line-height:1.6;"><span>Subtotal</span><strong id="lmBatchSubtotal">$<?php echo number_format(isset($sum)?$sum:0,2,'.',''); ?></strong></div>
            <div id="lmBatchDiscountRow" class="lm-hidden" style="display:flex;justify-content:space-between;gap:10px;font-size:14px;line-height:1.6;margin-top:6px;"><span>Promo discount</span><strong id="lmBatchDiscount">$0.00</strong></div>
            <div style="display:flex;justify-content:space-between;gap:10px;font-size:15px;line-height:1.6;margin-top:6px;"><span>Final total</span><strong id="lmBatchFinalTotal">$<?php echo number_format(isset($sum)?$sum:0,2,'.',''); ?></strong></div>
          </div>
        </div>
        <div class="lm-public-form__actions"><button type="button" id="lmBatchSummarySubmit" class="lm-public-btn lm-public-btn--main" <?php echo $allSelectedAlreadyPurchased ? 'disabled="disabled"' : ''; ?> style="cursor:<?php echo $allSelectedAlreadyPurchased ? 'not-allowed' : 'pointer'; ?>;opacity:<?php echo $allSelectedAlreadyPurchased ? '.68' : '1'; ?>;"><?php echo $allSelectedAlreadyPurchased ? 'Already Purchased for This Email' : 'Create Shared Checkout'; ?></button></div>
      </div>
      <?php if ($buyerEmailValue !== '' && ($showResendAccess || $repeatPurchaseNotice !== '')): ?>
      <div class="lm-batch-inline-actions" style="margin-top:10px;">
        <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;">
          <?php echo JHtml::_('form.token'); ?>
          <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmailValue, ENT_QUOTES, 'UTF-8'); ?>">
          <input type="hidden" name="return_url" value="<?php echo $buyerAccessReturn; ?>">
          <button type="submit" class="lm-public-btn lm-public-btn--main">Send Buyer Access Link</button>
        </form>
        <?php if ($showResendAccess): ?>
        <button type="button" id="lmResendBatchLinks" class="lm-public-btn lm-public-btn--ghost" data-action="<?php echo $batchStartUrl; ?>" data-selected="<?php echo $selectionIdsCsv; ?>" data-email="<?php echo htmlspecialchars($buyerEmailValue, ENT_QUOTES, 'UTF-8'); ?>" data-token-name="<?php echo JSession::getFormToken(); ?>">Send Access Links Again</button>
        <?php endif; ?>
      </div>
      <?php endif; ?>
      <script>
      (function(){
        function submitDetached(action, fields){
          var form = document.createElement('form');
          form.method = 'post';
          form.action = action;
          form.style.display = 'none';
          Object.keys(fields).forEach(function(name){
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = fields[name];
            form.appendChild(input);
          });
          document.body.appendChild(form);
          form.submit();
        }
        function money(v){
          var n=parseFloat(v||0); if(!isFinite(n)) n=0; return '$'+n.toFixed(2);
        }
        function promoMessage(type, text){
          var box=document.getElementById('lmBatchPromoMessage');
          if(!box) return;
          box.className='lm-promo-inline__status';
          if(!text){ box.style.display='none'; box.textContent=''; return; }
          box.style.display='block'; box.textContent=text;
          if(type==='success'){ box.classList.add('lm-promo-inline__status--success'); }
          else if(type==='error'){ box.classList.add('lm-promo-inline__status--error'); }
          else { box.classList.add('lm-promo-inline__status--info'); }
        }
        function setBatchPromoPanelOpen(isOpen){
          var panel=document.getElementById('lmBatchPromoPanel');
          var toggle=document.getElementById('lmBatchPromoToggle');
          if(panel){ panel.style.display = isOpen ? 'block' : 'none'; }
          if(toggle){
            toggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
            toggle.textContent = isOpen ? 'Hide promo code' : 'Have a promo code?';
          }
        }
        function setBatchPromoUiApplied(isApplied){
          var input=document.getElementById('batch_promo_code');
          var remove=document.getElementById('lmBatchRemovePromo');
          if(input){ input.readOnly=!!isApplied; input.classList[isApplied ? 'add' : 'remove']('is-applied'); }
          if(remove){ remove.classList[isApplied ? 'remove' : 'add']('lm-hidden'); }
          if(isApplied){ setBatchPromoPanelOpen(true); }
        }
        function setBatchPromoSummary(data){
          var card=document.getElementById('lmBatchPromoSummary');
          var code=document.getElementById('lmBatchPromoCodeText');
          var discount=document.getElementById('lmBatchPromoDiscountText');
          var total=document.getElementById('lmBatchPromoTotalText');
          if(code) code.textContent=(data && data.promo_code) ? data.promo_code : '—';
          if(discount) discount.textContent=money((data && data.discount_amount) ? data.discount_amount : 0);
          if(total) total.textContent=money((data && data.final_total) ? data.final_total : 0);
          if(card) card.classList[(data && data.discount_amount) ? 'add' : 'remove']('is-visible');
          setBatchPromoUiApplied(!!(data && data.discount_amount));
        }
        function clearBatchPromo(message, collapsePanel){
          var hidden=document.getElementById('batch_promo_code_hidden');
          var remove=document.getElementById('lmBatchRemovePromo');
          var row=document.getElementById('lmBatchDiscountRow');
          var subtotal=document.getElementById('lmBatchSubtotal');
          var total=document.getElementById('lmBatchFinalTotal');
          var estimate=document.getElementById('lmBatchEstimateTotal');
          var box=document.getElementById('lmBatchSummaryBox');
          var summary=document.getElementById('lmBatchPromoSummary');
          var input=document.getElementById('batch_promo_code');
          if(hidden) hidden.value='';
          if(remove) remove.classList.add('lm-hidden');
          if(row) row.classList.add('lm-hidden');
          if(total && subtotal) total.textContent=subtotal.textContent;
          if(estimate && subtotal) estimate.textContent=subtotal.textContent;
          if(box){ box.setAttribute('data-final-total', box.getAttribute('data-subtotal') || '0'); box.setAttribute('data-discount','0'); }
          if(summary) summary.classList.remove('is-visible');
          if(input) input.value='';
          setBatchPromoUiApplied(false);
          if(collapsePanel){ setBatchPromoPanelOpen(false); }
          if(message) promoMessage('info', message); else promoMessage('', '');
        }
        var promoToggle = document.getElementById('lmBatchPromoToggle');
        if(promoToggle){
          promoToggle.addEventListener('click', function(){
            var panel=document.getElementById('lmBatchPromoPanel');
            var isOpen=!!(panel && panel.style.display !== 'none');
            setBatchPromoPanelOpen(!isOpen);
          });
        }
        var box = document.getElementById('lmBatchSummaryBox');
        var btn = document.getElementById('lmBatchSummarySubmit');
        var email = document.getElementById('batch_buyer_email');
        var codeInput = document.getElementById('batch_promo_code');
        var applyBtn = document.getElementById('lmBatchApplyPromo');
        var removeBtn = document.getElementById('lmBatchRemovePromo');
        if (box && btn && email) {
          btn.addEventListener('click', function(){
            var value = (email.value || '').trim();
            email.value = value;
            if (!value) { email.focus(); return; }
            btn.disabled = true;
            var old = btn.textContent;
            btn.textContent = 'Checking Selection...';
            var fields = {
              option: 'com_leadmarket',
              task: 'batchsummarysubmit',
              view: 'batch',
              selected_ids_csv: box.getAttribute('data-selected') || '',
              buyer_email: value,
              promo_code: (document.getElementById('batch_promo_code_hidden')||{}).value || ''
            };
            fields[box.getAttribute('data-token-name')] = '1';
            submitDetached(box.getAttribute('data-action'), fields);
            setTimeout(function(){ btn.disabled = false; btn.textContent = old; }, 4000);
          });
        }
        if(removeBtn){ removeBtn.addEventListener('click', function(){ clearBatchPromo('Promo removed.', true); }); }
        if(codeInput){ codeInput.addEventListener('keydown', function(e){ if(e.key==='Enter'){ e.preventDefault(); if(applyBtn && !applyBtn.disabled){ applyBtn.click(); } } }); }
        if(applyBtn && codeInput && box){
          applyBtn.addEventListener('click', function(){
            var buyer=email ? (email.value||'').trim() : '';
            var code=(codeInput.value||'').trim();
            if(!code){ codeInput.focus(); promoMessage('error', 'Enter a promo code.'); return; }
            var fd=new FormData();
            fd.append('option','com_leadmarket');
            fd.append('task','applypromo');
            fd.append('context_type','batch');
            fd.append('selected_ids_csv', box.getAttribute('data-selected') || '');
            fd.append('buyer_email', buyer);
            fd.append('promo_code', code);
            fd.append(box.getAttribute('data-token-name'), '1');
            var old=applyBtn.textContent;
            applyBtn.disabled=true;
            applyBtn.classList.add('is-loading');
            applyBtn.textContent='Applying...';
            fetch('<?php echo JRoute::_("index.php?option=com_leadmarket&task=applypromo", false); ?>', {method:'POST', body:fd, credentials:'same-origin', headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}})
              .then(function(r){ return r.json(); })
              .then(function(data){
                if(data && data.ok){
                  var hidden=document.getElementById('batch_promo_code_hidden');
                  var row=document.getElementById('lmBatchDiscountRow');
                  var discount=document.getElementById('lmBatchDiscount');
                  var total=document.getElementById('lmBatchFinalTotal');
                  if(hidden) hidden.value=data.promo_code || '';
                  if(row) row.classList.remove('lm-hidden');
                  if(discount) discount.textContent=money(data.discount_amount || 0);
                  if(total) total.textContent=money(data.final_total || 0);
                  var estimate=document.getElementById('lmBatchEstimateTotal'); if(estimate) estimate.textContent=money(data.final_total || 0);
                  box.setAttribute('data-final-total', String(data.final_total || 0));
                  box.setAttribute('data-discount', String(data.discount_amount || 0));
                  setBatchPromoSummary(data);
                  promoMessage('success', data.message || 'Discount added.');
                }else{
                  clearBatchPromo();
                  promoMessage('error', (data && data.message) ? data.message : 'Promo code could not be applied.');
                }
              })
              .catch(function(){ promoMessage('error', 'Connection error. Please try again.'); })
              .finally(function(){ applyBtn.disabled=false; applyBtn.classList.remove('is-loading'); applyBtn.textContent=old; });
          });
        }
        var resend = document.getElementById('lmResendBatchLinks');
        if (resend) {
          resend.addEventListener('click', function(){
            var fields = {
              option: 'com_leadmarket',
              task: 'resendbatchaccesslinks',
              view: 'batch',
              selected_ids_csv: resend.getAttribute('data-selected') || '',
              buyer_email: resend.getAttribute('data-email') || ''
            };
            fields[resend.getAttribute('data-token-name')] = '1';
            submitDetached(resend.getAttribute('data-action'), fields);
          });
        }
      })();
      </script>
      <div style="margin-top:10px;color:#607080;font-size:12px;line-height:1.6">Enter the buyer email and continue. If all selected leads are already available for this email, the summary will stay here and show a clear notice.</div>
      <?php endif; ?>
    </aside>
  </div>
<?php else: ?>
  <?php if ($this->accessDenied): ?>
    <div style="background:#fff;border:1px solid #f0d2d2;border-radius:16px;padding:20px;color:#6a2a2a">Access denied. This shared checkout requires a valid secure token. If the direct link expired, request a fresh buyer access link and reopen the batch from there.</div>
  <?php else: ?>
    <?php $status = strtolower((string)($batch['status'] ?? 'pending')); $paymentStatus = strtolower((string)($batch['payment_status'] ?? 'unverified')); $secureBatchUrl = LeadMarketHelper::buildAbsoluteBatchUrl((int)$batch['id'], LeadMarketHelper::ensureBatchToken($batch)); $batchBuyerEmail = LeadMarketHelper::normalizeEmail((string) ($batch['buyer_email'] ?? '')); $batchUnlockSummary = LeadMarketHelper::getBatchUnlockSummary((int) $batch['id'], $batchBuyerEmail); $buyerAccessUrl = LeadMarketHelper::getBuyerAccessActionAbsoluteUrl((string) ($batch['buyer_email'] ?? '')); ?>
    <?php $statusLabel = LeadMarketHelper::getBuyerCheckoutStatusLabel($status, $paymentStatus); $statusBadgeStyle = LeadMarketHelper::getBuyerCheckoutBadgeStyle($status, $paymentStatus); $statusNotice = LeadMarketHelper::getBuyerCheckoutNotice($status, $paymentStatus, 'batch'); ?>
    <div class="lm-public-hero">
      <span class="lm-public-hero__eyebrow">Secure shared access</span>
      <h1 class="lm-public-hero__title">Shared Batch Checkout</h1>
      <p class="lm-public-hero__copy">Complete one shared payment to unlock all selected leads in this secure checkout set. Availability is rechecked before final confirmation and access is released only after payment is approved.</p>
      <div class="lm-public-hero__actions">
        <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Return to Marketplace</a>
      </div>
    </div>
    <div class="lm-public-note"><strong>Secure checkout flow</strong>This batch view keeps shared access, payment instructions, and secure order context together in one place so buyers can complete checkout without losing their selected set.</div>
    <?php if ($sessionNotice !== ''): ?>
      <div style="<?php echo LeadMarketHelper::getBuyerNoticeBoxStyle('warn'); ?>"><?php echo htmlspecialchars($sessionNotice, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>
    <div style="display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:18px;align-items:start">
      <div>
        <?php foreach ($items as $item): lmBuyerCardMini($item, (float)$item['amount_usd']); endforeach; ?>
      </div>
      <aside class="lm-public-panel lm-batch-aside">
        <h3 style="margin:0 0 8px;font-size:20px;color:#0c5585">Checkout status</h3>
        <p style="margin:0 0 12px;color:#51626d;line-height:1.7;font-size:14px">Batch ID <b><?php echo (int)$batch['id']; ?></b> for <b><?php echo htmlspecialchars((string)$batch['buyer_email'],ENT_QUOTES,'UTF-8'); ?></b>.</p>
        <div style="<?php echo $statusBadgeStyle; ?>">Status: <?php echo htmlspecialchars($statusLabel, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php if ($statusNotice): ?>
          <div style="<?php echo LeadMarketHelper::getBuyerNoticeBoxStyle($statusNotice['tone']); ?>"><strong><?php echo htmlspecialchars($statusNotice['title'], ENT_QUOTES, 'UTF-8'); ?>.</strong> <?php echo htmlspecialchars($statusNotice['body'], ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <?php if ($status === 'paid'): ?>
          <div style="margin:0 0 12px;padding:12px;border-radius:12px;background:#eefaf0;border:1px solid #cfe5d4;color:#1f6b35;line-height:1.6;">
            Shared batch unlocked. <b><?php echo (int) ($batchUnlockSummary['unlocked_count'] ?? count($items)); ?></b> of <b><?php echo (int) ($batchUnlockSummary['total_count'] ?? count($items)); ?></b> selected leads are ready below.
            <?php if (isset($batch['balance_after_purchase_usd']) && $batch['balance_after_purchase_usd'] !== null && $batch['balance_after_purchase_usd'] !== ''): ?>Final wallet balance: <b>$<?php echo htmlspecialchars(number_format((float) $batch['balance_after_purchase_usd'], 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>.<?php endif; ?>
          </div>
          <?php $hasBatchPromoSummary = (!empty($batch['promo_code']) || (float) ($batch['promo_discount_amount'] ?? 0) > 0); ?>
          <?php if ($hasBatchPromoSummary): ?>
            <?php
              $batchPromoSubtotal = (float) ($batch['subtotal_before_discount'] ?? ($batch['amount_usd'] ?? 0));
              $batchPromoDiscount = (float) ($batch['promo_discount_amount'] ?? 0);
              $batchPromoFinal = (float) ($batch['total_after_discount'] ?? ($batch['amount_usd'] ?? 0));
            ?>
            <div class="lm-promo-order-summary">
              <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 8px;">
                <span class="lm-promo-badge">Discount summary</span>
                <span class="lm-promo-badge lm-promo-badge--soft">Saved on this batch</span>
              </div>
              <div style="font-weight:800;color:#14384f;">Promo code <b><?php echo htmlspecialchars((string) ($batch['promo_code'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></b> adjusted the batch total.</div>
              <div class="lm-promo-order-summary__grid">
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Subtotal</span><strong>$<?php echo htmlspecialchars(number_format($batchPromoSubtotal, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Discount</span><strong>-$<?php echo htmlspecialchars(number_format($batchPromoDiscount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Final total</span><strong>$<?php echo htmlspecialchars(number_format($batchPromoFinal, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Promo record</span><strong>Stored in batch details</strong></div>
              </div>
            </div>
          <?php endif; ?>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 12px">
            <div style="background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Unlocked leads</span><strong style="font-size:18px;color:#13232f"><?php echo (int) ($batchUnlockSummary['unlocked_count'] ?? count($items)); ?>/<?php echo (int) ($batchUnlockSummary['total_count'] ?? count($items)); ?></strong></div>
            <div style="background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Paid at</span><strong style="font-size:18px;color:#13232f"><?php echo htmlspecialchars((string) ($batch['paid_at_utc'] ?? $batch['payment_confirmed_utc'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></strong></div>
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;margin:0 0 14px;">
            <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($secureBatchUrl, ENT_QUOTES, 'UTF-8'); ?>">Open unlocked batch</a>
            <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Opening buyer dashboard..." href="<?php echo htmlspecialchars($buyerAccessUrl, ENT_QUOTES, 'UTF-8'); ?>">Open buyer access</a>
          </div>
          <?php $paidBatchItems = array(); foreach ($items as $__batchItem) { if (strtolower((string) ($__batchItem['status'] ?? '')) === 'paid' && strtolower((string) ($__batchItem['payment_status'] ?? '')) === 'confirmed') $paidBatchItems[] = $__batchItem; } unset($__batchItem); ?>
          <?php
            $creditWindowHours = (int) LeadMarketHelper::creditRequestWindowHours();
            $creditReasonOptions = LeadMarketHelper::getCreditRequestReasonOptions();
            $batchBuyerToken = '';
            $rememberedBuyerToken = LeadMarketHelper::getRememberedBuyerAccessToken();
            if ($rememberedBuyerToken !== '') {
              $rememberedAccess = LeadMarketHelper::validateBuyerAccessToken($rememberedBuyerToken);
              if (!empty($rememberedAccess['buyer_email']) && LeadMarketHelper::normalizeBuyerEmail((string) $rememberedAccess['buyer_email']) === LeadMarketHelper::normalizeBuyerEmail($batchBuyerEmail)) {
                $batchBuyerToken = $rememberedBuyerToken;
              }
            }
            $paidBatchOrderIds = array(); foreach ($paidBatchItems as $__paidBatchItem) { $paidBatchOrderIds[] = (int) ($__paidBatchItem['id'] ?? 0); } unset($__paidBatchItem);
            $paidBatchCreditMap = LeadMarketHelper::getBuyerCreditRequestMap($paidBatchOrderIds, $batchBuyerEmail);
            $batchReturnUrl = JUri::getInstance()->toString();
          ?>
          <?php if ($paidBatchItems): ?>
          <div class="lm-batch-status-actions">
            <div class="lm-batch-status-actions__title">Lead actions</div>
            <?php foreach ($paidBatchItems as $item): ?>
              <?php
                $itemId = (int) ($item['id'] ?? 0);
                $itemLeadUrl = JRoute::_(LeadMarketHelper::buildLeadUrl((int)$item['lead_id'], $itemId, LeadMarketHelper::ensureOrderToken($item)), false);
                $itemCreditMeta = (array) ($paidBatchCreditMap[$itemId] ?? array());
                $itemHasCreditMeta = !empty($itemCreditMeta);
                $itemCreditTarget = 'batch-credit-box-' . $itemId;
                $itemCreditFallbackUrl = JRoute::_('index.php?option=com_leadmarket&view=batch&id=' . (int) $batch['id'] . '&token=' . urlencode($token) . '&show_credit_order=' . $itemId . '#batch-credit-box-' . $itemId, false);
              ?>
              <div class="lm-batch-status-row">
                <div>
                  <div style="font-weight:800;color:#13232f;"><?php echo htmlspecialchars(LeadMarketHelper::formatLeadTitle($item),ENT_QUOTES,'UTF-8'); ?></div>
                  <div class="lm-batch-status-row__meta">Open the paid lead or request a credit review.</div>
                </div>
                <div class="lm-batch-status-row__actions">
                  <a class="lm-public-btn lm-public-btn--ghost" rel="nofollow" href="<?php echo htmlspecialchars($itemLeadUrl,ENT_QUOTES,'UTF-8'); ?>">Open lead</a>
                  <?php if ($batchBuyerToken !== ''): ?>
                    <a class="lm-public-btn lm-public-btn--ghost lm-js-batch-credit-link" rel="nofollow" href="<?php echo htmlspecialchars($itemCreditFallbackUrl, ENT_QUOTES, 'UTF-8'); ?>" data-target="<?php echo htmlspecialchars($itemCreditTarget, ENT_QUOTES, 'UTF-8'); ?>">Request credit</a>
                  <?php else: ?>
                    <a class="lm-public-btn lm-public-btn--ghost" rel="nofollow" href="<?php echo htmlspecialchars($itemCreditFallbackUrl, ENT_QUOTES, 'UTF-8'); ?>">Request credit</a>
                  <?php endif; ?>
                </div>
              </div>
              <?php if ($batchBuyerToken !== ''): ?>
              <div class="lm-batch-credit-box" id="<?php echo htmlspecialchars($itemCreditTarget, ENT_QUOTES, 'UTF-8'); ?>"<?php echo ((int) $showCreditOrder === (int) $itemId) ? '' : ' hidden'; ?>>
                <div class="lm-batch-credit-box__summary">
                  <div class="lm-batch-credit-box__title">Lead review / credit request</div>
                  <div class="lm-batch-credit-box__hint">Opens only when needed</div>
                </div>
                <p class="lm-batch-credit-box__copy">Use this only for verified data-quality issues. The review window is limited to <?php echo (int) $creditWindowHours; ?> hours after purchase.</p>
                <?php if (!empty($itemCreditMeta['existing'])): ?>
                  <?php $req = $itemCreditMeta['existing']; $reqStatus = $itemCreditMeta['status_meta'] ?? array('label' => 'Submitted', 'tone' => 'warn'); ?>
                  <div class="lm-credit-status">
                    <span class="<?php echo lmBuyerBadgeClass($reqStatus['tone'] ?? 'warn'); ?>"><?php echo htmlspecialchars((string) ($reqStatus['label'] ?? 'Submitted'), ENT_QUOTES, 'UTF-8'); ?></span>
                    <div class="lm-buyer-note" style="margin-top:8px;">Reason: <?php echo htmlspecialchars(lmBuyerCreditReasonLabel((string) ($req['reason_code'] ?? ''), $creditReasonOptions), ENT_QUOTES, 'UTF-8'); ?><?php if ((string) ($req['status'] ?? '') === 'approved' && (float) ($req['approved_amount'] ?? 0) > 0): ?> · Approved — $<?php echo htmlspecialchars(number_format((float) ($req['approved_amount'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> credited to your balance<?php endif; ?></div>
                    <?php if (!empty($req['buyer_note'])): ?><div class="lm-buyer-note">Your note: <?php echo nl2br(htmlspecialchars((string) $req['buyer_note'], ENT_QUOTES, 'UTF-8')); ?></div><?php endif; ?>
                    <?php if (!empty($req['admin_note']) && (string) ($req['status'] ?? '') === 'declined'): ?><div class="lm-buyer-note">Review note: <?php echo nl2br(htmlspecialchars((string) $req['admin_note'], ENT_QUOTES, 'UTF-8')); ?></div><?php endif; ?>
                  </div>
                <?php elseif (!empty($itemCreditMeta['can_request'])): ?>
                  <form class="lm-buyer-form lm-js-credit-submit-form" action="<?php echo htmlspecialchars($batchReturnUrl, ENT_QUOTES, 'UTF-8'); ?>" method="post">
                    <?php echo JHtml::_('form.token'); ?>
                    <input type="hidden" name="lm_inline_credit_submit" value="1">
                    <input type="hidden" name="buyer_token" value="<?php echo htmlspecialchars($batchBuyerToken, ENT_QUOTES, 'UTF-8'); ?>">
                    <input type="hidden" name="order_id" value="<?php echo $itemId; ?>">
                    <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($batchReturnUrl . '#'.$itemCreditTarget, ENT_QUOTES, 'UTF-8'); ?>">
                    <label for="batch-credit-reason-<?php echo $itemId; ?>">Reason</label>
                    <select id="batch-credit-reason-<?php echo $itemId; ?>" name="reason_code" required>
                      <?php foreach ($creditReasonOptions as $reasonCode => $reasonLabel): ?>
                        <option value="<?php echo htmlspecialchars($reasonCode, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars($reasonLabel, ENT_QUOTES, 'UTF-8'); ?></option>
                      <?php endforeach; ?>
                    </select>
                    <label for="batch-credit-note-<?php echo $itemId; ?>">Comment</label>
                    <textarea id="batch-credit-note-<?php echo $itemId; ?>" name="buyer_note" rows="3" placeholder="Add a short explanation for the review team."></textarea>
                    <div class="lm-public-actions" style="margin-top:10px;">
                      <button type="submit" class="lm-public-btn lm-public-btn--ghost">Request Credit</button>
                    </div>
                  </form>
                <?php else: ?>
                  <div class="lm-buyer-note"><?php echo htmlspecialchars((string) ($itemHasCreditMeta ? ($itemCreditMeta['message'] ?? ('Review window closed. Credit requests must be submitted within ' . (int) $creditWindowHours . ' hours of purchase.')) : 'Review availability is loading. Refresh and try again.'), ENT_QUOTES, 'UTF-8'); ?></div>
                <?php endif; ?>
              </div>
              <?php endif; ?>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>
        <?php else: ?>
          <?php
            $batchPricing = LeadMarketHelper::getBatchPricingForBuyer((int) $batch['id'], $batchBuyerEmail);
            $batchTotalUsd = (float) ($batchPricing['recalculated_total_usd'] ?? ($batch['amount_usd'] ?? 0));
            $batchCurrentBalance = LeadMarketHelper::getBuyerBalance($batchBuyerEmail);
            $batchRoute = LeadMarketHelper::determinePurchaseRoute('batch', (int) $batch['id'], $batchBuyerEmail);
            $batchTopupOptions = !empty($batchRoute['suggested_topups']) ? (array) $batchRoute['suggested_topups'] : LeadMarketHelper::getSuggestedTopupOptions($batchTotalUsd, $batchCurrentBalance, 'batch');
            $batchSuggestedTopup = (float) ($batchTopupOptions['recommended_amount'] ?? LeadMarketHelper::calculateSuggestedTopup($batchTotalUsd, $batchCurrentBalance));
            $batchPaymentType = strtolower((string) ($batch['payment_type'] ?? 'direct'));
            $routeKey = (string) ($batchRoute['route'] ?? 'topup_required');
            $minimumTransfer = (float) LeadMarketHelper::minimumTopupUsd();
            $batchAppliedFromWallet = (float) ($batchRoute['applied_from_balance'] ?? LeadMarketHelper::calculateAppliedFromWallet($batchTotalUsd, $batchCurrentBalance));
            $batchRemainingShortage = (float) ($batchRoute['amount_needed'] ?? LeadMarketHelper::calculateWalletShortage($batchTotalUsd, $batchCurrentBalance));
            $batchWalletLeftAfterUnlock = max(0, $batchCurrentBalance - $batchTotalUsd);
            $batchRecommendedTopup = max((float) $minimumTransfer, (float) $batchSuggestedTopup);
            $batchUsedFromTopup = max(0, min((float) $batchRecommendedTopup, (float) $batchRemainingShortage));
            $batchWalletLeftAfterRecommendedTopup = max(0, LeadMarketHelper::roundMoney($batchCurrentBalance + $batchRecommendedTopup - $batchTotalUsd));
            $batchExactTransferAmount = (float) ($batch['expected_amount'] ?? 0);
            if ($batchExactTransferAmount <= 0 && $routeKey === 'direct_or_topup') {
              $batchExactTransferAmount = $batchRemainingShortage;
            }
            $batchAdjustmentRequested = (int) ($batchAdjustmentData['requested_count'] ?? 0);
            $batchAdjustmentRemoved = (int) ($batchAdjustmentData['removed_count'] ?? 0);
            $batchIncludedPreview = !empty($batchAdjustmentData['included_preview']) ? (array) $batchAdjustmentData['included_preview'] : array();
            if (!$batchIncludedPreview) {
              foreach ($items as $item) {
                $batchIncludedPreview[] = array(
                  'lead_id' => (int) ($item['lead_id'] ?? 0),
                  'title' => LeadMarketHelper::formatLeadTitle($item),
                  'location' => trim((string) ($item['city'] ?? '') . ', ' . (string) ($item['state'] ?? '') . ' ' . (string) ($item['zip'] ?? '')),
                  'price_usd' => (float) ($item['amount_usd'] ?? 0),
                );
              }
            }
            $batchRemovedPreview = !empty($batchAdjustmentData['removed_preview']) ? (array) $batchAdjustmentData['removed_preview'] : array();
            $batchFinalCount = (int) ($batchPricing['remaining_count'] ?: count($items));
            $batchRequestedEligibleTotal = (float) ($batchAdjustmentData['requested_eligible_total_usd'] ?? $batchTotalUsd);
            $batchBalanceBeforeDisplay = array_key_exists('buyer_balance_before_usd', $batchAdjustmentData) ? (float) $batchAdjustmentData['buyer_balance_before_usd'] : $batchCurrentBalance;
          ?>
          <?php if ($batchAdjustmentRequested > 0): ?>
          <div style="margin:0 0 12px;padding:14px;border-radius:14px;background:#f8fbfd;border:1px solid #dbe6ef;">
            <div style="font-size:18px;font-weight:800;color:#0c5585;margin:0 0 10px;">Selection adjustment</div>
            <div style="display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:10px;">
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Initially selected</span><strong style="font-size:18px;color:#13232f"><?php echo (int) $batchAdjustmentRequested; ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Removed</span><strong style="font-size:18px;color:#13232f"><?php echo (int) $batchAdjustmentRemoved; ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Remaining</span><strong style="font-size:18px;color:#13232f"><?php echo (int) $batchFinalCount; ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Already purchased</span><strong style="font-size:18px;color:#13232f"><?php echo (int) ($batchAdjustmentData['already_purchased_count'] ?? 0); ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Active checkout</span><strong style="font-size:18px;color:#13232f"><?php echo (int) ($batchAdjustmentData['active_checkout_count'] ?? 0); ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Final eligible total</span><strong style="font-size:18px;color:#13232f">$<?php echo htmlspecialchars(number_format((float) $batchTotalUsd, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
            </div>
            <?php if ($batchAdjustmentRemoved > 0): ?>
            <div style="margin-top:10px;color:#44545e;line-height:1.6;">This batch was rechecked before payment.</div>
            <?php endif; ?>
          </div>
          <?php endif; ?>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:0 0 12px;align-items:start;">
            <div style="border:1px solid #dbe6ef;border-radius:14px;padding:14px;background:#fff;">
              <div style="font-size:18px;font-weight:800;color:#0c5585;margin:0 0 10px;">Included in this checkout</div>
              <?php if ($batchIncludedPreview): ?>
                <?php foreach ($batchIncludedPreview as $entry): ?>
                  <div style="padding:10px 0;border-top:1px solid #edf2f7;<?php echo $entry === reset($batchIncludedPreview) ? 'border-top:0;padding-top:0;' : ''; ?>">
                    <div style="font-weight:800;color:#13232f"><?php echo htmlspecialchars((string) ($entry['title'] ?? 'Lead'), ENT_QUOTES, 'UTF-8'); ?></div>
                    <div style="color:#61717f;line-height:1.6;font-size:13px;"><?php echo htmlspecialchars(trim((string) ($entry['location'] ?? '')), ENT_QUOTES, 'UTF-8'); ?></div>
                    <div style="color:#0c5585;font-weight:700;font-size:13px;">$<?php echo htmlspecialchars(number_format((float) ($entry['price_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div style="color:#61717f;">No eligible leads remain in this checkout.</div>
              <?php endif; ?>
            </div>
            <div style="border:1px solid #dbe6ef;border-radius:14px;padding:14px;background:#fff;">
              <div style="font-size:18px;font-weight:800;color:#0c5585;margin:0 0 10px;">Removed from this checkout</div>
              <?php if ($batchRemovedPreview): ?>
                <?php foreach ($batchRemovedPreview as $entry): ?>
                  <div style="padding:10px 0;border-top:1px solid #edf2f7;<?php echo $entry === reset($batchRemovedPreview) ? 'border-top:0;padding-top:0;' : ''; ?>">
                    <div style="font-weight:800;color:#13232f"><?php echo htmlspecialchars((string) ($entry['title'] ?? 'Lead'), ENT_QUOTES, 'UTF-8'); ?></div>
                    <?php if (!empty($entry['location'])): ?><div style="color:#61717f;line-height:1.6;font-size:13px;"><?php echo htmlspecialchars(trim((string) $entry['location']), ENT_QUOTES, 'UTF-8'); ?></div><?php endif; ?>
                    <div style="color:#7a5c1e;font-weight:700;font-size:13px;"><?php echo htmlspecialchars((string) ($entry['reason'] ?? 'Removed during checkout recheck.'), ENT_QUOTES, 'UTF-8'); ?></div>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <div style="color:#61717f;">No leads were removed during the final recheck.</div>
              <?php endif; ?>
            </div>
          </div>

          <div style="border:1px solid #dbe6ef;border-radius:14px;padding:14px;background:#f8fbfd;margin:0 0 12px;">
            <div style="font-size:18px;font-weight:800;color:#0c5585;margin:0 0 10px;">Batch summary</div>
            <div style="display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;">
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Final batch value</span><strong style="font-size:18px;color:#13232f">$<?php echo htmlspecialchars(number_format((float) $batchTotalUsd, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Wallet balance before</span><strong style="font-size:18px;color:#13232f">$<?php echo htmlspecialchars(number_format((float) $batchBalanceBeforeDisplay, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Applied from wallet</span><strong style="font-size:18px;color:#13232f">$<?php echo htmlspecialchars(number_format((float) $batchAppliedFromWallet, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Remaining shortage</span><strong style="font-size:18px;color:#13232f">$<?php echo htmlspecialchars(number_format((float) $batchRemainingShortage, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
              <div style="background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:12px"><span style="display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px">Wallet left after unlock</span><strong style="font-size:18px;color:#13232f">$<?php echo htmlspecialchars(number_format((float) $batchWalletLeftAfterUnlock, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
            </div>
            <?php if ($routeKey === 'direct_or_topup'): ?>
              <div style="margin-top:10px;padding:12px;border-radius:12px;background:#fff;border:1px solid #edf2f7;color:#13232f;line-height:1.6;">
                <b>Pay now:</b> $<?php echo htmlspecialchars(number_format((float) $batchExactTransferAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?>.
                <?php if ($batchAppliedFromWallet > 0): ?> Wallet is used first.<?php else: ?> This is the exact amount to send.<?php endif; ?>
              </div>
            <?php elseif ($routeKey === 'topup_required'): ?>
              <div style="margin-top:10px;padding:12px;border-radius:12px;background:#fff;border:1px solid #edf2f7;color:#13232f;line-height:1.6;">
                <div style="font-weight:800;margin:0 0 8px;color:#0c5585;">Payment plan for this batch</div>
                <div><b>Remaining for this batch:</b> $<?php echo htmlspecialchars(number_format((float) $batchRemainingShortage, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
                <div><b>Recommended top-up now:</b> $<?php echo htmlspecialchars(number_format((float) $batchRecommendedTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b></div>
                <div><b>Used for this batch:</b> $<?php echo htmlspecialchars(number_format((float) $batchUsedFromTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b></div>
                <div><b>Wallet left after unlock:</b> $<?php echo htmlspecialchars(number_format((float) $batchWalletLeftAfterRecommendedTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b></div>
              </div>
            <?php endif; ?>
          </div>

          <?php if ($routeKey === 'balance_only'): ?>
            <div style="margin:0 0 12px;padding:12px;border-radius:12px;background:#eefaf0;border:1px solid #cfe5d4;color:#1f6b35;line-height:1.6;">Wallet covers this batch. No transfer is needed.</div>
            <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=batchunlockbalance'); ?>" method="post" style="margin:0 0 10px;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="batch_id" value="<?php echo (int)$batch['id']; ?>">
              <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
              <button type="submit" style="display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent;cursor:pointer;background:#1f6b35;color:#fff;width:100%;">Unlock Batch Using Balance</button>
            </form>
          <?php elseif ($routeKey === 'already_unlocked'): ?>
            <div style="margin:0 0 12px;padding:12px;border-radius:12px;background:#eefaf0;border:1px solid #cfe5d4;color:#1f6b35;line-height:1.6;">This batch is already unlocked for this buyer email.</div>
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin:0 0 12px;">
              <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($secureBatchUrl, ENT_QUOTES, 'UTF-8'); ?>">Open unlocked batch</a>
              <a class="lm-public-btn lm-public-btn--ghost lm-js-open-state" data-loading-text="Opening buyer dashboard..." href="<?php echo htmlspecialchars($buyerAccessUrl, ENT_QUOTES, 'UTF-8'); ?>">Open buyer access</a>
            </div>
          <?php elseif ($routeKey === 'topup_required'): ?>
            <div style="margin:0 0 12px;padding:12px;border-radius:12px;background:#fff8ef;border:1px solid #eadfc7;color:#7a5c1e;line-height:1.6;">
              <?php if ($batchRemainingShortage < $minimumTransfer): ?>
                Your wallet is used first. The remaining amount is below the <b>$<?php echo htmlspecialchars(number_format((float) $minimumTransfer, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b> minimum, so this batch continues through a linked top-up.
              <?php else: ?>
                Your wallet is used first. This batch continues through a linked top-up.
              <?php endif; ?>
              <div style="margin-top:6px;">The extra balance stays in your wallet for the next purchase.</div>
            </div>
            <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=batchcreatelinkedtopup'); ?>" method="post" style="margin:0 0 10px;" id="lmBatchFundingForm">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="batch_id" value="<?php echo (int)$batch['id']; ?>">
              <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
              <input type="hidden" name="payment_method" id="lm_batch_payment_method" value="crypto">
              <div style="display:flex;gap:8px;flex-wrap:wrap;margin:0 0 10px;">
                <?php foreach ((array) ($batchTopupOptions['presets'] ?? array()) as $preset): $amount = (float) (is_array($preset) ? ($preset['amount'] ?? 0) : $preset); ?>
                  <button type="button" class="lm-topup-preset" data-target="#lm_batch_topup_amount" data-amount="<?php echo htmlspecialchars(number_format($amount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">$<?php echo htmlspecialchars(number_format($amount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></button>
                <?php endforeach; ?>
              </div>
              <label style="display:block;margin:0 0 6px;font-weight:700;" for="lm_batch_topup_amount">Recommended top-up (USD)</label>
              <input id="lm_batch_topup_amount" name="topup_amount_usd" type="number" step="0.01" min="<?php echo htmlspecialchars(number_format(LeadMarketHelper::topupCustomMinimumUsd(), 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" value="<?php echo htmlspecialchars(number_format((float) $batchRecommendedTopup, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" <?php echo !LeadMarketHelper::isCustomTopupAllowed() ? 'readonly="readonly"' : ''; ?> style="display:block;width:100%;max-width:280px;min-height:46px;padding:0 14px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
              <details style="margin-top:8px;color:#607080;font-size:12px;"><summary style="cursor:pointer;">Why this amount?</summary><div style="margin-top:6px;line-height:1.6;">Used for this batch: <b>$<?php echo htmlspecialchars(number_format((float) $batchUsedFromTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>.<br>Left in wallet after unlock: <b>$<?php echo htmlspecialchars(number_format((float) $batchWalletLeftAfterRecommendedTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>.</div></details>
              <div class="lm-pay-methods" id="lmBatchFundingMethods">
                <button type="button" class="lm-pay-method is-active" data-method="crypto"><span class="lm-pay-method__title">Crypto</span><span class="lm-pay-method__meta">Use the current secure crypto top-up flow.</span></button>
                <button type="button" class="lm-pay-method" data-method="moneygram" data-min="<?php echo htmlspecialchars(number_format(LeadMarketHelper::moneygramMinimumUsd(), 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"><span class="lm-pay-method__title">Western Union</span><span class="lm-pay-method__meta">Manual wallet top-up. Visible always, active from $<?php echo htmlspecialchars(number_format(LeadMarketHelper::moneygramMinimumUsd(), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?>.</span></button>
              </div>
              <div class="lm-pay-method-note" id="lmBatchFundingNote">Crypto is selected. Western Union becomes available once the top-up amount reaches $<?php echo htmlspecialchars(number_format(LeadMarketHelper::moneygramMinimumUsd(), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?>.</div>
              <button type="submit" id="lmBatchFundingSubmit" style="display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent;cursor:pointer;background:#0c5585;color:#fff;width:100%;margin-top:10px;">Create linked top-up</button>
            </form>
            <script>
            (function(){
              var input=document.getElementById('lm_batch_topup_amount');
              var hidden=document.getElementById('lm_batch_payment_method');
              var note=document.getElementById('lmBatchFundingNote');
              var submit=document.getElementById('lmBatchFundingSubmit');
              function syncBatchFunding(){
                var amount=input?parseFloat(input.value||'0'):0;
                if(!isFinite(amount)) amount=0;
                var selected=hidden&&hidden.value?hidden.value:'crypto';
                document.querySelectorAll('#lmBatchFundingMethods .lm-pay-method').forEach(function(card){
                  var method=card.getAttribute('data-method')||'crypto';
                  var min=parseFloat(card.getAttribute('data-min')||'0');
                  var allowed=(method!=='moneygram') || amount>=min;
                  if(method===selected && !allowed){ selected='crypto'; if(hidden) hidden.value='crypto'; }
                  card.classList.toggle('is-disabled', !allowed);
                  card.classList.toggle('is-active', method===selected && allowed);
                });
                if(note){
                  var mgMin=<?php echo json_encode((float) LeadMarketHelper::moneygramMinimumUsd()); ?>;
                  if(hidden && hidden.value==='moneygram' && amount>=mgMin) note.textContent='Western Union is selected. The checkout summary stays the same; after submit, the secure request page will show receiver details and the MTCN / reference form.';
                  else if(amount<mgMin) note.textContent='Crypto is selected. Western Union stays visible but activates only from $'+mgMin.toFixed(2)+'.';
                  else note.textContent='Crypto is selected. You can switch to Western Union for a manual top-up if you prefer.';
                }
                if(submit){ submit.textContent=(hidden && hidden.value==='moneygram') ? 'Create Western Union request' : 'Create linked top-up'; }
              }
              document.querySelectorAll('#lmBatchFundingMethods .lm-pay-method').forEach(function(card){
                card.addEventListener('click', function(){
                  if(!hidden) return;
                  var method=card.getAttribute('data-method')||'crypto';
                  var min=parseFloat(card.getAttribute('data-min')||'0');
                  var amount=input?parseFloat(input.value||'0'):0;
                  if(method==='moneygram' && amount<min){ syncBatchFunding(); return; }
                  hidden.value=method; syncBatchFunding();
                });
              });
              document.querySelectorAll('.lm-topup-preset[data-target="#lm_batch_topup_amount"]').forEach(function(btn){ btn.addEventListener('click', function(){ if(input){ input.value=btn.getAttribute('data-amount')||''; } syncBatchFunding(); }); });
              if(input){ input.addEventListener('input', syncBatchFunding); }
              syncBatchFunding();
            })();
            </script>
          <?php else: ?>
            <?php $checking = LeadMarketHelper::isBuyerCheckingState($status, $paymentStatus); ?>
            <?php if ($checking): ?>
            <div class="lm-batch-checking" id="lmBatchCheckingPanel">
              <div class="lm-batch-checking__row"><span class="lm-batch-checking__spinner" aria-hidden="true"></span><div class="lm-batch-checking__title">Checking payment and unlocking batch</div></div>
              <p class="lm-batch-checking__copy">Payment sent. We are checking the transfer and unlocking the batch automatically.</p>
              <ol class="lm-batch-checking__steps">
                <li class="is-active">Payment sent</li>
                <li class="is-active">Checking blockchain transfer</li>
                <li class="is-active">Matching payment amount</li>
                <li class="is-active">Unlocking batch automatically</li>
              </ol>
              <div class="lm-batch-checking__meta" id="lmBatchCheckingMeta">This page refreshes every 10 seconds until unlock.</div>
            </div>
            <?php endif; ?>
            <div style="margin:0 0 12px;padding:12px;border-radius:12px;background:#eef6fb;border:1px solid #d8e8f3;color:#0c5585;line-height:1.6;">
              <?php if ($batchAppliedFromWallet > 0): ?>Wallet is used first. Send only the amount below.<?php else: ?>Send the exact amount below.<?php endif; ?>
            </div>
            <div style="border:1px solid #e5e5e5;border-radius:10px;padding:12px;background:#fafafa;margin:0 0 12px 0">
              <p style="margin:0 0 8px;line-height:1.6"><b>USDT TRC20 Address:</b></p>
              <div style="display:flex;gap:8px;align-items:flex-start;margin:0 0 10px">
                <span id="lmBatchAddress" style="flex:1;word-break:break-all"><?php echo $address !== '' ? htmlspecialchars($address,ENT_QUOTES,'UTF-8') : 'Address not configured'; ?></span>
                <button type="button" id="lmCopyAddressBtn" style="display:inline-flex;align-items:center;justify-content:center;min-height:36px;padding:0 12px;border-radius:10px;border:1px solid #d5e3ee;background:#fff;color:#0c5585;font-weight:700;cursor:pointer;white-space:nowrap">Copy</button>
              </div>
              <div style="margin:0 0 12px;padding:14px 16px;border:2px solid #f0c36d;border-radius:12px;background:#fff8e8;color:#7a4b00;"><div style="font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;margin:0 0 4px;">Exact transfer amount</div><div style="font-size:28px;font-weight:900;line-height:1.1;">$<?php echo htmlspecialchars(number_format((float)$batchExactTransferAmount,2,'.',''),ENT_QUOTES,'UTF-8'); ?></div><div style="margin-top:6px;font-size:13px;">Send this exact amount for automatic matching.</div><div style="margin-top:8px;font-size:13px;color:#7a4b00;"><b>Expires (UTC):</b> <?php echo htmlspecialchars((string)$batch['expires_at_utc'],ENT_QUOTES,'UTF-8'); ?> · <b>Payment status:</b> <?php echo htmlspecialchars($paymentStatus,ENT_QUOTES,'UTF-8'); ?></div></div>
              <p style="margin:0 0 8px;line-height:1.6"><b>Secure access:</b><br><span style="word-break:break-all"><?php echo htmlspecialchars($secureBatchUrl,ENT_QUOTES,'UTF-8'); ?></span></p>
            </div>
                        <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=batchipaid'); ?>" method="post" style="margin-bottom:10px" id="lmBatchPaidForm">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="batch_id" value="<?php echo (int)$batch['id']; ?>">
              <input type="hidden" name="token" value="<?php echo htmlspecialchars($token,ENT_QUOTES,'UTF-8'); ?>">
              <button type="submit" id="lmBatchPaidBtn" <?php echo $checking ? 'disabled="disabled"' : ''; ?> style="display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent;cursor:<?php echo $checking ? 'not-allowed' : 'pointer'; ?>;background:#0c5585;color:#fff;width:100%;opacity:<?php echo $checking ? '.72' : '1'; ?>"><?php echo $checking ? '<span class="lm-spinner-inline"></span>Checking Payment...' : 'I Paid'; ?></button>
            </form>
            <script>
            (function(){
              var copyBtn = document.getElementById('lmCopyAddressBtn');
              var copyText = document.getElementById('lmBatchAddress');
              if (copyBtn && copyText) {
                copyBtn.addEventListener('click', function(){
                  var txt = (copyText.innerText || copyText.textContent || '').trim();
                  if (!txt) return;
                  if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(txt);
                  } else {
                    var ta = document.createElement('textarea');
                    ta.value = txt; document.body.appendChild(ta); ta.select();
                    try { document.execCommand('copy'); } catch (e) {}
                    document.body.removeChild(ta);
                  }
                  var old = copyBtn.textContent; copyBtn.textContent = 'Copied';
                  setTimeout(function(){ copyBtn.textContent = old; }, 1400);
                });
              }
              var paidForm = document.getElementById('lmBatchPaidForm');
              var paidBtn = document.getElementById('lmBatchPaidBtn');
              if (paidForm && paidBtn && !paidBtn.disabled) {
                paidForm.addEventListener('submit', function(){
                  paidBtn.disabled = true;
                  paidBtn.innerHTML = '<span class="lm-spinner-inline"></span>Checking Payment...';
                  var existing = document.getElementById('lmBatchCheckingPanel');
                  if (!existing) {
                    var panel = document.createElement('div');
                    panel.className = 'lm-batch-checking';
                    panel.id = 'lmBatchCheckingPanel';
                    panel.innerHTML = '<div class="lm-batch-checking__row"><span class="lm-batch-checking__spinner" aria-hidden="true"></span><div class="lm-batch-checking__title">Checking payment and unlocking batch</div></div>' +
                      '<p class="lm-batch-checking__copy">Looking for your TRC20 transfer now. Once matched, the wallet credit and batch unlock will complete automatically.</p>' +
                      '<ol class="lm-batch-checking__steps">' +
                      '<li class="is-active">Payment sent</li>' +
                      '<li class="is-active">Checking blockchain transfer</li>' +
                      '<li class="is-active">Matching payment amount</li>' +
                      '<li class="is-active">Unlocking batch automatically</li>' +
                      '</ol>' +
                      '<div class="lm-batch-checking__meta">Keep this page open. It will refresh automatically while the payment is being checked.</div>';
                    paidForm.parentNode.insertBefore(panel, paidForm);
                  }
                });
              }
              <?php if ($checking): ?>
              setInterval(function(){
                var meta = document.getElementById('lmBatchCheckingMeta');
                if (meta) meta.textContent = 'Last checked: ' + new Date().toLocaleTimeString() + ' • Next automatic refresh in ~10 seconds';
              }, 1000);
              setTimeout(function(){ window.location.href = window.location.href.split('#')[0]; }, 10000);
              <?php endif; ?>
            })();
            </script>
          <?php endif; ?>
          <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=cancelbatch'); ?>" method="post">
            <?php echo JHtml::_('form.token'); ?>
            <input type="hidden" name="batch_id" value="<?php echo (int)$batch['id']; ?>">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token,ENT_QUOTES,'UTF-8'); ?>">
            <button type="submit" style="display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid #d5e3ee;cursor:pointer;background:#fff;color:#44545e;width:100%">Cancel checkout</button>
          </form>
        <?php endif; ?>
      </aside>
    </div>
  <?php endif; ?>
<?php endif; ?>
</div>


<script>
window.lmTrackEvent = window.lmTrackEvent || function(name, props){
  try {
    var payload = new FormData();
    payload.append('event_name', name || '');
    payload.append('props_json', JSON.stringify(props || {}));
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=api.track', false), ENT_QUOTES, 'UTF-8'); ?>', payload);
      return;
    }
    if (window.fetch) {
      fetch('<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=api.track', false), ENT_QUOTES, 'UTF-8'); ?>', {method:'POST', credentials:'same-origin', body:payload, keepalive:true});
    }
  } catch(e) {}
};
</script>
<script>
(function(){
  function lmOpenBatchCreditBox(targetId){
    if(!targetId) return;
    var el=document.getElementById(targetId);
    if(!el) return;
    el.hidden=false;
    if (typeof el.scrollIntoView === 'function') { el.scrollIntoView({behavior:'smooth', block:'center'}); }
    el.classList.remove('is-pulse');
    window.requestAnimationFrame(function(){ el.classList.add('is-pulse'); setTimeout(function(){ el.classList.remove('is-pulse'); }, 1200); });
  }
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-batch-credit-link')).forEach(function(btn){
    btn.addEventListener('click', function(ev){
      var targetId = btn.getAttribute('data-target') || '';
      var el = document.getElementById(targetId);
      if(!el) return;
      ev.preventDefault();
      Array.prototype.slice.call(document.querySelectorAll('.lm-batch-credit-box')).forEach(function(box){ box.hidden = true; });
      el.hidden = false;
      lmOpenBatchCreditBox(targetId);
    });
  });
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-open-state')).forEach(function(link){
    link.addEventListener('click', function(){
      link.textContent = link.getAttribute('data-loading-text') || 'Opening...';
      link.style.pointerEvents = 'none';
      link.style.opacity = '0.85';
    });
  });
})();
</script>

<script>(function(){Array.prototype.slice.call(document.querySelectorAll('.lm-js-credit-toggle, .lm-batch-request-credit')).forEach(function(btn){btn.addEventListener('click', function(){ window.lmTrackEvent('credit_request_opened', {page_name:'batch'}); });});Array.prototype.slice.call(document.querySelectorAll('a[href*="view=lead&id="]')).forEach(function(link){link.addEventListener('click', function(){ var href=link.getAttribute('href')||''; var m=href.match(/id=(\d+)/); window.lmTrackEvent('lead_open_click',{page_name:'batch', lead_id:m?parseInt(m[1],10)||0:0});});});})();</script>
