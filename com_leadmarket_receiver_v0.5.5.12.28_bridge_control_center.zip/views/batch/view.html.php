<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketViewBatch extends JViewLegacy
{
    protected function applyTechnicalSeoProtection()
    {
        $doc = JFactory::getDocument();
        if ($doc && method_exists($doc, 'setMetaData')) {
            $doc->setMetaData('robots', 'noindex, nofollow');
        }
        $app = JFactory::getApplication();
        $this->applyTechnicalSeoProtection();
        try {
            $app->setHeader('X-Robots-Tag', 'noindex, nofollow', true);
        } catch (Exception $e) {}
        if (!headers_sent()) {
            header('X-Robots-Tag: noindex, nofollow', true);
        }
    }

    public $batch;
    public $items;
    public $token;
    public $selectionLeads;
    public $mode;
    public $accessDenied = false;
    public $address;
    public $removedCount = 0;
    public $sessionNotice = "";
    public $errorNotice = "";
    public $eligibilityNotice = "";
    public $buyerEmailValue = "";
    public $repeatPurchaseNotice = "";
    public $repeatPurchaseTone = "";
    public $allSelectedAlreadyPurchased = false;
    public $errorTone = "warn";
    public $showResendAccess = false;
    public $disableSharedCheckout = false;
    public $batchAdjustmentData = array();
    public $inlineCreditSubmitResult = null;
    public $focusCreditOrderId = 0;

    public function display($tpl = null)
    {
        LeadMarketHelper::trackPageView('batch_checkout_view', array('page_name' => 'batch'));
        $app = JFactory::getApplication();
        $session = JFactory::getSession();
        $batchId = $app->input->getInt('id', 0);
        $token = LeadMarketHelper::readBuyerAccessTokenFromRequest();
        $inlineCredit = LeadMarketHelper::handleInlineCreditRequestPost();
        if (!empty($inlineCredit['handled'])) {
            $this->inlineCreditSubmitResult = $inlineCredit;
            $this->focusCreditOrderId = (int) ($inlineCredit['order_id'] ?? 0);
        }
        LeadMarketHelper::ensureSchema();
        LeadMarketHelper::cleanupExpiredOrders();
        LeadMarketHelper::cleanupExpiredBatches();
        $this->address = LeadMarketHelper::cryptoWalletAddress();
        $this->sessionNotice = (string)$session->get('lm.batch_removed_notice', '', 'com_leadmarket');
        $session->clear('lm.batch_removed_notice', 'com_leadmarket');
        $this->errorNotice = (string)$session->get('lm.batch_error_notice', '', 'com_leadmarket');
        $this->batchAdjustmentData = (array)$session->get('lm.batch_adjustment_data', array(), 'com_leadmarket');
        $this->errorTone = (string)$session->get('lm.batch_error_tone', 'warn', 'com_leadmarket');
        $queryNotice = trim((string)$app->input->getString('summary_notice', ''));
        $queryTone = trim((string)$app->input->getString('summary_tone', ''));
        $queryShowResend = (int)$app->input->getInt('show_resend', 0);
        if ($queryNotice === '' && isset($_GET['summary_notice'])) $queryNotice = trim((string)$_GET['summary_notice']);
        if ($queryTone === '' && isset($_GET['summary_tone'])) $queryTone = trim((string)$_GET['summary_tone']);
        if (!$queryShowResend && isset($_GET['show_resend'])) $queryShowResend = (int)$_GET['show_resend'];
        if ($queryNotice !== '') $this->errorNotice = $queryNotice;
        if ($queryTone !== '') $this->errorTone = $queryTone;
        $session->clear('lm.batch_error_notice', 'com_leadmarket');
        $session->clear('lm.batch_adjustment_data', 'com_leadmarket');
        $session->clear('lm.batch_error_tone', 'com_leadmarket');
        $requestBuyerEmail = trim((string)$app->input->getString('buyer_email', ''));
        if ($requestBuyerEmail === '') {
            $requestBuyerEmail = trim((string)$app->input->post->getString('buyer_email', ''));
        }
        if ($requestBuyerEmail === '' && isset($_GET['buyer_email'])) {
            $requestBuyerEmail = trim((string)$_GET['buyer_email']);
        }
        if ($requestBuyerEmail === '' && isset($_POST['buyer_email'])) {
            $requestBuyerEmail = trim((string)$_POST['buyer_email']);
        }
        if ($requestBuyerEmail === '' && !empty($_SERVER['QUERY_STRING']) && preg_match('/(?:^|&)buyer_email=([^&]+)/', (string)$_SERVER['QUERY_STRING'], $m)) {
            $requestBuyerEmail = trim(urldecode((string)$m[1]));
        }
        $requestBuyerEmail = str_replace(' ', '+', $requestBuyerEmail);
        $this->buyerEmailValue = $requestBuyerEmail !== '' ? $requestBuyerEmail : trim((string)$session->get('lm.batch_buyer_email', '', 'com_leadmarket'));
        if ($this->buyerEmailValue === '') $this->buyerEmailValue = LeadMarketHelper::getActiveBuyerEmail();
        if ($this->buyerEmailValue !== '') {
            $session->set('lm.batch_buyer_email', $this->buyerEmailValue, 'com_leadmarket');
            LeadMarketHelper::setActiveBuyerContext($this->buyerEmailValue, 'batch_summary');
        }
        $this->batch = null;
        $this->items = array();
        $this->selectionLeads = array();
        $this->token = $token;
        $this->mode = 'summary';

        if ($batchId > 0) {
            $batch = LeadMarketHelper::loadBatchById($batchId);
            if (!$batch) throw new Exception('Shared checkout not found', 404);
            $batch = LeadMarketHelper::reconcileBatchById((int)$batch['id']);
      $batch['access_token'] = LeadMarketHelper::ensureBatchToken($batch);
            if (!LeadMarketHelper::canAccessBatch($batch, $token)) {
                $this->accessDenied = true;
            }
            $this->batch = $batch;
            if (!empty($batch['buyer_email'])) LeadMarketHelper::setActiveBuyerContext((string) $batch['buyer_email'], 'batch', $token);
            $this->items = LeadMarketHelper::getBatchItems($batchId);
            $this->mode = 'checkout';
        } else {
            $ids = array();
            $ids = (array)$session->get('lm.shared_selection_ids', array(), 'com_leadmarket');
            $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
            if (!$ids) {
                $csv = '';
                if (!empty($_SERVER['QUERY_STRING']) && preg_match('/(?:^|&)selected=([^&]+)/', (string)$_SERVER['QUERY_STRING'], $m)) {
                    $csv = urldecode((string)$m[1]);
                }
                if ($csv === '' && isset($_GET['selected'])) {
                    $csv = (string)$_GET['selected'];
                }
                if ($csv === '') {
                    $csv = trim((string)$app->input->getString('selected', ''));
                }
                if ($csv !== '') {
                    $ids = array_values(array_unique(array_filter(array_map('intval', preg_split('/\s*,\s*/', $csv)))));
                    $session->set('lm.shared_selection_ids', $ids, 'com_leadmarket');
                }
            }
            if ($ids) {
                $db = JFactory::getDbo();
                $requestedCount = count($ids);
                $reservedCount = 0;
                $reservedUntil = array();
                $otherRemovedCount = 0;
                foreach ($ids as $leadId) {
                    $db->setQuery('SELECT * FROM #__leadmarket_leads WHERE id=' . (int)$leadId);
                    $lead = $db->loadAssoc();
                    if (!$lead) { $otherRemovedCount++; continue; }
                    $opts = LeadMarketHelper::getSaleModeOptions($lead);
                    if (empty($opts['shared']['enabled'])) {
                        if (!empty($opts['exclusive']['window_open'])) {
                            $reservedCount++;
                            $endUtc = LeadMarketHelper::formatUtcForBuyer(LeadMarketHelper::getBuyerExclusiveWindowEndUtc($lead));
                            if ($endUtc !== '') $reservedUntil[] = $endUtc;
                        } else {
                            $otherRemovedCount++;
                        }
                        continue;
                    }
                    $this->selectionLeads[] = array('lead' => $lead, 'price' => (float)$opts['shared']['price_usd']);
                }
                $visibleCount = count($this->selectionLeads);
                if ($requestedCount > $visibleCount) {
                    $removed = $requestedCount - $visibleCount;
                    if ($reservedCount > 0 && $otherRemovedCount > 0) {
                        $this->eligibilityNotice = $reservedCount . ' selected lead(s) are reserved during an exclusive access window and cannot be added yet, and ' . $otherRemovedCount . ' more lead(s) are no longer eligible for shared checkout.';
                    } elseif ($reservedCount > 0) {
                        $untilText = !empty($reservedUntil) ? min($reservedUntil) : '';
                        $this->eligibilityNotice = $reservedCount . ' selected lead(s) are reserved during an exclusive access window and cannot be added to shared checkout' . ($untilText !== '' ? (' until ' . $untilText) : '') . '.';
                    } else {
                        $this->eligibilityNotice = $removed . ' selected lead(s) were removed because they are no longer eligible for shared checkout.';
                    }
                    $session->set('lm.shared_selection_ids', array_map(function($row){ return (int)($row['lead']['id'] ?? 0); }, $this->selectionLeads), 'com_leadmarket');
                }
                if ($queryShowResend === 1) { $this->showResendAccess = true; }
                if ($this->buyerEmailValue !== '' && filter_var($this->buyerEmailValue, FILTER_VALIDATE_EMAIL) && $this->selectionLeads) {
                    $visibleIds = array_map(function($row){ return (int)($row['lead']['id'] ?? 0); }, $this->selectionLeads);
                    $purchaseState = LeadMarketHelper::getSharedBatchEmailPurchaseCounts($visibleIds, $this->buyerEmailValue);
                    if (!empty($purchaseState['all_purchased'])) {
                        $this->allSelectedAlreadyPurchased = true;
                        $this->showResendAccess = true;
                        $this->disableSharedCheckout = true;
                        $this->repeatPurchaseTone = 'error';
                        $this->repeatPurchaseNotice = 'These leads are already linked to this buyer email. Send a secure buyer access link to reopen them.';
                    } elseif ((int)($purchaseState['eligible_count'] ?? 0) <= 0 && (int)($purchaseState['active_checkout_count'] ?? 0) > 0) {
                        $this->disableSharedCheckout = true;
                        $this->repeatPurchaseTone = 'warn';
                        $this->repeatPurchaseNotice = (int)$purchaseState['active_checkout_count'] . ' selected lead(s) are already inside an unfinished checkout for this buyer email. Send a secure buyer access link to reopen the active checkout.';
                    } elseif (!empty($purchaseState['partially_purchased']) || (int)($purchaseState['active_checkout_count'] ?? 0) > 0) {
                        $this->repeatPurchaseTone = 'warn';
                        $remaining = max(0, (int)($purchaseState['eligible_count'] ?? 0));
                        $bits = array();
                        if ((int)($purchaseState['purchased_count'] ?? 0) > 0) $bits[] = (int)$purchaseState['purchased_count'] . ' already purchased';
                        if ((int)($purchaseState['active_checkout_count'] ?? 0) > 0) $bits[] = (int)$purchaseState['active_checkout_count'] . ' already in an unfinished checkout';
                        $this->repeatPurchaseNotice = implode('; ', $bits) . '. A new shared checkout will include only the remaining ' . $remaining . ' eligible lead(s). Use buyer access if you want to reopen leads already linked to this email.';
                    }
                }
            }
        }
        parent::display($tpl);
    }
}
