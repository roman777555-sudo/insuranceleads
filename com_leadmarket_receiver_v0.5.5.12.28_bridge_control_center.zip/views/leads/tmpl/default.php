<?php defined('_JEXEC') or die; ?>
<?php require_once JPATH_COMPONENT . '/helpers/leadmarket.php'; ?>
<?php
$filters = is_array($this->filters) ? $this->filters : array();
$stateCode = isset($filters['state_code']) ? $filters['state_code'] : '';
$leadType = isset($filters['lead_type']) ? $filters['lead_type'] : '';
$tier = isset($filters['tier']) ? $filters['tier'] : '';
$availability = isset($filters['availability']) ? $filters['availability'] : '';
$sort = isset($filters['sort']) ? $filters['sort'] : 'newest';
$states = LeadMarketHelper::getMarketplaceStateOptions($leadType);
$buyerEmail = trim((string) ($this->buyerEmail ?? ''));
$buyerSummary = is_array($this->buyerSummary ?? null) ? $this->buyerSummary : array();
$buyerLeadContext = is_array($this->buyerLeadContext ?? null) ? $this->buyerLeadContext : array();
$buyerRecognized = !empty($buyerSummary['recognized']) && $buyerEmail !== '';
$buyerBalance = (float) ($buyerSummary['balance_usd'] ?? 0);
$buyerPurchasesCount = (int) ($buyerSummary['purchases_count'] ?? 0);
$buyerActiveCount = (int) ($buyerSummary['active_count'] ?? 0);
$buyerUnlockedCount = (int) ($buyerSummary['unlocked_count'] ?? 0);
$buyerAccessUrl = $buyerRecognized ? LeadMarketHelper::getBuyerAccessActionAbsoluteUrl($buyerEmail) : '';
$buyerAccessRequestUrl = LeadMarketHelper::getBuyerAccessRequestUrl($buyerEmail);
$buyerAccessRequestReturnUrl = 'index.php?option=com_leadmarket&view=leads';
$buyerAccessReturnParams = array();
if ($stateCode !== '') $buyerAccessReturnParams['state_code'] = $stateCode;
if ($leadType !== '') $buyerAccessReturnParams['lead_type'] = $leadType;
if ($tier !== '') $buyerAccessReturnParams['tier'] = $tier;
if ($availability !== '') $buyerAccessReturnParams['availability'] = $availability;
if ($sort !== '' && $sort !== 'newest') $buyerAccessReturnParams['sort'] = $sort;
if ($buyerEmail !== '') $buyerAccessReturnParams['buyer_email'] = $buyerEmail;
if (!empty($buyerAccessReturnParams)) $buyerAccessRequestReturnUrl .= '&' . http_build_query($buyerAccessReturnParams);
$buyerAccessRequestReturnUrl .= '#lm-buyer-tools';
$sampleAuto = LeadMarketHelper::getSampleLeadByType('auto');
$sampleHome = LeadMarketHelper::getSampleLeadByType('home');
$sampleAutoUrl = $sampleAuto ? JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$sampleAuto['id'] . '&sample=1') : '';
$sampleHomeUrl = $sampleHome ? JRoute::_('index.php?option=com_leadmarket&view=lead&id=' . (int)$sampleHome['id'] . '&sample=1') : '';
$clearBuyerUrl = $this->marketUrl;
$clearParams = array();
if ($stateCode !== '') $clearParams['state_code'] = $stateCode;
if ($leadType !== '') $clearParams['lead_type'] = $leadType;
if ($tier !== '') $clearParams['tier'] = $tier;
if ($availability !== '') $clearParams['availability'] = $availability;
if ($sort !== '' && $sort !== 'newest') $clearParams['sort'] = $sort;
$clearParams['clear_buyer'] = 1;
if (!empty($clearParams)) $clearBuyerUrl .= (strpos($clearBuyerUrl, '?') === false ? '?' : '&') . http_build_query($clearParams);
$app = JFactory::getApplication();
$buyerAccessLinkStatus = trim((string) $app->input->getCmd('lm_access_status', ''));
$buyerAccessLinkEmail = trim((string) $app->input->getString('lm_access_email', ''));
$buyerAccessLinkTone = '';
$buyerAccessLinkMessage = '';
if ($buyerAccessLinkStatus === 'sent') {
  $buyerAccessLinkTone = 'success';
  $buyerAccessLinkMessage = 'Buyer access link sent' . ($buyerAccessLinkEmail !== '' ? ' to <b>' . htmlspecialchars($buyerAccessLinkEmail, ENT_QUOTES, 'UTF-8') . '</b>.' : '.');
} elseif ($buyerAccessLinkStatus === 'invalid_email') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'Enter a valid buyer email and try again.';
} elseif ($buyerAccessLinkStatus === 'mail_failed') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'The secure link was created, but the email could not be sent right now.';
} elseif ($buyerAccessLinkStatus === 'link_failed') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'We could not create a secure buyer access link right now.';
} elseif ($buyerAccessLinkStatus === 'invalid_token') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'Your session expired. Refresh the page and try again.';
}
?>
<?php
$paginationHtml = '';
if (!empty($this->pagination)) {
  $paginationHtml = (string) $this->pagination->getPagesLinks();
  if ($paginationHtml !== '') {
    $normalizePaginationHref = function($href) {
      $decoded = html_entity_decode((string) $href, ENT_QUOTES, 'UTF-8');
      $parts = @parse_url($decoded);
      if ($parts === false) {
        return htmlspecialchars((string) $href, ENT_QUOTES, 'UTF-8');
      }
      $query = array();
      if (!empty($parts['query'])) {
        parse_str($parts['query'], $query);
      }
      if (isset($query['start']) && (int) $query['start'] <= 0) {
        unset($query['start']);
      }
      $rebuilt = isset($parts['path']) ? $parts['path'] : '';
      if (!empty($query)) {
        $rebuilt .= '?' . http_build_query($query);
      }
      if (!empty($parts['fragment'])) {
        $rebuilt .= '#' . $parts['fragment'];
      }
      return htmlspecialchars($rebuilt, ENT_QUOTES, 'UTF-8');
    };

    $paginationHtml = preg_replace_callback('/href="([^"]+)"/i', function($m) use ($normalizePaginationHref) {
      return 'href="' . $normalizePaginationHref($m[1]) . '" rel="nofollow"';
    }, $paginationHtml);
  }
}
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderIframeBreakoutScript(); ?>
<style>
.lm-market{max-width:1180px;margin:24px auto;padding:0 16px;font-family:Arial,sans-serif;color:#13232f}
.lm-shell{background:linear-gradient(135deg,#f6fbff 0%,#eef7fd 100%);border:1px solid #d8e7f3;border-radius:20px;padding:20px}
.lm-shell__top{display:flex;justify-content:space-between;gap:14px;align-items:flex-end;flex-wrap:wrap}
.lm-shell__eyebrow{display:inline-block;margin-bottom:8px;background:#fff;border:1px solid #dceaf4;color:#0c5585;border-radius:999px;padding:7px 12px;font-size:12px;font-weight:800}
.lm-shell h1{margin:0 0 6px;font-size:34px;color:#0c5585;letter-spacing:-.02em;line-height:1.08}
.lm-shell p{margin:0;color:#44545e;line-height:1.6;max-width:760px}
.lm-shell__actions{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
.lm-launchbar{margin-top:14px;background:#fff8ef;border:1px solid #eadfc7;border-radius:14px;padding:10px 14px;display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px}
.lm-launchbar__badge{display:inline-block;background:#fff;border:1px solid #eadfc7;color:#9a6711;border-radius:999px;padding:6px 10px;font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.03em}
.lm-launchbar__copy{color:#6a5621;font-size:14px;line-height:1.55;font-weight:600}
.lm-launchbar__copy strong{color:#7a4e00}
.lm-toolbar{margin-top:14px;display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}
.lm-field label{display:block;margin:0 0 6px;font-size:12px;color:#56656f;font-weight:800;text-transform:uppercase;letter-spacing:.03em}
.lm-field select{width:100%;min-height:46px;border:1px solid #cfd9e3;border-radius:12px;padding:0 12px;background:#fff;color:#22313b}
.lm-toolbar__actions{display:flex;align-items:flex-end;gap:10px;flex-wrap:wrap}
.lm-btn-main,.lm-btn-ghost{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent;cursor:pointer;transition:background .18s ease,color .18s ease,border-color .18s ease,box-shadow .18s ease}
.lm-btn-main{background:#0c5585;color:#fff;box-shadow:0 6px 18px rgba(12,85,133,.16)}
.lm-btn-ghost{background:#fff;color:#44545e;border-color:#d5e3ee}
.lm-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(280px,320px);gap:18px;margin-top:18px;align-items:start}
.lm-list{display:grid;grid-template-columns:1fr;gap:14px}
.lm-summary{position:sticky;top:16px;background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:18px;box-shadow:0 4px 16px rgba(12,85,133,.05)}
.lm-summary h3{margin:0 0 8px;font-size:20px;color:#0c5585}
.lm-summary p{margin:0 0 12px;color:#51626d;line-height:1.7;font-size:14px}
.lm-summary__stats{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 12px}
.lm-summary__box{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px}
.lm-summary__label{display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}
.lm-summary__value{font-size:18px;font-weight:800;color:#13232f}
.lm-summary__notice{display:none;background:#fff7e8;border:1px solid #f0ddb6;border-radius:12px;padding:12px;color:#7b5a1d;font-size:13px;line-height:1.6;margin-bottom:12px}.lm-summary__actions{display:grid;gap:10px}.lm-summary__actions .lm-btn-main,.lm-summary__actions .lm-btn-ghost{width:100%}.lm-toolbar__actions .lm-btn-main,.lm-toolbar__actions .lm-btn-ghost{min-width:110px}.lm-summary__helper{margin:0 0 12px;color:#61717f;line-height:1.6;font-size:13px}.lm-btn-main:hover,.lm-btn-main:focus{background:#0a4a73;color:#fff;box-shadow:0 8px 20px rgba(12,85,133,.22)}.lm-btn-ghost:hover,.lm-btn-ghost:focus{background:#f4f8fb;color:#44545e}.lm-card__actions .lm-btn{box-shadow:0 6px 18px rgba(12,85,133,.14)}.lm-card__actions .lm-btn:hover,.lm-card__actions .lm-btn:focus{background:#0a4a73;color:#fff}.lm-card__actions .lm-link:hover,.lm-card__actions .lm-link:focus{color:#0a4a73;text-decoration:underline}
.lm-inline-buyer{margin:0 0 12px}.lm-inline-buyer details{border:1px solid #dbe6ef;border-radius:14px;background:#f8fbfd}.lm-inline-buyer summary{list-style:none;cursor:pointer;padding:12px 14px;font-weight:800;color:#0c5585;display:flex;align-items:center;justify-content:space-between;gap:10px}.lm-inline-buyer summary::-webkit-details-marker{display:none}.lm-inline-buyer__meta{color:#5c6d78;font-size:12px;font-weight:600}.lm-inline-buyer__body{padding:0 14px 14px;display:grid;gap:12px}.lm-inline-buyer__copy{margin:0;color:#5c6d78;line-height:1.55;font-size:13px}.lm-inline-buyer__form{display:grid;gap:10px;margin:0}.lm-inline-buyer__field label{display:block;margin:0 0 6px;font-size:12px;color:#56656f;font-weight:800;text-transform:uppercase;letter-spacing:.03em}.lm-inline-buyer__field input{width:100%;min-height:44px;border:1px solid #cfd9e3;border-radius:12px;padding:0 12px;background:#fff;color:#22313b;box-sizing:border-box}.lm-inline-buyer__actions{display:grid;gap:10px}.lm-inline-buyer__actions .lm-btn-main,.lm-inline-buyer__actions .lm-btn-ghost,.lm-inline-buyer__secondary-form .lm-btn-main,.lm-inline-buyer__secondary-form .lm-btn-ghost,.lm-inline-buyer__clearlink{width:100%;min-height:48px;padding:12px 14px;line-height:1.35;white-space:normal;text-align:center;box-sizing:border-box}.lm-inline-buyer__secondary-form{margin:0;display:block}.lm-inline-buyer__clearlink{display:inline-flex;align-items:center;justify-content:center;text-decoration:none}.lm-inline-buyer__stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:10px}.lm-inline-buyer__box{background:#fff;border:1px solid #edf2f7;border-radius:12px;padding:10px}.lm-inline-buyer__label{display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}.lm-inline-buyer__value{font-size:17px;font-weight:800;color:#13232f}.lm-inline-buyer__notice{margin:0;padding:10px 12px;border-radius:12px;background:#eef6fb;border:1px solid #d8e8f3;color:#0c5585;line-height:1.6;font-size:13px}.lm-inline-buyer__notice--success{background:#eefaf0;border-color:#cfe5d4;color:#1f6b35}.lm-inline-buyer__notice--error{background:#fff0f0;border-color:#f0d2d2;color:#9b2d2d}.lm-inline-buyer__notice--info{background:#f6fbff;border-color:#d8e7f3;color:#0c5585}.lm-ajax-btn{position:relative;transition:transform .16s ease,opacity .16s ease}.lm-ajax-btn.is-loading{pointer-events:none;opacity:.92}.lm-ajax-btn.is-loading:after{content:'';position:absolute;right:14px;top:50%;width:16px;height:16px;margin-top:-8px;border-radius:50%;border:2px solid rgba(255,255,255,.45);border-top-color:#fff;animation:lmBtnSpin .7s linear infinite}.lm-btn-ghost.lm-ajax-btn.is-loading:after{border-color:rgba(12,85,133,.2);border-top-color:#0c5585}.lm-badge--buyer-owned{background:#eefaf0;color:#1f6b35;border:1px solid #cfe5d4}.lm-badge--buyer-active{background:#fff8ef;color:#7a5c1e;border:1px solid #eadfc7}.lm-badge--buyer-ready{background:#eef6fb;color:#0c5585;border:1px solid #d8e8f3}.lm-badge--buyer-review{background:#edf8f1;color:#1f6a3c;border:1px solid #cfe7d8}.lm-summary__buyerline{margin:0 0 12px;padding:10px 12px;border-radius:12px;background:#eef6fb;border:1px solid #d8e8f3;color:#0c5585;font-size:13px;line-height:1.55}.lm-summary__buyerline strong{font-weight:800}.lm-summary__buyerline small{display:block;color:#5c7285;font-size:12px;margin-top:2px}.lm-market-trust{margin-top:14px;background:#fff;border:1px solid #dbe7ef;border-radius:16px;padding:16px 18px;box-shadow:0 4px 14px rgba(12,85,133,.04)}.lm-market-trust__row{display:flex;flex-wrap:wrap;gap:14px;align-items:center;justify-content:space-between}.lm-market-trust__main{flex:1 1 560px;min-width:260px}.lm-market-trust__badges{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:8px}.lm-market-trust__badge{display:inline-block;background:#fff;border:1px solid #d8e6ee;color:#0c5585;border-radius:999px;padding:7px 11px;font-size:12px;font-weight:700}.lm-market-trust__badge--ok{background:#edf8f1;border-color:#cfe7d8;color:#1f6a3c}.lm-market-trust__title{display:block;color:#14384f;font-size:24px;line-height:1.2;margin-bottom:6px;font-weight:800}.lm-market-trust__copy{color:#4b5f6c;line-height:1.7;font-size:14px}.lm-market-trust__side{flex:0 1 230px;min-width:190px;background:#f8fbfd;border:1px solid #dbe7ef;border-radius:12px;padding:11px 12px;color:#51626d;line-height:1.6;font-size:13px}.lm-market-trust__side strong{display:block;color:#0c5585;font-size:13px;margin-bottom:3px}@keyframes lmBtnSpin{to{transform:rotate(360deg)}}
.lm-empty{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:20px;color:#50616d}
.lm-card{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:16px;box-shadow:0 4px 16px rgba(12,85,133,.05)}
.lm-card__head{display:flex;justify-content:space-between;align-items:flex-start;gap:14px}
.lm-card__titlewrap{min-width:0}
.lm-select{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:800;color:#0c5585;margin-bottom:6px}
.lm-select__input{width:16px;height:16px}
.lm-card__title{font-size:23px;font-weight:800;margin:0 0 6px;color:#13232f;letter-spacing:-.01em}
.lm-card__meta{font-size:14px;color:#61717f;line-height:1.6}
.lm-dot{opacity:.5;padding:0 4px}
.lm-card__badges{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}
.lm-badge{display:inline-block;background:#eef7fd;color:#0c5585;border-radius:999px;padding:6px 10px;font-size:11px;font-weight:800;white-space:nowrap}
.lm-badge--exclusive{background:#e8f7ec;color:#18663a;box-shadow:inset 0 0 0 1px #c3e5ce}
.lm-badge--exclusive-locked{background:#fff7e8;color:#9a6711;box-shadow:inset 0 0 0 1px #f0ddb6}
.lm-badge--freshness{background:#f2f5f8;color:#5e6f7c;box-shadow:inset 0 0 0 1px #e1e8ef}
.lm-badge--freshness-hot{background:#e8f7ec;color:#17663a;box-shadow:inset 0 0 0 1px #bfe3ca}
.lm-badge--freshness-live{background:#e9f4ff;color:#0c5585;box-shadow:inset 0 0 0 1px #bfd9ef}
.lm-badge--feature{background:#eef6fb;color:#0c5585;box-shadow:inset 0 0 0 1px #d8e8f3}
.lm-badge--feature-risk{background:#eef6fb;color:#0c5585;box-shadow:inset 0 0 0 1px #d8e8f3}
.lm-badge--older{background:#f4f1fb;color:#5c5c7d;box-shadow:inset 0 0 0 1px #e2ddf3}
.lm-badge--older-secondary{background:#f7f8fa;color:#64707b;box-shadow:inset 0 0 0 1px #e5e9ef}
.lm-badge--access-muted{background:#f6f8fb;color:#50606c;box-shadow:inset 0 0 0 1px #dfe7ef}
.lm-status{display:inline-block;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:800;white-space:nowrap;background:#f2f5f8;color:#51626d}
.lm-status--ok{background:#e8f7ee;color:#1d7a43}
.lm-status--warn{background:#fff4df;color:#9a6711}
.lm-card__grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:12px}
.lm-card__info{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px}
.lm-card__info--exclusive.is-available{background:#edf9f1;border-color:#cfead9}
.lm-card__info--exclusive.is-locked{background:#fff7e8;border-color:#f0ddb6}
.lm-card__info--exclusive.is-unavailable{background:#f8fbfd;border-color:#edf2f7}
.lm-card__info-note{display:block;margin-top:4px;color:#44545e;line-height:1.45;font-size:14px;font-weight:700}
.lm-card--exclusive-available{border-color:#b7e3c7;box-shadow:0 0 0 3px rgba(29,122,67,.08),0 4px 16px rgba(12,85,133,.05)}
.lm-card--exclusive-locked{border-color:#f0ddb6}
.lm-label{display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}
.lm-card__info strong{font-size:18px;color:#13232f}
.lm-card__actions{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:14px;flex-wrap:wrap}
.lm-btn{display:inline-flex;align-items:center;justify-content:center;background:#0c5585;color:#fff;text-decoration:none;border-radius:10px;padding:10px 14px;font-size:14px;font-weight:800}
.lm-link{font-size:13px;color:#0c5585;text-decoration:none;font-weight:800}
.lm-card.is-selected{border-color:#7fb1d3;box-shadow:0 0 0 3px rgba(12,85,133,.08),0 4px 16px rgba(12,85,133,.05)}
.lm-samplebar{margin-top:14px;display:flex;flex-wrap:wrap;gap:10px;align-items:stretch}.lm-samplebar__copy{flex:1 1 280px;background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:12px 14px;color:#50616d;line-height:1.65;font-size:13px;box-shadow:0 4px 16px rgba(12,85,133,.05)}.lm-samplebar__copy strong{display:block;margin-bottom:4px;color:#0c5585;font-size:13px}.lm-samplebar__actions{display:flex;flex-wrap:wrap;gap:10px}.lm-samplebar__actions .lm-btn-main,.lm-samplebar__actions .lm-btn-ghost{min-width:170px}
@media (max-width:960px){.lm-grid{grid-template-columns:1fr}.lm-summary{position:static;order:-1}}
@media (max-width:640px){.lm-card__head{flex-direction:column}.lm-card__badges{justify-content:flex-start}.lm-card__grid{grid-template-columns:1fr}.lm-shell h1{font-size:32px}}
</style>
<div class="lm-market lm-public-wrap">
  <?php echo LeadMarketHelper::renderPublicSurfaceNav('marketplace'); ?>
  <div class="lm-shell">
    <div class="lm-shell__top">
      <div>
        <span class="lm-shell__eyebrow">Buyer-safe marketplace</span>
        <h1>Insurance Leads Marketplace</h1>
        <p>Search masked auto and home leads, filter fast, and open any lead for live checkout.</p>
      </div>
      <?php if ($sampleAutoUrl !== '' || $sampleHomeUrl !== ''): ?>
      <div class="lm-shell__actions">
        <?php if ($sampleAutoUrl !== ''): ?><a href="<?php echo htmlspecialchars($sampleAutoUrl, ENT_QUOTES, 'UTF-8'); ?>" class="lm-btn-ghost">Sample Auto Lead</a><?php endif; ?>
        <?php if ($sampleHomeUrl !== ''): ?><a href="<?php echo htmlspecialchars($sampleHomeUrl, ENT_QUOTES, 'UTF-8'); ?>" class="lm-btn-ghost">Sample Home Lead</a><?php endif; ?>
      </div>
      <?php endif; ?>
    </div>

    <?php echo LeadMarketHelper::renderOpeningPromoBar('lm-launchbar', 'lm-launchbar__badge', 'lm-launchbar__copy'); ?>

    <form action="<?php echo htmlspecialchars($this->marketUrl, ENT_QUOTES, 'UTF-8'); ?>" method="get" class="lm-toolbar">
      <input type="hidden" name="option" value="com_leadmarket">
      <input type="hidden" name="view" value="leads">
      <?php if ($buyerRecognized): ?><input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
      <div class="lm-field">
        <label>State</label>
        <select name="state_code">
          <option value="">All states</option>
          <?php foreach ($states as $st): ?>
            <option value="<?php echo htmlspecialchars($st, ENT_QUOTES, 'UTF-8'); ?>" <?php echo $stateCode === $st ? 'selected' : ''; ?>><?php echo htmlspecialchars($st, ENT_QUOTES, 'UTF-8'); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="lm-field">
        <label>Type</label>
        <select name="lead_type">
          <option value="">All types</option>
          <option value="auto" <?php echo $leadType === 'auto' ? 'selected' : ''; ?>>Auto</option>
          <option value="home" <?php echo $leadType === 'home' ? 'selected' : ''; ?>>Home</option>
        </select>
      </div>
      <div class="lm-field">
        <label>Tier</label>
        <select name="tier">
          <option value="">All tiers</option>
          <option value="premium" <?php echo $tier === 'premium' ? 'selected' : ''; ?>>Premium</option>
          <option value="standard" <?php echo $tier === 'standard' ? 'selected' : ''; ?>>Standard</option>
        </select>
      </div>
      <div class="lm-field">
        <label>Availability</label>
        <select name="availability">
          <option value="">All</option>
          <option value="available" <?php echo $availability === 'available' ? 'selected' : ''; ?>>Available now</option>
          <option value="limited" <?php echo $availability === 'limited' ? 'selected' : ''; ?>>Limited availability</option>
        </select>
      </div>
      <div class="lm-field">
        <label>Sort</label>
        <select name="sort">
          <option value="newest" <?php echo $sort === 'newest' ? 'selected' : ''; ?>>Newest</option>
          <option value="price_asc" <?php echo $sort === 'price_asc' ? 'selected' : ''; ?>>Price low to high</option>
          <option value="price_desc" <?php echo $sort === 'price_desc' ? 'selected' : ''; ?>>Price high to low</option>
          <option value="state_asc" <?php echo $sort === 'state_asc' ? 'selected' : ''; ?>>State A–Z</option>
        </select>
      </div>
      <div class="lm-toolbar__actions">
        <button type="submit" class="lm-btn-main">Apply</button>
        <a href="<?php echo htmlspecialchars($this->marketUrl, ENT_QUOTES, 'UTF-8'); ?>" class="lm-btn-ghost">Reset</a>
      </div>
    </form>
  </div>

  <div class="lm-grid">
    <div class="lm-list">
      <?php if (!$this->items): ?>
        <div class="lm-empty">No recent leads match your current filters. Please adjust your filters and try again.</div>
      <?php else: ?>
        <?php foreach ((array)$this->items as $it): ?>
          <?php $leadRow = (array) $it; $leadBuyerState = $buyerLeadContext[(int) ($leadRow['id'] ?? 0)] ?? array(); echo LeadMarketHelper::renderBuyerLeadCard($leadRow, array('mini'=>false,'show_exclusive'=>true,'show_marketplace_link'=>false,'selectable'=>true,'buyer_email'=>$buyerEmail,'buyer_context'=>$leadBuyerState,'buyer_access_url'=>$buyerAccessUrl)); ?>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>

    <aside class="lm-summary" id="lm-summary" data-buyer-balance="<?php echo htmlspecialchars(number_format($buyerBalance, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" data-buyer-recognized="<?php echo $buyerRecognized ? '1' : '0'; ?>">
      <h3>Shared selection</h3>
      <p><?php echo $buyerRecognized ? 'Wallet and buyer markers are active for this email.' : 'Select leads to build one shared checkout.'; ?></p>
      <div class="lm-summary__notice" id="lm-summary-notice">Availability is rechecked before purchase.</div>
      <div class="lm-summary__helper" id="lm-summary-helper"><?php echo $buyerRecognized ? 'Wallet applies first. Totals update live.' : 'Select leads to see the live total.'; ?></div>
      <?php if ($buyerRecognized): ?>
      <div class="lm-summary__stats">
        <div class="lm-summary__box">
          <span class="lm-summary__label">Wallet balance</span>
          <strong class="lm-summary__value" id="lm-buyer-balance">$<?php echo htmlspecialchars(number_format($buyerBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong>
        </div>
        <div class="lm-summary__box">
          <span class="lm-summary__label">Estimated pay now</span>
          <strong class="lm-summary__value" id="lm-estimated-pay-now">$0.00</strong>
        </div>
      </div>
      <?php endif; ?>
      <div class="lm-summary__stats">
        <div class="lm-summary__box">
          <span class="lm-summary__label">Selected leads</span>
          <strong class="lm-summary__value" id="lm-selected-count">0</strong>
        </div>
        <div class="lm-summary__box">
          <span class="lm-summary__label">Estimated shared total</span>
          <strong class="lm-summary__value" id="lm-selected-total">$0.00</strong>
        </div>
      </div>
      <?php if ($buyerRecognized): ?>
      <div class="lm-summary__buyerline">
        <strong>Buyer recognized:</strong> <?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?> · <strong>Wallet:</strong> $<?php echo htmlspecialchars(number_format($buyerBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> · <strong>Unlocked:</strong> <?php echo (int) $buyerUnlockedCount; ?>
      </div>
      <?php endif; ?>
      <div class="lm-summary__actions">
        <button type="button" class="lm-btn-main" id="lm-proceed-btn" disabled data-loading-text="Opening Secure Checkout...">Proceed to Checkout</button>
        <button type="button" class="lm-btn-ghost" id="lm-clear-btn" disabled>Clear selection</button>
      </div>
      <p style="margin-top:12px;font-size:13px;color:#63737f;" id="lm-checkout-copy">Review the set before payment.</p>
      <div class="lm-inline-buyer" id="lm-buyer-tools">
        <details <?php echo !empty($this->buyerNotice) ? 'open' : ''; ?>>
          <summary>
            <span><?php echo $buyerRecognized ? 'Buyer tools' : 'Use buyer email'; ?></span>
            <span class="lm-inline-buyer__meta"><?php echo $buyerRecognized ? ('Wallet $' . htmlspecialchars(number_format($buyerBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8')) : 'Optional'; ?></span>
          </summary>
          <div class="lm-inline-buyer__body">
            <p class="lm-inline-buyer__copy"><?php echo $buyerRecognized ? 'Use the same buyer email for wallet and access link.' : 'Use buyer email to load wallet and purchased markers.'; ?></p>
            <form action="<?php echo htmlspecialchars($this->marketUrl, ENT_QUOTES, 'UTF-8'); ?>" method="get" class="lm-inline-buyer__form">
              <input type="hidden" name="option" value="com_leadmarket">
              <input type="hidden" name="view" value="leads">
              <?php if ($stateCode !== ''): ?><input type="hidden" name="state_code" value="<?php echo htmlspecialchars($stateCode, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
              <?php if ($leadType !== ''): ?><input type="hidden" name="lead_type" value="<?php echo htmlspecialchars($leadType, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
              <?php if ($tier !== ''): ?><input type="hidden" name="tier" value="<?php echo htmlspecialchars($tier, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
              <?php if ($availability !== ''): ?><input type="hidden" name="availability" value="<?php echo htmlspecialchars($availability, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
              <?php if ($sort !== ''): ?><input type="hidden" name="sort" value="<?php echo htmlspecialchars($sort, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
              <div class="lm-inline-buyer__field">
                <label for="lm_buyer_email_sidebar">Buyer email</label>
                <input id="lm_buyer_email_sidebar" type="email" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>" placeholder="name@example.com">
              </div>
              <div class="lm-inline-buyer__actions">
                <button type="submit" class="lm-btn-main"><?php echo $buyerRecognized ? 'Save buyer email' : 'Use this email'; ?></button>
              </div>
            </form>
            <?php if ($buyerRecognized): ?>
              <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'), ENT_QUOTES, 'UTF-8'); ?>" method="post" id="lmBuyerAccessLinkForm" class="lm-inline-buyer__secondary-form" data-lm-ajax-access-link="1" data-result-target="#lmBuyerAccessLinkResult">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>">
                <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buyerAccessRequestReturnUrl, ENT_QUOTES, 'UTF-8'); ?>">
                <button type="submit" class="lm-btn-main lm-ajax-btn" data-lm-ajax-submit data-loading-text="Sending access link...">Email me a new buyer access link</button>
              </form>
              <a href="<?php echo htmlspecialchars($clearBuyerUrl, ENT_QUOTES, 'UTF-8'); ?>" class="lm-btn-ghost lm-inline-buyer__clearlink">Clear buyer email</a>
            <?php endif; ?>
            <div id="lmBuyerAccessLinkResult" class="lm-inline-buyer__notice<?php echo $buyerAccessLinkMessage !== '' ? ' lm-inline-buyer__notice--' . htmlspecialchars($buyerAccessLinkTone !== '' ? $buyerAccessLinkTone : 'info', ENT_QUOTES, 'UTF-8') : ''; ?>"<?php echo $buyerAccessLinkMessage !== '' ? '' : ' style="display:none;"'; ?>><?php echo $buyerAccessLinkMessage; ?></div>
            <?php if (!empty($this->buyerNotice)): ?>
              <div class="lm-inline-buyer__notice lm-inline-buyer__notice--info"><?php echo htmlspecialchars((string) $this->buyerNotice, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
          </div>
        </details>
      </div>
    </aside>
  </div>


<form id="lm-batch-form" action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=batchcheckoutsummary'); ?>" method="post" style="display:none;">
  <?php echo JHtml::_('form.token'); ?>
  <input type="hidden" name="selected_ids_csv" id="lm-selected-ids-csv" value="">
  <?php if ($buyerRecognized): ?><input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmail, ENT_QUOTES, 'UTF-8'); ?>"><?php endif; ?>
</form>
  <?php if ($paginationHtml !== ''): ?>
    <div style="margin-top:18px;"><?php echo $paginationHtml; ?></div>
  <?php endif; ?>
</div>

<script>
window.lmTrackEvent = window.lmTrackEvent || function(name, props){
  try {
    var payload = new FormData();
    payload.append('event_name', name || '');
    payload.append('props_json', JSON.stringify(props || {}));
    if (navigator.sendBeacon) {
      navigator.sendBeacon('<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=api.track', false), ENT_QUOTES, 'UTF-8'); ?>', payload);
      return;
    }
    if (window.fetch) {
      fetch('<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=api.track', false), ENT_QUOTES, 'UTF-8'); ?>', {method:'POST', credentials:'same-origin', body:payload, keepalive:true});
    }
  } catch(e) {}
};
</script>
<script>
(function(){
  var boxes = Array.prototype.slice.call(document.querySelectorAll('[data-lm-select]'));
  if (!boxes.length) return;
  var countEl = document.getElementById('lm-selected-count');
  var totalEl = document.getElementById('lm-selected-total');
  var proceedBtn = document.getElementById('lm-proceed-btn');
  var clearBtn = document.getElementById('lm-clear-btn');
  var notice = document.getElementById('lm-summary-notice');
  var form = document.getElementById('lm-batch-form');
  var csvInput = document.getElementById('lm-selected-ids-csv');
  var STORE_KEY = 'lm_shared_selection_v1';
  var checkoutCopy = document.getElementById('lm-checkout-copy');

  function safeParse(raw){
    try {
      var obj = JSON.parse(raw || '{}');
      return obj && typeof obj === 'object' ? obj : {};
    } catch(e){ return {}; }
  }
  function loadStore(){ return safeParse(window.sessionStorage ? sessionStorage.getItem(STORE_KEY) : '{}'); }
  function saveStore(store){ if (window.sessionStorage) sessionStorage.setItem(STORE_KEY, JSON.stringify(store || {})); }
  function pruneUnavailableVisible(store){
    var cards = Array.prototype.slice.call(document.querySelectorAll('[data-lm-card-id]'));
    cards.forEach(function(card){
      var id = String(parseInt(card.getAttribute('data-lm-card-id') || '0', 10));
      if (!id || id === '0') return;
      var selectable = card.getAttribute('data-shared-selectable') === '1';
      if (!selectable && store[id]) delete store[id];
    });
    return store;
  }
  function normalizeStore(store){
    var out = {};
    Object.keys(store || {}).forEach(function(id){
      var n = parseInt(id, 10);
      if (!n) return;
      var row = store[id] || {};
      out[String(n)] = {
        price: parseFloat(row.price || 0) || 0,
        title: String(row.title || ''),
        ts: row.ts || Date.now()
      };
    });
    return out;
  }
  function syncDomFromStore(){
    var store = pruneUnavailableVisible(normalizeStore(loadStore()));
    boxes.forEach(function(box){
      var id = String(parseInt(box.getAttribute('data-lead-id') || '0', 10));
      box.checked = !!store[id];
    });
    saveStore(store);
    return store;
  }
  function syncStoreFromDom(){
    var store = pruneUnavailableVisible(normalizeStore(loadStore()));
    boxes.forEach(function(box){
      var id = String(parseInt(box.getAttribute('data-lead-id') || '0', 10));
      if (!id || id === '0') return;
      if (box.checked) {
        store[id] = {
          price: parseFloat(box.getAttribute('data-price') || '0') || 0,
          title: String(box.getAttribute('data-title') || ''),
          ts: Date.now()
        };
      } else if (store[id]) {
        delete store[id];
      }
    });
    store = normalizeStore(store);
    saveStore(store);
    return store;
  }
  var summary = document.getElementById('lm-summary');
  var helperEl = document.getElementById('lm-summary-helper');
  var buyerRecognized = summary && summary.getAttribute('data-buyer-recognized') === '1';
  var buyerBalance = summary ? (parseFloat(summary.getAttribute('data-buyer-balance') || '0') || 0) : 0;
  var payNowEl = document.getElementById('lm-estimated-pay-now');

  function render(){
    var store = syncStoreFromDom();
    var ids = Object.keys(store);
    var total = ids.reduce(function(sum, id){ return sum + (parseFloat(store[id].price || 0) || 0); }, 0);
    var walletApplied = buyerRecognized ? Math.min(total, buyerBalance) : 0;
    var shortage = Math.max(0, total - walletApplied);
    if (countEl) countEl.textContent = String(ids.length);
    if (totalEl) totalEl.textContent = '$' + total.toFixed(2);
    if (payNowEl) payNowEl.textContent = '$' + shortage.toFixed(2);
    if (helperEl) {
      if (!ids.length) {
        helperEl.textContent = buyerRecognized ? 'Wallet applies first. Totals update live.' : 'Select leads to see the live total.';
      } else if (buyerRecognized && shortage <= 0.0001) {
        helperEl.textContent = 'Wallet covers this selection. Proceed to checkout to confirm.';
      } else if (buyerRecognized && shortage < 10) {
        helperEl.textContent = 'Wallet applies first. The small remainder may continue through a linked top-up.';
      } else if (buyerRecognized) {
        helperEl.textContent = 'Wallet applies first. Pay-now updates as you change the selection.';
      }
    }
    if (proceedBtn) proceedBtn.disabled = !ids.length;
    if (clearBtn) clearBtn.disabled = !ids.length;
    boxes.forEach(function(box){
      var card = box.closest('.lm-card');
      if (card) card.classList.toggle('is-selected', !!box.checked);
    });
    if (csvInput) csvInput.value = ids.join(',');
    return ids;
  }
  boxes.forEach(function(box){ box.addEventListener('change', function(){ window.lmTrackEvent(box.checked ? 'add_to_batch' : 'remove_from_batch', {lead_id: parseInt(box.getAttribute('data-lead-id')||'0',10)||0, price: parseFloat(box.getAttribute('data-price')||'0')||0, title: String(box.getAttribute('data-title')||'')}); render(); }); });
  if (window.addEventListener) {
    window.addEventListener('pageshow', function(){ syncDomFromStore(); render(); });
  }
  if (clearBtn) clearBtn.addEventListener('click', function(){
    if (window.sessionStorage) sessionStorage.removeItem(STORE_KEY);
    boxes.forEach(function(box){ box.checked = false; });
    render();
  });
  if (proceedBtn) proceedBtn.addEventListener('click', function(){
    var ids = render();
    if (!ids.length) return;
    if (notice) notice.style.display = 'block';
    if (!form) return;
    if (csvInput) csvInput.value = ids.join(',');
    var subtotal = parseFloat((totalEl && totalEl.textContent || '').replace(/[^0-9.]/g,'')) || 0; window.lmTrackEvent('checkout_start', {page_name:'marketplace', mode:'batch', selected_count: ids.length, subtotal: subtotal});
    proceedBtn.disabled = true;
    proceedBtn.textContent = proceedBtn.getAttribute('data-loading-text') || 'Opening Secure Checkout...';
    if (checkoutCopy) checkoutCopy.textContent = 'Please wait while we prepare your checkout session.';
    if (clearBtn) clearBtn.disabled = true;
    form.submit();
  });
  Array.prototype.slice.call(document.querySelectorAll('a[href*="view=lead&id="]')).forEach(function(link){ link.addEventListener('click', function(){ var href = link.getAttribute('href') || ''; var m = href.match(/id=(\d+)/); window.lmTrackEvent('lead_open_click', {lead_id: m ? parseInt(m[1],10)||0 : 0, page_name:'marketplace'}); }); });
  syncDomFromStore();
  render();
})();
</script>

<script>
(function(){
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-open-state')).forEach(function(link){
    link.addEventListener('click', function(){
      link.textContent = link.getAttribute('data-loading-text') || 'Opening...';
      link.style.pointerEvents = 'none';
      link.style.opacity = '0.85';
    });
  });

  function setAjaxResult(node, tone, message){
    if (!node) return;
    node.className = 'lm-inline-buyer__notice lm-inline-buyer__notice--' + (tone || 'info');
    node.innerHTML = message || '';
    node.style.display = 'block';
  }

  Array.prototype.slice.call(document.querySelectorAll('form[data-lm-ajax-access-link]')).forEach(function(form){
    var btn = form.querySelector('[data-lm-ajax-submit]');
    var resultTarget = form.getAttribute('data-result-target') || '';
    var resultNode = resultTarget ? document.querySelector(resultTarget) : null;
    if (!btn) return;
    form.addEventListener('submit', function(ev){
      if (!window.fetch || !window.FormData || !window.URLSearchParams) return;
      ev.preventDefault();
      var originalText = btn.getAttribute('data-original-text') || btn.textContent;
      btn.setAttribute('data-original-text', originalText);
      btn.disabled = true;
      btn.classList.add('is-loading');
      btn.textContent = btn.getAttribute('data-loading-text') || 'Sending...';
      if (resultNode) resultNode.style.display = 'none';
      var body = new URLSearchParams();
      var formData = new FormData(form);
      formData.forEach(function(value, key){ body.append(key, value); });
      body.append('ajax', '1');
      fetch(form.getAttribute('action'), {
        method: 'POST',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'Accept': 'application/json'
        },
        credentials: 'same-origin',
        body: body
      }).then(function(response){
        return response.json().catch(function(){ return null; }).then(function(data){
          if (!data) throw new Error('bad_json');
          if (!response.ok || data.ok === false) {
            var err = new Error(data.message || 'We could not send the buyer access link right now.');
            err.payload = data;
            throw err;
          }
          return data;
        });
      }).then(function(data){
        setAjaxResult(resultNode, data.tone || 'success', data.message || 'Buyer access link sent.');
      }).catch(function(error){
        var payload = error && error.payload ? error.payload : null;
        setAjaxResult(resultNode, (payload && payload.tone) || 'error', (payload && payload.message) || 'We could not send the buyer access link right now.');
      }).finally(function(){
        btn.disabled = false;
        btn.classList.remove('is-loading');
        btn.textContent = originalText;
      });
    });
  });
})();
</script>
