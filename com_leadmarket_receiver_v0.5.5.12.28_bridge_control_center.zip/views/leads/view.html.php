<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketViewLeads extends JViewLegacy
{
  public $items;
  public $pagination;
  public $state;
  public $filters;
  public $marketUrl;
  public $seoContext = array();
  public $buyerEmail = '';
  public $buyerSummary = array();
  public $buyerLeadContext = array();
  public $buyerNotice = '';

  protected function hasExplicitQueryParameter($name)
  {
    $name = (string) $name;
    if ($name === '') {
      return false;
    }

    if (!empty($_SERVER['QUERY_STRING'])) {
      $qs = array();
      parse_str($_SERVER['QUERY_STRING'], $qs);
      if (array_key_exists($name, $qs)) {
        return true;
      }
    }

    return isset($_GET[$name]);
  }

  protected function buildMarketplaceSeoContext()
  {
    $app = JFactory::getApplication();

    $stateCode = strtoupper(trim((string)$app->input->getString('state_code', '')));
    $leadType = strtolower(trim((string)$app->input->getString('lead_type', '')));
    $tier = strtolower(trim((string)$app->input->getString('tier', '')));
    $availability = strtolower(trim((string)$app->input->getString('availability', '')));
    $sort = strtolower(trim((string)$app->input->getString('sort', 'newest')));
    $start = max(0, (int) $app->input->getInt('start', 0));
    $limit = max(1, (int) $app->input->getInt('limit', 20));

    $hasFilters = ($stateCode !== '' || $leadType !== '' || $tier !== '' || $availability !== '' || $sort !== 'newest');
    $hasExplicitStart = $this->hasExplicitQueryParameter('start');
    $hasExplicitLimit = $this->hasExplicitQueryParameter('limit');
    $isPrimaryMarketplace = (!$hasFilters && $start === 0 && !$hasExplicitStart && !$hasExplicitLimit);

    return array(
      'state_code' => $stateCode,
      'lead_type' => $leadType,
      'tier' => $tier,
      'availability' => $availability,
      'sort' => $sort,
      'start' => $start,
      'limit' => $limit,
      'has_filters' => $hasFilters,
      'has_explicit_start' => $hasExplicitStart,
      'has_explicit_limit' => $hasExplicitLimit,
      'is_primary_marketplace' => $isPrimaryMarketplace,
      'should_noindex' => !$isPrimaryMarketplace,
    );
  }

  protected function applyMarketplaceSeo()
  {
    $app = JFactory::getApplication();
    $doc = JFactory::getDocument();
    if (!$doc) {
      return;
    }

    $params = $app->getParams();
    $defaultTitle = 'Insurance Leads Marketplace | Fresh Auto & Home Leads';
    $defaultDescription = 'Browse fresh auto and home insurance leads by state, compare shared pricing, and review live marketplace availability before purchase.';

    $pageTitle = trim((string) $params->get('page_title', ''));
    if ($pageTitle === '') {
      $pageTitle = $defaultTitle;
    }
    $doc->setTitle($pageTitle);

    $metaDescription = trim((string) $params->get('menu-meta_description', ''));
    if ($metaDescription === '') {
      $metaDescription = $defaultDescription;
    }
    if (method_exists($doc, 'setDescription')) {
      $doc->setDescription($metaDescription);
    } else {
      $doc->setMetaData('description', $metaDescription);
    }

    $robots = $this->seoContext['should_noindex'] ? 'noindex, follow' : 'index, follow';
    $doc->setMetaData('robots', $robots);
    try {
      $app->setHeader('X-Robots-Tag', $robots, true);
    } catch (Exception $e) {}
    if (!headers_sent()) {
      header('X-Robots-Tag: ' . $robots, true);
    }

    // Only the clean marketplace root should point to the menu URL as canonical.
    // We intentionally avoid canonicalizing page 2+ to page 1.
    if (!empty($this->marketUrl) && (!$this->seoContext['has_filters']) && $this->seoContext['start'] === 0) {
      if (method_exists($doc, 'addHeadLink')) {
        $doc->addHeadLink($this->marketUrl, 'canonical');
      }
    }
  }

  public function display($tpl = null)
  {
    LeadMarketHelper::trackPageView('marketplace_view', array('page_name' => 'marketplace'));
    $app = JFactory::getApplication();
    $input = $app->input;

    if ((int) $input->getInt('clear_buyer', 0) === 1) {
      LeadMarketHelper::clearActiveBuyerContext();
      $this->buyerNotice = 'Buyer recognition cleared for this session.';
    }

    $buyerEmailInput = trim((string) $input->getString('buyer_email', ''));
    if ($buyerEmailInput === '') {
      $buyerEmailInput = trim((string) $input->post->getString('buyer_email', ''));
    }
    if ($buyerEmailInput !== '') {
      if (filter_var($buyerEmailInput, FILTER_VALIDATE_EMAIL)) {
        LeadMarketHelper::setActiveBuyerContext($buyerEmailInput, 'marketplace');
      } else {
        $this->buyerNotice = 'Enter a valid buyer email to load balance and purchase context.';
      }
    }

    $this->buyerEmail = LeadMarketHelper::getActiveBuyerEmail();
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    $this->state = $this->get('State');
    $this->marketUrl = LeadMarketHelper::getMarketplaceUrl(false);
    $this->seoContext = $this->buildMarketplaceSeoContext();
    $this->filters = array(
      'state_code' => $this->seoContext['state_code'],
      'lead_type' => $this->seoContext['lead_type'],
      'tier' => $this->seoContext['tier'],
      'availability' => $this->seoContext['availability'],
      'sort' => $this->seoContext['sort'],
      'limit' => $this->seoContext['limit'],
    );

    $leadIds = array();
    foreach ((array) $this->items as $it) {
      $leadIds[] = (int) ((is_object($it) ? ($it->id ?? 0) : ($it['id'] ?? 0)));
    }
    $this->buyerSummary = LeadMarketHelper::getMarketplaceBuyerSummary($this->buyerEmail);
    $this->buyerLeadContext = LeadMarketHelper::getMarketplaceLeadBuyerContextMap($leadIds, $this->buyerEmail);

    $this->applyMarketplaceSeo();
    parent::display($tpl);
  }
}
