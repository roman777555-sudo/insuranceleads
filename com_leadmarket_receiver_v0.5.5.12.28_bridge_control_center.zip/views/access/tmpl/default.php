<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';
$sent = !empty($this->sent);
$errorCode = (string)$this->errorCode;
$requestEmail = (string)$this->requestEmail;
$errorText = '';
if ($errorCode === 'invalid_email') {
  $errorText = 'Enter a valid buyer email address and try again.';
} elseif ($errorCode === 'mail_failed') {
  $errorText = 'We created the secure access link, but the email could not be sent. Check Joomla mail settings and the sender email, then try again.';
} elseif ($errorCode === 'table_missing' || $errorCode === 'table_check_failed' || $errorCode === 'db_insert_failed' || $errorCode === 'token_storage_unavailable' || $errorCode === 'token_insert_failed') {
  $errorText = 'We could not create a secure buyer access link right now. Please try again in a moment.';
} elseif ($errorCode === 'link_failed') {
  $errorText = 'We could not create a secure access link right now. Please try again.';
}
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderIframeBreakoutScript(); ?>
<div class="lm-public-wrap">
  <div class="lm-public-hero">
    <span class="lm-public-hero__eyebrow">Buyer access</span>
    <h1 class="lm-public-hero__title">Request your secure buyer link</h1>
    <p class="lm-public-hero__copy">Use the same email that was used to buy the lead or batch. We send a secure magic link so the buyer can reopen purchases, wallet balance, top-ups, and secure order links without using a password.</p>
    <div class="lm-public-chiprow">
      <span class="lm-public-chip">Magic link by email</span>
      <span class="lm-public-chip">No password required</span>
      <span class="lm-public-chip">Secure buyer access</span>
    </div>
  </div>

  <div class="lm-public-panel" style="max-width:760px;margin:0 auto;">
    <h2 class="lm-section-title" style="font-size:28px;margin-bottom:8px;">Request magic link</h2>
    <p class="lm-muted" style="margin:0 0 16px;line-height:1.7;">Use the same buyer email that was used during checkout. The access link expires automatically after <?php echo (int) LeadMarketHelper::getBuyerAccessLifetimeHours(); ?> hours.</p>

    <?php if ($sent): ?>
      <div class="lm-state lm-state--success">
        <strong>Access link sent</strong>
        We sent a secure access link<?php echo $requestEmail !== '' ? ' to <b>' . htmlspecialchars($requestEmail, ENT_QUOTES, 'UTF-8') . '</b>' : ''; ?>. Check the inbox and spam folder, then open the button from the email.
      </div>
    <?php endif; ?>

    <?php if ($errorText !== ''): ?>
      <div class="lm-state lm-state--error">
        <strong>Access link could not be sent</strong>
        <?php echo htmlspecialchars($errorText, ENT_QUOTES, 'UTF-8'); ?>
      </div>
    <?php endif; ?>

    <form class="lm-public-form" action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'); ?>" method="post">
      <?php echo JHtml::_('form.token'); ?>
      <label for="buyer_email">Buyer email</label>
      <input id="buyer_email" name="buyer_email" type="email" required value="<?php echo htmlspecialchars($requestEmail, ENT_QUOTES, 'UTF-8'); ?>">
      <div class="lm-public-form__actions">
        <button type="submit" class="lm-public-btn lm-public-btn--main lm-js-submit-state" data-loading-text="Sending secure link...">Send access link</button>
      </div>
    </form>

    <div class="lm-public-note" style="margin-top:16px;">
      <strong>What this link opens</strong>
      The buyer access page shows purchased leads, batches, wallet balance, recent top-ups, and any linked purchases that are still checking or ready to reopen.
    </div>
  </div>
</div>
