<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketViewAccess extends JViewLegacy
{
  public $sent = false;
  public $errorCode = '';
  public $requestEmail = '';

  protected function applyTechnicalSeoProtection()
  {
    $robots = 'noindex, nofollow';
    $doc = JFactory::getDocument();
    if ($doc && method_exists($doc, 'setMetaData')) {
      $doc->setMetaData('robots', $robots);
    }
    if (!headers_sent()) {
      header('X-Robots-Tag: ' . $robots, true);
    }
    try { JFactory::getApplication()->setHeader('X-Robots-Tag', $robots, true); } catch (Exception $e) {}
  }

  public function display($tpl = null)
  {
    LeadMarketHelper::trackPageView('buyer_access_request_view', array('page_name' => 'access'));
    $this->applyTechnicalSeoProtection();
    LeadMarketHelper::ensureSchema();
    $app = JFactory::getApplication();
    $this->sent = ((int)$app->input->getInt('sent', 0) === 1);
    $this->errorCode = trim((string)$app->input->getString('error', ''));
    $this->requestEmail = LeadMarketHelper::normalizeBuyerEmail(trim((string)$app->input->get('email', '', 'raw')));
    parent::display($tpl);
  }
}
