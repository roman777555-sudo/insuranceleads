<?php defined('_JEXEC') or die; $p = $this->params; ?>
<form action="index.php?option=com_leadmarket&task=config.save" method="post" name="adminForm" id="adminForm">
  <div class="row-fluid">
    <div class="span8">
      <fieldset class="adminform">
        <legend>Mail, brand & admin notifications</legend>
        <div class="control-group">
          <div class="control-label"><label>Send activity emails to admin</label></div>
          <div class="controls"><select name="jform[admin_activity_notify_enabled]"><option value="1" <?php echo ((int)$p->get('admin_activity_notify_enabled',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('admin_activity_notify_enabled',0)===0)?'selected':''; ?>>Disabled</option></select><div class="help-block">Receive email notifications about new orders, new top-ups, and confirmed payments.</div></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Admin activity email</label></div>
          <div class="controls"><input type="text" name="jform[admin_activity_notify_email]" value="<?php echo htmlspecialchars($p->get('admin_activity_notify_email','roman777555123@icloud.com')); ?>" style="width:100%"><div class="help-block">Main inbox for top-up and order notifications. If you can see this field, the admin notification block is installed correctly.</div></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>From Email</label></div>
          <div class="controls"><input type="text" name="jform[from_email]" value="<?php echo htmlspecialchars($p->get('from_email','support@insuranceleads.co')); ?>" style="width:100%"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>From Name</label></div>
          <div class="controls"><input type="text" name="jform[from_name]" value="<?php echo htmlspecialchars($p->get('from_name','InsuranceLeads.co')); ?>" style="width:100%"></div>
        </div>
      </fieldset>

      <fieldset class="adminform">
        <legend>Admin notifications (duplicate visibility check)</legend>
        <div class="control-group">
          <div class="control-label"><label>Send activity emails to admin</label></div>
          <div class="controls"><select name="jform[admin_activity_notify_enabled]"><option value="1" <?php echo ((int)$p->get('admin_activity_notify_enabled',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('admin_activity_notify_enabled',0)===0)?'selected':''; ?>>Disabled</option></select><div class="help-block">When enabled, the component sends you summary emails for new orders, top-ups, and confirmed payments.</div></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Admin activity email</label></div>
          <div class="controls"><input type="text" name="jform[admin_activity_notify_email]" value="<?php echo htmlspecialchars($p->get('admin_activity_notify_email','roman777555123@icloud.com')); ?>" style="width:100%"><div class="help-block">Main notification inbox for top-ups and orders. If you can see this field, the admin notification block is installed correctly.</div></div>
        </div>
      </fieldset>

      <fieldset class="adminform">
        <legend>Crypto (USDT TRC20)</legend>
        <div class="control-group">
          <div class="control-label"><label>USDT TRC20 Address</label></div>
          <div class="controls"><input type="text" name="jform[usdt_trc20_address]" value="<?php echo htmlspecialchars($p->get('usdt_trc20_address','')); ?>" style="width:100%" placeholder="ADDRESS_PLACEHOLDER"></div>
          <p class="help-block">Used for automatic checks via TRONSCAN API. Buyers will see this address on checkout.</p>
        </div>
      </fieldset>

      <fieldset class="adminform">
        <legend>Alerts</legend>

        <div class="control-group">
          <div class="control-label"><label>TRC20 verify enabled</label></div>
          <div class="controls">
            <select name="jform[trc20_verify_enabled]"><option value="1" <?php echo ((int)$p->get('trc20_verify_enabled',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('trc20_verify_enabled',0)===0)?'selected':''; ?>>Disabled</option></select>
            <span class="help-inline">Uses TRONSCAN transfer API for inbound USDT TRC20 checks.</span>
          </div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>TRC20 verify API base</label></div>
          <div class="controls"><input type="text" name="jform[trc20_verify_api_base]" value="<?php echo htmlspecialchars($p->get('trc20_verify_api_base','https://apilist.tronscanapi.com/api/transfer/trc20')); ?>" style="width:100%"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>TRC20 token contract</label></div>
          <div class="controls"><input type="text" name="jform[trc20_token_contract]" value="<?php echo htmlspecialchars($p->get('trc20_token_contract','TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t')); ?>" style="width:100%"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>TRC20 verify API key</label></div>
          <div class="controls"><input type="text" name="jform[trc20_verify_api_key]" value="<?php echo htmlspecialchars($p->get('trc20_verify_api_key','')); ?>" style="width:100%" placeholder="Optional"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>TRC20 time window</label></div>
          <div class="controls">
            <input type="number" name="jform[trc20_time_window_before_minutes]" value="<?php echo (int)$p->get('trc20_time_window_before_minutes',20); ?>" style="width:90px"> min before
            &nbsp;&nbsp;
            <input type="number" name="jform[trc20_time_window_after_minutes]" value="<?php echo (int)$p->get('trc20_time_window_after_minutes',180); ?>" style="width:90px"> min after
          </div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>TRC20 verify fetch limit</label></div>
          <div class="controls"><input type="number" name="jform[trc20_verify_limit]" value="<?php echo (int)$p->get('trc20_verify_limit',50); ?>" style="width:90px"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Amount tolerance</label></div>
          <div class="controls"><input type="text" name="jform[trc20_amount_tolerance]" value="<?php echo htmlspecialchars($p->get('trc20_amount_tolerance','0.01')); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Auto confirm matched</label></div>
          <div class="controls"><select name="jform[auto_confirm_matched_payment]"><option value="1" <?php echo ((int)$p->get('auto_confirm_matched_payment',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('auto_confirm_matched_payment',0)===0)?'selected':''; ?>>Disabled</option></select></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Order event log</label></div>
          <div class="controls"><select name="jform[enable_order_event_log]"><option value="1" <?php echo ((int)$p->get('enable_order_event_log',1)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('enable_order_event_log',1)===0)?'selected':''; ?>>Disabled</option></select></div>
        </div>

        <div class="control-group">
          <div class="control-label"><label>Background verify</label></div>
          <div class="controls"><select name="jform[background_verify_enabled]"><option value="1" <?php echo ((int)$p->get('background_verify_enabled',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('background_verify_enabled',0)===0)?'selected':''; ?>>Disabled</option></select></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Background verify secret</label></div>
          <div class="controls"><input type="text" name="jform[background_verify_secret]" value="<?php echo htmlspecialchars($p->get('background_verify_secret','')); ?>" style="width:60%"> <span class="help-inline">Required for cron endpoint</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Background interval (minutes)</label></div>
          <div class="controls"><input type="number" name="jform[background_verify_interval_minutes]" value="<?php echo (int)$p->get('background_verify_interval_minutes',5); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Background batch limit</label></div>
          <div class="controls"><input type="number" name="jform[background_verify_batch_limit]" value="<?php echo (int)$p->get('background_verify_batch_limit',25); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Amount reuse quarantine (minutes)</label></div>
          <div class="controls"><input type="number" name="jform[amount_reuse_quarantine_minutes]" value="<?php echo (int)$p->get('amount_reuse_quarantine_minutes',1440); ?>"> <span class="help-inline">Expired/checking/mismatch amounts stay reserved during this window.</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Amount reuse delay (short statuses, minutes)</label></div>
          <div class="controls"><input type="number" name="jform[amount_reuse_short_minutes]" value="<?php echo (int)$p->get('amount_reuse_short_minutes',1440); ?>"> <span class="help-inline">Used for mismatch / cancelled / failed / expired / refunded amounts.</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Amount reuse delay (paid/confirmed, minutes)</label></div>
          <div class="controls"><input type="number" name="jform[amount_reuse_paid_minutes]" value="<?php echo (int)$p->get('amount_reuse_paid_minutes',4320); ?>"> <span class="help-inline">Used for paid / confirmed amounts before they can return to the pool.</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Amount overflow max extra (USDT)</label></div>
          <div class="controls"><input type="number" name="jform[amount_overflow_max_extra]" value="<?php echo (int)$p->get('amount_overflow_max_extra',5); ?>"> <span class="help-inline">Generator can expand from base.xx up to base+N.xx when the base range is full.</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Include expired late cases</label></div>
          <div class="controls"><select name="jform[background_verify_include_expired_late]"><option value="1" <?php echo ((int)$p->get('background_verify_include_expired_late',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('background_verify_include_expired_late',0)===0)?'selected':''; ?>>Disabled</option></select></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Verify retry limit</label></div>
          <div class="controls"><input type="number" name="jform[background_verify_retry_limit]" value="<?php echo (int)$p->get('background_verify_retry_limit',50); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Verify retry delay (minutes)</label></div>
          <div class="controls"><input type="number" name="jform[background_verify_retry_delay_minutes]" value="<?php echo (int)$p->get('background_verify_retry_delay_minutes',5); ?>"></div>
        </div>

        <div class="control-group">
          <div class="control-label"><label>Checking timeout (minutes)</label></div>
          <div class="controls"><input type="number" name="jform[checking_timeout_minutes]" value="<?php echo (int)$p->get('checking_timeout_minutes',60); ?>"> <span class="help-inline">Regular orders in checking revert if no payment is found in time.</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Late checking timeout (minutes)</label></div>
          <div class="controls"><input type="number" name="jform[late_checking_timeout_minutes]" value="<?php echo (int)$p->get('late_checking_timeout_minutes',180); ?>"> <span class="help-inline">Expired late-payment orders in checking revert if no payment is found in time.</span></div>
        </div>

        <div class="control-group">
          <div class="control-label"><label>Instant alerts</label></div>
          <div class="controls">
            <select name="jform[instant_enabled]">
              <option value="1" <?php echo ((int)$p->get('instant_enabled',1)===1)?'selected':''; ?>>Enabled</option>
              <option value="0" <?php echo ((int)$p->get('instant_enabled',1)===0)?'selected':''; ?>>Disabled</option>
            </select>
          </div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Daily digest</label></div>
          <div class="controls">
            <select name="jform[daily_enabled]">
              <option value="1" <?php echo ((int)$p->get('daily_enabled',1)===1)?'selected':''; ?>>Enabled</option>
              <option value="0" <?php echo ((int)$p->get('daily_enabled',1)===0)?'selected':''; ?>>Disabled</option>
            </select>
            <span class="help-inline">Time is UTC</span>
          </div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Daily time (UTC)</label></div>
          <div class="controls"><input type="text" name="jform[daily_time_utc]" value="<?php echo htmlspecialchars($p->get('daily_time_utc','10:00')); ?>" placeholder="10:00"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Mini widget lead count</label></div>
          <div class="controls"><input type="number" name="jform[mini_widget_limit]" value="<?php echo (int)$p->get('mini_widget_limit',5); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Mini widget hours window</label></div>
          <div class="controls"><input type="number" name="jform[mini_widget_hours]" value="<?php echo (int)$p->get('mini_widget_hours',25); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Mini widget title</label></div>
          <div class="controls"><input type="text" name="jform[mini_widget_title]" value="<?php echo htmlspecialchars($p->get('mini_widget_title','Latest Lead Activity')); ?>" style="width:60%"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Show freshness on marketplace cards</label></div>
          <div class="controls"><select name="jform[marketplace_show_freshness]"><option value="1" <?php echo ((int)$p->get('marketplace_show_freshness',1)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('marketplace_show_freshness',1)===0)?'selected':''; ?>>Disabled</option></select></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Freshness today hours</label></div>
          <div class="controls"><input type="number" name="jform[marketplace_freshness_today_hours]" value="<?php echo (int)$p->get('marketplace_freshness_today_hours',24); ?>"> <span class="help-inline">Within this window, cards show Added today.</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Freshness relative days</label></div>
          <div class="controls"><input type="number" name="jform[marketplace_freshness_relative_days]" value="<?php echo (int)$p->get('marketplace_freshness_relative_days',7); ?>"> <span class="help-inline">After yesterday, cards show Added X days ago until this limit, then switch to Added Mar 10 style.</span></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Reserve minutes (UTC)</label></div>
          <div class="controls"><input type="number" name="jform[reserve_minutes]" value="<?php echo (int)$p->get('reserve_minutes',30); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Exclusive window (hours)</label></div>
          <div class="controls"><input type="number" name="jform[exclusive_hours]" value="<?php echo (int)$p->get('exclusive_hours',3); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Auto shared max sales</label></div>
          <div class="controls"><input type="number" name="jform[auto_shared_max_sales]" value="<?php echo (int)$p->get('auto_shared_max_sales',3); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Home shared max sales</label></div>
          <div class="controls"><input type="number" name="jform[home_shared_max_sales]" value="<?php echo (int)$p->get('home_shared_max_sales',2); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Post-exclusive shared slots</label></div>
          <div class="controls"><input type="number" name="jform[post_exclusive_shared_slots]" value="<?php echo (int)$p->get('post_exclusive_shared_slots',1); ?>"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Cooldown minutes</label></div>
          <div class="controls"><input type="number" name="jform[cooldown_minutes]" value="<?php echo (int)$p->get('cooldown_minutes',5); ?>"></div>
        </div>
      </fieldset>

      <fieldset class="adminform">
        <legend>Cron</legend>
        <div class="control-group">
          <div class="control-label"><label>Cron key</label></div>
          <div class="controls"><input type="text" name="jform[cron_key]" value="<?php echo htmlspecialchars($p->get('cron_key','')); ?>" style="width:60%">
            <span class="help-inline">optional (recommended)</span>
          </div>
        </div>

        <div class="control-group">
          <div class="control-label"><label>Background verify URL</label></div>
          <div class="controls"><code><?php echo htmlspecialchars(JUri::root() . 'index.php?option=com_leadmarket&task=cronverify&key=' . urlencode((string)$p->get('background_verify_secret','YOUR_SECRET'))); ?></code></div>
        </div>
        <div class="control-group">
          <div class="control-label">Daily Digest Cron URL</div>
          <div class="controls"><code><?php echo htmlspecialchars(JUri::root() . 'index.php?option=com_leadmarket&task=crondigest&key=' . urlencode((string)$p->get('cron_key','YOUR_DAILY_KEY'))); ?></code></div>
        </div>
        <div class="control-group">
          <div class="control-label">Mini Widget URL</div>
          <div class="controls"><code><?php echo htmlspecialchars(JUri::root() . 'index.php?option=com_leadmarket&task=widget.market&layout=mini'); ?></code><div class="help-block">Optional query params: &amp;limit=5&amp;hours=25</div></div>
        </div>
      </fieldset>

      <fieldset class="adminform">
        <legend>Email templates</legend>
        <p class="help-block">Use variables: {{state}}, {{type}}, {{count}}, {{now_utc}}, {{leads_html}}, {{list_name}}, {{unsubscribe_url}}, {{reserve_minutes}}, {{exclusive_hours}}, {{market_url}}, {{lead_url}}, {{current_price}}, {{shared_price}}, {{exclusive_option_text}}</p>
        <div class="control-group">
          <div class="control-label"><label>Instant subject</label></div>
          <div class="controls"><input type="text" name="jform[instant_subject_tpl]" value="<?php echo htmlspecialchars($p->get('instant_subject_tpl','New {{state}} {{type}} lead from ${{shared_price}} (UTC)')); ?>" style="width:100%"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Daily subject</label></div>
          <div class="controls"><input type="text" name="jform[daily_subject_tpl]" value="<?php echo htmlspecialchars($p->get('daily_subject_tpl','{{state}} Daily Digest (UTC): {{count}} new leads')); ?>" style="width:100%"></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Instant body (HTML)</label></div>
          <div class="controls"><textarea name="jform[instant_body_tpl]" rows="8" style="width:100%"><?php echo htmlspecialchars($p->get('instant_body_tpl','')); ?></textarea></div>
        </div>
        <div class="control-group">
          <div class="control-label"><label>Daily body (HTML)</label></div>
          <div class="controls"><textarea name="jform[daily_body_tpl]" rows="8" style="width:100%"><?php echo htmlspecialchars($p->get('daily_body_tpl','')); ?></textarea></div>
        </div>
      </fieldset>

      <fieldset class="adminform">
        <legend>Sales rules</legend>
        <div class="control-group"><div class="control-label"><label>Premium multiplier</label></div><div class="controls"><input type="text" name="jform[premium_multiplier]" value="<?php echo htmlspecialchars($p->get('premium_multiplier','1.20')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Standard multiplier</label></div><div class="controls"><input type="text" name="jform[standard_multiplier]" value="<?php echo htmlspecialchars($p->get('standard_multiplier','1.00')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Premium states (CSV)</label></div><div class="controls"><textarea name="jform[premium_states_csv]" rows="3" style="width:100%"><?php echo htmlspecialchars($p->get('premium_states_csv','CA,TX,FL,NY,NJ,PA,IL,OH,GA,NC,MI,VA,WA,MA,AZ,TN,IN,MO,MD,CO,MN,WI,CT,OR,SC')); ?></textarea></div></div>
        <div class="control-group"><div class="control-label"><label>Auto shared / exclusive base</label></div><div class="controls"><input type="text" name="jform[auto_shared_base]" value="<?php echo htmlspecialchars($p->get('auto_shared_base','15')); ?>"> <input type="text" name="jform[auto_exclusive_base]" value="<?php echo htmlspecialchars($p->get('auto_exclusive_base','35')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Home shared / exclusive base</label></div><div class="controls"><input type="text" name="jform[home_shared_base]" value="<?php echo htmlspecialchars($p->get('home_shared_base','25')); ?>"> <input type="text" name="jform[home_exclusive_base]" value="<?php echo htmlspecialchars($p->get('home_exclusive_base','55')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Exclusive buyer block text</label></div><div class="controls"><textarea name="jform[exclusive_buyer_block_text]" rows="3" style="width:100%;max-width:720px;"><?php echo htmlspecialchars($p->get('exclusive_buyer_block_text','Exclusive protected first-contact access for {{hours}} hours|You receive the first protected contact window for this {{type_label}}. {{distribution_note}}')); ?></textarea><div class="help-block">Use one pipe to split title and body. Variables: {{hours}}, {{type_label}}, {{distribution_note}}</div></div></div>
        <div class="control-group"><div class="control-label"><label>Exclusive buyer notice text</label></div><div class="controls"><textarea name="jform[exclusive_buyer_notice_text]" rows="3" style="width:100%;max-width:720px;"><?php echo htmlspecialchars($p->get('exclusive_buyer_notice_text','Checkout: Protected first-contact access|You are purchasing a protected first-contact window for {{hours}} hours on this {{type_label}}. {{distribution_note}}')); ?></textarea><div class="help-block">Use one pipe to split title and body. Variables: {{hours}}, {{type_label}}, {{distribution_note}}</div></div></div>
        <div class="control-group"><div class="control-label"><label>Age multipliers</label></div><div class="controls">0-1h <input type="text" name="jform[age_coef_0_1h]" value="<?php echo htmlspecialchars($p->get('age_coef_0_1h','1.00')); ?>"> 1-3h <input type="text" name="jform[age_coef_1_3h]" value="<?php echo htmlspecialchars($p->get('age_coef_1_3h','0.80')); ?>"> 3-12h <input type="text" name="jform[age_coef_3_12h]" value="<?php echo htmlspecialchars($p->get('age_coef_3_12h','0.60')); ?>"> 12h+ <input type="text" name="jform[age_coef_12p_h]" value="<?php echo htmlspecialchars($p->get('age_coef_12p_h','0.40')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Activity windows</label></div><div class="controls">Fresh <input type="number" name="jform[fresh_max_hours]" value="<?php echo (int)$p->get('fresh_max_hours',12); ?>"> Auto aged <input type="number" name="jform[aged_auto_max_hours]" value="<?php echo (int)$p->get('aged_auto_max_hours',24); ?>"> Home aged <input type="number" name="jform[aged_home_max_hours]" value="<?php echo (int)$p->get('aged_home_max_hours',48); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Older leads in market</label></div><div class="controls"><label style="margin-right:12px;"><input type="checkbox" name="jform[show_archived_unsold_in_market]" value="1" <?php echo (int)$p->get('show_archived_unsold_in_market',1) === 1 ? 'checked' : ''; ?>> Show older unsold leads</label><label><input type="checkbox" name="jform[show_archived_sold_in_market]" value="1" <?php echo (int)$p->get('show_archived_sold_in_market',0) === 1 ? 'checked' : ''; ?>> Show older sold/recycled leads</label></div></div>
        <div class="control-group"><div class="control-label"><label>Older lead price coefs</label></div><div class="controls">Unsold older <input type="text" name="jform[archived_unsold_price_coef]" value="<?php echo htmlspecialchars($p->get('archived_unsold_price_coef','0.45')); ?>"> Sold/recycled older <input type="text" name="jform[archived_sold_price_coef]" value="<?php echo htmlspecialchars($p->get('archived_sold_price_coef','0.25')); ?>"></div></div>
        <p class="help-block">Fresh and aged leads still use the normal age multipliers. Older archived leads can optionally remain visible in the marketplace with separate pricing and badges.</p>
      </fieldset>


      <fieldset class="adminform">
        <legend>Top-up payments</legend>
        <div class="control-group"><div class="control-label"><label>Minimum top-up / transfer amount (USD)</label></div><div class="controls"><input type="text" name="jform[minimum_topup_usd]" value="<?php echo htmlspecialchars($p->get('minimum_topup_usd','10')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Top-up preset amounts (CSV)</label></div><div class="controls"><input type="text" name="jform[topup_presets]" value="<?php echo htmlspecialchars($p->get('topup_presets','10,50,100')); ?>" style="width:100%"></div></div>
        <div class="control-group"><div class="control-label"><label>Allow custom top-up amount</label></div><div class="controls"><select name="jform[topup_allow_custom]"><option value="1" <?php echo ((int)$p->get('topup_allow_custom',1)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('topup_allow_custom',1)===0)?'selected':''; ?>>Disabled</option></select></div></div>
        <div class="control-group"><div class="control-label"><label>Custom top-up minimum (USD)</label></div><div class="controls"><input type="text" name="jform[topup_custom_min]" value="<?php echo htmlspecialchars($p->get('topup_custom_min','10')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Default recommended preset (USD)</label></div><div class="controls"><input type="text" name="jform[topup_default_preset]" value="<?php echo htmlspecialchars($p->get('topup_default_preset','10')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Auto-apply linked top-up on paid</label></div><div class="controls"><select name="jform[topup_auto_apply_on_paid]"><option value="1" <?php echo ((int)$p->get('topup_auto_apply_on_paid',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('topup_auto_apply_on_paid',0)===0)?'selected':''; ?>>Disabled</option></select></div></div>
        <div class="control-group"><div class="control-label"><label>Allow partial wallet usage</label></div><div class="controls"><select name="jform[wallet_allow_partial_usage]"><option value="1" <?php echo ((int)$p->get('wallet_allow_partial_usage',1)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('wallet_allow_partial_usage',1)===0)?'selected':''; ?>>Disabled</option></select></div></div>
        <div class="control-group"><div class="control-label"><label>Allow direct payment when wallet is insufficient</label></div><div class="controls"><select name="jform[wallet_allow_direct_when_insufficient]"><option value="1" <?php echo ((int)$p->get('wallet_allow_direct_when_insufficient',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('wallet_allow_direct_when_insufficient',0)===0)?'selected':''; ?>>Disabled</option></select></div></div>
      </fieldset>

      <fieldset class="adminform">
        <legend>PayPal</legend>
        <div class="control-group"><div class="control-label"><label>PayPal top-ups enabled</label></div><div class="controls"><select name="jform[paypal_enabled]"><option value="1" <?php echo ((int)$p->get('paypal_enabled',0)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('paypal_enabled',0)===0)?'selected':''; ?>>Disabled</option></select><div class="help-block">PayPal is offered only for top-ups up to $10.00.</div></div></div>
        <div class="control-group"><div class="control-label"><label>PayPal Live Client ID</label></div><div class="controls"><input type="text" name="jform[paypal_client_id]" value="<?php echo htmlspecialchars($p->get('paypal_client_id','')); ?>" style="width:100%"></div></div>
        <div class="control-group"><div class="control-label"><label>PayPal Live Client Secret</label></div><div class="controls"><input type="text" name="jform[paypal_client_secret]" value="<?php echo htmlspecialchars($p->get('paypal_client_secret','')); ?>" style="width:100%"></div></div>
        <div class="control-group"><div class="control-label"><label>PayPal Webhook ID</label></div><div class="controls"><input type="text" name="jform[paypal_webhook_id]" value="<?php echo htmlspecialchars($p->get('paypal_webhook_id','')); ?>" style="width:100%"><div class="help-block">Use the webhook ID from your PayPal REST app. Webhook URL: https://insuranceleads.co/index.php?option=com_leadmarket&amp;task=paypalwebhook&amp;format=raw</div></div></div>
      </fieldset>

      <fieldset class="adminform">
        <legend>Western Union</legend>
        <div class="control-group"><div class="control-label"><label>Enable Western Union manual top-up</label></div><div class="controls"><select name="jform[moneygram_enabled]"><option value="1" <?php echo ((int)$p->get('moneygram_enabled',1)===1)?'selected':''; ?>>Enabled</option><option value="0" <?php echo ((int)$p->get('moneygram_enabled',1)===0)?'selected':''; ?>>Disabled</option></select></div></div>
        <div class="control-group"><div class="control-label"><label>Western Union minimum amount (USD)</label></div><div class="controls"><input type="text" name="jform[moneygram_min_amount_usd]" value="<?php echo htmlspecialchars($p->get('moneygram_min_amount_usd','100')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Western Union receiver name</label></div><div class="controls"><input type="text" name="jform[moneygram_receiver_name]" value="<?php echo htmlspecialchars($p->get('moneygram_receiver_name','')); ?>" style="width:100%"></div></div>
        <div class="control-group"><div class="control-label"><label>Western Union receiver country</label></div><div class="controls"><input type="text" name="jform[moneygram_receiver_country]" value="<?php echo htmlspecialchars($p->get('moneygram_receiver_country','Turkey')); ?>"></div></div>
        <div class="control-group"><div class="control-label"><label>Western Union instructions</label></div><div class="controls"><textarea name="jform[moneygram_instructions]" rows="4" style="width:100%;max-width:720px;"><?php echo htmlspecialchars($p->get('moneygram_instructions','Send the transfer through Western Union, then return to the secure top-up page and submit the MTCN / reference number for review.')); ?></textarea></div></div>
      </fieldset>

    </div>
  </div>

  <?php echo JHtml::_('form.token'); ?>
  <input type="hidden" name="task" value="config.save" />
</form>
