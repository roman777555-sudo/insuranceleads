<?php
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';
defined('_JEXEC') or die;
$lead = $this->lead;
$masked = $this->masked;
$order = $this->order;
$normalized = $this->normalized;
$address = trim((string)$this->params->get('usdt_trc20_address', ''));
$slotsLeft = LeadMarketHelper::getAvailableSlots($lead, $order ? (int)$order['id'] : 0);
$saleOptions = isset($this->saleOptions) && is_array($this->saleOptions) ? $this->saleOptions : LeadMarketHelper::getSaleModeOptions($lead, $order ? (int)$order['id'] : 0);
$status = $order ? strtolower((string)$order['status']) : '';
$paymentStatus = $order ? strtolower((string)(isset($order['payment_status']) ? $order['payment_status'] : 'unverified')) : '';
$token = isset($this->token) ? (string)$this->token : '';
$secureOrderUrl = $order ? LeadMarketHelper::getSecureOrderUrl($order, $lead) : '';
$accessDenied = !empty($this->orderAccessDenied);
$isUnlocked = ($order && $status === 'paid');
$singleChecking = ($order && LeadMarketHelper::isBuyerCheckingState($status, $paymentStatus));
$statusLabel = $order ? LeadMarketHelper::getBuyerCheckoutStatusLabel($status, $paymentStatus) : '';
$statusBadgeStyle = $order ? LeadMarketHelper::getBuyerCheckoutBadgeStyle($status, $paymentStatus) : '';
$statusNotice = $order ? LeadMarketHelper::getBuyerCheckoutNotice($status, $paymentStatus, 'single') : null;
$buyerEmailPrefill = isset($this->buyerEmail) ? (string)$this->buyerEmail : '';
$currentBalance = isset($this->currentBalance) ? (float)$this->currentBalance : 0.0;
$defaultSaleMode = !empty($saleOptions['shared']['enabled']) ? 'shared' : (!empty($saleOptions['exclusive']['enabled']) ? 'exclusive' : 'shared');
$sharedPrice = isset($saleOptions['shared']['price_usd']) ? (float)$saleOptions['shared']['price_usd'] : 0.0;
$exclusivePrice = isset($saleOptions['exclusive']['price_usd']) ? (float)$saleOptions['exclusive']['price_usd'] : 0.0;
$minimumTopup = (float) LeadMarketHelper::minimumTopupUsd();
$selectedPreviewPrice = $defaultSaleMode === 'exclusive' ? $exclusivePrice : $sharedPrice;
$checkoutSuggestedOptions = LeadMarketHelper::getSuggestedTopupOptions($selectedPreviewPrice, $currentBalance, 'lead');
$suggestedCheckoutTopup = (float) ($checkoutSuggestedOptions['recommended_amount'] ?? LeadMarketHelper::calculateSuggestedTopup($selectedPreviewPrice, $currentBalance));
$checkoutTopupPresets = array();
foreach ((array) ($checkoutSuggestedOptions['presets'] ?? array()) as $presetRow) {
  $presetAmount = LeadMarketHelper::roundMoney((float) (is_array($presetRow) ? ($presetRow['amount'] ?? 0) : $presetRow));
  if ($presetAmount < $minimumTopup) $presetAmount = $minimumTopup;
  if (!in_array($presetAmount, $checkoutTopupPresets, true)) $checkoutTopupPresets[] = $presetAmount;
}
$allowCustomTopup = !empty($checkoutSuggestedOptions['custom_allowed']);
$customTopupMin = (float) ($checkoutSuggestedOptions['custom_min'] ?? $minimumTopup);
$paypalEnabled = LeadMarketHelper::paypalEnabled();
$paypalTopupMax = (float) LeadMarketHelper::paypalTopupMaxUsd();
$moneygramEnabled = LeadMarketHelper::moneygramEnabled();
$moneygramMin = (float) LeadMarketHelper::moneygramMinimumUsd();
$defaultScenario = 'direct';
if ($selectedPreviewPrice > 0 && $currentBalance >= $selectedPreviewPrice) {
  $defaultScenario = 'balance';
} elseif ($selectedPreviewPrice > 0 && $selectedPreviewPrice < $minimumTopup && $currentBalance < $selectedPreviewPrice) {
  $defaultScenario = 'topup_required';
} elseif ($selectedPreviewPrice > 0 && $currentBalance < $selectedPreviewPrice) {
  $defaultScenario = 'direct_or_topup';
}
$defaultRemainingAfterUnlock = max(0, LeadMarketHelper::roundMoney($currentBalance - $selectedPreviewPrice));
$defaultTopupRemaining = max(0, LeadMarketHelper::roundMoney(max($minimumTopup, $suggestedCheckoutTopup) + $currentBalance - $selectedPreviewPrice));
$leadPurchaseRoute = ($buyerEmailPrefill !== '' && filter_var($buyerEmailPrefill, FILTER_VALIDATE_EMAIL)) ? LeadMarketHelper::determinePurchaseRoute('lead', (int)$lead['id'], $buyerEmailPrefill, $defaultSaleMode) : null;
$alreadyUnlockedForBuyer = !empty($leadPurchaseRoute['already_unlocked']);
$alreadyUnlockedOrder = !empty($leadPurchaseRoute['existing_paid_order']) && is_array($leadPurchaseRoute['existing_paid_order']) ? $leadPurchaseRoute['existing_paid_order'] : null;
$alreadyUnlockedOrderUrl = '';
if ($alreadyUnlockedOrder) { $alreadyUnlockedOrderUrl = LeadMarketHelper::getSecureOrderUrl($alreadyUnlockedOrder, $lead); }
$app = JFactory::getApplication();
$buyerAccessLinkStatus = trim((string) $app->input->getCmd('lm_access_status', ''));
$buyerAccessLinkEmail = trim((string) $app->input->getString('lm_access_email', ''));
$buyerAccessLinkTone = '';
$buyerAccessLinkMessage = '';
$buyerAccessLeadReturnUrl = 'index.php?option=com_leadmarket&view=lead&id=' . (int) ($lead['id'] ?? 0);
if ($buyerEmailPrefill !== '') $buyerAccessLeadReturnUrl .= '&buyer_email=' . urlencode($buyerEmailPrefill);
if ($buyerAccessLinkStatus === 'sent') {
  $buyerAccessLinkTone = 'success';
  $buyerAccessLinkMessage = 'Buyer access link sent' . ($buyerAccessLinkEmail !== '' ? ' to <b>' . htmlspecialchars($buyerAccessLinkEmail, ENT_QUOTES, 'UTF-8') . '</b>.' : '.');
} elseif ($buyerAccessLinkStatus === 'invalid_email') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'Enter a valid buyer email and try again.';
} elseif ($buyerAccessLinkStatus === 'mail_failed') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'The secure link was created, but the email could not be sent right now.';
} elseif ($buyerAccessLinkStatus === 'link_failed') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'We could not create a secure buyer access link right now.';
} elseif ($buyerAccessLinkStatus === 'invalid_token') {
  $buyerAccessLinkTone = 'error';
  $buyerAccessLinkMessage = 'Your session expired. Refresh the page and try again.';
}
?>

<?php if (!empty($this->sampleMode)): ?>
<?php
$sampleLead = $lead;
$sampleContact = (array)($normalized['contact'] ?? array());
$sampleLocation = LeadMarketHelper::formatCityStateZip($sampleContact);
$sampleBadges = LeadMarketHelper::getLeadFeatureBadges($sampleLead);
$sampleDisclaimer = (string)($this->sampleDisclaimer ?? LeadMarketHelper::getDefaultSampleDisclaimer());
$sampleTypeLabel = strtoupper((string)($sampleLead['type'] ?? ($normalized['type'] ?? '')));
$sampleVehicles = (array)($normalized['vehicles'] ?? array());
$sampleDrivers = (array)($normalized['drivers'] ?? array());
$sampleCoverage = (array)($normalized['coverage'] ?? array());
$sampleUnlockHtml = LeadMarketHelper::buildSampleUnlockHtml($sampleLead);
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderIframeBreakoutScript(); ?>
<style>
.lm-sample-wrap{max-width:1080px;margin:24px auto;padding:0 16px;font-family:Arial,sans-serif;color:#13232f}
.lm-sample-card{background:linear-gradient(135deg,#f6fbff 0%,#eef7fd 100%);border:1px solid #d8e7f3;border-radius:20px;padding:24px;box-shadow:0 14px 32px rgba(16,54,82,.08)}
.lm-sample-badge{display:inline-block;padding:7px 12px;border-radius:999px;background:#fff8e7;border:1px solid #f0d999;color:#7a5a00;font-size:12px;font-weight:800;margin-bottom:12px}
.lm-sample-grid{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(280px,.9fr);gap:18px;margin-top:18px}
.lm-sample-box{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:18px;box-shadow:0 8px 24px rgba(16,54,82,.05)}
.lm-sample-title{margin:0 0 10px;font-size:40px;line-height:1.06;color:#0c5585}
.lm-sample-copy{margin:0 0 14px;color:#44545e;line-height:1.7}
.lm-sample-row{display:grid;grid-template-columns:180px 1fr;gap:12px;padding:8px 0;border-top:1px solid #edf3f7}
.lm-sample-row:first-child{border-top:0;padding-top:0}
.lm-sample-k{font-size:12px;font-weight:800;color:#61717f;text-transform:uppercase;letter-spacing:.03em}
.lm-sample-v{font-size:15px;line-height:1.65;color:#13232f}
.lm-sample-chiprow{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 0}
.lm-sample-chip{display:inline-block;background:#eef6fb;color:#0c5585;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:800;border:1px solid #d8e8f3}
.lm-sample-note{background:#fff8e7;border:1px solid #f0d999;border-radius:12px;padding:14px;color:#5d4a11;line-height:1.7}
.lm-sample-detail{margin-top:18px}
.lm-sample-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
.lm-sample-btn{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent}
.lm-sample-btn--main{background:#0c5585;color:#fff}
.lm-sample-btn--ghost{background:#fff;color:#0c5585;border-color:#cfe0eb}
@media(max-width:760px){.lm-sample-grid{grid-template-columns:1fr}.lm-sample-title{font-size:32px}.lm-sample-row{grid-template-columns:1fr}}
</style>
<div class="lm-sample-wrap">
  <div class="lm-sample-card">
    <span class="lm-sample-badge">Sample Lead</span>
    <h1 class="lm-sample-title"><?php echo htmlspecialchars(trim($sampleTypeLabel . ' Lead Preview'), ENT_QUOTES, 'UTF-8'); ?></h1>
    <p class="lm-sample-copy">This sample opens inside the normal lead view so buyers can see how unlocked details appear inside the platform without triggering checkout or billing.</p>
    <?php if (!empty($sampleBadges)): ?>
    <div class="lm-sample-chiprow">
      <?php foreach (array_slice($sampleBadges, 0, 4) as $sampleBadge): ?>
        <span class="lm-sample-chip"><?php echo htmlspecialchars((string)$sampleBadge, ENT_QUOTES, 'UTF-8'); ?></span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="lm-sample-actions">
      <a class="lm-sample-btn lm-sample-btn--main" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Back to Marketplace</a>
      <a class="lm-sample-btn lm-sample-btn--ghost" href="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&view=leads', false), ENT_QUOTES, 'UTF-8'); ?>">Browse Live Leads</a>
    </div>
    <div class="lm-sample-grid">
      <div class="lm-sample-box">
        <div class="lm-sample-row"><div class="lm-sample-k">Name</div><div class="lm-sample-v"><?php echo htmlspecialchars((string)($sampleLead['name'] ?? 'Sample Buyer'), ENT_QUOTES, 'UTF-8'); ?></div></div>
        <div class="lm-sample-row"><div class="lm-sample-k">Email</div><div class="lm-sample-v"><?php echo htmlspecialchars((string)($sampleLead['email'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></div></div>
        <div class="lm-sample-row"><div class="lm-sample-k">Phone</div><div class="lm-sample-v"><?php echo htmlspecialchars((string)($sampleLead['phone'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></div></div>
        <div class="lm-sample-row"><div class="lm-sample-k">Location</div><div class="lm-sample-v"><?php echo htmlspecialchars($sampleLocation !== '' ? $sampleLocation : '—', ENT_QUOTES, 'UTF-8'); ?></div></div>
        <div class="lm-sample-row"><div class="lm-sample-k">Type</div><div class="lm-sample-v"><?php echo htmlspecialchars(ucfirst(strtolower((string)($sampleLead['type'] ?? 'lead'))), ENT_QUOTES, 'UTF-8'); ?></div></div>
        <?php if (count($sampleVehicles) >= 1): ?>
        <div class="lm-sample-row"><div class="lm-sample-k">Vehicles</div><div class="lm-sample-v"><?php echo (int)count($sampleVehicles); ?></div></div>
        <?php endif; ?>
        <?php if (count($sampleDrivers) >= 1): ?>
        <div class="lm-sample-row"><div class="lm-sample-k">Drivers</div><div class="lm-sample-v"><?php echo (int)count($sampleDrivers); ?></div></div>
        <?php endif; ?>
        <?php if (!empty($sampleCoverage['desired_coverage'])): ?>
        <div class="lm-sample-row"><div class="lm-sample-k">Coverage</div><div class="lm-sample-v"><?php echo htmlspecialchars((string)$sampleCoverage['desired_coverage'], ENT_QUOTES, 'UTF-8'); ?></div></div>
        <?php endif; ?>
      </div>
      <div class="lm-sample-box">
        <h2 style="margin:0 0 10px;font-size:24px;color:#0c5585;">Demo Only</h2>
        <div class="lm-sample-note"><?php echo htmlspecialchars($sampleDisclaimer, ENT_QUOTES, 'UTF-8'); ?></div>
        <div style="margin-top:14px;color:#44545e;line-height:1.7;">
          <strong style="display:block;color:#13232f;margin-bottom:6px;">What this shows</strong>
          This page demonstrates the unlocked lead experience using safe placeholder contact data. No balance deduction, order creation, or exclusive reservation happens in sample mode.
        </div>
      </div>
    </div>
    <div class="lm-sample-detail"><?php echo $sampleUnlockHtml; ?></div>
  </div>
</div>
<?php return; ?>
<?php endif; ?>


<?php if (!empty($this->trialMode)): ?>
<?php
$trialLead = $lead;
$trialAccess = is_array($this->trialAccess ?? null) ? $this->trialAccess : array();
$trialContact = (array)($normalized['contact'] ?? array());
$trialVehicles = (array)($normalized['vehicles'] ?? array());
$trialDrivers = (array)($normalized['drivers'] ?? array());
$trialCoverage = (array)($normalized['coverage'] ?? array());
$trialLocation = LeadMarketHelper::formatCityStateZip($trialContact);
$trialBadges = LeadMarketHelper::getLeadFeatureBadges($trialLead);
$trialMarketUrl = LeadMarketHelper::getMarketplaceUrl(false);
$trialMarketCta = LeadMarketHelper::getFreeTestSettings()['market_cta_text'];
$trialTrackedMarketUrl = LeadMarketHelper::buildFreeTestMarketplaceClickUrl((string)($trialAccess['access_token'] ?? ''), $trialMarketUrl);
$trialUnlockHtml = LeadMarketHelper::buildUnlockHtml($trialLead);
$trialSummaryRows = array();
$trialSummaryName = trim((string)($trialContact['name'] ?? ($trialLead['name'] ?? '')));
if ($trialSummaryName !== '') $trialSummaryRows['Name'] = $trialSummaryName;
$trialSummaryEmail = trim((string)($trialContact['email'] ?? ($trialLead['email'] ?? '')));
if ($trialSummaryEmail !== '') $trialSummaryRows['Email'] = $trialSummaryEmail;
$trialSummaryPhone = trim((string)($trialContact['phone'] ?? ($trialLead['phone'] ?? '')));
if ($trialSummaryPhone !== '') $trialSummaryRows['Phone'] = $trialSummaryPhone;
if (trim((string)$trialLocation) !== '') $trialSummaryRows['Location'] = $trialLocation;
$trialSummaryAddress = trim((string)($trialContact['address'] ?? ''));
if ($trialSummaryAddress !== '') $trialSummaryRows['Address'] = $trialSummaryAddress;
$trialSummaryType = trim((string)($trialLead['type'] ?? ''));
if ($trialSummaryType !== '') $trialSummaryRows['Type'] = ucfirst(strtolower($trialSummaryType));
$trialSummaryCoverage = trim((string)($trialCoverage['desired_coverage'] ?? ''));
if ($trialSummaryCoverage !== '') $trialSummaryRows['Coverage'] = $trialSummaryCoverage;
?>
<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderIframeBreakoutScript(); ?>
<style>
.lm-trial-wrap{max-width:1100px;margin:24px auto;padding:0 16px;font-family:Arial,sans-serif;color:#13232f}
.lm-trial-card{background:linear-gradient(135deg,#f6fbff 0%,#eef7fd 100%);border:1px solid #d8e7f3;border-radius:20px;padding:24px;box-shadow:0 14px 32px rgba(16,54,82,.08)}
.lm-trial-badge{display:inline-block;padding:7px 12px;border-radius:999px;background:#e9f7ee;border:1px solid #cbe7d4;color:#1f6a3c;font-size:12px;font-weight:800;margin-bottom:12px}
.lm-trial-title{margin:0 0 10px;font-size:38px;line-height:1.08;color:#0c5585}.lm-trial-copy{margin:0 0 14px;color:#44545e;line-height:1.7}
.lm-trial-chiprow{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 0}.lm-trial-chip{display:inline-block;background:#eef6fb;color:#0c5585;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:800;border:1px solid #d8e8f3}
.lm-trial-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.lm-trial-btn{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent}.lm-trial-btn--main{background:#0c5585;color:#fff}.lm-trial-btn--ghost{background:#fff;color:#0c5585;border-color:#cfe0eb}
.lm-trial-grid{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(280px,.9fr);gap:18px;margin-top:18px}.lm-trial-box{background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:18px;box-shadow:0 8px 24px rgba(16,54,82,.05)}
.lm-trial-row{display:grid;grid-template-columns:180px 1fr;gap:12px;padding:8px 0;border-top:1px solid #edf3f7}.lm-trial-row:first-child{border-top:0;padding-top:0}.lm-trial-k{font-size:12px;font-weight:800;color:#61717f;text-transform:uppercase;letter-spacing:.03em}.lm-trial-v{font-size:15px;line-height:1.65;color:#13232f}
.lm-trial-section{margin-top:18px;background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:18px;box-shadow:0 8px 24px rgba(16,54,82,.05)}
.lm-trial-list{margin:0;padding-left:18px;color:#44545e;line-height:1.8}.lm-trial-list li strong{color:#13232f}
@media(max-width:760px){.lm-trial-grid{grid-template-columns:1fr}.lm-trial-title{font-size:30px}.lm-trial-row{grid-template-columns:1fr}}
</style>
<div class="lm-trial-wrap">
  <div class="lm-trial-card">
    <span class="lm-trial-badge">Free Test Lead</span>
    <h1 class="lm-trial-title"><?php echo htmlspecialchars(trim(strtoupper((string)($trialLead['type'] ?? '')) . ' lead unlocked for trial access'), ENT_QUOTES, 'UTF-8'); ?></h1>
    <p class="lm-trial-copy">This lead is part of your curated free test pool. Contact details are fully visible here, but checkout, reserve, and billing are disabled in trial mode.</p>
    <?php if (!empty($trialBadges)): ?><div class="lm-trial-chiprow"><?php foreach (array_slice($trialBadges, 0, 4) as $trialBadge): ?><span class="lm-trial-chip"><?php echo htmlspecialchars((string)$trialBadge, ENT_QUOTES, 'UTF-8'); ?></span><?php endforeach; ?></div><?php endif; ?>
    <div class="lm-trial-actions">
      <a class="lm-trial-btn lm-trial-btn--main" href="<?php echo htmlspecialchars($trialTrackedMarketUrl, ENT_QUOTES, 'UTF-8'); ?>"><?php echo htmlspecialchars((string)$trialMarketCta, ENT_QUOTES, 'UTF-8'); ?></a>
      <a class="lm-trial-btn lm-trial-btn--ghost" href="<?php echo htmlspecialchars(LeadMarketHelper::getFreeTestPageUrl(false) . '?trial_token=' . urlencode((string)($trialAccess['access_token'] ?? '')), ENT_QUOTES, 'UTF-8'); ?>">Back to free test leads</a>
    </div>
    <div class="lm-trial-grid">
      <div class="lm-trial-box">
        <h2 style="margin:0 0 10px;font-size:24px;color:#0c5585;">Quick overview</h2>
        <?php if (!empty($trialSummaryRows)): ?>
          <?php foreach ($trialSummaryRows as $trialSummaryLabel => $trialSummaryValue): ?>
            <div class="lm-trial-row"><div class="lm-trial-k"><?php echo htmlspecialchars((string)$trialSummaryLabel, ENT_QUOTES, 'UTF-8'); ?></div><div class="lm-trial-v"><?php echo htmlspecialchars((string)$trialSummaryValue, ENT_QUOTES, 'UTF-8'); ?></div></div>
          <?php endforeach; ?>
        <?php else: ?>
          <div style="color:#44545e;line-height:1.75;">No summary fields were available for this lead, but any captured details still appear below.</div>
        <?php endif; ?>
      </div>
      <div class="lm-trial-box">
        <h2 style="margin:0 0 10px;font-size:24px;color:#0c5585;">Trial access notes</h2>
        <div style="color:#44545e;line-height:1.75;">
          <strong style="display:block;color:#13232f;margin-bottom:6px;">Included in your trial</strong>
          This lead can be reviewed in full as part of the free trial pool. It does not create an order, reserve window, or charge your wallet.
        </div>
        <?php if (!empty($trialAccess['expires_at_utc'])): ?><div style="margin-top:12px;color:#44545e;line-height:1.7;"><strong style="color:#13232f;">Trial access expires:</strong> <?php echo htmlspecialchars((string)$trialAccess['expires_at_utc'], ENT_QUOTES, 'UTF-8'); ?> UTC</div><?php endif; ?>
        <div style="margin-top:12px;color:#44545e;line-height:1.7;"><strong style="color:#13232f;">What to do next:</strong> use your alert emails to watch new inventory and open the live marketplace when you want more leads like this.</div>
      </div>
    </div>
    <div class="lm-trial-section">
      <h2 style="margin:0 0 12px;font-size:24px;color:#0c5585;">Full lead details</h2>
      <div style="color:#44545e;line-height:1.75;margin-bottom:12px;">Only captured fields are shown below. Empty values are hidden automatically.</div>
      <?php echo $trialUnlockHtml; ?>
    </div>
  </div>
</div>
<?php return; ?>
<?php endif; ?>

<?php echo LeadMarketHelper::renderPublicSurfaceStyles(); ?>
<?php echo LeadMarketHelper::renderIframeBreakoutScript(); ?>
<style>.lm-checkout-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;max-width:820px}.lm-wallet-box{margin:0 0 14px;padding:14px;border-radius:12px;background:#f8fbfd;border:1px solid #e3edf5;color:#44545e;line-height:1.7}.lm-wallet-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-top:12px}.lm-wallet-stat{background:#fff;border:1px solid #e3edf5;border-radius:12px;padding:12px}.lm-wallet-stat strong{display:block;font-size:12px;text-transform:uppercase;letter-spacing:.03em;color:#607080;margin-bottom:4px}.lm-wallet-stat span{font-size:24px;font-weight:800;color:#13232f}.lm-action-row{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}.lm-action-row button{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;border:1px solid transparent;font-weight:800;cursor:pointer}.lm-action-row button[name=checkout_action][value=instructions]{background:#0c5585;color:#fff}.lm-action-row button[name=checkout_action][value=balance]{background:#1f6b35;color:#fff}.lm-action-row button[name=checkout_action][value=topup]{background:#fff;color:#44545e;border-color:#d5e3ee}.lm-topup-presets{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.lm-topup-preset{display:inline-flex;align-items:center;justify-content:center;min-height:40px;padding:0 14px;border-radius:999px;border:1px solid #d5e3ee;background:#fff;color:#0c5585;font-weight:800;cursor:pointer}.lm-topup-preset.is-active{background:#0c5585;color:#fff;border-color:#0c5585}.lm-option-badge{display:inline-block;margin-top:8px;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:800;border:1px solid #d8e8f3;background:#eef6fb;color:#0c5585}.lm-option-badge--ok{background:#eefaf0;border-color:#cfe5d4;color:#1f6b35}.lm-option-badge--warn{background:#fff8ef;border-color:#eadfc7;color:#7a5c1e}.lm-decision-card{margin:0 0 14px;padding:16px;border-radius:14px;background:#fff;border:1px solid #dbe6ef}.lm-decision-card__title{font-size:20px;font-weight:800;color:#0c5585;margin:0 0 8px}.lm-decision-card__copy{margin:0;color:#44545e;line-height:1.7}.lm-decision-card__list{margin:12px 0 0 18px;color:#44545e;line-height:1.8}.lm-decision-card__list strong{color:#13232f}.lm-checkout-legacy-note{margin-top:12px;padding:14px;border-radius:12px;background:#fff8ef;border:1px solid #eadfc7;color:#7a5c1e;line-height:1.7}.lm-promo-inline{margin:12px 0 10px}.lm-promo-inline__controls{display:flex;flex-wrap:wrap;align-items:center;gap:10px}.lm-promo-inline__toggle{display:inline-flex;align-items:center;justify-content:center;min-height:40px;padding:0 14px;border-radius:999px;border:1px solid #cfe0eb;background:#fff;color:#0c5585;font-weight:800;cursor:pointer;transition:background .18s ease,color .18s ease,border-color .18s ease,opacity .18s ease}.lm-promo-inline__toggle.is-applied{background:#f3f5f7;border-color:#d8e0e7;color:#7a8894}.lm-promo-inline__check{display:none;align-items:center;gap:6px;font-size:13px;font-weight:800;color:#1f6a3c}.lm-promo-inline__check.is-visible{display:inline-flex}.lm-promo-inline__checkmark{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:50%;background:#1f6a3c;color:#fff;font-size:12px;line-height:1}.lm-promo-inline__panel{display:none;max-width:430px;margin-top:10px;padding:12px;border:1px solid #dbe6ef;border-radius:12px;background:linear-gradient(135deg,#fbfdff 0%,#f5faf7 100%)}.lm-promo-inline__panel.is-open{display:block}.lm-promo-inline__label{display:block;margin:0 0 6px;font-weight:700;color:#18384b}.lm-promo-inline__row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.lm-promo-inline__input{flex:1 1 170px;min-height:40px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;background:#fff;color:#18384b}.lm-promo-inline__input.is-applied{background:#f3f5f7;border-color:#d8e0e7;color:#7a8894}.lm-promo-inline__apply,.lm-promo-inline__remove{display:inline-flex;align-items:center;justify-content:center;min-height:40px;padding:0 14px;border-radius:10px;font-weight:700;cursor:pointer}.lm-promo-inline__apply{border:1px solid #0c5585;background:#fff;color:#0c5585}.lm-promo-inline__remove{border:1px solid #d7e2eb;background:#fff;color:#425561}.lm-promo-inline__apply.lm-ajax-btn.is-loading:after,.lm-promo-inline__apply.is-loading:after{border-color:rgba(12,85,133,.22);border-top-color:#0c5585}.lm-promo-inline__apply.is-loading{position:relative;padding-right:34px;pointer-events:none;opacity:.92}.lm-promo-inline__apply.is-loading:after{content:"";position:absolute;right:12px;top:50%;width:15px;height:15px;margin-top:-8px;border-radius:50%;border:2px solid rgba(12,85,133,.22);border-top-color:#0c5585;animation:lmspin .8s linear infinite}.lm-promo-inline__note{margin-top:8px;color:#607080;font-size:12px;line-height:1.6}.lm-promo-inline__status{display:none;margin-top:10px;padding:10px 12px;border-radius:12px;font-size:13px;line-height:1.6}.lm-promo-inline__status--success{border:1px solid #cfe5d4;background:#eefaf0;color:#1f6b35}.lm-promo-inline__status--error{border:1px solid #efd5d5;background:#fff5f5;color:#7a2b2b}.lm-promo-inline__status--info{border:1px solid #d5e6f1;background:#eef6fb;color:#24475d}.lm-promo-inline__summary{display:none;margin-top:10px;border:1px solid #dbe6ef;border-radius:12px;background:#fff;padding:12px}.lm-promo-inline__summary.is-visible{display:block}.lm-promo-badge{display:inline-block;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:800;border:1px solid #cfe7d8;background:#edf8f1;color:#1f6a3c}.lm-promo-badge--soft{border-color:#d8e8f3;background:#eef6fb;color:#0c5585}.lm-promo-inline__summary-title{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 8px}.lm-promo-inline__summary-copy{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;color:#465761;line-height:1.6;font-size:14px}.lm-promo-inline__summary-copy strong{color:#13232f}.lm-promo-order-summary{margin:0 0 12px;padding:12px 14px;border:1px solid #d8e7f3;border-radius:12px;background:#f6fbff}.lm-promo-order-summary__grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px}.lm-promo-order-summary__box{background:#fff;border:1px solid #e3edf5;border-radius:12px;padding:12px}.lm-promo-order-summary__label{display:block;font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px}.lm-checkout-promo-applied{display:inline-flex;align-items:center;gap:6px;margin-top:8px;padding:7px 11px;border-radius:999px;border:1px solid #cfe7d8;background:#edf8f1;color:#1f6b35;font-size:12px;font-weight:800}.lm-hidden{display:none!important}.lm-ajax-btn{position:relative;transition:transform .16s ease,opacity .16s ease}.lm-ajax-btn.is-loading{pointer-events:none;opacity:.92}.lm-ajax-btn.is-loading:after{content:'';position:absolute;right:14px;top:50%;width:16px;height:16px;margin-top:-8px;border-radius:50%;border:2px solid rgba(255,255,255,.45);border-top-color:#fff;animation:lmBtnSpin .7s linear infinite}.lm-public-btn.lm-ajax-btn.is-loading:after{border-color:rgba(255,255,255,.45);border-top-color:#fff}.lm-ajax-result{display:none;margin-top:12px;padding:12px;border-radius:12px;line-height:1.6}.lm-ajax-result--success{border:1px solid #cfe5d4;background:#eefaf0;color:#1f6b35}.lm-ajax-result--error{border:1px solid #efd5d5;background:#fff5f5;color:#7a2b2b}@keyframes lmBtnSpin{to{transform:rotate(360deg)}}@media(max-width:640px){.lm-action-row button{width:100%}}</style>
<div class="lm-public-wrap">
  <div class="lm-public-hero">
    <span class="lm-public-hero__eyebrow"><?php echo $isUnlocked ? 'Secure order access' : 'Buyer-safe lead preview'; ?></span>
    <h1 class="lm-public-hero__title"><?php echo $isUnlocked ? 'Access Unlocked' : 'Lead Preview'; ?></h1>
    <p class="lm-public-hero__copy"><?php echo $isUnlocked ? 'Payment confirmed. Full lead details and secure order context are shown below.' : 'Review the masked lead preview below, compare shared and exclusive paths, and continue into a secure checkout only when this opportunity fits your workflow.'; ?></p>
    <div class="lm-public-hero__actions">
      <a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars(LeadMarketHelper::getMarketplaceUrl(false), ENT_QUOTES, 'UTF-8'); ?>">Back to Marketplace</a>
    </div>
    <?php if (!$isUnlocked): ?>
    <div class="lm-public-chiprow">
      <span class="lm-public-chip">Masked preview</span>
      <span class="lm-public-chip">Shared + Exclusive</span>
      <span class="lm-public-chip">Secure unlock flow</span>
    </div>
    <?php endif; ?>
  </div>
  <div style="background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:22px;box-shadow:0 4px 16px rgba(12,85,133,.05);">
    <h2 style="margin:0 0 10px;font-size:28px;color:#0c5585;">Lead Summary</h2>
    <p style="margin:0 0 16px;line-height:1.6;color:#44545e;"><?php echo $isUnlocked ? 'Your secure access is active. The summary stays here for reference while full contact details appear further down the page.' : 'Review the masked summary below. Complete payment to unlock full contact details.'; ?></p>

    <div style="border:1px solid #e5e5e5;border-radius:12px;padding:16px;background:#fff;">
      <div style="font-size:24px;font-weight:700;margin-bottom:8px;"><?php echo htmlspecialchars(strtoupper($masked['state']) . ' ' . strtoupper($masked['type'])); ?> lead</div>
      <div style="color:#666;font-size:14px;margin-bottom:10px;"><?php echo $isUnlocked ? 'Your payment is confirmed. The preview remains below for reference, and full lead details are unlocked further down the page.' : 'Review the masked preview below. Live availability is checked when you open checkout.'; ?></div>
      <ul style="margin:0 0 12px 20px;line-height:1.8;">
        <li><b>Location:</b> <?php echo htmlspecialchars(trim($masked['city'] . ' ' . $masked['state'] . ' ' . $masked['zip'])); ?></li>
        <li><b>Contact:</b> <?php echo htmlspecialchars($masked['phone_masked'] . ' / ' . $masked['email_masked']); ?></li>
        <?php $tierLabel = LeadMarketHelper::stateTierLabel(isset($lead['state']) ? $lead['state'] : $masked['state']); $activityLabel = ucfirst((string)$lead['lead_status']); ?>
        <li><b>Tier:</b> <?php echo htmlspecialchars($tierLabel); ?></li>
        <li><b>Activity:</b> <?php echo htmlspecialchars($activityLabel); ?></li>
        <?php $addedTimestampLabel = LeadMarketHelper::getLeadAddedTimestampLabel($lead); ?>
        <?php if ($addedTimestampLabel !== ''): ?><li><b>Added:</b> <?php echo htmlspecialchars($addedTimestampLabel, ENT_QUOTES, 'UTF-8'); ?></li><?php endif; ?>
        <?php if (!$isUnlocked): ?>
        <li><b>Shared price:</b> from $<?php echo htmlspecialchars($saleOptions['shared']['price_usd']); ?> (Pay in USDT TRC20)</li>
        <li><b>Exclusive option:</b> <?php echo htmlspecialchars(LeadMarketHelper::getBuyerExclusiveText($lead)); ?></li>
        <li><b>Availability:</b> <?php echo htmlspecialchars(LeadMarketHelper::getBuyerAvailabilityLabel($lead)); ?>. Availability is checked live when opened.</li>
        <?php else: ?>
        <li><b>Order status:</b> Payment confirmed</li>
        <li><b>Access:</b> Full lead details are unlocked below for this secure order.</li>
        <?php endif; ?>
      </ul>
    </div>

    <?php if ($accessDenied): ?>
      <div style="margin-top:18px;border:1px solid #f0d2d2;border-radius:12px;padding:16px;background:#fff;">
        <h2 style="margin:0 0 10px;font-size:24px;color:#9b2d2d;">Access denied</h2>
        <p style="margin:0;line-height:1.6;color:#6a2a2a;">This order requires a valid secure token. The plain order URL is not enough to unlock or manage a purchased lead.</p>
      </div>
    <?php elseif ($order): ?>
      <div style="margin-top:18px;border:1px solid #e5e5e5;border-radius:12px;padding:16px;background:<?php echo $status === 'paid' ? '#eefaf0' : '#fff'; ?>;">
        <h2 style="margin:0 0 10px;font-size:24px;color:<?php echo $status === 'paid' ? '#1f6b35' : '#0c5585'; ?>;"><?php echo $status === 'paid' ? 'Access Unlocked' : 'Checkout Status'; ?></h2>
        <div style="<?php echo $statusBadgeStyle; ?>">Status: <?php echo htmlspecialchars($statusLabel, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php if ($statusNotice): ?>
          <div style="<?php echo LeadMarketHelper::getBuyerNoticeBoxStyle($statusNotice['tone']); ?>"><strong><?php echo htmlspecialchars($statusNotice['title'], ENT_QUOTES, 'UTF-8'); ?>.</strong> <?php echo htmlspecialchars($statusNotice['body'], ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>

        <?php if ($status === 'paid'): ?>
          <?php
            $paidCurrency = !empty($order['expected_currency']) ? $order['expected_currency'] : 'USDT';
            $paymentType = strtolower((string) ($order['payment_type'] ?? 'direct'));
            $walletUsedPaid = (float) ($order['wallet_amount_used_usd'] ?? 0);
            $externalUsedPaid = (float) ($order['external_amount_used_usd'] ?? 0);
            if ($externalUsedPaid <= 0) {
              $externalUsedPaid = isset($order['received_amount']) && $order['received_amount'] !== '' && $order['received_amount'] !== null
                ? (float) $order['received_amount']
                : ((isset($order['expected_amount']) && $order['expected_amount'] !== '' && $order['expected_amount'] !== null) ? (float) $order['expected_amount'] : 0.0);
            }
            $pricePaid = (float) ($order['amount_usd'] ?? 0);
            $balanceAfterPaid = isset($order['balance_after_purchase_usd']) && $order['balance_after_purchase_usd'] !== '' && $order['balance_after_purchase_usd'] !== null
              ? (float) $order['balance_after_purchase_usd']
              : LeadMarketHelper::getBuyerBalance((string) ($order['buyer_email'] ?? ''));
            $paymentTypeLabel = $paymentType === 'topup_linked' ? 'Linked top-up' : ($paymentType === 'balance' ? 'Wallet balance' : ($paymentType === 'hybrid' ? 'Wallet + external payment' : 'Direct payment'));
          ?>
          <p style="margin:0 0 12px;line-height:1.6;">Secure access is active for <b><?php echo htmlspecialchars($order['buyer_email']); ?></b>.</p>
          <div style="margin:0 0 12px;padding:12px 14px;border:1px solid #cfe5d4;border-radius:10px;background:#eefaf0;color:#1f6b35;">
            <div style="font-weight:700;margin:0 0 6px;">Lead price: $<?php echo htmlspecialchars(number_format($pricePaid, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
            <div style="line-height:1.7;">
              <div><b>Payment type:</b> <?php echo htmlspecialchars($paymentTypeLabel, ENT_QUOTES, 'UTF-8'); ?></div>
              <div><b>Applied from existing balance:</b> $<?php echo htmlspecialchars(number_format($walletUsedPaid, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
              <div><b>External / top-up amount used:</b> $<?php echo htmlspecialchars(number_format($externalUsedPaid, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> <?php echo htmlspecialchars($paidCurrency, ENT_QUOTES, 'UTF-8'); ?></div>
              <div><b>Remaining wallet balance:</b> $<?php echo htmlspecialchars(number_format($balanceAfterPaid, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></div>
              <div style="margin-top:6px;">Order ID: <b><?php echo (int)$order['id']; ?></b> &nbsp;•&nbsp; Lead ID: <b><?php echo (int)$lead['id']; ?></b><?php if (!empty($order['paid_at_utc'])): ?> &nbsp;•&nbsp; Paid (UTC): <b><?php echo htmlspecialchars((string)$order['paid_at_utc']); ?></b><?php endif; ?></div>
            </div>
          </div>
          <?php $hasPromoSummary = (!empty($order['promo_code']) || (float) ($order['promo_discount_amount'] ?? 0) > 0); ?>
          <?php if ($hasPromoSummary): ?>
            <?php
              $promoSubtotalPaid = (float) ($order['subtotal_before_discount'] ?? $pricePaid);
              if ($promoSubtotalPaid <= 0) $promoSubtotalPaid = $pricePaid;
              $promoDiscountPaid = (float) ($order['promo_discount_amount'] ?? 0);
              $promoFinalPaid = (float) ($order['total_after_discount'] ?? $pricePaid);
              if ($promoFinalPaid <= 0 && $pricePaid > 0) $promoFinalPaid = $pricePaid;
            ?>
            <div class="lm-promo-order-summary">
              <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 8px;">
                <span class="lm-promo-badge">Promo applied</span>
                <span class="lm-promo-badge lm-promo-badge--soft">Saved in this order</span>
              </div>
              <div style="font-weight:800;color:#14384f;">Promo code <b><?php echo htmlspecialchars((string) ($order['promo_code'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></b> adjusted this lead checkout.</div>
              <div class="lm-promo-order-summary__grid">
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Subtotal</span><strong>$<?php echo htmlspecialchars(number_format($promoSubtotalPaid, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Discount</span><strong>-$<?php echo htmlspecialchars(number_format($promoDiscountPaid, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Final total</span><strong>$<?php echo htmlspecialchars(number_format($promoFinalPaid, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></div>
                <div class="lm-promo-order-summary__box"><span class="lm-promo-order-summary__label">Promo record</span><strong>Stored in order details</strong></div>
              </div>
            </div>
          <?php endif; ?>
          <?php if (strtolower((string)($order['kind'] ?? 'shared')) === 'exclusive'): ?>
            <div style="margin:0 0 12px;padding:12px 14px;border:1px solid #d8e7f3;border-radius:10px;background:#f6fbff;">
              <div style="font-weight:700;color:#0c5585;margin:0 0 6px;"><?php echo htmlspecialchars($saleOptions['exclusive']['block_title'] ?? 'Exclusive access'); ?></div>
              <div style="color:#44545e;line-height:1.6;"><?php echo htmlspecialchars($saleOptions['exclusive']['block_body'] ?? 'You receive the first protected contact window for this lead. Lead distribution is paused during this protected period.'); ?></div>
              <?php if (!empty($lead['exclusive_expires_utc'])): ?>
                <div style="margin-top:6px;color:#44545e;">Protected window ends: <b><?php echo htmlspecialchars((string)$lead['exclusive_expires_utc']); ?> UTC</b></div>
              <?php endif; ?>
            </div>
          <?php endif; ?>
          <?php echo LeadMarketHelper::buildUnlockHtml($lead); ?>
        <?php else: ?>
          <?php $orderPaymentType = strtolower((string) ($order['payment_type'] ?? 'direct')); ?>
          <?php $orderWalletUsed = (float) ($order['wallet_amount_used_usd'] ?? 0); ?>
          <?php $orderExternalUsed = (float) ($order['external_amount_used_usd'] ?? 0); ?>
          <?php $exactTransferAmount = (float) (($order['expected_amount'] ?? ($order['amount_usdt'] ?? 0))); ?>
          <?php $displayExternalAmount = $orderExternalUsed > 0 ? $orderExternalUsed : $exactTransferAmount; ?>
          <?php if ($exactTransferAmount <= 0) $exactTransferAmount = $displayExternalAmount; ?>
          <?php $orderIsHybrid = ($orderPaymentType === 'hybrid' && $orderWalletUsed > 0); ?>
          <?php $directBelowMinimum = ($displayExternalAmount > 0 && $displayExternalAmount < $minimumTopup && !$orderIsHybrid); ?>
          <?php $linkedBuyerBalance = LeadMarketHelper::getBuyerBalance((string) ($order['buyer_email'] ?? '')); ?>
          <?php $linkedSuggestedTopup = LeadMarketHelper::calculateSuggestedTopup((float) ($order['amount_usd'] ?? 0), (float) $linkedBuyerBalance); ?>
          <?php $linkedTopupDefault = (float) max($minimumTopup, $linkedSuggestedTopup); ?>
          <?php $linkedRemaining = max(0, LeadMarketHelper::roundMoney($linkedTopupDefault + $linkedBuyerBalance - (float) ($order['amount_usd'] ?? 0))); ?>
          <?php $linkedTopupPresets = array(); foreach (array($linkedTopupDefault, $minimumTopup, $minimumTopup + 5, $minimumTopup + 10) as $presetAmount) { $presetAmount = LeadMarketHelper::roundMoney($presetAmount); if ($presetAmount < $minimumTopup) $presetAmount = $minimumTopup; if (!in_array($presetAmount, $linkedTopupPresets, true)) $linkedTopupPresets[] = $presetAmount; } ?>
          <?php $showLegacyDirectInstructions = (!$directBelowMinimum && !$orderIsHybrid && in_array($status, array('pending','submitted'), true) && !in_array($paymentStatus, array('checking','matched','late_matched','expired','mismatch','late_no_slots'), true)); ?>
          <?php $showCurrentTopupPlan = (!in_array($status, array('paid','cancelled','failed'), true) && !$orderIsHybrid && !$showLegacyDirectInstructions); ?>
          <?php if ($orderIsHybrid): ?>
            <div class="lm-decision-card" style="margin:0 0 12px 0;">
              <div class="lm-decision-card__title">Pay the rest</div>
              <p class="lm-decision-card__copy">Wallet is used first. Pay only the rest.</p>
              <ul class="lm-decision-card__list">
                <li>Lead price: <strong>$<?php echo htmlspecialchars(number_format((float) ($order['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Wallet used: <strong>$<?php echo htmlspecialchars(number_format((float) $orderWalletUsed, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Pay now: <strong>$<?php echo htmlspecialchars(number_format((float) $displayExternalAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              </ul>
            </div>
          <?php elseif ($directBelowMinimum): ?>
            <div class="lm-decision-card" style="margin:0 0 12px 0;">
              <div class="lm-decision-card__title">Top-up required</div>
              <p class="lm-decision-card__copy">This lead is below the minimum transfer, so it starts with a linked top-up.</p>
              <ul class="lm-decision-card__list">
                <li>Lead price: <strong>$<?php echo htmlspecialchars(number_format((float) ($order['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Minimum transfer in this flow: <strong>$<?php echo htmlspecialchars(number_format($minimumTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Top-up now: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedTopupDefault, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Wallet left after unlock: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedRemaining, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              </ul>
            </div>
          <?php elseif ($showLegacyDirectInstructions): ?>
            <div style="margin:0 0 12px;padding:14px 16px;border:2px solid #f0c36d;border-radius:12px;background:#fff8e8;color:#7a4b00;"><div style="font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;margin:0 0 4px;">Exact transfer amount</div><div style="font-size:30px;font-weight:900;line-height:1.1;"><?php echo htmlspecialchars(number_format((float) $exactTransferAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> USDT</div><div style="margin-top:4px;font-size:13px;">Send this exact amount for automatic matching.</div></div>
            <?php if ($orderExternalUsed > 0 && abs($exactTransferAmount - $orderExternalUsed) >= 0.001): ?>
              <p style="margin:0 0 10px;line-height:1.6;color:#61717f;">Lead amount to cover: <b>$<?php echo htmlspecialchars(number_format((float) $orderExternalUsed, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>. The crypto transfer includes unique cents for automatic matching.</p>
            <?php endif; ?>
          <?php elseif ($showCurrentTopupPlan): ?>
            <div class="lm-decision-card" style="margin:0 0 12px 0;">
              <div class="lm-decision-card__title">Current payment plan</div>
              <p class="lm-decision-card__copy">Your wallet is used first. This lead continues through a linked top-up.</p>
              <ul class="lm-decision-card__list">
                <li>Lead price: <strong>$<?php echo htmlspecialchars(number_format((float) ($order['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Wallet applied: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedBuyerBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Needed for this lead: <strong>$<?php echo htmlspecialchars(number_format(max(0, (float) ($order['amount_usd'] ?? 0) - (float) $linkedBuyerBalance), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Recommended top-up now: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedTopupDefault, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Wallet left after unlock: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedRemaining, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              </ul>
            </div>
          <?php endif; ?>
          <?php if (strtolower((string)($order['kind'] ?? 'shared')) === 'exclusive'): ?>
            <div style="margin:0 0 12px;padding:12px 14px;border:1px solid #d8e7f3;border-radius:10px;background:#f6fbff;">
              <div style="font-weight:700;color:#0c5585;margin:0 0 6px;"><?php echo htmlspecialchars($saleOptions['exclusive']['notice_title'] ?? 'Checkout: Exclusive access'); ?></div>
              <div style="color:#44545e;line-height:1.6;"><?php echo htmlspecialchars($saleOptions['exclusive']['notice_body'] ?? 'You are purchasing a protected first-contact window. Lead distribution is paused during this protected period.'); ?></div>
            </div>
          <?php endif; ?>
          <div style="border:1px solid #e5e5e5;border-radius:10px;padding:12px;background:#fafafa;margin:0 0 12px 0;">
            <?php if (!$showLegacyDirectInstructions): ?>
              <details style="margin:0;"><summary style="cursor:pointer;font-weight:700;margin:0 0 8px;">Previous checkout details</summary><p style="margin:0 0 8px;line-height:1.6;"><b>Order ID:</b> <?php echo (int)$order['id']; ?><br><b>Buyer:</b> <?php echo htmlspecialchars($order['buyer_email']); ?><br><b>Checkout:</b> <?php echo htmlspecialchars(strtolower((string)($order['kind'] ?? 'shared')) === 'exclusive' ? 'Exclusive access' : ucfirst((string)($order['kind'] ?? 'shared'))); ?><br><b>Original lead price:</b> $<?php echo htmlspecialchars(number_format((float) ($order['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?><br><b>Expires (UTC):</b> <?php echo htmlspecialchars($order['expires_at_utc']); ?><br><b>Payment status:</b> <?php echo htmlspecialchars($paymentStatus); ?></p></details><p style="margin:0;line-height:1.6;color:#555;">Use the current payment plan below to continue this lead.</p>
            <?php else: ?>
              <p style="margin:0 0 8px;line-height:1.6;"><b>USDT TRC20 Address:</b><br><span id="lm-pay-address"><?php echo $address !== '' ? htmlspecialchars($address) : 'Address not configured'; ?></span></p>
              <p style="margin:0 0 8px;line-height:1.6;"><b>Order ID:</b> <?php echo (int)$order['id']; ?><br><b>Buyer:</b> <?php echo htmlspecialchars($order['buyer_email']); ?><br><b>Checkout:</b> <?php echo htmlspecialchars(strtolower((string)($order['kind'] ?? 'shared')) === 'exclusive' ? 'Exclusive access' : ucfirst((string)($order['kind'] ?? 'shared'))); ?><?php if ($orderIsHybrid): ?><br><b>Applied from wallet:</b> $<?php echo htmlspecialchars(number_format((float) $orderWalletUsed, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?><br><b>Remaining to pay:</b> $<?php echo htmlspecialchars(number_format((float) $displayExternalAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?><?php else: ?><br><span style="display:inline-block;margin-top:6px;padding:8px 10px;border-radius:10px;background:#fff8e8;border:1px solid #f0c36d;color:#7a4b00;font-weight:800;">Exact crypto transfer: <?php echo htmlspecialchars(number_format((float) $exactTransferAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> USDT</span><?php endif; ?><br><b>Expires (UTC):</b> <?php echo htmlspecialchars($order['expires_at_utc']); ?><br><b>Payment status:</b> <?php echo htmlspecialchars($paymentStatus); ?></p>
              <p style="margin:0 0 8px;line-height:1.6;"><b>Secure access:</b><br><span style="word-break:break-all;"><?php echo htmlspecialchars($secureOrderUrl); ?></span></p>
              <p style="margin:0 0 10px;line-height:1.6;color:#555;">Send the exact amount only. After payment is confirmed, full lead details will be emailed and unlocked on this page.</p>
              <div style="display:flex;gap:10px;flex-wrap:wrap;">
                <button type="button" onclick="navigator.clipboard&&navigator.clipboard.writeText('<?php echo addslashes((string)$address); ?>');this.innerHTML='Copied address';" style="padding:10px 14px;border:1px solid #cfd6dd;border-radius:10px;background:#fff;color:#44525d;font-weight:700;cursor:pointer;">Copy address</button>
                <button type="button" onclick="navigator.clipboard&&navigator.clipboard.writeText('<?php echo addslashes(number_format((float) ($showLegacyDirectInstructions ? $exactTransferAmount : $displayExternalAmount), 2, '.', '')); ?>');this.innerHTML='Copied amount';" style="padding:10px 14px;border:1px solid #cfd6dd;border-radius:10px;background:#fff;color:#44525d;font-weight:700;cursor:pointer;">Copy amount</button>
                <button type="button" onclick="navigator.clipboard&&navigator.clipboard.writeText('<?php echo addslashes($secureOrderUrl); ?>');this.innerHTML='Copied secure link';" style="padding:10px 14px;border:1px solid #cfd6dd;border-radius:10px;background:#fff;color:#44525d;font-weight:700;cursor:pointer;">Copy secure link</button>
              </div>
            <?php endif; ?>
          </div>

          <?php if ($showCurrentTopupPlan): ?>
            <div style="border:1px solid #dbe6ef;border-radius:12px;padding:14px;background:#f8fbfd;margin:0 0 12px 0;">
              <div style="font-size:18px;font-weight:800;color:#0c5585;margin:0 0 8px;">Payment plan for this lead</div>
              <p style="margin:0 0 8px;line-height:1.7;color:#44545e;">$<?php echo htmlspecialchars(number_format(max(0, (float) ($order['amount_usd'] ?? 0) - (float) $linkedBuyerBalance), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?> unlocks this lead. The rest stays in your wallet.</p>
              <ul class="lm-decision-card__list" style="margin:0 0 8px 18px;">
                <li>Selected lead price: <strong>$<?php echo htmlspecialchars(number_format((float) ($order['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Wallet now: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedBuyerBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Minimum transfer: <strong>$<?php echo htmlspecialchars(number_format($minimumTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Top-up now: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedTopupDefault, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Used for this lead: <strong>$<?php echo htmlspecialchars(number_format((float) ($order['amount_usd'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
                <li>Wallet left: <strong>$<?php echo htmlspecialchars(number_format((float) $linkedRemaining, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              </ul>
              <div class="lm-topup-presets">
                <?php foreach ($linkedTopupPresets as $presetAmount): ?>
                  <button type="button" class="lm-topup-preset" data-target="#lm_order_topup_amount" data-amount="<?php echo htmlspecialchars(number_format((float) $presetAmount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">$<?php echo htmlspecialchars(number_format((float) $presetAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></button>
                <?php endforeach; ?>
              </div>
              <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=createtopup'); ?>" method="post" style="margin:0;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
                <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
                <input type="hidden" name="order_token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
                <label style="display:block;margin:0 0 6px;font-weight:700;" for="lm_order_topup_amount">Recommended top-up (USD)</label>
                <input id="lm_order_topup_amount" name="topup_amount_usd" type="number" step="0.01" min="0.01" value="<?php echo htmlspecialchars(number_format((float) $linkedTopupDefault,2,'.',''), ENT_QUOTES, 'UTF-8'); ?>" style="display:block;width:100%;max-width:280px;min-height:46px;padding:0 14px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
                <input type="hidden" name="payment_method" id="lm_order_topup_payment_method" value="<?php echo LeadMarketHelper::isPaypalAllowedForAmount((float) $linkedTopupDefault) ? 'paypal' : 'crypto'; ?>">
                <div style="margin-top:14px;font-weight:800;color:#13232f;font-size:16px;">Step 2. Select funding method</div>
                <div style="margin-top:6px;color:#61717f;line-height:1.6;">These buttons only select how this top-up will be funded. To continue, use the main button below.</div>
                <div class="lm-topup-methods" data-lm-method-group="linked" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
                  <?php if ($paypalEnabled): ?><button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="paypal">Use PayPal</button><?php endif; ?>
                  <button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="crypto">Use Crypto</button>
                  <?php if ($moneygramEnabled): ?><button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="moneygram">Use Western Union</button><?php endif; ?>
                </div>
                <div id="lmOrderTopupMethodNote" style="margin-top:10px;color:#61717f;line-height:1.6;padding:10px 12px;border:1px solid #dbe6ef;border-radius:10px;background:#f8fbfd;">Selected method: <b>Crypto</b>. The next step opens your secure payment page with the wallet address and exact amount.</div>
                <button type="submit" id="lmOrderTopupSubmit" style="display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:0 18px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent;cursor:pointer;background:#0c5585;color:#fff;width:100%;max-width:420px;margin-top:12px;font-size:16px;">Continue to crypto payment</button>
              </form>
            </div>
          <?php endif; ?>

          <?php if ($status === 'pending' && !$directBelowMinimum): ?>
            <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:12px;">
              <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=ipaid'); ?>" method="post" style="margin:0;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
                <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
                <button type="submit" id="lmLeadPaidBtn" style="display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 18px;border:0;border-radius:10px;background:#0c5585;color:#fff;font-weight:700;cursor:pointer;">I Paid</button>
              </form>
              <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=cancelorder'); ?>" method="post" style="margin:0;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
                <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
                <button type="submit" style="padding:12px 18px;border:1px solid #cfd6dd;border-radius:10px;background:#fff;color:#44525d;font-weight:700;cursor:pointer;">Cancel Checkout</button>
              </form>
            </div>
          <?php elseif ($status === 'pending' && $directBelowMinimum): ?>
            <div class="lm-checkout-legacy-note">Direct payment is disabled for this old small checkout. Use the linked top-up above instead.</div>
            <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=cancelorder'); ?>" method="post" style="margin-top:12px;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
              <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
              <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
              <button type="submit" style="padding:12px 18px;border:1px solid #cfd6dd;border-radius:10px;background:#fff;color:#44525d;font-weight:700;cursor:pointer;">Cancel old checkout</button>
            </form>
          <?php elseif ($paymentStatus === 'matched'): ?>
            <div style="margin-top:12px;padding:12px 14px;border-radius:10px;background:#eefaf0;border:1px solid #cfe5d4;color:#1f6b35;">Payment detected and matched. Full details will unlock automatically after confirmation.</div>
          <?php elseif ($paymentStatus === 'late_matched'): ?>
            <div style="margin-top:12px;padding:12px 14px;border-radius:10px;background:#eefaf0;border:1px solid #cfe5d4;color:#1f6b35;">Late payment detected after expiry, but a slot is still available. Your order is ready for approval.</div>
          <?php elseif ($status === 'submitted'): ?>
            <button type="button" disabled="disabled" style="margin-top:12px;display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 18px;border:0;border-radius:10px;background:#0c5585;color:#fff;font-weight:700;opacity:.72;cursor:not-allowed;"><span class="lm-spinner"></span>Checking Payment...</button>
            <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=cancelorder'); ?>" method="post" style="margin-top:12px;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
              <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
              <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
              <button type="submit" style="padding:12px 18px;border:1px solid #cfd6dd;border-radius:10px;background:#fff;color:#44525d;font-weight:700;cursor:pointer;">Cancel Checkout</button>
            </form>
          <?php elseif ($status === 'expired' && $paymentStatus === 'late_no_slots'): ?>
            <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=ipaid'); ?>" method="post" style="margin-top:12px;max-width:560px;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
              <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
              <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
              <label style="display:block;margin:0 0 6px;font-weight:700;" for="refund_wallet_address">Refund wallet address (USDT TRC20)</label>
              <input id="refund_wallet_address" name="refund_wallet_address" type="text" value="<?php echo htmlspecialchars((string)(isset($order['refund_wallet_address']) ? $order['refund_wallet_address'] : ''), ENT_QUOTES, 'UTF-8'); ?>" style="display:block;width:100%;max-width:520px;min-height:44px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
              <label style="display:block;margin:10px 0 6px;font-weight:700;" for="refund_note">Note (optional)</label>
              <textarea id="refund_note" name="refund_note" rows="3" style="display:block;width:100%;max-width:520px;padding:10px 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;"><?php echo htmlspecialchars((string)(isset($order['refund_note']) ? $order['refund_note'] : ''), ENT_QUOTES, 'UTF-8'); ?></textarea>
              <button type="submit" style="margin-top:12px;padding:12px 18px;border:0;border-radius:10px;background:#0c5585;color:#fff;font-weight:700;cursor:pointer;">Submit refund wallet</button>
            </form>
          <?php elseif ($status === 'expired'): ?>
            <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=ipaid'); ?>" method="post" style="margin-top:12px;max-width:560px;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
              <input type="hidden" name="order_id" value="<?php echo (int)$order['id']; ?>">
              <input type="hidden" name="token" value="<?php echo htmlspecialchars($token, ENT_QUOTES, 'UTF-8'); ?>">
              <label style="display:block;margin:0 0 6px;font-weight:700;" for="refund_wallet_address">Refund wallet address (optional, USDT TRC20)</label>
              <input id="refund_wallet_address" name="refund_wallet_address" type="text" value="<?php echo htmlspecialchars((string)(isset($order['refund_wallet_address']) ? $order['refund_wallet_address'] : ''), ENT_QUOTES, 'UTF-8'); ?>" style="display:block;width:100%;max-width:520px;min-height:44px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
              <label style="display:block;margin:10px 0 6px;font-weight:700;" for="refund_note">Note (optional)</label>
              <textarea id="refund_note" name="refund_note" rows="3" style="display:block;width:100%;max-width:520px;padding:10px 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;"><?php echo htmlspecialchars((string)(isset($order['refund_note']) ? $order['refund_note'] : ''), ENT_QUOTES, 'UTF-8'); ?></textarea>
              <button type="submit" style="margin-top:12px;padding:12px 18px;border:0;border-radius:10px;background:#0c5585;color:#fff;font-weight:700;cursor:pointer;">I paid after expiry</button>
            </form>
          <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>
      <?php if ($alreadyUnlockedForBuyer): ?>
      <div style="margin-top:18px;border:1px solid #cfe5d4;border-radius:12px;padding:16px;background:#eefaf0;">
        <h2 style="margin:0 0 10px;font-size:24px;color:#1f6b35;">This lead is already unlocked</h2>
        <p style="margin:0 0 12px;line-height:1.7;color:#44545e;">Access is already available for <b><?php echo htmlspecialchars($buyerEmailPrefill, ENT_QUOTES, 'UTF-8'); ?></b>. You do not need to pay again and your wallet balance will not be charged a second time.</p>
        <div class="lm-action-row" id="lm-buyer-access-tools">
          <?php if ($alreadyUnlockedOrderUrl !== ''): ?><a class="lm-public-btn lm-public-btn--main" href="<?php echo htmlspecialchars($alreadyUnlockedOrderUrl, ENT_QUOTES, 'UTF-8'); ?>">Open lead</a><?php endif; ?>
          <form action="<?php echo htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'), ENT_QUOTES, 'UTF-8'); ?>" method="post" style="margin:0;display:inline-block;" data-lm-ajax-access-link="1" data-result-target="#lm-lead-access-result">
            <?php echo JHtml::_('form.token'); ?>
            <input type="hidden" name="buyer_email" value="<?php echo htmlspecialchars($buyerEmailPrefill, ENT_QUOTES, 'UTF-8'); ?>">
            <input type="hidden" name="return_url" value="<?php echo htmlspecialchars($buyerAccessLeadReturnUrl, ENT_QUOTES, 'UTF-8'); ?>">
            <button type="submit" class="lm-public-btn lm-public-btn--main lm-ajax-btn" data-lm-ajax-submit data-loading-text="Sending access link...">Email buyer access link</button>
          </form>
        </div>
        <div id="lm-lead-access-result" class="lm-ajax-result<?php echo $buyerAccessLinkMessage !== '' ? ' lm-ajax-result--' . htmlspecialchars($buyerAccessLinkTone !== '' ? $buyerAccessLinkTone : 'success', ENT_QUOTES, 'UTF-8') : ''; ?>"<?php echo $buyerAccessLinkMessage !== '' ? ' style="display:block;"' : ''; ?>><?php echo $buyerAccessLinkMessage; ?></div>
      </div>
      <?php else: ?>
      <div style="margin-top:18px;border:1px solid #e5e5e5;border-radius:12px;padding:16px;background:#fff;">
        <h2 style="margin:0 0 10px;font-size:24px;color:#0c5585;">Choose your checkout</h2>
        <p style="margin:0 0 12px;line-height:1.6;color:#44545e;">Enter your buyer email, select the purchase mode, and follow the next step the page recommends. If the selected lead price is below <b>$<?php echo htmlspecialchars(number_format($minimumTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>, the secure purchase starts with a wallet top-up because transfers below the minimum are not supported.</p>
        <?php if (empty($saleOptions['shared']['enabled']) && !empty($saleOptions['exclusive']['window_open'])): ?>
          <div style="margin:0 0 12px;padding:12px 14px;border-radius:10px;background:#fff8ef;border:1px solid #eadfc7;color:#7a5c1e;line-height:1.6;">Shared checkout is temporarily blocked for this lead because another buyer has an active exclusive access window. <?php echo htmlspecialchars((string)($saleOptions['shared']['reason'] ?? ''), ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
        <?php if ($buyerEmailPrefill !== ''): ?>
          <div class="lm-wallet-box">Wallet loaded for <b><?php echo htmlspecialchars($buyerEmailPrefill, ENT_QUOTES, 'UTF-8'); ?></b>.
            <div class="lm-wallet-stats">
              <div class="lm-wallet-stat"><strong>Current balance</strong><span>$<?php echo htmlspecialchars(number_format($currentBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></span></div>
              <div class="lm-wallet-stat"><strong>Shared unlock</strong><span><?php echo $currentBalance >= $sharedPrice ? 'Ready now' : '$' . htmlspecialchars(number_format(LeadMarketHelper::calculateSuggestedTopup($sharedPrice, $currentBalance), 2, '.', ','), ENT_QUOTES, 'UTF-8') . ' top-up needed'; ?></span></div>
              <div class="lm-wallet-stat"><strong>Exclusive unlock</strong><span><?php echo $currentBalance >= $exclusivePrice ? 'Ready now' : '$' . htmlspecialchars(number_format(LeadMarketHelper::calculateSuggestedTopup($exclusivePrice, $currentBalance), 2, '.', ','), ENT_QUOTES, 'UTF-8') . ' top-up needed'; ?></span></div>
            </div>
          </div>
        <?php endif; ?>
        <form action="<?php echo JRoute::_('index.php?option=com_leadmarket&task=buy'); ?>" method="post" id="lmLeadCheckoutForm">
          <?php echo JHtml::_('form.token'); ?>
          <input type="hidden" name="lead_id" value="<?php echo (int)$lead['id']; ?>">
          <label style="display:block;margin:0 0 6px;font-weight:700;" for="buyer_email">Buyer email</label>
          <input id="buyer_email" name="buyer_email" type="email" required value="<?php echo htmlspecialchars($buyerEmailPrefill, ENT_QUOTES, 'UTF-8'); ?>" style="display:block;width:100%;max-width:460px;min-height:48px;padding:0 14px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
          <input type="hidden" name="promo_code" id="lm_promo_code_hidden" value="">
          <input type="hidden" name="payment_method" id="lm_checkout_payment_method" value="<?php echo LeadMarketHelper::isPaypalAllowedForAmount(max($selectedPreviewPrice, 0)) ? 'paypal' : 'crypto'; ?>">
          <div class="lm-checkout-grid" style="margin-top:16px;">
            <?php foreach (array('shared','exclusive') as $modeKey): $opt = $saleOptions[$modeKey]; $optionPrice = (float) ($opt['price_usd'] ?? 0); $optionBalanceReady = ($buyerEmailPrefill !== '' && $currentBalance >= $optionPrice && $optionPrice > 0); $optionNeedsTopup = ($optionPrice > 0 && $optionPrice < $minimumTopup && $currentBalance < $optionPrice); $optionShortfall = LeadMarketHelper::calculateSuggestedTopup($optionPrice, $currentBalance); ?>
              <label style="display:block;border:1px solid <?php echo !empty($opt['enabled']) ? '#cfd9e3' : '#ececec'; ?>;border-radius:12px;padding:14px;background:<?php echo !empty($opt['enabled']) ? '#f9fcff' : '#fafafa'; ?>;">
                <div style="display:flex;align-items:flex-start;gap:10px;">
                  <input type="radio" name="sale_mode" value="<?php echo htmlspecialchars($modeKey); ?>" <?php echo $modeKey === $defaultSaleMode ? 'checked' : ''; ?> <?php echo !empty($opt['enabled']) ? '' : 'disabled'; ?> style="margin-top:4px;" data-price="<?php echo htmlspecialchars(number_format($optionPrice, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" data-enabled="<?php echo !empty($opt['enabled']) ? '1' : '0'; ?>" data-label="<?php echo htmlspecialchars($opt['label'], ENT_QUOTES, 'UTF-8'); ?>">
                  <div>
                    <div style="font-size:20px;font-weight:700;color:#0c5585;"><?php echo htmlspecialchars($opt['label']); ?></div>
                    <div style="margin-top:4px;font-size:16px;"><b>$<?php echo htmlspecialchars($opt['price_usd']); ?></b></div>
                    <?php if ($optionBalanceReady): ?><div class="lm-option-badge lm-option-badge--ok">Wallet ready now</div><?php elseif ($optionNeedsTopup): ?><div class="lm-option-badge lm-option-badge--warn">Top-up first</div><?php else: ?><div class="lm-option-badge">Direct payment instructions available</div><?php endif; ?>
                    <?php if ($modeKey === 'exclusive'): ?>
                      <div style="margin-top:4px;font-size:13px;color:#666;"><?php echo htmlspecialchars($opt['block_title'] ?? 'Exclusive access'); ?></div>
                      <div style="margin-top:4px;font-size:13px;color:#666;line-height:1.5;"><?php echo htmlspecialchars($opt['block_body'] ?? 'You receive the first protected contact window for this lead. Lead distribution is paused during this protected period.'); ?></div>
                    <?php else: ?>
                      <div style="margin-top:4px;font-size:13px;color:#666;line-height:1.5;">Standard secure unlock.</div><?php if ($optionNeedsTopup): ?><div style="margin-top:6px;font-size:13px;color:#7a5c1e;line-height:1.55;">Price: <b>$<?php echo htmlspecialchars(number_format($optionPrice, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>. Minimum: <b>$<?php echo htmlspecialchars(number_format($minimumTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>. Suggested top-up: <b>$<?php echo htmlspecialchars(number_format($optionShortfall, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>.</div><?php endif; ?>
                    <?php endif; ?>
                    <?php if (!empty($opt['reason'])): ?><div style="margin-top:6px;font-size:13px;color:#8a4d00;"><?php echo htmlspecialchars($opt['reason']); ?></div><?php endif; ?>
                  </div>
                </div>
              </label>
            <?php endforeach; ?>
          </div>

          <div class="lm-decision-card" id="lmCheckoutDecision" data-current-balance="<?php echo htmlspecialchars(number_format($currentBalance, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" data-minimum-topup="<?php echo htmlspecialchars(number_format($minimumTopup, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" data-promo-code="" data-promo-discount="0" data-promo-final="0" data-promo-sale-mode="">
            <div class="lm-decision-card__title" id="lmDecisionTitle">Payment plan for this lead</div>
            <p class="lm-decision-card__copy" id="lmDecisionCopy">Pick an option above to see what to pay now.</p>
            <ul class="lm-decision-card__list">
              <li>Option: <strong id="lmDecisionMode"><?php echo htmlspecialchars($defaultSaleMode === 'exclusive' ? ($saleOptions['exclusive']['label'] ?? 'Exclusive') : ($saleOptions['shared']['label'] ?? 'Shared'), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              <li>Lead price: <strong id="lmDecisionPrice">$<?php echo htmlspecialchars(number_format($selectedPreviewPrice, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              <li id="lmDecisionDiscountRow" class="lm-hidden">Promo discount: <strong id="lmDecisionDiscount">$0.00</strong></li>
              <li>Order total: <strong id="lmDecisionTotal">$<?php echo htmlspecialchars(number_format($selectedPreviewPrice, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              <li>Wallet balance: <strong id="lmDecisionBalance">$<?php echo htmlspecialchars(number_format($currentBalance, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></strong></li>
              <li id="lmDecisionWhy">The summary below explains the next step.</li>
              <li id="lmDecisionOutcome">Any extra stays in the wallet.</li>
            </ul>
          </div>

          <div class="lm-wallet-box" id="lmCheckoutTopupBox">
            <div style="font-size:18px;font-weight:800;color:#0c5585;margin:0 0 8px;">Top-up for this lead</div>
            <p style="margin:0 0 8px;line-height:1.7;">Add funds, unlock this lead, keep the rest in the wallet.</p>
            <div class="lm-promo-inline" id="lmPromoInlineWrap">
              <div class="lm-promo-inline__controls">
                <button type="button" id="lmPromoToggleBtn" class="lm-promo-inline__toggle">Apply Promo Code</button>
                <span id="lmPromoAcceptedMark" class="lm-promo-inline__check"><span class="lm-promo-inline__checkmark">✓</span> Promo accepted</span>
              </div>
              <div id="lmPromoInlinePanel" class="lm-promo-inline__panel">
                <label class="lm-promo-inline__label" for="lm_promo_code">Promo code</label>
                <div class="lm-promo-inline__row">
                  <input id="lm_promo_code" class="lm-promo-inline__input" type="text" value="" placeholder="Enter promo code">
                  <button type="button" id="lmApplyPromoBtn" class="lm-promo-inline__apply lm-ajax-btn" data-loading-text="Applying...">Apply</button>
                  <button type="button" id="lmRemovePromoBtn" class="lm-promo-inline__remove lm-hidden">Remove</button>
                </div>
                <div class="lm-promo-inline__note">Apply one code to this checkout. The discount is calculated on the server and updates the final total instantly.</div>
                <div id="lmPromoResult" class="lm-promo-inline__status"></div>
                <div id="lmPromoAppliedCard" class="lm-promo-inline__summary">
                  <div class="lm-promo-inline__summary-title">
                    <span class="lm-promo-badge">Promo applied</span>
                    <span class="lm-promo-badge lm-promo-badge--soft" id="lmPromoAppliedTitle">Discount added to this order</span>
                  </div>
                  <div class="lm-promo-inline__summary-copy">
                    <div>Code: <strong id="lmPromoAppliedCode">—</strong></div>
                    <div>Discount: <strong id="lmPromoAppliedDiscount">$0.00</strong></div>
                    <div>Updated total: <strong id="lmPromoAppliedTotal">$0.00</strong></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="lm-topup-presets">
              <?php foreach ($checkoutTopupPresets as $presetAmount): ?>
                <button type="button" class="lm-topup-preset" data-target="#lm_checkout_topup_amount" data-amount="<?php echo htmlspecialchars(number_format((float) $presetAmount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>">$<?php echo htmlspecialchars(number_format((float) $presetAmount, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></button>
              <?php endforeach; ?>
            </div>
            <label style="display:block;margin:0 0 6px;font-weight:700;" for="lm_checkout_topup_amount">Top-up amount (USD)</label>
            <input id="lm_checkout_topup_amount" name="topup_amount_usd" type="number" step="0.01" min="0.01" value="<?php echo htmlspecialchars(number_format(max($minimumTopup, $suggestedCheckoutTopup), 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>" <?php echo !$allowCustomTopup ? 'readonly="readonly"' : ''; ?> style="display:block;width:100%;max-width:280px;min-height:46px;padding:0 14px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;">
            <div style="margin-top:14px;font-weight:800;color:#13232f;font-size:16px;">Step 2. Select funding method</div>
            <div style="margin-top:6px;color:#61717f;line-height:1.6;">These buttons only select how the top-up will be funded. To continue, use the main action button below.</div>
            <div class="lm-topup-methods" data-lm-method-group="checkout" style="display:flex;gap:8px;flex-wrap:wrap;margin-top:10px;">
              <?php if ($paypalEnabled): ?><button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="paypal">Use PayPal</button><?php endif; ?>
              <button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="crypto">Use Crypto</button>
              <?php if ($moneygramEnabled): ?><button type="button" class="lm-public-btn lm-public-btn--ghost" data-lm-method="moneygram">Use Western Union</button><?php endif; ?>
            </div>
            <div id="lmCheckoutMethodNote" style="margin-top:10px;color:#61717f;line-height:1.6;padding:10px 12px;border:1px solid #dbe6ef;border-radius:10px;background:#f8fbfd;">Selected method: <b>Crypto</b>. The next step opens your secure payment page with the wallet address and exact amount.</div>
            <details style="margin-top:8px;color:#61717f;"><summary style="cursor:pointer;">Why this amount?</summary><div style="margin-top:6px;line-height:1.6;">Crypto minimum: <b>$<?php echo htmlspecialchars(number_format($minimumTopup, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>. Western Union minimum: <b>$<?php echo htmlspecialchars(number_format($moneygramMin, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>. PayPal can be used for smaller top-ups up to <b>$<?php echo htmlspecialchars(number_format($paypalTopupMax, 2, '.', ','), ENT_QUOTES, 'UTF-8'); ?></b>.</div></details>
          </div>

          <div class="lm-action-row">
            <button type="submit" name="checkout_action" value="instructions" id="lmCheckoutPrimaryBtn">Continue</button>
            <button type="submit" name="checkout_action" value="balance" id="lmCheckoutBalanceBtn">Unlock Using Balance</button>
            <button type="submit" name="checkout_action" value="topup" id="lmCheckoutTopupBtn">Top Up</button>
          </div>
          <div style="margin-top:10px;color:#61717f;line-height:1.6;max-width:760px;" id="lmCheckoutHelpText">The summary above follows your selected lead option.</div>
        </form>
      </div>
      <?php endif; ?>
    <?php endif; ?>
<?php if ($order): ?>
<style>
.lm-spinner{display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.45);border-top-color:#fff;border-radius:50%;margin-right:8px;animation:lmspin .8s linear infinite;vertical-align:-2px;}
@keyframes lmspin{to{transform:rotate(360deg);}}
</style>
<script>
(function(){
  var paidForm=document.querySelector('form[action*="task=ipaid"]');
  var paidBtn=document.getElementById('lmLeadPaidBtn');
  if(paidForm&&paidBtn){
    paidForm.addEventListener('submit',function(){
      paidBtn.disabled=true;
      paidBtn.style.opacity='.72';
      paidBtn.style.cursor='not-allowed';
      paidBtn.innerHTML='<span class="lm-spinner"></span>Checking Payment...';
    });
  }
  var shouldPoll=<?php echo $singleChecking ? 'true' : 'false'; ?>;
  if(shouldPoll){
    setTimeout(function(){
      var url=new URL(window.location.href);
      url.searchParams.set('_lmts', String(Date.now()));
      window.location.replace(url.toString());
    }, 10000);
  }
})();
</script>
<?php endif; ?>
<script>
(function(){
  var presetButtons=document.querySelectorAll('.lm-topup-preset');
  function setTopupInputAutoValue(input, value){
    if(!input) return;
    input.setAttribute('data-auto-syncing', '1');
    input.value = value;
    input.setAttribute('data-manual', '0');
    input.setAttribute('data-last-auto', value);
    input.setAttribute('data-auto-syncing', '0');
  }
  presetButtons.forEach(function(btn){
    btn.addEventListener('click', function(){
      var target=document.querySelector(btn.getAttribute('data-target'));
      if(!target) return;
      target.value=btn.getAttribute('data-amount') || '';
      target.setAttribute('data-manual','1');
      var selector='.lm-topup-preset[data-target="'+btn.getAttribute('data-target')+'"]';
      document.querySelectorAll(selector).forEach(function(other){ other.classList.remove('is-active'); });
      btn.classList.add('is-active');
      try{ target.focus(); }catch(e){}
      try{ updateLeadCheckoutDecision(); }catch(e){}
    });
  });

  function money(v){
    var n=parseFloat(v||0);
    if(!isFinite(n)) n=0;
    return '$'+n.toFixed(2);
  }
  var paypalEnabled=<?php echo $paypalEnabled ? 'true' : 'false'; ?>;
  var paypalTopupMax=<?php echo json_encode((float) $paypalTopupMax); ?>;
  var moneygramEnabled=<?php echo $moneygramEnabled ? 'true' : 'false'; ?>;
  var moneygramMin=<?php echo json_encode((float) $moneygramMin); ?>;
  var cryptoMin=<?php echo json_encode((float) $minimumTopup); ?>;
  function isPaypalAllowedAmount(amount){
    var n=parseFloat(amount||0);
    return paypalEnabled && isFinite(n) && n > 0 && n <= paypalTopupMax + 0.0001;
  }
  function isMoneygramAllowedAmount(amount){
    var n=parseFloat(amount||0);
    return moneygramEnabled && isFinite(n) && n + 0.0001 >= moneygramMin;
  }
  function syncMethodGroup(groupName, inputId, hiddenId, noteId){
    var wrap=document.querySelector('[data-lm-method-group="'+groupName+'"]');
    var input=document.getElementById(inputId);
    var hidden=document.getElementById(hiddenId);
    var note=document.getElementById(noteId);
    var submit=(groupName==='linked') ? document.getElementById('lmOrderTopupSubmit') : null;
    if(!wrap || !input || !hidden) return;
    var amount=parseFloat(input.value||0); if(!isFinite(amount)||amount<=0) amount=0;
    var requiredAmount=parseFloat(wrap.getAttribute('data-required-amount')||0); if(!isFinite(requiredAmount)||requiredAmount<0) requiredAmount=0;
    var amountForEligibility=Math.max(amount, requiredAmount);
    var paypalBtn=wrap.querySelector('[data-lm-method="paypal"]');
    var moneygramBtn=wrap.querySelector('[data-lm-method="moneygram"]');
    var current=hidden.value || 'crypto';
    var paypalAllowed=isPaypalAllowedAmount(amountForEligibility);
    var moneygramAllowed=isMoneygramAllowedAmount(amountForEligibility);
    if(current==='paypal' && !paypalAllowed){ current='crypto'; hidden.value=current; }
    if(current==='moneygram' && !moneygramAllowed){ current='crypto'; hidden.value=current; }
    wrap.querySelectorAll('[data-lm-method]').forEach(function(btn){
      var method=btn.getAttribute('data-lm-method')||'crypto';
      var allowed=(method==='paypal') ? paypalAllowed : (method==='moneygram' ? moneygramAllowed : true);
      var active=method===current;
      if(!btn.getAttribute('data-base-label')){ btn.setAttribute('data-base-label', (btn.textContent||'').trim()); }
      var baseLabel=btn.getAttribute('data-base-label') || (btn.textContent||'').trim();
      if(method==='paypal' && !allowed) btn.textContent='Use PayPal · up to '+money(paypalTopupMax);
      else if(method==='moneygram' && !allowed) btn.textContent='Use Western Union · from '+money(moneygramMin);
      else btn.textContent=baseLabel;
      btn.classList.toggle('is-active', active);
      btn.disabled=!allowed;
      btn.setAttribute('aria-disabled', allowed ? 'false' : 'true');
      btn.title = allowed ? '' : (method==='paypal' ? 'Available up to '+money(paypalTopupMax) : 'Available from '+money(moneygramMin));
      btn.style.background=!allowed ? '#eef2f6' : (active ? '#0c5585' : '#fff');
      btn.style.color=!allowed ? '#7f8e9c' : (active ? '#fff' : '#0c5585');
      btn.style.borderColor=!allowed ? '#d6dde5' : (active ? '#0c5585' : '#cfe0eb');
      btn.style.cursor=!allowed ? 'not-allowed' : 'pointer';
      btn.style.opacity=!allowed ? '0.48' : '1';
      btn.style.filter=!allowed ? 'grayscale(0.15)' : 'none';
      btn.style.boxShadow=!allowed ? 'none' : '';
      if(!allowed) btn.classList.remove('is-active');
    });
    if(note){
      if(current==='paypal') note.innerHTML='Selected method: <b>PayPal</b>. The next step opens a secure PayPal checkout. Buyers can pay with PayPal or an eligible card for top-ups up to <b>'+money(paypalTopupMax)+'</b>.';
      else if(current==='moneygram') note.innerHTML='Selected method: <b>Western Union</b>. The next step opens your secure instruction page with receiver details and the MTCN / reference form. Western Union is available from <b>'+money(moneygramMin)+'</b>.';
      else note.innerHTML='Selected method: <b>Crypto</b>. The next step opens your secure payment page with the wallet address and exact amount. Crypto minimum is <b>'+money(cryptoMin)+'</b>.';
      if(!paypalAllowed && paypalBtn){ note.innerHTML += ' <span style="display:block;margin-top:6px;color:#7a5c1e;">PayPal becomes available when the top-up amount is '+money(paypalTopupMax)+' or less.</span>'; }
      if(!moneygramAllowed && moneygramBtn){ note.innerHTML += ' <span style="display:block;margin-top:6px;color:#7a5c1e;">Western Union becomes available from '+money(moneygramMin)+'. Increase the amount to use it.</span>'; }
    }
    if(submit){
      if(current==='paypal') submit.textContent='Continue to PayPal checkout';
      else if(current==='moneygram') submit.textContent='Continue to Western Union instructions';
      else submit.textContent='Continue to crypto payment';
    }
  }
  function bindMethodGroup(groupName, inputId, hiddenId, noteId){
    var wrap=document.querySelector('[data-lm-method-group="'+groupName+'"]');
    var input=document.getElementById(inputId);
    var hidden=document.getElementById(hiddenId);
    if(!wrap || !input || !hidden) return;
    wrap.querySelectorAll('[data-lm-method]').forEach(function(btn){
      btn.addEventListener('click', function(){
        var method=btn.getAttribute('data-lm-method') || 'crypto';
        var amount=parseFloat(input.value||0); if(!isFinite(amount)||amount<=0) amount=0;
        if(method==='paypal' && !isPaypalAllowedAmount(amount)) return;
        if(method==='moneygram' && !isMoneygramAllowedAmount(amount)) return;
        hidden.value=method;
        syncMethodGroup(groupName, inputId, hiddenId, noteId);
        try{ updateLeadCheckoutDecision(); }catch(e){}
      });
    });
    input.addEventListener('input', function(){ syncMethodGroup(groupName, inputId, hiddenId, noteId); });
    syncMethodGroup(groupName, inputId, hiddenId, noteId);
  }

  function promoMessage(type, text){
    var box=document.getElementById('lmPromoResult');
    if(!box) return;
    box.className='lm-promo-inline__status';
    if(!text){ box.style.display='none'; box.textContent=''; return; }
    box.style.display='block';
    box.textContent=text||'';
    if(type==='success'){
      box.classList.add('lm-promo-inline__status--success');
    }else if(type==='error'){
      box.classList.add('lm-promo-inline__status--error');
    }else{
      box.classList.add('lm-promo-inline__status--info');
    }
  }
  function setLeadPromoUiApplied(isApplied){
    var toggle=document.getElementById('lmPromoToggleBtn');
    var mark=document.getElementById('lmPromoAcceptedMark');
    var input=document.getElementById('lm_promo_code');
    var removeBtn=document.getElementById('lmRemovePromoBtn');
    var panel=document.getElementById('lmPromoInlinePanel');
    if(toggle){
      if(isApplied){ toggle.classList.add('is-applied'); toggle.textContent='Promo Code Applied'; }
      else { toggle.classList.remove('is-applied'); toggle.textContent='Apply Promo Code'; }
    }
    if(mark){ mark.classList[isApplied ? 'add' : 'remove']('is-visible'); }
    if(input){
      input.readOnly=!!isApplied;
      input.classList[isApplied ? 'add' : 'remove']('is-applied');
    }
    if(removeBtn){ removeBtn.classList[isApplied ? 'remove' : 'add']('lm-hidden'); }
    if(panel && isApplied){ panel.classList.add('is-open'); }
  }
  function setLeadPromoApplied(data, saleMode){
    var card=document.getElementById('lmPromoAppliedCard');
    var codeNode=document.getElementById('lmPromoAppliedCode');
    var discountNode=document.getElementById('lmPromoAppliedDiscount');
    var totalNode=document.getElementById('lmPromoAppliedTotal');
    var titleNode=document.getElementById('lmPromoAppliedTitle');
    if(codeNode) codeNode.textContent=(data && data.promo_code) ? data.promo_code : '—';
    if(discountNode) discountNode.textContent=money((data && data.discount_amount) ? data.discount_amount : 0);
    if(totalNode) totalNode.textContent=money((data && data.final_total) ? data.final_total : 0);
    if(titleNode) titleNode.textContent=saleMode === 'exclusive' ? 'Exclusive checkout discount ready' : 'Shared checkout discount ready';
    if(card){ card.classList[(data && data.discount_amount) ? 'add' : 'remove']('is-visible'); }
    setLeadPromoUiApplied(!!(data && data.discount_amount));
  }
  function clearLeadPromo(message){
    var decision=document.getElementById('lmCheckoutDecision');
    var hidden=document.getElementById('lm_promo_code_hidden');
    var card=document.getElementById('lmPromoAppliedCard');
    var input=document.getElementById('lm_promo_code');
    var panel=document.getElementById('lmPromoInlinePanel');
    if(decision){
      decision.setAttribute('data-promo-code','');
      decision.setAttribute('data-promo-discount','0');
      decision.setAttribute('data-promo-final','0');
      decision.setAttribute('data-promo-sale-mode','');
    }
    if(hidden) hidden.value='';
    if(input){ input.value=''; }
    if(card) card.classList.remove('is-visible');
    if(panel) panel.classList.remove('is-open');
    setLeadPromoUiApplied(false);
    if(message){ promoMessage('info', message); } else { promoMessage('', ''); }
    updateLeadCheckoutDecision();
  }
  window.updateLeadCheckoutDecision = function(){
    var decision=document.getElementById('lmCheckoutDecision');
    if(!decision) return;
    var currentBalance=parseFloat(decision.getAttribute('data-current-balance')||'0');
    var minimumTopup=parseFloat(decision.getAttribute('data-minimum-topup')||'10');
    var selected=document.querySelector('input[name="sale_mode"]:checked');
    if(!selected) return;
    var basePrice=parseFloat(selected.getAttribute('data-price')||'0');
    var promoSaleMode=decision.getAttribute('data-promo-sale-mode')||'';
    var promoDiscount=parseFloat(decision.getAttribute('data-promo-discount')||'0');
    var promoFinal=parseFloat(decision.getAttribute('data-promo-final')||'0');
    var price=(promoSaleMode===selected.value && promoFinal>0)?promoFinal:basePrice;
    var hasPromo=(promoSaleMode===selected.value && promoDiscount>0 && promoFinal>=0);
    var modeLabel=selected.getAttribute('data-label')||selected.value||'Selected option';
    var title=document.getElementById('lmDecisionTitle');
    var copy=document.getElementById('lmDecisionCopy');
    var mode=document.getElementById('lmDecisionMode');
    var priceNode=document.getElementById('lmDecisionPrice');
    var totalNode=document.getElementById('lmDecisionTotal');
    var discountRow=document.getElementById('lmDecisionDiscountRow');
    var discountNode=document.getElementById('lmDecisionDiscount');
    var balanceNode=document.getElementById('lmDecisionBalance');
    var why=document.getElementById('lmDecisionWhy');
    var outcome=document.getElementById('lmDecisionOutcome');
    var topupBox=document.getElementById('lmCheckoutTopupBox');
    var help=document.getElementById('lmCheckoutHelpText');
    var primary=document.getElementById('lmCheckoutPrimaryBtn');
    var balanceBtn=document.getElementById('lmCheckoutBalanceBtn');
    var topupBtn=document.getElementById('lmCheckoutTopupBtn');
    var topupInput=document.getElementById('lm_checkout_topup_amount');
    var selectedTopup=parseFloat(topupInput && topupInput.value ? topupInput.value : minimumTopup);
    var shortfall=Math.max(0, price-currentBalance);
    var recommendedTopup=shortfall > 0 ? Math.max(minimumTopup, shortfall) : minimumTopup;
    var paymentMethodInput=document.getElementById('lm_checkout_payment_method');
    var selectedMethod=paymentMethodInput ? (paymentMethodInput.value || 'crypto') : 'crypto';
    if(topupInput){
      var currentInputAmount=parseFloat(topupInput.value||0); if(!isFinite(currentInputAmount)||currentInputAmount<=0) currentInputAmount=0;
      var lastAuto=parseFloat(topupInput.getAttribute('data-last-auto')||0); if(!isFinite(lastAuto)||lastAuto<0) lastAuto=0;
      var manual=(topupInput.getAttribute('data-manual')||'0')==='1';
      var autoTarget=(selectedMethod==='paypal' && isPaypalAllowedAmount(shortfall) && shortfall > 0) ? shortfall : recommendedTopup;
      var shouldAutoSync=(!currentInputAmount || !manual || Math.abs(currentInputAmount-lastAuto) < 0.005 || (shortfall > 0 && currentInputAmount + 0.0001 < shortfall));
      if(shouldAutoSync && document.activeElement !== topupInput){
        setTopupInputAutoValue(topupInput, autoTarget.toFixed(2));
        currentInputAmount=autoTarget;
      }
      selectedTopup=currentInputAmount;
    }
    if(!isFinite(selectedTopup) || selectedTopup <= 0) selectedTopup = (selectedMethod==='paypal' && isPaypalAllowedAmount(shortfall) && shortfall > 0) ? shortfall : recommendedTopup;
    if(selectedMethod!=='paypal' && selectedTopup < minimumTopup) selectedTopup = minimumTopup;
    var remainingAfterTopup=Math.max(0, selectedTopup + currentBalance - price);
    if(mode) mode.textContent=modeLabel;
    if(priceNode) priceNode.textContent=money(basePrice);
    if(totalNode) totalNode.textContent=money(price);
    if(balanceNode) balanceNode.textContent=money(currentBalance);
    if(discountRow){ if(hasPromo){ discountRow.classList.remove('lm-hidden'); } else { discountRow.classList.add('lm-hidden'); } }
    if(discountNode) discountNode.textContent=money(promoDiscount);
    if(currentBalance >= price && price > 0){
      if(title) title.textContent='Balance can unlock this lead right now';
      if(copy){ if(hasPromo){ copy.innerHTML='The wallet already covers the discounted total. <span class="lm-checkout-promo-applied">Promo applied</span>'; } else { copy.textContent='The wallet already covers this option.'; } }
      if(why) why.innerHTML='Order total: <strong>'+money(price)+'</strong>.';
      if(outcome) outcome.innerHTML='Wallet left: <strong>'+money(Math.max(0,currentBalance-price))+'</strong>.';
      if(primary){ primary.textContent='Unlock Using Balance'; primary.value='balance'; }
      if(balanceBtn) balanceBtn.classList.add('lm-hidden');
      if(topupBtn) topupBtn.classList.remove('lm-hidden');
      if(topupBox) topupBox.classList.add('lm-hidden');
      if(help) help.innerHTML='Unlock now, or top up only if you want extra wallet credit.';
    } else if(price > 0 && price < minimumTopup){
      if(title) title.textContent='Payment plan for this lead';
      if(copy) copy.innerHTML='Your wallet is used first. This lead continues through a linked top-up.' + (hasPromo ? ' <span class="lm-checkout-promo-applied">Promo applied</span>' : '');
      if(why) why.innerHTML='Order total: <strong>'+money(price)+'</strong>. Top-up now: <strong>'+money(selectedTopup)+'</strong>.';
      if(outcome) outcome.innerHTML='Used for this lead: <strong>'+money(price)+'</strong>. Wallet left after unlock: <strong>'+money(remainingAfterTopup)+'</strong>.';
      if(primary){ primary.textContent=(selectedMethod==='paypal' ? 'Continue to PayPal checkout' : (selectedMethod==='moneygram' ? 'Continue to Western Union instructions' : 'Continue to crypto payment')); primary.value='topup'; }
      if(balanceBtn) balanceBtn.classList.add('lm-hidden');
      if(topupBtn) topupBtn.classList.add('lm-hidden');
      if(topupBox) topupBox.classList.remove('lm-hidden');
      if(help) help.innerHTML='Step 1 selects the amount. Step 2 selects the funding method. The main button continues to the secure payment page.';
    } else {
      if(title) title.textContent='Payment plan for this lead';
      if(copy) copy.innerHTML='Your wallet is used first. You can pay the rest now or top up first.' + (hasPromo ? ' <span class="lm-checkout-promo-applied">Promo applied</span>' : '');
      if(why) why.innerHTML='Order total: <strong>'+money(price)+'</strong>. Pay now: <strong>'+money(shortfall)+'</strong>.';
      if(outcome) outcome.innerHTML='Recommended top-up: <strong>'+money(selectedTopup)+'</strong>. Wallet left after unlock: <strong>'+money(remainingAfterTopup)+'</strong>.';
      if(primary){ primary.textContent=(selectedMethod==='paypal' && isPaypalAllowedAmount(shortfall) ? 'Continue to PayPal checkout' : (selectedMethod==='moneygram' ? 'Continue to Western Union instructions' : 'Continue to crypto payment')); primary.value=(selectedMethod==='paypal' && isPaypalAllowedAmount(shortfall) ? 'topup' : 'instructions'); }
      if(balanceBtn) balanceBtn.classList.add('lm-hidden');
      if(topupBtn) topupBtn.classList.remove('lm-hidden');
      if(topupBox) topupBox.classList.remove('lm-hidden');
      if(help) help.innerHTML=(selectedMethod==='paypal' && isPaypalAllowedAmount(shortfall) ? 'The amount is eligible for PayPal. Use the main button to open the secure checkout.' : (selectedMethod==='moneygram' ? (isMoneygramAllowedAmount(selectedTopup) ? 'Use the main button to open the secure Western Union instruction page.' : 'Western Union is available from '+money(moneygramMin)+'. Increase the top-up amount or choose another method.') : 'Use the main button to open the secure crypto payment page.'));
    }
    var methodWrap=document.querySelector('[data-lm-method-group="checkout"]');
    if(methodWrap){ methodWrap.setAttribute('data-required-amount', String(shortfall > 0 ? Math.max(selectedTopup, shortfall) : selectedTopup)); }
    syncMethodGroup('checkout','lm_checkout_topup_amount','lm_checkout_payment_method','lmCheckoutMethodNote');
  };

  document.querySelectorAll('input[name="sale_mode"]').forEach(function(radio){
    radio.addEventListener('change', function(){ clearLeadPromo('Promo code was cleared because the purchase option changed.'); });
  });
  var topupInput=document.getElementById('lm_checkout_topup_amount');
  if(topupInput){
    topupInput.setAttribute('data-manual','0');
    topupInput.setAttribute('data-last-auto', topupInput.value || '');
    topupInput.addEventListener('input', function(){
      if(topupInput.getAttribute('data-auto-syncing')!=='1') topupInput.setAttribute('data-manual','1');
      updateLeadCheckoutDecision();
    });
  }
  var applyBtn=document.getElementById('lmApplyPromoBtn');
  var removeBtn=document.getElementById('lmRemovePromoBtn');
  var promoToggleBtn=document.getElementById('lmPromoToggleBtn');
  var buyerEmailInput=document.getElementById('buyer_email');
  if(promoToggleBtn){
    promoToggleBtn.addEventListener('click', function(){
      var panel=document.getElementById('lmPromoInlinePanel');
      var input=document.getElementById('lm_promo_code');
      if(promoToggleBtn.classList.contains('is-applied')) return;
      if(panel){ panel.classList.toggle('is-open'); }
      if(panel && panel.classList.contains('is-open') && input){ try{ input.focus(); }catch(e){} }
    });
  }
  if(removeBtn){ removeBtn.addEventListener('click', function(){ clearLeadPromo('Promo removed.'); }); }
  if(buyerEmailInput){ buyerEmailInput.addEventListener('change', function(){ clearLeadPromo('Promo code was cleared because the buyer email changed.'); }); }
  if(applyBtn){
    applyBtn.addEventListener('click', function(){
      var email=document.getElementById('buyer_email');
      var codeInput=document.getElementById('lm_promo_code');
      var selected=document.querySelector('input[name="sale_mode"]:checked');
      if(!email || !(email.value||'').trim()){ email.focus(); promoMessage('error', 'Buyer email is required to use promo codes.'); return; }
      if(!codeInput || !(codeInput.value||'').trim()){ codeInput.focus(); promoMessage('error', 'Enter a promo code.'); return; }
      if(!selected){ promoMessage('error', 'Select a checkout option first.'); return; }
      var fd=new FormData();
      fd.append('option','com_leadmarket');
      fd.append('task','applypromo');
      fd.append('context_type','single');
      fd.append('lead_id','<?php echo (int)$lead["id"]; ?>');
      fd.append('buyer_email',(email.value||'').trim());
      fd.append('sale_mode',selected.value||'shared');
      fd.append('promo_code',(codeInput.value||'').trim());
      fd.append('<?php echo JSession::getFormToken(); ?>','1');
      applyBtn.disabled=true;
      applyBtn.classList.add('is-loading');
      var old=applyBtn.textContent;
      applyBtn.textContent='Applying...';
      fetch('<?php echo JRoute::_("index.php?option=com_leadmarket&task=applypromo", false); ?>', {method:'POST', body:fd, credentials:'same-origin', headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}})
        .then(function(r){ return r.json(); })
        .then(function(data){
          if(data && data.ok){
            var decision=document.getElementById('lmCheckoutDecision');
            var hidden=document.getElementById('lm_promo_code_hidden');
            if(decision){
              decision.setAttribute('data-promo-code', data.promo_code || '');
              decision.setAttribute('data-promo-discount', String(data.discount_amount || 0));
              decision.setAttribute('data-promo-final', String(data.final_total || 0));
              decision.setAttribute('data-promo-sale-mode', selected.value || 'shared');
            }
            if(hidden) hidden.value=data.promo_code || '';
            setLeadPromoApplied(data, selected.value || 'shared');
            promoMessage('success', data.message || 'Promo code applied.');
            updateLeadCheckoutDecision();
          }else{
            clearLeadPromo();
            promoMessage('error', (data && data.message) ? data.message : 'Promo code could not be applied.');
          }
        })
        .catch(function(){ promoMessage('error', 'Connection error. Please try again.'); })
        .finally(function(){ applyBtn.disabled=false; applyBtn.classList.remove('is-loading'); applyBtn.textContent=old; });
    });
  }
  bindMethodGroup('checkout','lm_checkout_topup_amount','lm_checkout_payment_method','lmCheckoutMethodNote');
  bindMethodGroup('linked','lm_order_topup_amount','lm_order_topup_payment_method','lmOrderTopupMethodNote');
  updateLeadCheckoutDecision();
})();
</script>
</div>
</div>

<script>
(function(){
  Array.prototype.slice.call(document.querySelectorAll('.lm-js-open-state')).forEach(function(link){
    link.addEventListener('click', function(){
      link.textContent = link.getAttribute('data-loading-text') || 'Opening...';
      link.style.pointerEvents = 'none';
      link.style.opacity = '0.85';
    });
  });

  function setAjaxResult(node, tone, message){
    if (!node) return;
    node.className = 'lm-ajax-result lm-ajax-result--' + (tone || 'success');
    node.innerHTML = message || '';
    node.style.display = 'block';
  }

  Array.prototype.slice.call(document.querySelectorAll('form[data-lm-ajax-access-link]')).forEach(function(form){
    var btn = form.querySelector('[data-lm-ajax-submit]');
    var resultTarget = form.getAttribute('data-result-target') || '';
    var resultNode = resultTarget ? document.querySelector(resultTarget) : null;
    if (!btn) return;
    form.addEventListener('submit', function(ev){
      if (!window.fetch || !window.FormData || !window.URLSearchParams) return;
      ev.preventDefault();
      var originalText = btn.getAttribute('data-original-text') || btn.textContent;
      btn.setAttribute('data-original-text', originalText);
      btn.disabled = true;
      btn.classList.add('is-loading');
      btn.textContent = btn.getAttribute('data-loading-text') || 'Sending...';
      if (resultNode) resultNode.style.display = 'none';
      var body = new URLSearchParams();
      var formData = new FormData(form);
      formData.forEach(function(value, key){ body.append(key, value); });
      body.append('ajax', '1');
      fetch(form.getAttribute('action'), {
        method: 'POST',
        headers: {
          'X-Requested-With': 'XMLHttpRequest',
          'Accept': 'application/json'
        },
        credentials: 'same-origin',
        body: body
      }).then(function(response){
        return response.json().catch(function(){ return null; }).then(function(data){
          if (!data) throw new Error('bad_json');
          if (!response.ok || data.ok === false) {
            var err = new Error(data.message || 'We could not send the buyer access link right now.');
            err.payload = data;
            throw err;
          }
          return data;
        });
      }).then(function(data){
        setAjaxResult(resultNode, data.tone || 'success', data.message || 'Buyer access link sent.');
      }).catch(function(error){
        var payload = error && error.payload ? error.payload : null;
        setAjaxResult(resultNode, (payload && payload.tone) || 'error', (payload && payload.message) || 'We could not send the buyer access link right now.');
      }).finally(function(){
        btn.disabled = false;
        btn.classList.remove('is-loading');
        btn.textContent = originalText;
      });
    });
  });
})();
</script>
