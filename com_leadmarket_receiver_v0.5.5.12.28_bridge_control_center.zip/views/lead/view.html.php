<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketViewLead extends JViewLegacy
{
    protected function applyTechnicalSeoProtection()
    {
        $robots = 'noindex, nofollow';
        $doc = JFactory::getDocument();
        if ($doc && method_exists($doc, 'setMetaData')) {
            $doc->setMetaData('robots', $robots);
        }
        $app = JFactory::getApplication();
        try {
            $app->setHeader('X-Robots-Tag', $robots, true);
        } catch (Exception $e) {}
        if (!headers_sent()) {
            header('X-Robots-Tag: ' . $robots, true);
        }
    }

    protected $lead;
    protected $masked;
    protected $order;
    protected $params;
    protected $normalized;
    protected $orderAccessDenied = false;
    protected $token = '';
    protected $saleOptions;
    protected $buyerEmail = "";
    protected $currentBalance = 0.0;
    protected $sampleMode = false;
    protected $sampleDisclaimer = "";
    protected $trialMode = false;
    protected $trialAccess = array();

    public function display($tpl = null)
    {
        try {
            $app = JFactory::getApplication();
            $id = $app->input->getInt('id', 0);
            LeadMarketHelper::trackPageView('lead_preview_view', array('page_name' => 'lead', 'lead_id' => (int) $id));
            $this->applyTechnicalSeoProtection();
            $orderId = $app->input->getInt('order_id', 0);
            $token = LeadMarketHelper::readBuyerAccessTokenFromRequest();

            LeadMarketHelper::ensureSchema();
            LeadMarketHelper::cleanupExpiredOrders();
            $db = JFactory::getDbo();
            $db->setQuery('SELECT * FROM #__leadmarket_leads WHERE id=' . (int)$id);
            $lead = $db->loadAssoc();

        if (!$lead) {
            throw new Exception('Lead not found', 404);
        }

        $sampleMode = ((int)$app->input->getInt('sample', 0) === 1);
        if (!empty($lead['is_sample']) && (int)$lead['is_sample'] === 1 && $sampleMode) {
            if (empty($lead['sample_active'])) {
                throw new Exception('Sample lead is inactive.', 404);
            }
            $displayLead = LeadMarketHelper::getSampleDisplayLead($lead);
            $this->lead = $displayLead;
            $this->buyerEmail = '';
            $this->currentBalance = 0.0;
            try {
                $this->normalized = LeadMarketHelper::normalizeLead($displayLead);
            } catch (Throwable $e) {
                $this->normalized = array(
                    'type' => strtolower((string)($displayLead['type'] ?? 'auto')),
                    'contact' => array(
                        'name' => (string)($displayLead['name'] ?? ''),
                        'address' => (string)($displayLead['address'] ?? ''),
                        'city' => (string)($displayLead['city'] ?? ''),
                        'state' => strtoupper((string)($displayLead['state'] ?? '')),
                        'zip' => (string)($displayLead['zip'] ?? ''),
                        'phone' => (string)($displayLead['phone'] ?? ''),
                        'email' => (string)($displayLead['email'] ?? ''),
                        'occupation' => ''
                    ),
                    'vehicles' => array(),
                    'drivers' => array(),
                    'coverage' => array(),
                    '_source' => array()
                );
            }
            try {
                $this->masked = LeadMarketHelper::buildMaskedPreview($displayLead);
            } catch (Throwable $e) {
                $this->masked = array(
                    'type' => strtoupper((string)($displayLead['type'] ?? '')),
                    'state' => strtoupper((string)($displayLead['state'] ?? '')),
                    'city' => (string)($displayLead['city'] ?? ''),
                    'zip' => (string)($displayLead['zip'] ?? ''),
                    'phone_masked' => (string)($displayLead['phone'] ?? '—'),
                    'email_masked' => (string)($displayLead['email'] ?? '—')
                );
            }
            $this->params = LeadMarketHelper::params();
            $this->order = null;
            $this->token = '';
            $this->saleOptions = array('shared'=>array('enabled'=>false),'exclusive'=>array('enabled'=>false));
            $this->sampleMode = true;
            $this->sampleDisclaimer = LeadMarketHelper::getSampleLeadDisclaimer($lead);
            parent::display($tpl);
            return;
        }

        if (!empty($lead['is_sample']) && (int)$lead['is_sample'] === 1) {
            throw new Exception('Sample leads are not available through the standard checkout route.', 404);
        }

        $trialToken = trim((string)$app->input->getString('trial_token', ''));
        $trialMode = ((int)$app->input->getInt('trial', 0) === 1) || ($trialToken !== '');
        if ($trialMode) {
            if (!LeadMarketHelper::isLeadInFreeTestPool($lead)) {
                throw new Exception('This lead is not available in the free test pool.', 404);
            }
            if (!LeadMarketHelper::isValidTrialAccess($trialToken, $lead)) {
                throw new Exception('Your free test access has expired or is invalid.', 403);
            }
            LeadMarketHelper::touchTrialAccessView($trialToken);
            LeadMarketHelper::logFreeTestLeadOpen($trialToken, $lead);
            $this->lead = $lead;
            $this->buyerEmail = '';
            $this->currentBalance = 0.0;
            $this->normalized = LeadMarketHelper::normalizeLead($lead);
            $this->masked = LeadMarketHelper::buildMaskedPreview($lead);
            $this->params = LeadMarketHelper::params();
            $this->order = null;
            $this->token = '';
            $this->saleOptions = array('shared'=>array('enabled'=>false),'exclusive'=>array('enabled'=>false));
            $this->trialMode = true;
            $this->trialAccess = (array) LeadMarketHelper::getTrialAccessByToken($trialToken);
            parent::display($tpl);
            return;
        }

        $this->lead = $lead;
        $requestBuyerEmail = LeadMarketHelper::normalizeEmail((string)$app->input->getString('buyer_email', ''));
        $this->buyerEmail = LeadMarketHelper::resolveBuyerEmail($requestBuyerEmail);
        $this->currentBalance = ($this->buyerEmail !== "" && filter_var($this->buyerEmail, FILTER_VALIDATE_EMAIL)) ? LeadMarketHelper::getBuyerBalance($this->buyerEmail) : 0.0;
        $this->normalized = LeadMarketHelper::normalizeLead($lead);
        $this->masked = LeadMarketHelper::buildMaskedPreview($lead);
        $this->params = LeadMarketHelper::params();
        $this->order = null;
        $this->token = $token;
        $this->saleOptions = LeadMarketHelper::getSaleModeOptions($lead);

        if ($orderId > 0) {
            $db->setQuery('SELECT * FROM #__leadmarket_orders WHERE id=' . (int)$orderId . ' AND lead_id=' . (int)$id);
            $order = $db->loadAssoc();
            if ($order) {
                $order['access_token'] = LeadMarketHelper::ensureOrderToken($order);
                if (LeadMarketHelper::canAccessOrder($order, $token)) {
                    $this->order = $order;
                    LeadMarketHelper::setActiveBuyerContext((string) ($order['buyer_email'] ?? ''), 'lead_order', $token);
                    if ($this->buyerEmail === '') $this->buyerEmail = LeadMarketHelper::normalizeEmail((string) ($order['buyer_email'] ?? ''));
                    $this->currentBalance = ($this->buyerEmail !== '' && filter_var($this->buyerEmail, FILTER_VALIDATE_EMAIL)) ? LeadMarketHelper::getBuyerBalance($this->buyerEmail) : 0.0;
                    // Clear stale batch-related notices so they do not bleed onto secure lead pages.
                    $app->setUserState('application.queue', array());
                    try { JFactory::getSession()->set('application.queue', array()); } catch (Exception $e) {}
                    try { $app->set('_messageQueue', array()); } catch (Exception $e) {}
                    if (method_exists($app, 'getMessageQueue')) {
                        $queue = (array) $app->getMessageQueue();
                        if (!empty($queue)) {
                            try { $app->set('_messageQueue', array()); } catch (Exception $e) {}
                        }
                    }
                    $orderStatus = strtolower((string)($order['status'] ?? ''));
                    $paymentStatus = strtolower((string)($order['payment_status'] ?? ''));
                    if ($orderStatus === 'paid' || $paymentStatus === 'confirmed') {
                        LeadMarketHelper::trackEvent('lead_unlocked_view', array('page_name' => 'lead', 'buyer_email' => (string) ($order['buyer_email'] ?? ''), 'lead_id' => (int) ($order['lead_id'] ?? 0), 'order_id' => (int) ($order['id'] ?? 0)));
                    }
                    if (in_array($orderStatus, array('submitted','pending'), true) || in_array($paymentStatus, array('checking','matched','late_matched'), true)) {
                        if (!headers_sent()) {
                            header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
                            header('Pragma: no-cache');
                            header('Expires: 0');
                        }
                    }
                } else {
                    $this->orderAccessDenied = true;
                }
            }
        }

            parent::display($tpl);
            return;
        } catch (Throwable $e) {
            LeadMarketHelper::writeRuntimeLog('lead_view_failed', array(
                'lead_id' => isset($id) ? (int) $id : 0,
                'order_id' => isset($orderId) ? (int) $orderId : 0,
                'buyer_email' => (string) ($this->buyerEmail ?? ''),
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => (int) $e->getLine(),
            ));
            echo LeadMarketHelper::renderPublicSurfaceStyles();
            echo '<div class="lm-public-wrap"><div class="lm-public-hero"><span class="lm-public-hero__eyebrow">Lead access</span><h1 class="lm-public-hero__title">We could not open this lead right now</h1><p class="lm-public-hero__copy">Try the buyer dashboard again or request a fresh access link.</p><div class="lm-public-hero__actions">';
            $buyerEmail = trim((string) ($this->buyerEmail ?? ''));
            $dashboardUrl = '';
            if (!empty($token)) {
                try { $dashboardUrl = LeadMarketHelper::buildAbsoluteBuyerAccessUrl($token); } catch (Exception $ignore) {}
            }
            if ($dashboardUrl !== '') {
                echo '<a class="lm-public-btn lm-public-btn--main" href="' . htmlspecialchars($dashboardUrl, ENT_QUOTES, 'UTF-8') . '">Open buyer dashboard</a>';
            }
            echo '<a class="lm-public-btn lm-public-btn--ghost" href="' . htmlspecialchars(JRoute::_(LeadMarketHelper::getBuyerAccessRequestUrl($buyerEmail), false), ENT_QUOTES, 'UTF-8') . '">Request fresh access link</a>';
            echo '</div></div></div>';
            return;
        }
    }
}
