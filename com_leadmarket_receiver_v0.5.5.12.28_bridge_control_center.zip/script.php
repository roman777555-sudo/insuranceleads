<?php
defined('_JEXEC') or die;

jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder');

class com_leadmarketInstallerScript
{
    protected function recursiveCopy($src, $dest)
    {
        if (!is_dir($src)) {
            return;
        }
        if (!JFolder::exists($dest)) {
            JFolder::create($dest);
        }
        $items = JFolder::folders($src, '.', false, true);
        foreach ($items as $folder) {
            $name = basename($folder);
            $this->recursiveCopy($folder, $dest . '/' . $name);
        }
        $files = JFolder::files($src, '.', false, true);
        foreach ($files as $file) {
            $name = basename($file);
            JFile::copy($file, $dest . '/' . $name, null, true);
        }
    }

    protected function forceDeploy($parent)
    {
        $source = $parent->getParent()->getPath('source');
        if (!$source || !is_dir($source)) {
            return;
        }

        $siteDest = JPATH_SITE . '/components/com_leadmarket';
        $adminDest = JPATH_ADMINISTRATOR . '/components/com_leadmarket';

        if (!JFolder::exists(dirname($siteDest))) {
            JFolder::create(dirname($siteDest));
        }
        if (!JFolder::exists(dirname($adminDest))) {
            JFolder::create(dirname($adminDest));
        }
        if (!JFolder::exists($siteDest)) {
            JFolder::create($siteDest);
        }
        if (!JFolder::exists($adminDest)) {
            JFolder::create($adminDest);
        }

        $siteFolders = array('controllers','helpers','models','tables','views','language');
        $siteFiles = array('leadmarket.php','controller.php','router.php','config.xml');
        foreach ($siteFiles as $file) {
            if (JFile::exists($source . '/' . $file)) {
                JFile::copy($source . '/' . $file, $siteDest . '/' . $file, null, true);
            }
        }
        foreach ($siteFolders as $folder) {
            $this->recursiveCopy($source . '/' . $folder, $siteDest . '/' . $folder);
        }

        $adminSource = $source . '/admin';
        if (is_dir($adminSource)) {
            $adminFolders = array('controllers','helpers','models','tables','views','language','sql');
            $adminFiles = array('leadmarket.php','controller.php','config.xml');
            foreach ($adminFiles as $file) {
                if (JFile::exists($adminSource . '/' . $file)) {
                    JFile::copy($adminSource . '/' . $file, $adminDest . '/' . $file, null, true);
                }
            }
            foreach ($adminFolders as $folder) {
                $this->recursiveCopy($adminSource . '/' . $folder, $adminDest . '/' . $folder);
            }
        }

        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }
        // Best-effort Joomla cache cleanup for component updates.
        try {
            $cache = JFactory::getCache();
            if ($cache) {
                $cache->clean();
            }
        } catch (Exception $e) {
        }
    }

    public function install($parent)
    {
        $this->forceDeploy($parent);
    }

    public function update($parent)
    {
        $this->forceDeploy($parent);
    }

    public function postflight($type, $parent)
    {
        $this->forceDeploy($parent);
    }
}
