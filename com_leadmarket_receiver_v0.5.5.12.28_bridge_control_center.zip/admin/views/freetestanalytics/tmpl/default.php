<?php defined('_JEXEC') or die; ?>
<?php
$filters = (array) $this->filters;
$period = !empty($filters['period']) ? $filters['period'] : '30d';
$badge = function($label, $value, $accent = '#0c5585') {
  return '<div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;min-width:0;"><div style="font-size:12px;font-weight:700;color:#5f7281;text-transform:uppercase;letter-spacing:.04em;">' . htmlspecialchars($label) . '</div><div style="margin-top:8px;font-size:28px;line-height:1.1;font-weight:800;color:' . htmlspecialchars($accent) . ';">' . htmlspecialchars($value) . '</div></div>';
};
$statesLabel = function($json) {
  $arr = json_decode((string) $json, true);
  if (!is_array($arr) || empty($arr)) return 'All states';
  $arr = array_values(array_unique(array_filter(array_map('trim', $arr))));
  return implode(', ', $arr);
};
$currentReturn = base64_encode(JUri::getInstance()->toString(array('path', 'query')));
$deleteBtnStyle = 'display:inline-block;padding:5px 10px;border:1px solid #d9a7a7;border-radius:9px;background:#fff7f7;color:#8b1e1e;text-decoration:none;font-size:12px;font-weight:700;cursor:pointer;';
?>
<?php echo LeadMarketHelper::renderAdminQuickNav('freetestanalytics'); ?>
<div style="max-width:1420px;display:flex;flex-direction:column;gap:18px;">
  <form action="index.php?option=com_leadmarket&view=freetestanalytics" method="post" style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px 18px;">
    <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:12px;">
      <div>
        <div style="font-size:20px;font-weight:800;color:#193247;">Free Test Leads analytics</div>
        <div style="font-size:13px;color:#60717c;">See who subscribed from the free-test page and which free-test leads they opened.</div>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;align-items:end;">
      <div><label><strong>Period</strong></label><select name="period" style="width:100%;"><option value="today" <?php echo $period==='today'?'selected':''; ?>>Today</option><option value="7d" <?php echo $period==='7d'?'selected':''; ?>>Last 7 days</option><option value="30d" <?php echo $period==='30d'?'selected':''; ?>>Last 30 days</option><option value="custom" <?php echo $period==='custom'?'selected':''; ?>>Custom range</option></select></div>
      <div><label><strong>From</strong></label><input type="date" name="date_from" value="<?php echo htmlspecialchars((string) ($filters['date_from'] ?? '')); ?>" style="width:100%;" /></div>
      <div><label><strong>To</strong></label><input type="date" name="date_to" value="<?php echo htmlspecialchars((string) ($filters['date_to'] ?? '')); ?>" style="width:100%;" /></div>
      <div><label><strong>Search</strong></label><input type="text" name="filter_search" value="<?php echo htmlspecialchars((string) ($filters['search'] ?? '')); ?>" placeholder="email, state, lead #, subscriber #" style="width:100%;" /></div>
      <div style="display:flex;gap:8px;align-items:end;"><button class="btn btn-primary" type="submit">Apply</button><a class="btn btn-small" href="index.php?option=com_leadmarket&view=freetestanalytics">Clear</a></div>
    </div>
    <?php echo JHtml::_('form.token'); ?>
  </form>

  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
    <?php echo $badge('Signups / unlocks', (string) ((int) ($this->summary['signups'] ?? 0))); ?>
    <?php echo $badge('Unique emails', (string) ((int) ($this->summary['emails'] ?? 0)), '#1f6b35'); ?>
    <?php echo $badge('Landing views', (string) ((int) ($this->summary['landing_views'] ?? 0))); ?>
    <?php echo $badge('Lead opens', (string) ((int) ($this->summary['lead_views'] ?? 0)), '#8a4d00'); ?>
    <?php echo $badge('Unique leads opened', (string) ((int) ($this->summary['distinct_leads'] ?? 0)), '#245c9a'); ?>
    <?php echo $badge('Marketplace clicks', (string) ((int) ($this->summary['market_clicks'] ?? 0)), '#7a4d00'); ?>
  </div>

  <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:18px;align-items:start;">
    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;">
      <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Recent free-test signups</h3><span style="font-size:12px;color:#60717c;">Who unlocked the page and what they asked for</span></div>
      <table class="table table-striped">
        <thead><tr><th>Email</th><th>Preferences</th><th>Subscriber</th><th>Unlocked</th><th>Engagement</th><th style="width:96px;">Delete</th></tr></thead>
        <tbody>
          <?php foreach ((array) $this->recentUnlocks as $row): ?>
            <tr>
              <td><strong><?php echo htmlspecialchars((string) $row->email); ?></strong><div style="font-size:12px;color:#667681;">IP: <?php echo htmlspecialchars((string) $row->request_ip); ?></div></td>
              <td><?php echo htmlspecialchars((string) ucfirst((string) $row->lead_type)); ?> · <?php echo htmlspecialchars($statesLabel($row->states_json)); ?></td>
              <td><?php echo (int) $row->subscriber_id; ?></td>
              <td><?php echo htmlspecialchars((string) ($row->unlocked_at_utc ?: $row->created_at_utc)); ?><div style="font-size:12px;color:#667681;">Expires: <?php echo htmlspecialchars((string) $row->expires_at_utc); ?></div></td>
              <td>Landing: <?php echo (int) $row->view_count; ?><br>Lead opens: <?php echo (int) $row->lead_opens; ?><?php if (!empty($row->last_lead_open_utc)): ?><div style="font-size:12px;color:#667681;">Last open: <?php echo htmlspecialchars((string) $row->last_lead_open_utc); ?></div><?php endif; ?></td>
              <td>
                <form action="index.php?option=com_leadmarket" method="post" onsubmit="return confirm('Remove this free-test signup and its related lead-open history from analytics?');" style="margin:0;">
                  <input type="hidden" name="task" value="freetestanalytics.deleteSignup">
                  <input type="hidden" name="id" value="<?php echo (int) $row->id; ?>">
                  <input type="hidden" name="return" value="<?php echo htmlspecialchars($currentReturn); ?>">
                  <?php echo JHtml::_('form.token'); ?>
                  <button type="submit" style="<?php echo $deleteBtnStyle; ?>">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($this->recentUnlocks)): ?><tr><td colspan="6" style="text-align:center;color:#667681;">No free-test signups in this period.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>

    <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;">
      <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Top free-test leads opened</h3><span style="font-size:12px;color:#60717c;">Lead IDs and states that attracted attention</span></div>
      <table class="table table-striped">
        <thead><tr><th>Lead</th><th>Opens</th><th>Unique emails</th><th>Last open</th><th style="width:96px;">Delete</th></tr></thead>
        <tbody>
          <?php foreach ((array) $this->topViewedLeads as $row): ?>
            <tr>
              <td>#<?php echo (int) $row->lead_id; ?><?php if (!empty($row->lead_state) || !empty($row->lead_type)): ?> · <?php echo htmlspecialchars(trim((string) strtoupper((string) $row->lead_state) . ' ' . (string) ucfirst((string) $row->lead_type))); ?><?php endif; ?><?php if (!empty($row->lead_city)): ?><div style="font-size:12px;color:#667681;"><?php echo htmlspecialchars((string) $row->lead_city); ?></div><?php endif; ?></td>
              <td><?php echo (int) $row->opens_count; ?></td>
              <td><?php echo (int) $row->unique_emails; ?></td>
              <td><?php echo htmlspecialchars((string) $row->last_open_utc); ?></td>
              <td>
                <form action="index.php?option=com_leadmarket" method="post" onsubmit="return confirm('Delete all recorded free-test opens for lead #<?php echo (int) $row->lead_id; ?>?');" style="margin:0;">
                  <input type="hidden" name="task" value="freetestanalytics.deleteTopLead">
                  <input type="hidden" name="lead_id" value="<?php echo (int) $row->lead_id; ?>">
                  <input type="hidden" name="return" value="<?php echo htmlspecialchars($currentReturn); ?>">
                  <?php echo JHtml::_('form.token'); ?>
                  <button type="submit" style="<?php echo $deleteBtnStyle; ?>">Delete</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($this->topViewedLeads)): ?><tr><td colspan="5" style="text-align:center;color:#667681;">No lead opens recorded yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;">
    <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Recent free-test lead opens</h3><span style="font-size:12px;color:#60717c;">Which unlocked subscribers opened which leads</span></div>
    <table class="table table-striped">
      <thead><tr><th>Viewed at</th><th>Email</th><th>Lead opened</th><th>Requested filters</th><th>Subscriber</th><th style="width:96px;">Delete</th></tr></thead>
      <tbody>
        <?php foreach ((array) $this->recentLeadViews as $row): ?>
          <tr>
            <td><?php echo htmlspecialchars((string) $row->viewed_at_utc); ?></td>
            <td><strong><?php echo htmlspecialchars((string) $row->email); ?></strong></td>
            <td>#<?php echo (int) $row->lead_id; ?><?php if (!empty($row->lead_state) || !empty($row->lead_type)): ?> · <?php echo htmlspecialchars(trim((string) strtoupper((string) $row->lead_state) . ' ' . ucfirst((string) $row->lead_type))); ?><?php endif; ?><?php if (!empty($row->lead_city)): ?><div style="font-size:12px;color:#667681;"><?php echo htmlspecialchars((string) $row->lead_city); ?></div><?php endif; ?></td>
            <td><?php echo htmlspecialchars((string) ucfirst((string) $row->selected_lead_type)); ?> · <?php echo htmlspecialchars($statesLabel($row->states_json)); ?></td>
            <td><?php echo (int) $row->subscriber_id; ?></td>
            <td>
              <form action="index.php?option=com_leadmarket" method="post" onsubmit="return confirm('Delete this free-test lead-open record?');" style="margin:0;">
                <input type="hidden" name="task" value="freetestanalytics.deleteLeadView">
                <input type="hidden" name="id" value="<?php echo (int) $row->id; ?>">
                <input type="hidden" name="return" value="<?php echo htmlspecialchars($currentReturn); ?>">
                <?php echo JHtml::_('form.token'); ?>
                <button type="submit" style="<?php echo $deleteBtnStyle; ?>">Delete</button>
              </form>
            </td>
          </tr>
        <?php endforeach; ?>
        <?php if (empty($this->recentLeadViews)): ?><tr><td colspan="6" style="text-align:center;color:#667681;">Nobody has opened a free-test lead yet.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
