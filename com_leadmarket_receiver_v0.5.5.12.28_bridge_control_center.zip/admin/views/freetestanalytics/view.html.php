<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketViewFreetestanalytics extends JViewLegacy
{
  public $filters;
  public $summary;
  public $recentUnlocks;
  public $recentLeadViews;
  public $topViewedLeads;

  public function display($tpl = null)
  {
    LeadMarketHelper::ensureSchema();
    $model = JModelLegacy::getInstance('Freetestanalytics', 'LeadMarketModel');
    $this->filters = $model->getFilters();
    $this->summary = $model->getSummary($this->filters);
    $this->recentUnlocks = $model->getRecentUnlocks($this->filters, 30);
    $this->recentLeadViews = $model->getRecentLeadViews($this->filters, 40);
    $this->topViewedLeads = $model->getTopViewedLeads($this->filters, 15);
    JToolbarHelper::title('LeadMarket - Free Test Analytics', 'chart');
    parent::display($tpl);
  }
}
