<?php defined('_JEXEC') or die; ?>
<?php
$token = JSession::getFormToken();
$filters = (array) $this->filters;
$period = !empty($filters['period']) ? $filters['period'] : '7d';
$base = 'index.php?option=com_leadmarket&view=reports';
$qs = '&period=' . urlencode($period)
  . '&filter_search=' . urlencode((string) ($filters['search'] ?? ''))
  . '&date_from=' . urlencode((string) ($filters['date_from'] ?? ''))
  . '&date_to=' . urlencode((string) ($filters['date_to'] ?? ''))
  . '&filter_order_status=' . urlencode((string) ($filters['order_status'] ?? ''))
  . '&filter_topup_status=' . urlencode((string) ($filters['topup_status'] ?? ''))
  . '&' . $token . '=1';
$badge = function($label, $value, $accent = '#0c5585') {
  return '<div style="background:#fff;border:1px solid #dbe7f1;border-radius:14px;padding:16px 18px;min-width:0;"><div style="font-size:12px;font-weight:700;color:#5f7281;text-transform:uppercase;letter-spacing:.04em;">' . htmlspecialchars($label) . '</div><div style="margin-top:8px;font-size:28px;line-height:1.1;font-weight:800;color:' . htmlspecialchars($accent) . ';">' . htmlspecialchars($value) . '</div></div>';
};
$statusPill = function($text, $bg, $fg) { return '<span style="display:inline-block;padding:4px 8px;border-radius:999px;background:' . $bg . ';color:' . $fg . ';font-size:12px;font-weight:700;">' . htmlspecialchars($text) . '</span>'; };
?>
<?php echo LeadMarketHelper::renderAdminQuickNav('reports'); ?>
<div style="max-width:1400px;display:flex;flex-direction:column;gap:18px;">
  <form action="<?php echo $base; ?>" method="post" style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px 18px;">
    <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:12px;">
      <div>
        <div style="font-size:20px;font-weight:800;color:#193247;">Operator reporting</div>
        <div style="font-size:13px;color:#60717c;">Quick totals, period filters, search and CSV export.</div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;">
        <a class="btn btn-small" href="<?php echo $base; ?>&task=reports.export&export_type=leads<?php echo $qs; ?>">Export Leads CSV</a>
        <a class="btn btn-small" href="<?php echo $base; ?>&task=reports.export&export_type=orders<?php echo $qs; ?>">Export Orders CSV</a>
        <a class="btn btn-small" href="<?php echo $base; ?>&task=reports.export&export_type=topups<?php echo $qs; ?>">Export Top-ups CSV</a>
        <a class="btn btn-small" href="<?php echo $base; ?>&task=reports.export&export_type=wallets<?php echo $qs; ?>">Export Wallets CSV</a>
      </div>
    </div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;align-items:end;">
      <div>
        <label><strong>Period</strong></label>
        <select name="period" style="width:100%;">
          <?php foreach (array('today' => 'Today', '7d' => 'Last 7 days', '30d' => 'Last 30 days', 'custom' => 'Custom range') as $key => $label): ?>
            <option value="<?php echo $key; ?>" <?php echo $period === $key ? 'selected' : ''; ?>><?php echo htmlspecialchars($label); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label><strong>From</strong></label>
        <input type="date" name="date_from" value="<?php echo htmlspecialchars((string) ($filters['date_from'] ?? '')); ?>" style="width:100%;" />
      </div>
      <div>
        <label><strong>To</strong></label>
        <input type="date" name="date_to" value="<?php echo htmlspecialchars((string) ($filters['date_to'] ?? '')); ?>" style="width:100%;" />
      </div>
      <div>
        <label><strong>Search</strong></label>
        <input type="text" name="filter_search" value="<?php echo htmlspecialchars((string) ($filters['search'] ?? '')); ?>" placeholder="buyer email, lead #, order #, batch #, top-up #" style="width:100%;" />
      </div>
      <div>
        <label><strong>Orders</strong></label>
        <select name="filter_order_status" style="width:100%;">
          <option value="">All orders</option>
          <?php foreach (array('paid' => 'Paid', 'pending' => 'Pending', 'checking' => 'Checking', 'manual_review' => 'Manual review') as $key => $label): ?>
            <option value="<?php echo $key; ?>" <?php echo (($filters['order_status'] ?? '') === $key) ? 'selected' : ''; ?>><?php echo htmlspecialchars($label); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label><strong>Top-ups</strong></label>
        <select name="filter_topup_status" style="width:100%;">
          <option value="">All top-ups</option>
          <?php foreach (array('paid' => 'Paid', 'pending' => 'Pending', 'checking' => 'Checking', 'manual_review' => 'Manual review') as $key => $label): ?>
            <option value="<?php echo $key; ?>" <?php echo (($filters['topup_status'] ?? '') === $key) ? 'selected' : ''; ?>><?php echo htmlspecialchars($label); ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div style="display:flex;gap:8px;align-items:end;">
        <button class="btn btn-primary" type="submit">Apply</button>
        <a class="btn btn-small" href="<?php echo $base; ?>">Clear</a>
      </div>
    </div>
    <?php echo JHtml::_('form.token'); ?>
  </form>

  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
    <?php echo $badge('New leads', (string) ((int) ($this->summary['new_leads'] ?? 0))); ?>
    <?php echo $badge('Sold leads', (string) ((int) ($this->summary['sold_leads'] ?? 0)), '#1f6b35'); ?>
    <?php echo $badge('Orders', (string) ((int) ($this->summary['orders'] ?? 0))); ?>
    <?php echo $badge('Batches', (string) ((int) ($this->summary['batches'] ?? 0))); ?>
    <?php echo $badge('Top-ups', (string) ((int) ($this->summary['topups'] ?? 0))); ?>
    <?php echo $badge('Revenue', '$' . number_format((float) ($this->summary['revenue'] ?? 0), 2, '.', ''), '#8a4d00'); ?>
  </div>

  <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;">
    <?php echo $badge('Orders total', '$' . number_format((float) ($this->revenue['orders_total'] ?? 0), 2, '.', ''), '#1f6b35'); ?>
    <?php echo $badge('Top-ups total', '$' . number_format((float) ($this->revenue['topups_total'] ?? 0), 2, '.', ''), '#0c5585'); ?>
    <?php echo $badge('Paid items', (string) ((int) ($this->revenue['paid_items'] ?? 0)), '#1f6b35'); ?>
    <?php echo $badge('Manual review', (string) ((int) ($this->revenue['manual_review'] ?? 0)), '#9b2d2d'); ?>
  </div>


  <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;display:flex;flex-direction:column;gap:16px;">
    <div>
      <div style="font-size:20px;font-weight:800;color:#193247;">Event analytics</div>
      <div style="font-size:13px;color:#60717c;">Marketplace interest, checkout drop-off, top-up method behavior, and credit request activity.</div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;">
      <?php echo $badge('Tracked events', (string) ((int) ($this->analyticsSummary['events_total'] ?? 0)), '#0c5585'); ?>
      <?php echo $badge('Unique visitors', (string) ((int) ($this->analyticsSummary['visitors'] ?? 0)), '#1f6b35'); ?>
      <?php echo $badge('Sessions', (string) ((int) ($this->analyticsSummary['sessions'] ?? 0))); ?>
      <?php echo $badge('Lead interest', (string) ((int) ($this->analyticsSummary['lead_views'] ?? 0)), '#8a4d00'); ?>
      <?php echo $badge('Checkout starts', (string) ((int) ($this->analyticsSummary['checkout_starts'] ?? 0)), '#245c9a'); ?>
      <?php echo $badge('Top-ups created', (string) ((int) ($this->analyticsSummary['topups_created'] ?? 0)), '#8a4d00'); ?>
      <?php echo $badge('Credit requests', (string) ((int) ($this->analyticsSummary['credit_submitted'] ?? 0)), '#9b2d2d'); ?>
    </div>

    <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:18px;align-items:start;">
      <div style="background:#fbfdff;border:1px solid #e5edf4;border-radius:14px;padding:14px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Lead interest report</h3><span style="font-size:12px;color:#60717c;">Most viewed and interacted leads</span></div>
        <table class="table table-striped">
          <thead><tr><th>Lead</th><th>Preview</th><th>Open</th><th>Add to batch</th><th>Checkout</th><th>Purchases</th></tr></thead>
          <tbody>
            <?php foreach ((array) $this->leadInterest as $it): ?>
              <tr>
                <td>#<?php echo (int) $it->lead_id; ?> <?php if (!empty($it->state) || !empty($it->type)): ?>· <?php echo htmlspecialchars(trim($it->state . ' ' . $it->type)); ?><?php endif; ?></td>
                <td><?php echo (int) $it->preview_views; ?></td>
                <td><?php echo (int) $it->lead_opens; ?></td>
                <td><?php echo (int) $it->added_to_batch; ?></td>
                <td><?php echo (int) $it->checkout_starts; ?></td>
                <td><?php echo (int) $it->purchases; ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($this->leadInterest)): ?><tr><td colspan="6" style="text-align:center;color:#667681;">No tracked lead events in this period.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
      <div style="display:flex;flex-direction:column;gap:18px;">
        <div style="background:#fbfdff;border:1px solid #e5edf4;border-radius:14px;padding:14px;">
          <h3 style="margin:0 0 10px;">Funnel drop-off</h3>
          <table class="table table-striped">
            <tbody>
              <tr><th>Marketplace views</th><td><?php echo (int) ($this->funnel['marketplace_views'] ?? 0); ?></td></tr>
              <tr><th>Lead previews</th><td><?php echo (int) ($this->funnel['lead_preview_views'] ?? 0); ?></td></tr>
              <tr><th>Lead open clicks</th><td><?php echo (int) ($this->funnel['lead_open_clicks'] ?? 0); ?></td></tr>
              <tr><th>Add to batch</th><td><?php echo (int) ($this->funnel['add_to_batch'] ?? 0); ?></td></tr>
              <tr><th>Batch summary views</th><td><?php echo (int) ($this->funnel['batch_summary_views'] ?? 0); ?></td></tr>
              <tr><th>Checkout starts</th><td><?php echo (int) ($this->funnel['checkout_starts'] ?? 0); ?></td></tr>
              <tr><th>Insufficient balance</th><td><?php echo (int) ($this->funnel['insufficient_balance'] ?? 0); ?></td></tr>
              <tr><th>Top-ups created</th><td><?php echo (int) ($this->funnel['topup_created'] ?? 0); ?></td></tr>
              <tr><th>Crypto/WU proof sent</th><td><?php echo (int) ($this->funnel['topup_reference_submitted'] ?? 0); ?></td></tr>
              <tr><th>Single paid</th><td><?php echo (int) ($this->funnel['order_paid'] ?? 0); ?></td></tr>
              <tr><th>Batch paid</th><td><?php echo (int) ($this->funnel['batch_paid'] ?? 0); ?></td></tr>
            </tbody>
          </table>
        </div>
        <div style="background:#fbfdff;border:1px solid #e5edf4;border-radius:14px;padding:14px;">
          <h3 style="margin:0 0 10px;">Top-up method report</h3>
          <table class="table table-striped">
            <thead><tr><th>Method</th><th>Selected</th><th>Created</th><th>Proof sent</th><th>Paid</th><th>Cancelled</th><th>Expired</th></tr></thead>
            <tbody>
              <?php foreach ((array) $this->topupAnalytics as $method => $row): ?>
                <tr>
                  <td><?php echo htmlspecialchars(ucwords(str_replace('_',' ', (string) $method))); ?></td>
                  <td><?php echo (int) ($row['topup_method_selected'] ?? 0); ?></td>
                  <td><?php echo (int) ($row['topup_created'] ?? 0); ?></td>
                  <td><?php echo (int) ($row['topup_reference_submitted'] ?? 0); ?></td>
                  <td><?php echo (int) ($row['paid'] ?? 0); ?></td>
                  <td><?php echo (int) ($row['topup_cancelled'] ?? 0); ?></td>
                  <td><?php echo (int) ($row['expired'] ?? 0); ?></td>
                </tr>
              <?php endforeach; ?>
              <?php if (empty($this->topupAnalytics)): ?><tr><td colspan="7" style="text-align:center;color:#667681;">No top-up analytics yet.</td></tr><?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;align-items:start;">
      <div style="background:#fbfdff;border:1px solid #e5edf4;border-radius:14px;padding:14px;">
        <h3 style="margin:0 0 10px;">Credit request report</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:12px;">
          <?php echo $badge('Opened', (string) ((int) ($this->creditAnalytics['credit_request_opened'] ?? 0)), '#0c5585'); ?>
          <?php echo $badge('Submitted', (string) ((int) ($this->creditAnalytics['credit_request_submitted'] ?? 0)), '#8a4d00'); ?>
          <?php echo $badge('Approved', (string) ((int) ($this->creditAnalytics['credit_request_approved'] ?? 0)), '#1f6b35'); ?>
          <?php echo $badge('Rejected', (string) ((int) ($this->creditAnalytics['credit_request_rejected'] ?? 0)), '#9b2d2d'); ?>
        </div>
        <table class="table table-striped">
          <thead><tr><th>Reason</th><th>Count</th></tr></thead>
          <tbody>
            <?php foreach ((array) ($this->creditAnalytics['reasons'] ?? array()) as $row): ?>
              <tr><td><?php echo htmlspecialchars((string) $row->reason_code); ?></td><td><?php echo (int) $row->cnt; ?></td></tr>
            <?php endforeach; ?>
            <?php if (empty($this->creditAnalytics['reasons'])): ?><tr><td colspan="2" style="text-align:center;color:#667681;">No credit request reasons in this period.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
      <div style="background:#fbfdff;border:1px solid #e5edf4;border-radius:14px;padding:14px;">
        <h3 style="margin:0 0 10px;">Top credit-request leads</h3>
        <table class="table table-striped">
          <thead><tr><th>Lead</th><th>Requests</th></tr></thead>
          <tbody>
            <?php foreach ((array) ($this->creditAnalytics['top_leads'] ?? array()) as $row): ?>
              <tr><td>#<?php echo (int) $row->lead_id; ?> <?php if (!empty($row->state) || !empty($row->type)): ?>· <?php echo htmlspecialchars(trim($row->state . ' ' . $row->type)); ?><?php endif; ?></td><td><?php echo (int) $row->request_count; ?></td></tr>
            <?php endforeach; ?>
            <?php if (empty($this->creditAnalytics['top_leads'])): ?><tr><td colspan="2" style="text-align:center;color:#667681;">No credit-request lead data yet.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div style="display:grid;grid-template-columns:1.2fr 1fr;gap:18px;align-items:start;">
    <div style="display:flex;flex-direction:column;gap:18px;">
      <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Recent orders</h3><a class="btn btn-small" href="index.php?option=com_leadmarket&view=orders">Open Orders</a></div>
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>Buyer</th><th>Lead/Batch</th><th>Amount</th><th>Status</th><th>Created</th></tr></thead>
          <tbody>
            <?php foreach ((array) $this->orders as $it): ?>
              <tr>
                <td>#<?php echo (int) $it->id; ?></td>
                <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
                <td><?php echo !empty($it->batch_id) ? 'Batch #' . (int) $it->batch_id : 'Lead #' . (int) $it->lead_id; ?><?php if (!empty($it->state) || !empty($it->type)): ?> · <?php echo htmlspecialchars(trim($it->state . ' ' . $it->type)); ?><?php endif; ?></td>
                <td>$<?php echo number_format((float) $it->amount_usd, 2, '.', ''); ?></td>
                <td><?php echo $statusPill((string) ($it->payment_status === 'checking' ? 'Checking' : ($it->status ?: 'Pending')), strtolower((string) $it->payment_status) === 'checking' ? '#eef6ff' : ((string)$it->status === 'paid' ? '#eefaf0' : '#fff8ef'), strtolower((string) $it->payment_status) === 'checking' ? '#245c9a' : ((string)$it->status === 'paid' ? '#1f6b35' : '#8a4d00')); ?></td>
                <td><?php echo htmlspecialchars($it->created_at_utc); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($this->orders)): ?><tr><td colspan="6" style="text-align:center;color:#667681;">No orders matched the current filters.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>

      <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Recent top-ups</h3><a class="btn btn-small" href="index.php?option=com_leadmarket&view=topups">Open Top-ups</a></div>
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>Buyer</th><th>Target</th><th>Amount</th><th>Status</th><th>Created</th></tr></thead>
          <tbody>
            <?php foreach ((array) $this->topups as $it): ?>
              <tr>
                <td>#<?php echo (int) $it->id; ?></td>
                <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
                <td><?php echo htmlspecialchars(((string)$it->target_type !== '' ? ucfirst($it->target_type) . ' #' . (int)$it->target_id : 'Wallet only')); ?></td>
                <td>$<?php echo number_format((float) $it->topup_amount_usd, 2, '.', ''); ?></td>
                <td><?php echo $statusPill((string) (($it->status === 'paid' && !empty($it->result_status)) ? ucfirst(str_replace('_', ' ', (string) $it->result_status)) : ucfirst((string) $it->status)), (string)$it->status === 'paid' ? '#eefaf0' : ((string)$it->status === 'checking' ? '#eef6ff' : '#fff8ef'), (string)$it->status === 'paid' ? '#1f6b35' : ((string)$it->status === 'checking' ? '#245c9a' : '#8a4d00')); ?></td>
                <td><?php echo htmlspecialchars($it->created_at_utc); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($this->topups)): ?><tr><td colspan="6" style="text-align:center;color:#667681;">No top-ups matched the current filters.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div style="display:flex;flex-direction:column;gap:18px;">
      <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Recent leads</h3><a class="btn btn-small" href="index.php?option=com_leadmarket&view=leads">Open Leads</a></div>
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>Lead</th><th>Price</th><th>Market</th><th>Arrival</th></tr></thead>
          <tbody>
            <?php foreach ((array) $this->leads as $it): ?>
              <tr>
                <td>#<?php echo (int) $it->id; ?></td>
                <td><?php echo htmlspecialchars(trim($it->state . ' ' . $it->type . (!empty($it->city) ? ' · ' . $it->city : ''))); ?></td>
                <td>$<?php echo number_format((float) $it->price_usd, 2, '.', ''); ?></td>
                <td><?php echo $statusPill((string) ucfirst((string) $it->lead_status), (string)$it->lead_status === 'fresh' ? '#eefaf0' : ((string)$it->lead_status === 'aged' ? '#fff8ef' : '#f4f5f7'), (string)$it->lead_status === 'fresh' ? '#1f6b35' : ((string)$it->lead_status === 'aged' ? '#8a4d00' : '#667')); ?></td>
                <td><?php echo htmlspecialchars($it->uploaded_at_utc); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($this->leads)): ?><tr><td colspan="5" style="text-align:center;color:#667681;">No leads matched the current filters.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>

      <div style="background:#fff;border:1px solid #dbe7f1;border-radius:16px;padding:16px;">
        <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:10px;"><h3 style="margin:0;">Wallet preview</h3><a class="btn btn-small" href="index.php?option=com_leadmarket&view=wallets">Open Wallets</a></div>
        <table class="table table-striped">
          <thead><tr><th>Buyer</th><th>Balance</th><th>Credits</th><th>Debits</th><th>Last activity</th></tr></thead>
          <tbody>
            <?php foreach ((array) $this->wallets as $it): ?>
              <tr>
                <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
                <td>$<?php echo number_format((float) $it->balance_usd, 2, '.', ''); ?></td>
                <td>$<?php echo number_format((float) $it->total_credits, 2, '.', ''); ?></td>
                <td>$<?php echo number_format((float) $it->total_debits, 2, '.', ''); ?></td>
                <td><?php echo htmlspecialchars($it->last_activity_at ?: '—'); ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (empty($this->wallets)): ?><tr><td colspan="5" style="text-align:center;color:#667681;">No wallet records matched the current filters.</td></tr><?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
