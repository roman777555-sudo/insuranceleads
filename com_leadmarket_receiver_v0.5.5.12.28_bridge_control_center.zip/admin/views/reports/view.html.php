<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketViewReports extends JViewLegacy
{
  public $filters;
  public $summary;
  public $revenue;
  public $orders;
  public $topups;
  public $leads;
  public $wallets;
  public $analyticsSummary;
  public $leadInterest;
  public $funnel;
  public $topupAnalytics;
  public $creditAnalytics;

  public function display($tpl = null)
  {
    LeadMarketHelper::ensureSchema();
    $model = JModelLegacy::getInstance('Reports', 'LeadMarketModel');
    $this->filters = $model->getFilters();
    $this->summary = $model->getSummary($this->filters);
    $this->revenue = $model->getRevenueSlice($this->filters);
    $this->orders = $model->getRecentOrders($this->filters, 15);
    $this->topups = $model->getRecentTopups($this->filters, 15);
    $this->leads = $model->getRecentLeads($this->filters, 12);
    $this->wallets = $model->getWalletPreview($this->filters, 12);
    $this->analyticsSummary = method_exists($model, 'getAnalyticsSummary') ? $model->getAnalyticsSummary($this->filters) : array();
    $this->leadInterest = method_exists($model, 'getLeadInterestAnalytics') ? $model->getLeadInterestAnalytics($this->filters, 12) : array();
    $this->funnel = method_exists($model, 'getFunnelAnalytics') ? $model->getFunnelAnalytics($this->filters) : array();
    $this->topupAnalytics = method_exists($model, 'getTopupMethodAnalytics') ? $model->getTopupMethodAnalytics($this->filters) : array();
    $this->creditAnalytics = method_exists($model, 'getCreditRequestAnalytics') ? $model->getCreditRequestAnalytics($this->filters, 10) : array();

    JToolbarHelper::title('LeadMarket - Reports', 'chart');
    parent::display($tpl);
  }
}
