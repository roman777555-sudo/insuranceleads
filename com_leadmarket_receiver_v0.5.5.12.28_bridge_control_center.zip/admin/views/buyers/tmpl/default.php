<?php defined('_JEXEC') or die; ?>
<?php echo LeadMarketHelper::renderAdminQuickNav('buyers'); ?>
<form action="index.php?option=com_leadmarket&view=buyers" method="post" name="adminForm" id="adminForm">
  <div class="js-stools clearfix" style="margin-bottom:12px;">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
      <input type="text" name="filter_search" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" placeholder="Search buyer email" />
      <button class="btn btn-small" type="submit">Filter</button>
      <a class="btn btn-small" href="index.php?option=com_leadmarket&view=buyers">Clear</a>
    </div>
  </div>

  <table class="table table-striped">
    <thead>
      <tr>
        <th><?php echo JHtml::_('grid.sort', 'Buyer Email', 'buyer_email', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th><?php echo JHtml::_('grid.sort', 'First Purchase (UTC)', 'first_purchase_at', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th><?php echo JHtml::_('grid.sort', 'Last Purchase (UTC)', 'last_purchase_at', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th><?php echo JHtml::_('grid.sort', 'Orders', 'orders_count', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th><?php echo JHtml::_('grid.sort', 'Total Spent (USD)', 'total_spent', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ((array) $this->items as $it): ?>
      <tr>
        <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
        <td><?php echo htmlspecialchars($it->first_purchase_at); ?></td>
        <td><?php echo htmlspecialchars($it->last_purchase_at); ?></td>
        <td><?php echo (int) $it->orders_count; ?></td>
        <td><?php echo number_format((float) $it->total_spent, 2, '.', ''); ?></td>
        <td>
          <a class="btn btn-mini" href="index.php?option=com_leadmarket&view=orders&filter_search=<?php echo urlencode($it->buyer_email); ?>">View orders</a>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($this->items)): ?>
      <tr>
        <td colspan="6" style="text-align:center;color:#666;">No buyers found.</td>
      </tr>
      <?php endif; ?>
    </tbody>
  </table>

  <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>

  <input type="hidden" name="task" value="" />
  <input type="hidden" name="filter_order" value="<?php echo htmlspecialchars($this->state->get('list.ordering')); ?>" />
  <input type="hidden" name="filter_order_Dir" value="<?php echo htmlspecialchars($this->state->get('list.direction')); ?>" />
  <?php echo JHtml::_('form.token'); ?>
</form>
