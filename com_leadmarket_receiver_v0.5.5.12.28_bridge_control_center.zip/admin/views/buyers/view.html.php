<?php
defined('_JEXEC') or die;

class LeadMarketViewBuyers extends JViewLegacy
{
  public $items;
  public $pagination;
  public $state;

  public function display($tpl = null)
  {
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    $this->state = $this->get('State');

    JToolbarHelper::title('LeadMarket - Buyers', 'users');

    parent::display($tpl);
  }
}
