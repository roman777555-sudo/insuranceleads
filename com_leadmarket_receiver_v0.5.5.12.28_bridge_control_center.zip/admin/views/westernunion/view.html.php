<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketViewWesternUnion extends JViewLegacy
{
  protected $items;
  protected $pagination;
  protected $state;
  protected $summary;
  protected $params;

  public function display($tpl = null)
  {
    LeadMarketHelper::ensureSchema();
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    $this->state = $this->get('State');
    $this->summary = $this->get('Summary');
    $this->params = JComponentHelper::getParams('com_leadmarket');

    JToolbarHelper::title('LeadMarket - Western Union', 'credit');
    parent::display($tpl);
  }
}
