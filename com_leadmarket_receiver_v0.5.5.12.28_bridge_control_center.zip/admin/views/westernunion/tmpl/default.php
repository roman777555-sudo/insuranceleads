<?php defined('_JEXEC') or die; ?>
<?php
$token = JSession::getFormToken();
$p = $this->params;
$summary = (array) $this->summary;
$minAmount = (float) $p->get('moneygram_min_amount_usd', 100);
$enabled = (int) $p->get('moneygram_enabled', 1);
$receiverName = (string) $p->get('moneygram_receiver_name', '');
$receiverCountry = (string) $p->get('moneygram_receiver_country', 'Turkey');
$instructions = (string) $p->get('moneygram_instructions', '');
$autoApply = (int) $p->get('topup_auto_apply_on_paid', 0);
?>
<?php echo LeadMarketHelper::renderAdminQuickNav('westernunion'); ?>

<div style="display:grid;grid-template-columns:minmax(340px,420px) 1fr;gap:18px;align-items:start;">
  <div>
    <form action="index.php?option=com_leadmarket" method="post" style="background:#fff;border:1px solid #d8e7f3;border-radius:18px;padding:18px;box-shadow:0 10px 24px rgba(12,85,133,.06);margin-bottom:18px;">
      <h2 style="margin:0 0 6px;font-size:22px;line-height:1.2;">Western Union settings</h2>
      <div style="color:#5c6f7f;margin-bottom:14px;">Configure the manual top-up method, the receiver details shown to buyers, and the review behavior after a transfer is confirmed.</div>

      <div class="control-group" style="margin-bottom:12px;">
        <div class="control-label" style="font-weight:700;margin-bottom:6px;">Enable Western Union</div>
        <div class="controls"><select name="jform[moneygram_enabled]"><option value="1" <?php echo $enabled === 1 ? 'selected' : ''; ?>>Enabled</option><option value="0" <?php echo $enabled === 0 ? 'selected' : ''; ?>>Disabled</option></select></div>
      </div>

      <div class="control-group" style="margin-bottom:12px;">
        <div class="control-label" style="font-weight:700;margin-bottom:6px;">Minimum amount (USD)</div>
        <div class="controls"><input type="text" name="jform[moneygram_min_amount_usd]" value="<?php echo htmlspecialchars(number_format($minAmount, 2, '.', '')); ?>" style="width:140px"></div>
      </div>

      <div class="control-group" style="margin-bottom:12px;">
        <div class="control-label" style="font-weight:700;margin-bottom:6px;">Receiver name</div>
        <div class="controls"><input type="text" name="jform[moneygram_receiver_name]" value="<?php echo htmlspecialchars($receiverName); ?>" style="width:100%"></div>
      </div>

      <div class="control-group" style="margin-bottom:12px;">
        <div class="control-label" style="font-weight:700;margin-bottom:6px;">Receiver country</div>
        <div class="controls"><input type="text" name="jform[moneygram_receiver_country]" value="<?php echo htmlspecialchars($receiverCountry); ?>" style="width:100%"></div>
      </div>

      <div class="control-group" style="margin-bottom:12px;">
        <div class="control-label" style="font-weight:700;margin-bottom:6px;">Instructions shown to buyers</div>
        <div class="controls"><textarea name="jform[moneygram_instructions]" rows="5" style="width:100%;max-width:100%;"><?php echo htmlspecialchars($instructions); ?></textarea></div>
      </div>

      <div class="control-group" style="margin-bottom:16px;">
        <div class="control-label" style="font-weight:700;margin-bottom:6px;">Auto-apply linked top-up when marked paid</div>
        <div class="controls"><select name="jform[topup_auto_apply_on_paid]"><option value="1" <?php echo $autoApply === 1 ? 'selected' : ''; ?>>Enabled</option><option value="0" <?php echo $autoApply === 0 ? 'selected' : ''; ?>>Disabled</option></select><div class="help-block" style="margin-top:6px;color:#667681;">When enabled, manually confirming a Western Union top-up will credit the wallet and automatically reopen the linked lead or batch when possible.</div></div>
      </div>

      <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
        <button class="btn btn-success" type="submit">Save Western Union settings</button>
        <a class="btn" href="index.php?option=com_leadmarket&view=westernunion">Reset</a>
      </div>

      <?php echo JHtml::_('form.token'); ?>
      <input type="hidden" name="task" value="config.save" />
      <input type="hidden" name="return_view" value="westernunion" />
    </form>

    <div style="background:#fff;border:1px solid #d8e7f3;border-radius:18px;padding:18px;box-shadow:0 10px 24px rgba(12,85,133,.06);">
      <h3 style="margin:0 0 10px;font-size:18px;line-height:1.3;">Current buyer-facing details</h3>
      <div style="display:grid;gap:10px;font-size:14px;">
        <div><strong>Status:</strong> <?php echo $enabled ? '<span style="color:#0b7a2e;font-weight:700;">Enabled</span>' : '<span style="color:#9a4a14;font-weight:700;">Disabled</span>'; ?></div>
        <div><strong>Minimum:</strong> $<?php echo number_format($minAmount, 2, '.', ''); ?></div>
        <div><strong>Receiver:</strong> <?php echo htmlspecialchars($receiverName !== '' ? $receiverName : 'Not set'); ?></div>
        <div><strong>Country:</strong> <?php echo htmlspecialchars($receiverCountry !== '' ? $receiverCountry : 'Not set'); ?></div>
        <div><strong>Instructions:</strong><div style="margin-top:6px;padding:10px 12px;border-radius:12px;background:#f6fbff;border:1px solid #e2edf6;color:#33434d;"><?php echo nl2br(htmlspecialchars($instructions !== '' ? $instructions : 'Not set')); ?></div></div>
      </div>
    </div>
  </div>

  <div>
    <div style="display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px;">
      <?php
      $cards = array(
        array('Requests', (int) ($summary['total_requests'] ?? 0), '#0c5585'),
        array('Awaiting review', (int) ($summary['awaiting_review'] ?? 0), '#9a4a14'),
        array('Paid', (int) ($summary['paid_count'] ?? 0), '#0b7a2e'),
        array('Paid total', '$' . number_format((float) ($summary['paid_amount'] ?? 0), 2, '.', ''), '#33434d'),
      );
      foreach ($cards as $card):
      ?>
      <div style="background:#fff;border:1px solid #d8e7f3;border-radius:16px;padding:14px 16px;box-shadow:0 10px 24px rgba(12,85,133,.06);">
        <div style="font-size:12px;font-weight:700;color:#6b7c88;text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px;"><?php echo htmlspecialchars($card[0]); ?></div>
        <div style="font-size:26px;line-height:1.1;font-weight:800;color:<?php echo $card[2]; ?>;"><?php echo htmlspecialchars((string) $card[1]); ?></div>
      </div>
      <?php endforeach; ?>
    </div>

    <div style="background:#fff;border:1px solid #d8e7f3;border-radius:18px;padding:18px;box-shadow:0 10px 24px rgba(12,85,133,.06);margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:12px;">
        <div>
          <h2 style="margin:0;font-size:22px;line-height:1.2;">Western Union top-up requests</h2>
          <div style="color:#5c6f7f;margin-top:4px;">Only Western Union manual requests are shown here. Manually marking a request as paid uses the existing top-up credit flow.</div>
        </div>
        <a class="btn" href="index.php?option=com_leadmarket&view=topups">Open all top-ups</a>
      </div>

      <form action="index.php?option=com_leadmarket&view=westernunion" method="post" name="adminForm" id="adminForm">
        <div class="js-stools clearfix" style="margin-bottom:12px;">
          <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
            <input type="text" name="filter_search" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" placeholder="Search buyer email, MTCN, sender, or #ID" />
            <select name="filter_status">
              <option value="">- Status -</option>
              <?php foreach (array('pending','checking','pending_review','paid','cancelled','expired') as $s): ?>
                <option value="<?php echo $s; ?>" <?php echo $this->state->get('filter.status') === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
              <?php endforeach; ?>
            </select>
            <select name="filter_target_type">
              <option value="">- Target -</option>
              <?php foreach (array('lead','batch','manual') as $s): ?>
                <option value="<?php echo $s; ?>" <?php echo $this->state->get('filter.target_type') === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
              <?php endforeach; ?>
            </select>
            <button class="btn btn-small" type="submit">Filter</button>
            <a class="btn btn-small" href="index.php?option=com_leadmarket&view=westernunion">Clear</a>
          </div>
        </div>

        <div style="overflow:auto;">
          <table class="table table-striped">
            <thead>
              <tr>
                <th><?php echo JHtml::_('grid.sort', 'ID', 't.id', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
                <th><?php echo JHtml::_('grid.sort', 'Created (UTC)', 't.created_at_utc', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
                <th><?php echo JHtml::_('grid.sort', 'Buyer Email', 't.buyer_email', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
                <th><?php echo JHtml::_('grid.sort', 'Status', 't.status', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
                <th>Target</th>
                <th>Top-up amount</th>
                <th>Manual ref / MTCN</th>
                <th>Sender</th>
                <th>After credit</th>
                <th>Paid (UTC)</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ((array) $this->items as $it): ?>
              <tr>
                <td><?php echo (int) $it->id; ?></td>
                <td><?php echo htmlspecialchars($it->created_at_utc); ?></td>
                <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
                <td><?php echo htmlspecialchars($it->status); ?></td>
                <td><?php echo htmlspecialchars(trim((string) $it->target_type) !== '' ? $it->target_type . '#' . (int) $it->target_id : 'manual'); ?></td>
                <td>$<?php echo number_format((float) $it->topup_amount_usd, 2, '.', ''); ?></td>
                <td><?php echo htmlspecialchars(!empty($it->manual_reference) ? $it->manual_reference : '—'); ?></td>
                <td><?php echo htmlspecialchars(trim((string) ($it->manual_sender_name ?? '')) !== '' ? trim((string) $it->manual_sender_name) . (!empty($it->manual_sender_country) ? ' / ' . trim((string) $it->manual_sender_country) : '') : '—'); ?></td>
                <td><?php echo $it->balance_after_credit !== null && $it->balance_after_credit !== '' ? '$' . number_format((float) $it->balance_after_credit, 2, '.', '') : '—'; ?></td>
                <td><?php echo htmlspecialchars(!empty($it->paid_at_utc) ? $it->paid_at_utc : '—'); ?></td>
                <td>
                  <div style="display:flex;gap:6px;flex-wrap:wrap;">
                    <?php if (in_array((string)$it->status, array('pending','checking','pending_review'), true)): ?>
                      <a class="btn btn-small btn-success" href="index.php?option=com_leadmarket&task=topups.markpaid&id=<?php echo (int)$it->id; ?>&return_view=westernunion&<?php echo $token; ?>=1">Mark paid</a>
                      <a class="btn btn-small btn-danger" href="index.php?option=com_leadmarket&task=topups.cancel&id=<?php echo (int)$it->id; ?>&return_view=westernunion&<?php echo $token; ?>=1" onclick="return confirm('Cancel this Western Union top-up?');">Cancel</a>
                    <?php endif; ?>
                    <?php if ((string)$it->target_type === 'lead' && (int)$it->target_id > 0): ?>
                      <a class="btn btn-small" target="_blank" href="../index.php?option=com_leadmarket&view=lead&id=<?php echo (int)$it->target_id; ?>&buyer_email=<?php echo urlencode((string)$it->buyer_email); ?>">Open lead</a>
                    <?php elseif ((string)$it->target_type === 'batch' && (int)$it->target_id > 0): ?>
                      <a class="btn btn-small" target="_blank" href="../index.php?option=com_leadmarket&view=batch&id=<?php echo (int)$it->target_id; ?>&buyer_email=<?php echo urlencode((string)$it->buyer_email); ?>">Open batch</a>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
              <?php if (empty($this->items)): ?>
              <tr><td colspan="11" style="text-align:center;color:#667681;padding:22px 12px;">No Western Union top-up requests matched the current filters.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <?php if (!empty($this->pagination)): ?>
          <div style="margin-top:12px;"><?php echo $this->pagination->getListFooter(); ?></div>
        <?php endif; ?>
      </form>
    </div>
  </div>
</div>
