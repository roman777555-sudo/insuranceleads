<?php defined('_JEXEC') or die; ?>
<?php JHtml::_('behavior.multiselect'); ?>
<?php echo LeadMarketHelper::renderAdminQuickNav('leads'); ?>
<?php
$state = $this->state;
$filterState = strtoupper(trim((string) $state->get('filter.state')));
$filterMarketVisibility = strtolower(trim((string) $state->get('filter.market_visibility')));
$filterMarketStatus = strtolower(trim((string) $state->get('filter.market_status')));
$filterSoldState = strtolower(trim((string) $state->get('filter.sold_state')));
$filterActiveCheckout = strtolower(trim((string) $state->get('filter.active_checkout')));
$filterExclusive = strtolower(trim((string) $state->get('filter.exclusive')));
$filterRecentAction = strtolower(trim((string) $state->get('filter.recent_action')));
?>
<form action="index.php?option=com_leadmarket&view=leads" method="post" name="adminForm" id="adminForm">
  <div class="container-fluid">
    <div class="alert alert-info">
      <div><b>Receiver URL (set in QAI):</b> <code><?php echo JUri::root(); ?>?option=com_leadmarket&amp;task=api.receive</code></div>
      <div><b>Daily Digest Cron (UTC):</b> <code><?php echo JUri::root(); ?>index.php?option=com_leadmarket&amp;task=api.cronDailyDigest&amp;key=YOUR_CRON_KEY</code></div>
      <div><b>Payment Check Cron:</b> <code><?php echo JUri::root(); ?>index.php?option=com_leadmarket&amp;task=cronverify&amp;key=YOUR_CRON_KEY</code><div style="margin-top:6px;font-size:12px;color:#44545e;">This cron checks pending orders, batches, and top-ups automatically.</div></div>
      <div style="margin-top:8px;"><b>Market arrival:</b> Marketplace order and freshness badges follow <code>uploaded_at_utc</code>. <i>Refresh Arrival Date</i> only moves selected leads higher and makes them fresh again for buyers.</div>
      <div style="margin-top:6px;"><b>Testing:</b> <i>Reset Test Usage</i> restores selected test leads to an unsold state and puts them back on their original marketplace arrival time.</div>
    </div>

    <div style="background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:12px 14px;margin-bottom:14px;display:flex;flex-wrap:wrap;gap:10px;align-items:end;">
      <div>
        <label style="display:block;font-size:12px;font-weight:700;color:#44545e;margin-bottom:4px;">State</label>
        <select name="filter_state" onchange="document.adminForm.submit()" style="min-width:100px;">
          <option value="">All</option>
          <?php foreach (array('AL','AK','AZ','AR','CA','CO','CT','DE','FL','GA','HI','IA','ID','IL','IN','KS','KY','LA','MA','MD','ME','MI','MN','MO','MS','MT','NC','ND','NE','NH','NJ','NM','NV','NY','OH','OK','OR','PA','RI','SC','SD','TN','TX','UT','VA','VT','WA','WI','WV','WY') as $code): ?>
            <option value="<?php echo $code; ?>" <?php echo $filterState === $code ? 'selected' : ''; ?>><?php echo $code; ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label style="display:block;font-size:12px;font-weight:700;color:#44545e;margin-bottom:4px;">Market visibility</label>
        <select name="filter_market_visibility" onchange="document.adminForm.submit()">
          <option value="">All</option>
          <option value="listed" <?php echo $filterMarketVisibility === 'listed' ? 'selected' : ''; ?>>In market</option>
          <option value="hidden" <?php echo $filterMarketVisibility === 'hidden' ? 'selected' : ''; ?>>Not in market</option>
        </select>
      </div>
      <div>
        <label style="display:block;font-size:12px;font-weight:700;color:#44545e;margin-bottom:4px;">Market status</label>
        <select name="filter_market_status" onchange="document.adminForm.submit()">
          <option value="">All</option>
          <option value="fresh" <?php echo $filterMarketStatus === 'fresh' ? 'selected' : ''; ?>>Fresh</option>
          <option value="aged" <?php echo $filterMarketStatus === 'aged' ? 'selected' : ''; ?>>Aged</option>
          <option value="archived" <?php echo $filterMarketStatus === 'archived' ? 'selected' : ''; ?>>Archived</option>
        </select>
      </div>
      <div>
        <label style="display:block;font-size:12px;font-weight:700;color:#44545e;margin-bottom:4px;">Sold</label>
        <select name="filter_sold_state" onchange="document.adminForm.submit()">
          <option value="">All</option>
          <option value="unsold" <?php echo $filterSoldState === 'unsold' ? 'selected' : ''; ?>>Unsold</option>
          <option value="sold" <?php echo $filterSoldState === 'sold' ? 'selected' : ''; ?>>Sold</option>
        </select>
      </div>
      <div>
        <label style="display:block;font-size:12px;font-weight:700;color:#44545e;margin-bottom:4px;">Active checkout</label>
        <select name="filter_active_checkout" onchange="document.adminForm.submit()">
          <option value="">All</option>
          <option value="yes" <?php echo $filterActiveCheckout === 'yes' ? 'selected' : ''; ?>>Yes</option>
          <option value="no" <?php echo $filterActiveCheckout === 'no' ? 'selected' : ''; ?>>No</option>
        </select>
      </div>
      <div>
        <label style="display:block;font-size:12px;font-weight:700;color:#44545e;margin-bottom:4px;">Exclusive lock</label>
        <select name="filter_exclusive" onchange="document.adminForm.submit()">
          <option value="">All</option>
          <option value="yes" <?php echo $filterExclusive === 'yes' ? 'selected' : ''; ?>>Yes</option>
          <option value="no" <?php echo $filterExclusive === 'no' ? 'selected' : ''; ?>>No</option>
        </select>
      </div>
      <div>
        <label style="display:block;font-size:12px;font-weight:700;color:#44545e;margin-bottom:4px;">Recent action</label>
        <select name="filter_recent_action" onchange="document.adminForm.submit()">
          <option value="">All</option>
          <option value="reset" <?php echo $filterRecentAction === 'reset' ? 'selected' : ''; ?>>Reset recently</option>
          <option value="refresh" <?php echo $filterRecentAction === 'refresh' ? 'selected' : ''; ?>>Refreshed recently</option>
        </select>
      </div>
      <div style="margin-left:auto;display:flex;gap:8px;">
        <a class="btn btn-small" href="index.php?option=com_leadmarket&view=leads&clear_filters=1">Clear filters</a>
      </div>
    </div>

    <table class="table table-striped table-condensed">
      <thead>
        <tr>
          <th width="1%"><input type="checkbox" name="checkall-toggle" value="" onclick="Joomla.checkAll(this)" /></th>
          <th>ID</th>
          <th>Lead</th>
          <th>Price</th>
          <th>Market</th>
          <th>Reason</th>
          <th>Related</th>
          <th>Inspector</th>
          <th>Sample</th>
          <th>Free Test</th>
          <th>Email Sends</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ((array)$this->items as $i => $it): ?>
        <?php
          $masked = LeadMarketHelper::buildMaskedPreview((array)$it);
          $cityOut = trim((string)$it->city) !== '' ? (string)$it->city : (string)$masked['city'];
          $inspector = LeadMarketHelper::getAdminLeadInspector((array)$it);
          $marketColor = !empty($inspector['listed']) ? '#1f7a3d' : '#8a3d3d';
          $marketBg = !empty($inspector['listed']) ? '#ecf8f0' : '#fff1f1';
          $statusBg = strtolower((string)$it->lead_status) === 'archived' ? '#f4f0ff' : '#eef7fd';
        ?>
        <tr>
          <td><?php echo JHtml::_('grid.id', $i, $it->id); ?></td>
          <td><?php echo (int)$it->id; ?></td>
          <td>
            <div style="font-weight:700;color:#13232f;"><?php echo htmlspecialchars(strtoupper((string)$it->state) . ' · ' . ucfirst((string)$it->type) . ' lead'); ?></div>
            <div style="font-size:12px;color:#5b6c78;"><?php echo htmlspecialchars($cityOut !== '' ? $cityOut : 'Unknown city'); ?><?php echo trim((string)$it->zip) !== '' ? ' · ' . htmlspecialchars((string)$it->zip) : ''; ?></div>
            <?php if (trim((string)$it->reserve_until_utc) !== ''): ?>
              <div style="font-size:11px;color:#7a6a2a;">Reserve until: <?php echo htmlspecialchars((string)$it->reserve_until_utc); ?></div>
            <?php endif; ?>
          </td>
          <td>
            <div style="font-weight:700;">$<?php echo htmlspecialchars(number_format((float)$it->price_usd, 2)); ?></div>
            <div style="font-size:12px;color:#5b6c78;">Sold: <?php echo (int)$it->sold_count; ?></div>
          </td>
          <td>
            <span style="display:inline-block;padding:3px 8px;border-radius:999px;background:<?php echo $marketBg; ?>;color:<?php echo $marketColor; ?>;font-size:11px;font-weight:700;">
              <?php echo htmlspecialchars($inspector['listed_label']); ?>
            </span>
            <div style="margin-top:6px;display:inline-block;padding:3px 8px;border-radius:999px;background:<?php echo $statusBg; ?>;color:#0c5585;font-size:11px;font-weight:700;">
              <?php echo htmlspecialchars($inspector['market_status']); ?>
            </div>
          </td>
          <td>
            <div style="font-weight:700;color:#22313b;"><?php echo htmlspecialchars($inspector['reason']); ?></div>
            <?php if (!empty($inspector['last_event_message'])): ?>
              <div style="font-size:12px;color:#5b6c78;margin-top:4px;"><?php echo htmlspecialchars((string)$inspector['last_event_message']); ?></div>
            <?php endif; ?>
          </td>
          <td>
            <div style="font-size:12px;line-height:1.6;">
              <div><b>Orders:</b> <?php echo (int)$inspector['orders_count']; ?></div>
              <div><b>Top-ups:</b> <?php echo (int)$inspector['topups_count']; ?></div>
              <div><b>Batches:</b> <?php echo (int)$inspector['batches_count']; ?></div>
            </div>
          </td>
          <td><?php echo LeadMarketHelper::renderAdminLeadInspectorHtml((array)$it); ?></td>
          <td>
            <?php if (!empty($it->is_sample)): ?>
              <div style="display:inline-block;padding:3px 8px;border-radius:999px;background:#fff8e7;color:#7a5a00;font-size:11px;font-weight:700;border:1px solid #f0d999;">Sample <?php echo htmlspecialchars(strtoupper((string)($it->sample_type ?: $it->type))); ?></div>
              <?php if (!empty($it->sample_active)): ?><div style="margin-top:6px;font-size:11px;color:#1f7a3d;font-weight:700;">Active</div><?php else: ?><div style="margin-top:6px;font-size:11px;color:#8a3d3d;font-weight:700;">Inactive</div><?php endif; ?>
            <?php else: ?>
              <div style="font-size:11px;color:#61717f;">No</div>
            <?php endif; ?>
            <div style="margin-top:6px;"><a href="index.php?option=com_leadmarket&task=leads.sampleSettings&id=<?php echo (int)$it->id; ?>">Settings</a></div>
          </td>
          <td>
            <?php if (!empty($it->is_free_test)): ?>
              <div style="display:inline-block;padding:3px 8px;border-radius:999px;background:#eefaf0;color:#1f6b35;font-size:11px;font-weight:700;border:1px solid #cfe5d4;">Free Test</div>
              <?php if (!empty($it->free_test_active)): ?><div style="margin-top:6px;font-size:11px;color:#1f7a3d;font-weight:700;">Active</div><?php else: ?><div style="margin-top:6px;font-size:11px;color:#8a3d3d;font-weight:700;">Inactive</div><?php endif; ?>
            <?php else: ?>
              <div style="font-size:11px;color:#61717f;">No</div>
            <?php endif; ?>
          </td>
          <td><?php echo (int)$it->sent_emails_count; ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>
  </div>
  <input type="hidden" name="task" value="" />
  <input type="hidden" name="boxchecked" value="0" />
  <?php echo JHtml::_('form.token'); ?>
</form>
