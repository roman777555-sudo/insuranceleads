<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketViewLeads extends JViewLegacy
{
  public $items;
  public $pagination;
  public $state;

  public function display($tpl = null)
  {
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    $this->state = $this->get('State');

    JToolbarHelper::title('LeadMarket - Leads', 'list');
    JToolbarHelper::custom('leads.refreshSelected', 'refresh.png', 'refresh_f2.png', 'Refresh Arrival Date', true);
    JToolbarHelper::custom('leads.resetTestUsage', 'undo.png', 'undo_f2.png', 'Reset Test Usage', true);
    JToolbarHelper::custom('leads.markSampleAuto', 'star.png', 'star_f2.png', 'Mark Sample Auto', true);
    JToolbarHelper::custom('leads.markSampleHome', 'star.png', 'star_f2.png', 'Mark Sample Home', true);
    JToolbarHelper::custom('leads.clearSample', 'minus.png', 'minus_f2.png', 'Clear Sample Flag', true);
    JToolbarHelper::custom('leads.markFreeTest', 'featured.png', 'featured_f2.png', 'Mark Free Test', true);
    JToolbarHelper::custom('leads.clearFreeTest', 'unpublish.png', 'unpublish_f2.png', 'Clear Free Test', true);
    JToolbarHelper::deleteList('Delete selected leads? Leads that already have orders will be skipped for safety.', 'leads.deleteSelected');
    JToolbarHelper::divider();
    JToolbarHelper::link('index.php?option=com_leadmarket&view=config', 'Settings', 'options');

    parent::display($tpl);
  }
}
