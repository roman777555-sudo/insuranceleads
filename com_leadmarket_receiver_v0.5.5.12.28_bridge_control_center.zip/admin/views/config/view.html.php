<?php
defined('_JEXEC') or die;

class LeadMarketViewConfig extends JViewLegacy
{
  public $params;

  public function display($tpl = null)
  {
    $this->params = JComponentHelper::getParams('com_leadmarket');

    JToolbarHelper::title('LeadMarket - Settings', 'options');

    // Joomla 3 toolbar mapping:
    // Apply => save and stay on the form
    // Save  => save and close (we route it to save2close)
    JToolbarHelper::apply('config.apply');
    JToolbarHelper::save('config.save2close');
    JToolbarHelper::cancel('config.cancel', 'JTOOLBAR_CLOSE');
    parent::display($tpl);
  }
}
