<?php
defined('_JEXEC') or die;
$app = JFactory::getApplication();
$search = (string) $this->state->get('filter.search');
$active = (string) $this->state->get('filter.active');
?>
<style>
.lm-admin-grid{display:grid;grid-template-columns:minmax(0,1.1fr) minmax(0,1.6fr);gap:18px;align-items:start}
.lm-admin-card{background:#fff;border:1px solid #dde7ef;border-radius:16px;padding:18px;box-sizing:border-box}
.lm-admin-card h3{margin:0 0 12px;color:#0c5585}
.lm-admin-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}
.lm-admin-form-grid label{display:block;font-weight:700;margin:0 0 6px}
.lm-admin-form-grid input,.lm-admin-form-grid select,.lm-admin-form-grid textarea{display:block;width:100%;min-height:42px;padding:0 12px;border:1px solid #cfdbe5;border-radius:10px;box-sizing:border-box}
.lm-admin-form-grid textarea{padding:10px 12px;min-height:88px}
.lm-admin-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}
.lm-admin-btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 16px;border-radius:10px;border:1px solid #0c5585;background:#0c5585;color:#fff;text-decoration:none;font-weight:700;cursor:pointer}
.lm-admin-btn--ghost{background:#fff;color:#0c5585}
.lm-admin-table{width:100%;border-collapse:collapse}
.lm-admin-table th,.lm-admin-table td{padding:10px 8px;border-bottom:1px solid #edf2f7;vertical-align:top;text-align:left}
.lm-admin-badge{display:inline-block;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid #d8e6ee;background:#f8fbfd;color:#0c5585}
.lm-admin-badge--ok{background:#edf8f1;border-color:#cfe7d8;color:#1f6a3c}
</style>

<?php echo LeadMarketHelper::renderAdminQuickNav('promocodes'); ?>

<div class="lm-admin-card" style="margin-bottom:16px;">
  <form action="index.php?option=com_leadmarket&view=promocodes" method="get" style="display:flex;flex-wrap:wrap;gap:10px;align-items:end;">
    <input type="hidden" name="option" value="com_leadmarket">
    <input type="hidden" name="view" value="promocodes">
    <div>
      <label for="filter_search"><strong>Search</strong></label>
      <input id="filter_search" type="text" name="filter_search" value="<?php echo htmlspecialchars($search, ENT_QUOTES, 'UTF-8'); ?>" style="min-width:220px;min-height:42px;padding:0 12px;border:1px solid #cfdbe5;border-radius:10px;box-sizing:border-box;">
    </div>
    <div>
      <label for="filter_active"><strong>Status</strong></label>
      <select id="filter_active" name="filter_active" style="min-width:160px;min-height:42px;padding:0 12px;border:1px solid #cfdbe5;border-radius:10px;box-sizing:border-box;">
        <option value=""<?php echo $active === '' ? ' selected="selected"' : ''; ?>>All</option>
        <option value="1"<?php echo $active === '1' ? ' selected="selected"' : ''; ?>>Active</option>
        <option value="0"<?php echo $active === '0' ? ' selected="selected"' : ''; ?>>Inactive</option>
      </select>
    </div>
    <button class="lm-admin-btn" type="submit">Filter</button>
  </form>
</div>

<div class="lm-admin-grid">
  <div class="lm-admin-card">
    <h3>Create Promo Code</h3>
    <form action="index.php?option=com_leadmarket&task=promocodes.save" method="post">
      <?php echo JHtml::_('form.token'); ?>
      <div class="lm-admin-form-grid">
        <div><label>Code</label><input type="text" name="code" required></div>
        <div><label>Title / note</label><input type="text" name="title"></div>
        <div><label>Discount type</label><select name="discount_type"><option value="fixed">Fixed USD</option><option value="percent">Percent</option></select></div>
        <div><label>Discount value</label><input type="number" step="0.01" min="0" name="discount_value" value="0"></div>
        <div><label>Max discount cap</label><input type="number" step="0.01" min="0" name="max_discount_amount" value=""></div>
        <div><label>Minimum order amount</label><input type="number" step="0.01" min="0" name="min_order_amount" value="0"></div>
        <div><label>Usage mode</label><select name="usage_mode"><option value="multi_use">Multi-use</option><option value="one_time_total">One-time total</option></select></div>
        <div><label>Max total uses</label><input type="number" min="0" name="max_total_uses" value=""></div>
        <div><label>Max uses per buyer</label><input type="number" min="0" name="max_uses_per_buyer" value=""></div>
        <div><label>Checkout type</label><select name="applies_checkout_type"><option value="both">Single + Batch</option><option value="single">Single only</option><option value="batch">Batch only</option></select></div>
        <div><label>Lead type</label><select name="applies_lead_type"><option value="both">Auto + Home</option><option value="auto">Auto only</option><option value="home">Home only</option></select></div>
        <div><label>Starts at</label><input type="text" name="starts_at" placeholder="YYYY-MM-DD HH:MM:SS"></div>
        <div><label>Ends at</label><input type="text" name="ends_at" placeholder="YYYY-MM-DD HH:MM:SS"></div>
        <div style="grid-column:1 / -1;"><label>Internal note</label><textarea name="note"></textarea></div>
        <div><label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1" checked style="width:auto;min-height:0;padding:0;"> Active</label></div>
      </div>
      <div class="lm-admin-actions"><button class="lm-admin-btn" type="submit">Save Promo Code</button></div>
    </form>
  </div>

  <div class="lm-admin-card">
    <h3>Existing Promo Codes</h3>
    <table class="lm-admin-table">
      <thead>
        <tr>
          <th>Code</th>
          <th>Discount</th>
          <th>Scope</th>
          <th>Usage</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$this->items): ?>
        <tr><td colspan="6">No promo codes found.</td></tr>
      <?php else: foreach ($this->items as $item): ?>
        <tr>
          <td>
            <strong><?php echo htmlspecialchars($item->code, ENT_QUOTES, 'UTF-8'); ?></strong><br>
            <span style="color:#607080;font-size:12px;"><?php echo htmlspecialchars((string) $item->title, ENT_QUOTES, 'UTF-8'); ?></span>
          </td>
          <td>
            <?php if ((string) $item->discount_type === 'percent'): ?>
              <?php echo htmlspecialchars(rtrim(rtrim(number_format((float) $item->discount_value, 2, '.', ''), '0'), '.'), ENT_QUOTES, 'UTF-8'); ?>%
            <?php else: ?>
              $<?php echo htmlspecialchars(number_format((float) $item->discount_value, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>
            <?php endif; ?>
            <?php if ((float) $item->max_discount_amount > 0): ?><br><span style="color:#607080;font-size:12px;">cap $<?php echo htmlspecialchars(number_format((float) $item->max_discount_amount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?></span><?php endif; ?>
          </td>
          <td>
            <span style="display:block;font-size:13px;"><?php echo htmlspecialchars((string) $item->applies_checkout_type, ENT_QUOTES, 'UTF-8'); ?></span>
            <span style="display:block;font-size:13px;color:#607080;"><?php echo htmlspecialchars((string) $item->applies_lead_type, ENT_QUOTES, 'UTF-8'); ?></span>
          </td>
          <td>
            <span style="display:block;font-size:13px;"><?php echo htmlspecialchars((string) $item->usage_mode, ENT_QUOTES, 'UTF-8'); ?></span>
            <span style="display:block;font-size:13px;color:#607080;">confirmed uses: <?php echo (int) $item->confirmed_uses; ?></span>
          </td>
          <td>
            <span class="lm-admin-badge <?php echo (int) $item->is_active === 1 ? 'lm-admin-badge--ok' : ''; ?>"><?php echo (int) $item->is_active === 1 ? 'Active' : 'Inactive'; ?></span>
            <?php if (!empty($item->ends_at)): ?><br><span style="display:block;color:#607080;font-size:12px;margin-top:6px;">Ends: <?php echo htmlspecialchars((string) $item->ends_at, ENT_QUOTES, 'UTF-8'); ?></span><?php endif; ?>
          </td>
          <td>
            <form action="index.php?option=com_leadmarket&task=promocodes.delete" method="post" onsubmit="return confirm('Delete this promo code?');" style="margin:0 0 8px;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="id" value="<?php echo (int) $item->id; ?>">
              <button class="lm-admin-btn lm-admin-btn--ghost" type="submit">Delete</button>
            </form>
            <details>
              <summary style="cursor:pointer;font-weight:700;">Edit</summary>
              <form action="index.php?option=com_leadmarket&task=promocodes.save" method="post" style="margin-top:10px;">
                <?php echo JHtml::_('form.token'); ?>
                <input type="hidden" name="id" value="<?php echo (int) $item->id; ?>">
                <div class="lm-admin-form-grid" style="grid-template-columns:1fr;">
                  <div><label>Code</label><input type="text" name="code" value="<?php echo htmlspecialchars((string) $item->code, ENT_QUOTES, 'UTF-8'); ?>" required></div>
                  <div><label>Title</label><input type="text" name="title" value="<?php echo htmlspecialchars((string) $item->title, ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Discount type</label><select name="discount_type"><option value="fixed"<?php echo (string)$item->discount_type === 'fixed' ? ' selected="selected"' : ''; ?>>Fixed USD</option><option value="percent"<?php echo (string)$item->discount_type === 'percent' ? ' selected="selected"' : ''; ?>>Percent</option></select></div>
                  <div><label>Discount value</label><input type="number" step="0.01" min="0" name="discount_value" value="<?php echo htmlspecialchars(number_format((float) $item->discount_value, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Minimum order</label><input type="number" step="0.01" min="0" name="min_order_amount" value="<?php echo htmlspecialchars(number_format((float) $item->min_order_amount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Checkout type</label><select name="applies_checkout_type"><option value="both"<?php echo (string)$item->applies_checkout_type === 'both' ? ' selected="selected"' : ''; ?>>Single + Batch</option><option value="single"<?php echo (string)$item->applies_checkout_type === 'single' ? ' selected="selected"' : ''; ?>>Single only</option><option value="batch"<?php echo (string)$item->applies_checkout_type === 'batch' ? ' selected="selected"' : ''; ?>>Batch only</option></select></div>
                  <div><label>Lead type</label><select name="applies_lead_type"><option value="both"<?php echo (string)$item->applies_lead_type === 'both' ? ' selected="selected"' : ''; ?>>Auto + Home</option><option value="auto"<?php echo (string)$item->applies_lead_type === 'auto' ? ' selected="selected"' : ''; ?>>Auto only</option><option value="home"<?php echo (string)$item->applies_lead_type === 'home' ? ' selected="selected"' : ''; ?>>Home only</option></select></div>
                  <div><label>Usage mode</label><select name="usage_mode"><option value="multi_use"<?php echo (string)$item->usage_mode === 'multi_use' ? ' selected="selected"' : ''; ?>>Multi-use</option><option value="one_time_total"<?php echo (string)$item->usage_mode === 'one_time_total' ? ' selected="selected"' : ''; ?>>One-time total</option></select></div>
                  <div><label>Max total uses</label><input type="number" min="0" name="max_total_uses" value="<?php echo htmlspecialchars((string) $item->max_total_uses, ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Max uses per buyer</label><input type="number" min="0" name="max_uses_per_buyer" value="<?php echo htmlspecialchars((string) $item->max_uses_per_buyer, ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Starts at</label><input type="text" name="starts_at" value="<?php echo htmlspecialchars((string) $item->starts_at, ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Ends at</label><input type="text" name="ends_at" value="<?php echo htmlspecialchars((string) $item->ends_at, ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Max discount cap</label><input type="number" step="0.01" min="0" name="max_discount_amount" value="<?php echo htmlspecialchars((string) $item->max_discount_amount, ENT_QUOTES, 'UTF-8'); ?>"></div>
                  <div><label>Internal note</label><textarea name="note"><?php echo htmlspecialchars((string) $item->note, ENT_QUOTES, 'UTF-8'); ?></textarea></div>
                  <div><label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="is_active" value="1"<?php echo (int)$item->is_active === 1 ? ' checked="checked"' : ''; ?> style="width:auto;min-height:0;padding:0;"> Active</label></div>
                </div>
                <div class="lm-admin-actions"><button class="lm-admin-btn" type="submit">Save Changes</button></div>
              </form>
            </details>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
$db = JFactory::getDbo();
$qRecent = $db->getQuery(true)
  ->select('u.*, p.title AS promo_title')
  ->from($db->qn('#__leadmarket_promocode_usages', 'u'))
  ->join('LEFT', $db->qn('#__leadmarket_promocodes', 'p') . ' ON p.id = u.promocode_id')
  ->where('u.status=' . $db->q('confirmed'))
  ->order('u.created_at DESC, u.id DESC');
$db->setQuery($qRecent, 0, 12);
$recentPromoUses = (array) $db->loadObjectList();
?>
<div class="lm-admin-card" style="margin-top:18px;">
  <h3>Recent Confirmed Promo Usage</h3>
  <table class="lm-admin-table">
    <thead>
      <tr><th>Code</th><th>Buyer</th><th>Discount</th><th>Subtotal</th><th>Final total</th><th>Order / Batch</th><th>Date</th></tr>
    </thead>
    <tbody>
      <?php if (!$recentPromoUses): ?>
        <tr><td colspan="7">No confirmed promo usage yet.</td></tr>
      <?php else: foreach ($recentPromoUses as $use): ?>
        <tr>
          <td><strong><?php echo htmlspecialchars((string) $use->promo_code, ENT_QUOTES, 'UTF-8'); ?></strong><br><span style="color:#607080;font-size:12px;"><?php echo htmlspecialchars((string) $use->promo_title, ENT_QUOTES, 'UTF-8'); ?></span></td>
          <td><?php echo htmlspecialchars((string) $use->buyer_email, ENT_QUOTES, 'UTF-8'); ?></td>
          <td>$<?php echo htmlspecialchars(number_format((float) $use->discount_amount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?></td>
          <td>$<?php echo htmlspecialchars(number_format((float) $use->subtotal_before_discount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?></td>
          <td>$<?php echo htmlspecialchars(number_format((float) $use->total_after_discount, 2, '.', ''), ENT_QUOTES, 'UTF-8'); ?></td>
          <td><?php if ((int) $use->order_id > 0): ?>Order #<?php echo (int) $use->order_id; ?><?php endif; ?><?php if ((int) $use->batch_id > 0): ?>Batch #<?php echo (int) $use->batch_id; ?><?php endif; ?></td>
          <td><?php echo htmlspecialchars((string) $use->created_at, ENT_QUOTES, 'UTF-8'); ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>
