<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketViewPromocodes extends JViewLegacy
{
  public $items;
  public $pagination;
  public $state;

  public function display($tpl = null)
  {
    LeadMarketHelper::ensureSchema();
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    $this->state = $this->get('State');
    JToolbarHelper::title('LeadMarket - Promo Codes', 'tag');
    parent::display($tpl);
  }
}
