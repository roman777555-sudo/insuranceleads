<?php
defined('_JEXEC') or die;

class LeadmarketViewSubscriber extends JViewLegacy
{
  protected $form;
  protected $item;

  public function display($tpl = null)
  {
    $this->form = $this->get('Form');
    $this->item = $this->get('Item');

    JToolbarHelper::title('LeadMarket - Subscriber', 'user');
    JToolbarHelper::apply('subscriber.apply');
    JToolbarHelper::save('subscriber.save');
    JToolbarHelper::cancel('subscriber.cancel', 'JTOOLBAR_CLOSE');

    parent::display($tpl);
  }
}
