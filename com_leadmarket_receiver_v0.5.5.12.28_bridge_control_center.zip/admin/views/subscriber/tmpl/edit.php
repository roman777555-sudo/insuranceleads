<?php
defined('_JEXEC') or die;

JHtml::_('behavior.formvalidator');

?>

<form action="<?php echo JRoute::_('index.php?option=com_leadmarket&layout=edit&id=' . (int) $this->item->id); ?>" method="post" name="adminForm" id="adminForm" class="form-validate">

  <div class="form-horizontal">
    <?php echo $this->form->renderFieldset('basic'); ?>
  </div>

  <input type="hidden" name="task" value="" />
  <?php echo JHtml::_('form.token'); ?>
</form>
