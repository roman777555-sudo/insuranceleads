<?php
defined('_JEXEC') or die;

require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/bridge.php';

class LeadMarketViewBridge extends JViewLegacy
{
  public $params;
  public $auditConnections = array();
  public $auditPage = 1;
  public $auditPerPage = 10;
  public $auditTotal = 0;
  public $auditTotalPages = 1;
  public $auditHasPrev = false;
  public $auditHasNext = false;
  public $auditStatus = 'all';
  public $auditQuery = '';
  public $connectionSummary = array();
  public $readiness = array();
  public $recentFailures = array();
  public $pendingProposals = array();
  public $openTasks = array();
  public $eventStream = array();
  public $eventPage = 1;
  public $eventPerPage = 10;
  public $eventType = '';
  public $eventActor = '';
  public $eventIp = '';
  public $eventRange = '24h';
  public $eventQuery = '';
  public $requestId = '';
  public $requestDetails = array();
  public $selfCheck = array();
  public $safeControlMatrix = array();

  public function display($tpl = null)
  {
    $this->params = JComponentHelper::getParams('com_leadmarket');

    $input = JFactory::getApplication()->input;
    $this->auditPage = max(1, $input->getInt('audit_page', 1));
    $this->auditStatus = $input->getCmd('audit_status', 'all');
    if ($this->auditStatus === '') {
      $this->auditStatus = 'all';
    }
    $this->auditQuery = trim((string) $input->getString('audit_q', ''));

    $auditData = LeadMarketBridgeHelper::getAuditConnectionPage($this->auditPage, $this->auditPerPage, array(
      'status' => $this->auditStatus,
      'q' => $this->auditQuery,
    ));
    $this->auditConnections = isset($auditData['items']) && is_array($auditData['items']) ? $auditData['items'] : array();
    $this->auditPage = isset($auditData['page']) ? (int) $auditData['page'] : 1;
    $this->auditPerPage = isset($auditData['per_page']) ? (int) $auditData['per_page'] : 10;
    $this->auditTotal = isset($auditData['total']) ? (int) $auditData['total'] : 0;
    $this->auditTotalPages = isset($auditData['total_pages']) ? (int) $auditData['total_pages'] : 1;
    $this->auditHasPrev = !empty($auditData['has_prev']);
    $this->auditHasNext = !empty($auditData['has_next']);

    $this->connectionSummary = LeadMarketBridgeHelper::getConnectionSummary(7);
    $this->readiness = LeadMarketBridgeHelper::getBridgeReadiness();
    $this->recentFailures = LeadMarketBridgeHelper::getRecentFailures(5);
    $this->pendingProposals = LeadMarketBridgeHelper::getPendingProposals(8);
    $this->openTasks = LeadMarketBridgeHelper::getTasks(array('limit' => 8, 'status' => 'open_like'));

    $this->eventPage = max(1, $input->getInt('event_page', 1));
    $this->eventType = trim((string) $input->getCmd('event_type', ''));
    $this->eventActor = trim((string) $input->getString('event_actor', ''));
    $this->eventIp = trim((string) $input->getString('event_ip', ''));
    $this->eventRange = trim((string) $input->getCmd('event_range', '24h'));
    if ($this->eventRange === '') {
      $this->eventRange = '24h';
    }
    $this->eventQuery = trim((string) $input->getString('event_q', ''));
    $this->eventStream = LeadMarketBridgeHelper::getEventStream(array(
      'page' => $this->eventPage,
      'per_page' => $this->eventPerPage,
      'event_type' => $this->eventType,
      'actor' => $this->eventActor,
      'ip' => $this->eventIp,
      'range' => $this->eventRange,
      'q' => $this->eventQuery,
    ));

    $this->requestId = trim((string) $input->getString('request_id', ''));
    if ($this->requestId !== '') {
      try {
        $this->requestDetails = LeadMarketBridgeHelper::getRequestDetails($this->requestId);
      } catch (Exception $e) {
        JFactory::getApplication()->enqueueMessage($e->getMessage(), 'warning');
        $this->requestDetails = array();
      }
    }

    $this->selfCheck = LeadMarketBridgeHelper::runBridgeSelfCheck();
    $this->safeControlMatrix = LeadMarketBridgeHelper::getSafeControlMatrix();

    JToolbarHelper::title('LeadMarket - Bridge', 'link');
    JToolbarHelper::apply('config.apply');
    JToolbarHelper::save('config.save2close');
    JToolbarHelper::cancel('config.cancel', 'JTOOLBAR_CLOSE');

    parent::display($tpl);
  }
}
