<?php defined('_JEXEC') or die; ?>
<?php echo LeadMarketHelper::renderAdminQuickNav('creditrequests'); ?>
<form action="index.php?option=com_leadmarket&view=creditrequests" method="post" name="adminForm" id="adminForm">
  <div class="js-stools clearfix" style="margin-bottom:12px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
    <input type="text" name="filter_search" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" placeholder="Search buyer email / order / lead" />
    <select name="filter_status">
      <option value="">All statuses</option>
      <?php foreach (array('submitted' => 'Submitted', 'under_review' => 'Under Review', 'approved' => 'Approved', 'declined' => 'Declined') as $value => $label): ?>
        <option value="<?php echo htmlspecialchars($value, ENT_QUOTES, 'UTF-8'); ?>"<?php echo ((string) $this->state->get('filter.status') === $value) ? ' selected="selected"' : ''; ?>><?php echo htmlspecialchars($label, ENT_QUOTES, 'UTF-8'); ?></option>
      <?php endforeach; ?>
    </select>
    <button class="btn btn-small" type="submit">Filter</button>
    <a class="btn btn-small" href="index.php?option=com_leadmarket&view=creditrequests">Clear</a>
  </div>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>Date (UTC)</th>
        <th>Buyer</th>
        <th>Lead / Order</th>
        <th>Reason</th>
        <th>Status</th>
        <th>Requested</th>
        <th>Approved</th>
        <th>Review</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ((array) $this->items as $it): ?>
      <tr>
        <td>#<?php echo (int) $it->id; ?></td>
        <td><?php echo htmlspecialchars($it->created_at ?: '—'); ?></td>
        <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
        <td>Lead #<?php echo (int) $it->lead_id; ?><br>Order #<?php echo (int) $it->order_id; ?></td>
        <td><?php echo htmlspecialchars(LeadMarketHelper::getCreditRequestReasonOptions()[(string) $it->reason_code] ?? ucfirst(str_replace('_', ' ', (string) $it->reason_code))); ?><?php if (!empty($it->buyer_note)): ?><div style="margin-top:6px;color:#60717c;max-width:320px;white-space:normal;"><?php echo nl2br(htmlspecialchars($it->buyer_note)); ?></div><?php endif; ?></td>
        <td><?php $meta = LeadMarketHelper::getCreditRequestStatusMeta((string) $it->status); ?><span style="display:inline-block;padding:6px 10px;border-radius:999px;border:1px solid #d7e4ee;background:#f7fbff;color:#35556b;font-size:12px;font-weight:800;"><?php echo htmlspecialchars($meta['label']); ?></span><?php if (!empty($it->admin_note)): ?><div style="margin-top:6px;color:#60717c;max-width:280px;white-space:normal;"><?php echo nl2br(htmlspecialchars($it->admin_note)); ?></div><?php endif; ?></td>
        <td>$<?php echo number_format((float) $it->requested_amount, 2, '.', ''); ?></td>
        <td>$<?php echo number_format((float) $it->approved_amount, 2, '.', ''); ?></td>
        <td style="min-width:280px;">
          <?php if ((string) $it->status === 'submitted' || (string) $it->status === 'under_review'): ?>
            <form action="index.php?option=com_leadmarket&task=creditrequests.approve" method="post" style="margin:0 0 8px 0;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="id" value="<?php echo (int) $it->id; ?>">
              <input type="text" name="approved_amount" value="<?php echo htmlspecialchars(number_format((float) $it->requested_amount, 2, '.', '')); ?>" style="width:90px;" />
              <input type="text" name="admin_note" placeholder="Admin note (optional)" style="width:160px;" />
              <button class="btn btn-mini btn-success" type="submit">Approve</button>
            </form>
            <form action="index.php?option=com_leadmarket&task=creditrequests.decline" method="post" style="margin:0;">
              <?php echo JHtml::_('form.token'); ?>
              <input type="hidden" name="id" value="<?php echo (int) $it->id; ?>">
              <input type="text" name="admin_note" placeholder="Reason / review note" style="width:180px;" />
              <button class="btn btn-mini" type="submit">Decline</button>
            </form>
          <?php else: ?>
            <span style="color:#60717c;">Review complete.</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($this->items)): ?><tr><td colspan="9" style="text-align:center;color:#666;">No credit requests found.</td></tr><?php endif; ?>
    </tbody>
  </table>

  <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>
  <input type="hidden" name="task" value="" />
  <input type="hidden" name="filter_order" value="<?php echo htmlspecialchars($this->state->get('list.ordering')); ?>" />
  <input type="hidden" name="filter_order_Dir" value="<?php echo htmlspecialchars($this->state->get('list.direction')); ?>" />
  <?php echo JHtml::_('form.token'); ?>
</form>
