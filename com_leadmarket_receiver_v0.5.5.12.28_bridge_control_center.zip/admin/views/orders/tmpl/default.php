<?php defined('_JEXEC') or die; ?>
<?php $token = JSession::getFormToken();
function lmStatusStyle($status, $type='order') {
  $status = strtolower((string)$status);
  $map = $type === 'payment'
    ? array('unverified'=>array('#f4f5f7','#666'),'checking'=>array('#eef6ff','#245c9a'),'matched'=>array('#fff8ef','#8a4d00'),'late_matched'=>array('#fff8ef','#8a4d00'),'late_no_slots'=>array('#fff0f0','#9b2d2d'),'refund_pending'=>array('#fff8ef','#8a4d00'),'refunded'=>array('#eefaf0','#1f6b35'),'mismatch'=>array('#fff0f0','#9b2d2d'),'confirmed'=>array('#eefaf0','#1f6b35'))
    : array('pending'=>array('#fff8ef','#8a4d00'),'submitted'=>array('#fff8ef','#8a4d00'),'paid'=>array('#eefaf0','#1f6b35'),'expired'=>array('#f4f5f7','#666'),'failed'=>array('#fff0f0','#9b2d2d'),'cancelled'=>array('#f4f5f7','#666'));
  $c = isset($map[$status]) ? $map[$status] : array('#f4f5f7','#666');
  return 'display:inline-block;padding:4px 8px;border-radius:999px;background:' . $c[0] . ';color:' . $c[1] . ';font-size:12px;font-weight:700;border:1px solid #e5e5e5';
}
?>
<?php echo LeadMarketHelper::renderAdminQuickNav('orders'); ?>
<form action="index.php?option=com_leadmarket&view=orders" method="post" name="adminForm" id="adminForm">
  <div style="margin:0 0 10px 0;"><a class="btn btn-small btn-primary" href="index.php?option=com_leadmarket&task=orders.runBackground&<?php echo $token; ?>=1">Run Background Verify Now</a></div>
  <div class="js-stools clearfix" style="margin-bottom:12px;">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
      <input type="text" name="filter_search" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" placeholder="Search buyer email, #ID or tx hash" />
      <select name="filter_status">
        <option value="">- Order Status -</option>
        <?php foreach (array('pending','submitted','paid','expired','failed','cancelled') as $s): ?>
          <option value="<?php echo $s; ?>" <?php echo $this->state->get('filter.status') === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
        <?php endforeach; ?>
      </select>
      <select name="filter_payment_status">
        <option value="">- Payment Status -</option>
        <?php foreach (array('unverified','checking','matched','late_matched','late_no_slots','refund_pending','refunded','mismatch','confirmed') as $s): ?>
          <option value="<?php echo $s; ?>" <?php echo $this->state->get('filter.payment_status') === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-small" type="submit">Filter</button>
      <a class="btn btn-small" href="index.php?option=com_leadmarket&view=orders">Clear</a>
    </div>
  </div>
  <table class="table table-striped">
    <thead><tr><th width="1%"><input type="checkbox" name="checkall-toggle" value="" onclick="Joomla.checkAll(this)" /></th><th>ID</th><th>Lead</th><th>Buyer</th><th>Status</th><th>Payment</th><th>Payment type</th><th>Expected</th><th>Received</th><th>Wallet used</th><th>Linked top-up</th><th>Expires (UTC)</th><th>Paid (UTC)</th><th>Tx hash</th><th>Created (UTC)</th><th>Actions</th></tr></thead>
    <tbody>
      <?php foreach ((array) $this->items as $i => $it): ?>
      <tr>
        <td><?php echo JHtml::_('grid.id', $i, $it->id); ?></td>
        <td><?php echo (int) $it->id; ?></td>
        <td>#<?php echo (int) $it->lead_id; ?> (<?php echo htmlspecialchars($it->state); ?> <?php echo htmlspecialchars($it->type); ?>)</td>
        <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
        <td><span style="<?php echo lmStatusStyle($it->status, 'order'); ?>"><?php echo htmlspecialchars($it->status); ?></span></td>
        <td><span style="<?php echo lmStatusStyle($it->payment_status, 'payment'); ?>"><?php echo htmlspecialchars($it->payment_status ? $it->payment_status : 'unverified'); ?></span></td>
        <td><?php echo htmlspecialchars($it->payment_type ? $it->payment_type : 'direct'); ?></td>
        <td><?php echo htmlspecialchars($it->expected_amount ? $it->expected_amount : $it->amount_usdt); ?> <?php echo htmlspecialchars($it->expected_currency ? $it->expected_currency : 'USDT'); ?></td>
        <td><?php echo htmlspecialchars($it->amount_received); ?></td>
        <td><?php echo $it->wallet_amount_used_usd !== null && $it->wallet_amount_used_usd !== '' ? htmlspecialchars(number_format((float)$it->wallet_amount_used_usd, 2, '.', '')) : '—'; ?></td>
        <td><?php echo !empty($it->linked_topup_id) ? '#' . (int)$it->linked_topup_id : '—'; ?></td>
        <td><?php echo htmlspecialchars($it->expires_at_utc); ?></td>
        <td><?php echo htmlspecialchars($it->paid_at_utc); ?></td>
        <td><?php echo htmlspecialchars($it->tx_hash ? substr($it->tx_hash,0,16) . '…' : ''); ?></td>
        <td><?php echo htmlspecialchars($it->created_at_utc); ?></td>
        <td>
          <?php $orderStatus = strtolower((string) $it->status); $paymentStatus = strtolower((string) ($it->payment_status ? $it->payment_status : 'unverified')); ?>
          <?php if (in_array($orderStatus, array('submitted','pending','expired'), true) && in_array($paymentStatus, array('unverified','checking','mismatch','late_matched','late_no_slots'), true)): ?>
            <a class="btn btn-mini" href="index.php?option=com_leadmarket&task=orders.verify&id=<?php echo (int) $it->id; ?>&<?php echo $token; ?>=1">Verify</a>
          <?php else: ?>
            <span class="btn btn-mini disabled" style="opacity:.45;cursor:not-allowed;">Verify</span>
          <?php endif; ?>

          <?php if ($orderStatus !== 'paid' && in_array($paymentStatus, array('matched','late_matched'), true)): ?>
            <a class="btn btn-mini btn-success" href="index.php?option=com_leadmarket&task=orders.confirm&id=<?php echo (int) $it->id; ?>&<?php echo $token; ?>=1">Confirm</a>
          <?php else: ?>
            <span class="btn btn-mini disabled" style="opacity:.45;cursor:not-allowed;">Confirm</span>
          <?php endif; ?>

          <?php if ($orderStatus === 'paid'): ?>
            <a class="btn btn-mini" href="index.php?option=com_leadmarket&task=orders.resendUnlock&id=<?php echo (int) $it->id; ?>&<?php echo $token; ?>=1">Resend</a>
          <?php else: ?>
            <span class="btn btn-mini disabled" style="opacity:.45;cursor:not-allowed;">Resend</span>
          <?php endif; ?>

          <?php if (!in_array($orderStatus, array('paid','cancelled','failed','expired'), true)): ?>
            <a class="btn btn-mini btn-success" href="index.php?option=com_leadmarket&task=orders.markPaid&id=<?php echo (int) $it->id; ?>&<?php echo $token; ?>=1">Paid</a>
            <a class="btn btn-mini" href="index.php?option=com_leadmarket&task=orders.markFailed&id=<?php echo (int) $it->id; ?>&<?php echo $token; ?>=1">Failed</a>
            <a class="btn btn-mini" href="index.php?option=com_leadmarket&task=orders.cancel&id=<?php echo (int) $it->id; ?>&<?php echo $token; ?>=1" onclick="return confirm('Cancel this order?');">Cancel</a>
          <?php else: ?>
            <span class="btn btn-mini disabled" style="opacity:.45;cursor:not-allowed;">Paid</span>
            <span class="btn btn-mini disabled" style="opacity:.45;cursor:not-allowed;">Failed</span>
            <span class="btn btn-mini disabled" style="opacity:.45;cursor:not-allowed;">Cancel</span>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
          <?php if (empty($this->items)): ?><tr><td colspan="16" style="text-align:center;color:#666;">No orders found.</td></tr><?php endif; ?>
    </tbody>
  </table>
  <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>
  <input type="hidden" name="task" value="" />
  <input type="hidden" name="boxchecked" value="0" />
  <?php echo JHtml::_('form.token'); ?>
</form>
