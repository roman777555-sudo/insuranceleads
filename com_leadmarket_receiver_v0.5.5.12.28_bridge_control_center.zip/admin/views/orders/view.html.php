<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketViewOrders extends JViewLegacy
{
  public $items;
  public $pagination;
  public $state;

  public function display($tpl = null)
  {
    LeadMarketHelper::cleanupExpiredOrders();
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    $this->state = $this->get('State');
    JToolbarHelper::title('LeadMarket - Orders', 'cart');
    JToolbarHelper::custom('orders.verify', 'refresh.png', 'refresh_f2.png', 'Verify Selected', true);
    JToolbarHelper::custom('orders.confirm', 'apply.png', 'apply_f2.png', 'Confirm Selected', true);
    JToolbarHelper::custom('orders.resendUnlock', 'mail.png', 'mail_f2.png', 'Resend Unlock Email', true);
    JToolbarHelper::custom('orders.markPaid', 'publish.png', 'publish_f2.png', 'Mark Paid', true);
    JToolbarHelper::custom('orders.markFailed', 'unpublish.png', 'unpublish_f2.png', 'Mark Failed', true);
    JToolbarHelper::custom('orders.cancel', 'trash.png', 'trash_f2.png', 'Cancel', true);
    parent::display($tpl);
  }
}
