<?php defined('_JEXEC') or die; ?>
<?php $token = JSession::getFormToken(); ?>
<?php echo LeadMarketHelper::renderAdminQuickNav('topups'); ?>
<form action="index.php?option=com_leadmarket&view=topups" method="post" name="adminForm" id="adminForm">
  <div class="js-stools clearfix" style="margin-bottom:12px;">
    <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
      <input type="text" name="filter_search" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" placeholder="Search buyer email or #ID" />
      <select name="filter_status">
        <option value="">- Status -</option>
        <?php foreach (array('pending','checking','pending_review','paid','cancelled','expired') as $s): ?>
          <option value="<?php echo $s; ?>" <?php echo $this->state->get('filter.status') === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
        <?php endforeach; ?>
      </select>
      <select name="filter_target_type">
        <option value="">- Target -</option>
        <?php foreach (array('lead','batch','manual') as $s): ?>
          <option value="<?php echo $s; ?>" <?php echo $this->state->get('filter.target_type') === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn btn-small" type="submit">Filter</button>
      <a class="btn btn-small" href="index.php?option=com_leadmarket&view=topups">Clear</a>
      <a class="btn btn-small" href="index.php?option=com_leadmarket&view=wallets">Open Wallets</a>
    </div>
  </div>

  <table class="table table-striped">
    <thead>
      <tr>
        <th><?php echo JHtml::_('grid.sort', 'ID', 't.id', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th><?php echo JHtml::_('grid.sort', 'Created (UTC)', 't.created_at_utc', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th><?php echo JHtml::_('grid.sort', 'Buyer Email', 't.buyer_email', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th><?php echo JHtml::_('grid.sort', 'Status', 't.status', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th>Method</th>
        <th>Target</th>
        <th>Target price</th>
        <th><?php echo JHtml::_('grid.sort', 'Top-up amount', 't.topup_amount_usd', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th>Auto apply</th>
        <th>Result</th>
        <th><?php echo JHtml::_('grid.sort', 'After credit', 't.balance_after_credit', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
        <th>After unlock</th>
        <th>Manual ref</th>
        <th>Tx hash</th>
        <th>Paid (UTC)</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ((array) $this->items as $it): ?>
      <tr>
        <td><?php echo (int) $it->id; ?></td>
        <td><?php echo htmlspecialchars($it->created_at_utc); ?></td>
        <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
        <td><?php echo htmlspecialchars($it->status); ?></td>
        <td><?php $pm = strtolower(trim((string) ($it->payment_method ?? 'crypto'))); echo htmlspecialchars($pm === 'moneygram' ? 'Western Union' : ($pm === 'westernunion' ? 'Western Union' : 'Crypto')); ?></td>
        <td><?php echo htmlspecialchars(trim((string)$it->target_type) !== '' ? $it->target_type . '#' . (int)$it->target_id : 'manual'); ?></td>
        <td><?php echo number_format((float) $it->target_price_usd, 2, '.', ''); ?></td>
        <td><?php echo number_format((float) $it->topup_amount_usd, 2, '.', ''); ?></td>
        <td><?php echo !empty($it->auto_apply_on_paid) ? 'Yes' : 'No'; ?></td>
        <td><?php echo htmlspecialchars(trim((string)$it->result_message) !== '' ? $it->result_message : $it->result_status); ?></td>
        <td><?php echo $it->balance_after_credit !== null && $it->balance_after_credit !== '' ? number_format((float) $it->balance_after_credit, 2, '.', '') : '—'; ?></td>
        <td><?php echo $it->balance_after_unlock !== null && $it->balance_after_unlock !== '' ? number_format((float) $it->balance_after_unlock, 2, '.', '') : '—'; ?></td>
        <td><?php echo htmlspecialchars(!empty($it->manual_reference) ? $it->manual_reference : '—'); ?></td>
        <td><?php echo htmlspecialchars(!empty($it->tx_hash) ? substr($it->tx_hash, 0, 18) . '…' : '—'); ?></td>
        <td><?php echo htmlspecialchars(!empty($it->paid_at_utc) ? $it->paid_at_utc : '—'); ?></td>
        <td>
          <div style="display:flex;gap:6px;flex-wrap:wrap;">
            <?php if (in_array((string)$it->status, array('pending','checking','pending_review'), true)): ?>
              <a class="btn btn-small btn-success" href="index.php?option=com_leadmarket&task=topups.markpaid&id=<?php echo (int)$it->id; ?>&<?php echo $token; ?>=1">Mark paid (manual)</a>
              <a class="btn btn-small btn-danger" href="index.php?option=com_leadmarket&task=topups.cancel&id=<?php echo (int)$it->id; ?>&<?php echo $token; ?>=1" onclick="return confirm('Cancel this top-up?');">Cancel</a>
            <?php endif; ?>
            <?php if ((string)$it->target_type === 'lead' && (int)$it->target_id > 0): ?>
              <a class="btn btn-small" target="_blank" href="../index.php?option=com_leadmarket&view=lead&id=<?php echo (int)$it->target_id; ?>&buyer_email=<?php echo urlencode((string)$it->buyer_email); ?>">Open lead</a>
            <?php elseif ((string)$it->target_type === 'batch' && (int)$it->target_id > 0): ?>
              <a class="btn btn-small" target="_blank" href="../index.php?option=com_leadmarket&view=batch&id=<?php echo (int)$it->target_id; ?>">Open batch</a>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($this->items)): ?>
      <tr><td colspan="16" style="text-align:center;color:#666;">No top-ups found.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>

  <input type="hidden" name="task" value="" />
  <input type="hidden" name="filter_order" value="<?php echo htmlspecialchars($this->state->get('list.ordering')); ?>" />
  <input type="hidden" name="filter_order_Dir" value="<?php echo htmlspecialchars($this->state->get('list.direction')); ?>" />
  <?php echo JHtml::_('form.token'); ?>
</form>
