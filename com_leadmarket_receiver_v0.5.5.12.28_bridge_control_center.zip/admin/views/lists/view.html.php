<?php
defined('_JEXEC') or die;

class LeadMarketViewLists extends JViewLegacy
{
  public $items;
  public $pagination;

  public function display($tpl = null)
  {
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    JToolbarHelper::title('LeadMarket - Lists', 'folder');
    parent::display($tpl);
  }
}
