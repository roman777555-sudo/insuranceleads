<?php defined('_JEXEC') or die; ?>
<div class="container-fluid">
  <p class="alert alert-info">Lists are auto-created: General + State:XX when leads arrive.</p>
  <table class="table table-striped">
    <thead><tr><th>ID</th><th>Name</th><th>State</th><th>Subscribers</th><th>Created</th></tr></thead>
    <tbody>
      <?php foreach ((array)$this->items as $it): ?>
      <tr>
        <td><?php echo (int)$it->id; ?></td>
        <td><?php echo htmlspecialchars($it->name); ?></td>
        <td><?php echo htmlspecialchars($it->state ? $it->state : 'GENERAL'); ?></td>
        <td><?php echo (int)$it->subscriber_count; ?></td>
        <td><?php echo htmlspecialchars($it->created_at); ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>
</div>
