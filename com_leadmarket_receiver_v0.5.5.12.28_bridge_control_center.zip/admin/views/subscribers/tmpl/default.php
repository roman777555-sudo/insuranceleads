<?php defined('_JEXEC') or die; ?>
<?php JHtml::_('behavior.multiselect'); ?>

<form action="<?php echo JRoute::_('index.php?option=com_leadmarket&view=subscribers'); ?>" method="post" name="adminForm" id="adminForm">
  <div class="container-fluid">
    <table class="table table-striped" id="subscriberList">
      <thead>
        <tr>
          <th width="1%" class="center"><?php echo JHtml::_('grid.checkall'); ?></th>
          <th width="1%">ID</th>
          <th>Email</th>
          <th>Lists</th>
          <th>Mode</th>
          <th>Lead Type</th>
          <th>Active</th>
          <th>Cooldown</th>
          <th>Created (UTC)</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ((array) $this->items as $i => $it): ?>
          <tr>
            <td class="center"><?php echo JHtml::_('grid.id', $i, (int) $it->id); ?></td>
            <td><?php echo (int) $it->id; ?></td>
            <td>
              <a href="<?php echo JRoute::_('index.php?option=com_leadmarket&task=subscriber.edit&id=' . (int) $it->id); ?>">
                <?php echo htmlspecialchars($it->email); ?>
              </a>
            </td>
            <td><?php echo htmlspecialchars($it->subscribed_lists ? $it->subscribed_lists : 'GENERAL'); ?></td>
            <td><?php echo htmlspecialchars($it->mode); ?></td>
            <td><?php echo htmlspecialchars(isset($it->lead_type) ? $it->lead_type : 'both'); ?></td>
            <td><?php echo (int) (isset($it->is_active) ? $it->is_active : $it->active) ? 'Yes' : 'No'; ?></td>
            <td><?php echo (int) $it->cooldown_minutes; ?></td>
            <td><?php echo htmlspecialchars(isset($it->created_at) ? $it->created_at : ''); ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>

    <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>
  </div>

  <input type="hidden" name="task" value="" />
  <input type="hidden" name="boxchecked" value="0" />
  <?php echo JHtml::_('form.token'); ?>
</form>
