<?php
defined('_JEXEC') or die;

class LeadMarketViewSubscribers extends JViewLegacy
{
  public $items;
  public $pagination;

  public function display($tpl = null)
  {
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    JToolbarHelper::title('LeadMarket - Subscribers', 'users');

    JToolbarHelper::addNew('subscriber.add');
    JToolbarHelper::editList('subscriber.edit');
    JToolbarHelper::divider();
    JToolbarHelper::deleteList('Are you sure?', 'subscribers.delete');

    parent::display($tpl);
  }
}
