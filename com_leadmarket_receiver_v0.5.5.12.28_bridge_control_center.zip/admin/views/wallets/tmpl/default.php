<?php defined('_JEXEC') or die; ?>
<div class="leadmarket-wallets" style="max-width:1280px;">
  <div style="display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:18px;align-items:start;">
    <div>
      <?php echo LeadMarketHelper::renderAdminQuickNav('wallets'); ?>
<form action="index.php?option=com_leadmarket&view=wallets" method="post" name="adminForm" id="adminForm">
        <div class="js-stools clearfix" style="margin-bottom:12px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
          <input type="text" name="filter_search" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" placeholder="Search buyer email" />
          <button class="btn btn-small" type="submit">Filter</button>
          <a class="btn btn-small" href="index.php?option=com_leadmarket&view=wallets">Clear</a>
        </div>

        <table class="table table-striped">
          <thead>
            <tr>
              <th><?php echo JHtml::_('grid.sort', 'Buyer Email', 'w.buyer_email', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
              <th><?php echo JHtml::_('grid.sort', 'Current Balance (USD)', 'w.balance_usd', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
              <th><?php echo JHtml::_('grid.sort', 'Total Credits', 'total_credits', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
              <th><?php echo JHtml::_('grid.sort', 'Total Debits', 'total_debits', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
              <th><?php echo JHtml::_('grid.sort', 'Last Activity (UTC)', 'last_activity_at', $this->state->get('list.direction'), $this->state->get('list.ordering')); ?></th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ((array) $this->items as $it): ?>
            <tr>
              <td><?php echo htmlspecialchars($it->buyer_email); ?></td>
              <td><strong><?php echo number_format((float) $it->balance_usd, 2, '.', ''); ?></strong></td>
              <td><?php echo number_format((float) $it->total_credits, 2, '.', ''); ?></td>
              <td><?php echo number_format((float) $it->total_debits, 2, '.', ''); ?></td>
              <td><?php echo htmlspecialchars($it->last_activity_at ?: '—'); ?></td>
              <td>
                <a class="btn btn-mini" href="index.php?option=com_leadmarket&view=orders&filter_search=<?php echo urlencode($it->buyer_email); ?>">View orders</a>
                <a class="btn btn-mini" href="index.php?option=com_leadmarket&view=buyers&filter_search=<?php echo urlencode($it->buyer_email); ?>">View buyer</a>
              </td>
            </tr>
            <?php endforeach; ?>
            <?php if (empty($this->items)): ?>
            <tr><td colspan="6" style="text-align:center;color:#666;">No wallets found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>

        <?php if ($this->pagination) echo $this->pagination->getListFooter(); ?>
        <input type="hidden" name="task" value="" />
        <input type="hidden" name="filter_order" value="<?php echo htmlspecialchars($this->state->get('list.ordering')); ?>" />
        <input type="hidden" name="filter_order_Dir" value="<?php echo htmlspecialchars($this->state->get('list.direction')); ?>" />
        <?php echo JHtml::_('form.token'); ?>
      </form>
    </div>

    <div>
      <div class="well" style="background:#fff;border:1px solid #dfe7ee;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h3 style="margin-top:0;">Manual Balance Adjustment</h3>
        <form action="index.php?option=com_leadmarket&task=wallets.adjust" method="post">
          <div style="margin-bottom:10px;">
            <label for="wallet-buyer-email"><strong>Buyer email</strong></label>
            <input id="wallet-buyer-email" type="email" name="buyer_email" required style="width:100%;" placeholder="buyer@example.com" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" />
          </div>
          <div style="margin-bottom:10px;">
            <label for="wallet-amount"><strong>Amount (USD)</strong></label>
            <input id="wallet-amount" type="text" name="amount_usd" required style="width:100%;" placeholder="10.00 or -3.00" />
            <div style="font-size:12px;color:#667681;margin-top:4px;">Positive = credit. Negative = debit.</div>
          </div>
          <div style="margin-bottom:10px;">
            <label for="wallet-note"><strong>Note</strong></label>
            <textarea id="wallet-note" name="note" rows="3" style="width:100%;" placeholder="Manual balance correction"></textarea>
          </div>
          <button class="btn btn-success" type="submit">Apply Adjustment</button>
          <?php echo JHtml::_('form.token'); ?>
        </form>
      </div>


      <div class="well" style="background:#fff;border:1px solid #dfe7ee;border-radius:12px;padding:16px;margin-bottom:16px;">
        <h3 style="margin-top:0;">Set Exact Balance / Reset</h3>
        <form action="index.php?option=com_leadmarket&task=wallets.setexact" method="post" style="margin-bottom:12px;">
          <div style="margin-bottom:10px;">
            <label for="wallet-set-email"><strong>Buyer email</strong></label>
            <input id="wallet-set-email" type="email" name="buyer_email" required style="width:100%;" placeholder="buyer@example.com" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" />
          </div>
          <div style="margin-bottom:10px;">
            <label for="wallet-exact"><strong>Exact balance (USD)</strong></label>
            <input id="wallet-exact" type="text" name="exact_amount_usd" required style="width:100%;" placeholder="0.00" />
          </div>
          <div style="margin-bottom:10px;">
            <label for="wallet-set-note"><strong>Note</strong></label>
            <textarea id="wallet-set-note" name="note" rows="2" style="width:100%;" placeholder="admin_set_exact_balance"></textarea>
          </div>
          <button class="btn btn-primary" type="submit">Set Exact Balance</button>
          <?php echo JHtml::_('form.token'); ?>
        </form>
        <form action="index.php?option=com_leadmarket&task=wallets.reset" method="post">
          <div style="margin-bottom:10px;">
            <label for="wallet-reset-email"><strong>Buyer email</strong></label>
            <input id="wallet-reset-email" type="email" name="buyer_email" required style="width:100%;" placeholder="buyer@example.com" value="<?php echo htmlspecialchars($this->state->get('filter.search')); ?>" />
          </div>
          <div style="margin-bottom:10px;">
            <label for="wallet-reset-note"><strong>Note</strong></label>
            <textarea id="wallet-reset-note" name="note" rows="2" style="width:100%;" placeholder="admin_reset_balance"></textarea>
          </div>
          <button class="btn btn-warning" type="submit" onclick="return confirm('Reset this wallet balance to zero?');">Reset to Zero</button>
          <?php echo JHtml::_('form.token'); ?>
        </form>
      </div>
      <div class="well" style="background:#fff;border:1px solid #dfe7ee;border-radius:12px;padding:16px;">
        <h3 style="margin-top:0;">Recent Balance Activity</h3>
        <?php if (!empty($this->recentActivity)): ?>
          <div style="display:flex;flex-direction:column;gap:10px;">
            <?php foreach ((array) $this->recentActivity as $row): ?>
              <div style="border:1px solid #e2e8ee;border-radius:10px;padding:10px 12px;">
                <div style="font-weight:700;"><?php echo htmlspecialchars($row->buyer_email); ?></div>
                <div style="font-size:12px;color:#60717c;margin:3px 0 6px;">
                  <?php echo htmlspecialchars($row->created_at_utc); ?> · <?php echo htmlspecialchars($row->entry_type); ?> · <?php echo htmlspecialchars($row->direction); ?>
                </div>
                <div>Amount: <strong><?php echo number_format((float) $row->amount_usd, 2, '.', ''); ?></strong></div>
                <div>Balance: <?php echo number_format((float) $row->balance_before, 2, '.', ''); ?> → <strong><?php echo number_format((float) $row->balance_after, 2, '.', ''); ?></strong></div>
                <?php if (!empty($row->note)): ?><div style="margin-top:6px;color:#44545e;"><?php echo htmlspecialchars($row->note); ?></div><?php endif; ?>
              </div>
            <?php endforeach; ?>
          </div>
        <?php else: ?>
          <div style="color:#667681;">No wallet activity yet.</div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
