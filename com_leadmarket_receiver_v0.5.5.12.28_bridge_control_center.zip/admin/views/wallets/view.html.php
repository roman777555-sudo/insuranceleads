<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketViewWallets extends JViewLegacy
{
  public $items;
  public $pagination;
  public $state;
  public $recentActivity;

  public function display($tpl = null)
  {
    $this->items = $this->get('Items');
    $this->pagination = $this->get('Pagination');
    $this->state = $this->get('State');
    $this->recentActivity = method_exists($this->getModel(), 'getRecentActivity') ? $this->getModel()->getRecentActivity(20) : array();

    JToolbarHelper::title('LeadMarket - Wallets', 'credit');

    parent::display($tpl);
  }
}
