<?php
defined('_JEXEC') or die;

class LeadmarketModelSubscriber extends JModelAdmin
{
  public function getTable($type = 'Subscriber', $prefix = 'LeadmarketTable', $config = array())
  {
    return JTable::getInstance($type, $prefix, $config);
  }

  public function getForm($data = array(), $loadData = true)
  {
    $form = $this->loadForm('com_leadmarket.subscriber', 'subscriber', array('control' => 'jform', 'load_data' => $loadData));
    if (empty($form)) {
      return false;
    }
    return $form;
  }

  protected function loadFormData()
  {
    $data = JFactory::getApplication()->getUserState('com_leadmarket.edit.subscriber.data', array());
    if (empty($data)) {
      $data = $this->getItem();
    }
    return $data;
  }
}
