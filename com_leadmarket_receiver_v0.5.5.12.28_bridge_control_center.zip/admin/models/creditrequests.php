<?php
defined('_JEXEC') or die;

class LeadMarketModelCreditrequests extends JModelList
{
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array('id','r.id','status','r.status','buyer_email','r.buyer_email','created_at','r.created_at','order_id','r.order_id');
    }
    parent::__construct($config);
  }

  protected function populateState($ordering = 'r.created_at', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    $this->setState('filter.search', $app->getUserStateFromRequest($this->context.'.filter.search', 'filter_search', '', 'string'));
    $this->setState('filter.status', $app->getUserStateFromRequest($this->context.'.filter.status', 'filter_status', '', 'string'));
    parent::populateState($ordering, $direction);
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('r.*, o.kind AS order_kind, o.amount_usd AS order_amount_usd, l.type AS lead_type, l.state AS lead_state, l.city AS lead_city')
      ->from($db->qn('#__leadmarket_credit_requests', 'r'))
      ->join('LEFT', $db->qn('#__leadmarket_orders', 'o') . ' ON o.id = r.order_id')
      ->join('LEFT', $db->qn('#__leadmarket_leads', 'l') . ' ON l.id = r.lead_id');

    $search = trim((string) $this->getState('filter.search'));
    if ($search !== '') {
      if (strpos($search, '#') === 0) {
        $query->where('r.id=' . (int) substr($search, 1));
      } else {
        $like = $db->q('%' . $db->escape($search, true) . '%', false);
        $query->where('(r.buyer_email LIKE ' . $like . ' OR CAST(r.order_id AS CHAR) LIKE ' . $like . ' OR CAST(r.lead_id AS CHAR) LIKE ' . $like . ')');
      }
    }

    $status = trim((string) $this->getState('filter.status'));
    if ($status !== '') $query->where('r.status=' . $db->q($status));

    $query->order('r.created_at DESC, r.id DESC');
    return $query;
  }
}
