<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketModelFreetestanalytics extends JModelLegacy
{
  public function getFilters()
  {
    $app = JFactory::getApplication();
    $context = 'com_leadmarket.freetestanalytics';
    $period = $app->getUserStateFromRequest($context . '.period', 'period', '30d', 'cmd');
    $search = trim((string) $app->getUserStateFromRequest($context . '.search', 'filter_search', '', 'string'));
    $dateFrom = trim((string) $app->getUserStateFromRequest($context . '.date_from', 'date_from', '', 'string'));
    $dateTo = trim((string) $app->getUserStateFromRequest($context . '.date_to', 'date_to', '', 'string'));
    if (!in_array($period, array('today','7d','30d','custom'), true)) $period = '30d';
    list($rangeFrom, $rangeTo) = $this->resolveDateRange($period, $dateFrom, $dateTo);
    return array('period'=>$period,'search'=>$search,'date_from'=>$dateFrom,'date_to'=>$dateTo,'range_from'=>$rangeFrom,'range_to'=>$rangeTo);
  }

  protected function resolveDateRange($period, $dateFrom, $dateTo)
  {
    $todayStart = gmdate('Y-m-d 00:00:00');
    $tomorrowStart = gmdate('Y-m-d 00:00:00', strtotime('+1 day'));
    switch ($period) {
      case 'today': return array($todayStart, $tomorrowStart);
      case '7d': return array(gmdate('Y-m-d 00:00:00', strtotime('-6 days')), $tomorrowStart);
      case 'custom':
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom) ? $dateFrom . ' 00:00:00' : gmdate('Y-m-d 00:00:00', strtotime('-29 days'));
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo) ? $dateTo . ' 23:59:59' : gmdate('Y-m-d 23:59:59');
        if ($from > $to) { $tmp = $from; $from = substr($to,0,10) . ' 00:00:00'; $to = substr($tmp,0,10) . ' 23:59:59'; }
        return array($from, $to);
      case '30d':
      default: return array(gmdate('Y-m-d 00:00:00', strtotime('-29 days')), $tomorrowStart);
    }
  }

  protected function applyDateRange($query, $column, array $filters)
  {
    $db = $this->getDbo();
    if (!empty($filters['range_from'])) $query->where($column . ' >= ' . $db->q($filters['range_from']));
    if (!empty($filters['range_to'])) $query->where($column . ' <= ' . $db->q($filters['range_to']));
  }

  protected function parseSearch(array $filters)
  {
    $search = trim((string) ($filters['search'] ?? ''));
    $numeric = null;
    if ($search !== '' && preg_match('/^#?(\d+)$/', $search, $m)) $numeric = (int) $m[1];
    return array($search, $numeric);
  }

  public function getSummary(array $filters)
  {
    $db = $this->getDbo();
    list($search, $numeric) = $this->parseSearch($filters);

    $q = $db->getQuery(true)->select('COUNT(*)')->from('#__leadmarket_trial_access AS a')->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'COALESCE(a.unlocked_at_utc, a.created_at_utc)', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('a.email LIKE ' . $like, 'a.states_json LIKE ' . $like, 'a.lead_type LIKE ' . $like);
      if ($numeric !== null) $parts[] = 'a.subscriber_id=' . (int) $numeric;
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $db->setQuery($q); $signups = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COUNT(DISTINCT a.email)')->from('#__leadmarket_trial_access AS a')->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'COALESCE(a.unlocked_at_utc, a.created_at_utc)', $filters);
    if ($search !== '') { $like = $db->q('%' . $db->escape($search, true) . '%', false); $q->where('(a.email LIKE ' . $like . ' OR a.states_json LIKE ' . $like . ')'); }
    $db->setQuery($q); $emails = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COALESCE(SUM(a.view_count),0)')->from('#__leadmarket_trial_access AS a')->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'COALESCE(a.last_view_at_utc, a.unlocked_at_utc, a.created_at_utc)', $filters);
    if ($search !== '') { $like = $db->q('%' . $db->escape($search, true) . '%', false); $q->where('(a.email LIKE ' . $like . ' OR a.states_json LIKE ' . $like . ')'); }
    $db->setQuery($q); $landingViews = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COUNT(*)')->from('#__leadmarket_trial_lead_views AS v')->join('LEFT', '#__leadmarket_trial_access AS a ON a.id = v.access_id')->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'v.viewed_at_utc', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('v.email LIKE ' . $like, 'v.lead_state LIKE ' . $like, 'v.lead_type LIKE ' . $like);
      if ($numeric !== null) $parts[] = 'v.lead_id=' . (int) $numeric;
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $db->setQuery($q); $leadViews = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COUNT(DISTINCT v.lead_id)')->from('#__leadmarket_trial_lead_views AS v')->join('LEFT', '#__leadmarket_trial_access AS a ON a.id = v.access_id')->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'v.viewed_at_utc', $filters);
    if ($search !== '') { $like = $db->q('%' . $db->escape($search, true) . '%', false); $q->where('(v.email LIKE ' . $like . ' OR v.lead_state LIKE ' . $like . ' OR CAST(v.lead_id AS CHAR) LIKE ' . $like . ')'); }
    $db->setQuery($q); $distinctLeads = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COALESCE(SUM(a.marketplace_click_count),0)')->from('#__leadmarket_trial_access AS a')->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'COALESCE(a.last_marketplace_click_utc, a.unlocked_at_utc, a.created_at_utc)', $filters);
    if ($search !== '') { $like = $db->q('%' . $db->escape($search, true) . '%', false); $q->where('(a.email LIKE ' . $like . ' OR a.states_json LIKE ' . $like . ')'); }
    $db->setQuery($q); $marketClicks = (int) $db->loadResult();

    return array('signups'=>$signups,'emails'=>$emails,'landing_views'=>$landingViews,'lead_views'=>$leadViews,'distinct_leads'=>$distinctLeads,'market_clicks'=>$marketClicks);
  }

  public function getRecentUnlocks(array $filters, $limit = 30)
  {
    $db = $this->getDbo();
    list($search, $numeric) = $this->parseSearch($filters);
    $statsSub = '(SELECT access_id, COUNT(*) AS lead_opens, COUNT(DISTINCT lead_id) AS unique_leads, MAX(viewed_at_utc) AS last_lead_open_utc FROM #__leadmarket_trial_lead_views GROUP BY access_id)';
    $q = $db->getQuery(true)
      ->select('a.*, COALESCE(vs.lead_opens,0) AS lead_opens, COALESCE(vs.unique_leads,0) AS unique_leads, vs.last_lead_open_utc')
      ->from('#__leadmarket_trial_access AS a')
      ->join('LEFT', $statsSub . ' AS vs ON vs.access_id = a.id')
      ->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'COALESCE(a.unlocked_at_utc, a.created_at_utc)', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('a.email LIKE ' . $like, 'a.states_json LIKE ' . $like, 'a.lead_type LIKE ' . $like, 'a.request_ip LIKE ' . $like);
      if ($numeric !== null) { $parts[] = 'a.subscriber_id=' . (int) $numeric; $parts[] = 'a.id=' . (int) $numeric; }
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $q->order('COALESCE(a.unlocked_at_utc, a.created_at_utc) DESC');
    $db->setQuery($q, 0, (int) $limit);
    return (array) $db->loadObjectList();
  }

  public function getRecentLeadViews(array $filters, $limit = 40)
  {
    $db = $this->getDbo();
    list($search, $numeric) = $this->parseSearch($filters);
    $q = $db->getQuery(true)
      ->select('v.id, v.viewed_at_utc, v.email, v.lead_id, v.lead_state, v.lead_type, v.lead_city, a.subscriber_id, a.states_json, a.lead_type AS selected_lead_type')
      ->from('#__leadmarket_trial_lead_views AS v')
      ->join('LEFT', '#__leadmarket_trial_access AS a ON a.id = v.access_id')
      ->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'v.viewed_at_utc', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('v.email LIKE ' . $like, 'v.lead_state LIKE ' . $like, 'v.lead_type LIKE ' . $like, 'v.lead_city LIKE ' . $like);
      if ($numeric !== null) { $parts[] = 'v.lead_id=' . (int) $numeric; $parts[] = 'a.subscriber_id=' . (int) $numeric; }
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $q->order('v.viewed_at_utc DESC');
    $db->setQuery($q, 0, (int) $limit);
    return (array) $db->loadObjectList();
  }

  public function getTopViewedLeads(array $filters, $limit = 15)
  {
    $db = $this->getDbo();
    list($search, $numeric) = $this->parseSearch($filters);
    $q = $db->getQuery(true)
      ->select('v.lead_id, MAX(v.lead_state) AS lead_state, MAX(v.lead_type) AS lead_type, MAX(v.lead_city) AS lead_city, COUNT(*) AS opens_count, COUNT(DISTINCT v.email) AS unique_emails, MAX(v.viewed_at_utc) AS last_open_utc')
      ->from('#__leadmarket_trial_lead_views AS v')
      ->join('LEFT', '#__leadmarket_trial_access AS a ON a.id = v.access_id')
      ->where('a.source_page=' . $db->q('free_test_leads'));
    $this->applyDateRange($q, 'v.viewed_at_utc', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('v.email LIKE ' . $like, 'v.lead_state LIKE ' . $like, 'v.lead_type LIKE ' . $like, 'v.lead_city LIKE ' . $like);
      if ($numeric !== null) $parts[] = 'v.lead_id=' . (int) $numeric;
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $q->group('v.lead_id')->order('opens_count DESC, last_open_utc DESC');
    $db->setQuery($q, 0, (int) $limit);
    return (array) $db->loadObjectList();
  }
}
