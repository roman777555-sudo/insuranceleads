<?php
defined('_JEXEC') or die;

class LeadMarketModelLists extends JModelList
{
  protected function getListQuery()
  {
    $db = $this->getDbo();
    return $db->getQuery(true)
      ->select('l.*')
      ->select('COUNT(sl.subscriber_id) AS subscriber_count')
      ->from($db->qn('#__leadmarket_lists', 'l'))
      ->join('LEFT', $db->qn('#__leadmarket_subscriber_lists', 'sl') . ' ON sl.list_id = l.id')
      ->group('l.id')
      ->order($db->qn('l.name').' ASC');
  }
}
