<?php
defined('_JEXEC') or die;

class LeadMarketModelBuyers extends JModelList
{
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array(
        'buyer_email', 'buyer_email',
        'first_purchase_at', 'first_purchase_at',
        'last_purchase_at', 'last_purchase_at',
        'orders_count', 'orders_count',
        'total_spent', 'total_spent',
      );
    }
    parent::__construct($config);
  }

  protected function populateState($ordering = 'last_purchase_at', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    $this->setState('filter.search', $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '', 'string'));
    parent::populateState($ordering, $direction);
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();

    $query = $db->getQuery(true)
      ->select(array(
        'LOWER(TRIM(o.buyer_email)) AS buyer_email_key',
        'MIN(o.buyer_email) AS buyer_email',
        'MIN(COALESCE(o.paid_at_utc, o.created_at_utc)) AS first_purchase_at',
        'MAX(COALESCE(o.paid_at_utc, o.created_at_utc)) AS last_purchase_at',
        'COUNT(*) AS orders_count',
        'ROUND(SUM(COALESCE(o.amount_usd, 0)), 2) AS total_spent'
      ))
      ->from($db->qn('#__leadmarket_orders', 'o'))
      ->where("o.status='paid'")
      ->where("TRIM(COALESCE(o.buyer_email,'')) <> ''")
      ->group('LOWER(TRIM(o.buyer_email))');

    $search = trim((string) $this->getState('filter.search'));
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $query->where('o.buyer_email LIKE ' . $like);
    }

    $ordering = (string) $this->state->get('list.ordering', 'last_purchase_at');
    $direction = strtoupper((string) $this->state->get('list.direction', 'DESC'));
    if (!in_array($direction, array('ASC','DESC'), true)) $direction = 'DESC';
    $allowed = array('buyer_email','first_purchase_at','last_purchase_at','orders_count','total_spent');
    if (!in_array($ordering, $allowed, true)) $ordering = 'last_purchase_at';
    $query->order($ordering . ' ' . $direction);

    return $query;
  }
}
