<?php
defined('_JEXEC') or die;

class LeadMarketModelLeads extends JModelList
{
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array('id','state','city','type','lead_status','uploaded_at_utc','original_uploaded_at_utc','sold_count');
    }
    parent::__construct($config);
  }

  protected function populateState($ordering = 'uploaded_at_utc', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    if ((int) $app->input->getInt('clear_filters', 0) === 1) {
      foreach (array('state','market_visibility','market_status','sold_state','active_checkout','exclusive','recent_action') as $suffix) {
        $app->setUserState($this->context . '.filter.' . $suffix, '');
      }
    }
    $this->setState('filter.state', strtoupper(trim((string) $app->getUserStateFromRequest($this->context . '.filter.state', 'filter_state', '', 'string'))));
    $this->setState('filter.market_visibility', strtolower(trim((string) $app->getUserStateFromRequest($this->context . '.filter.market_visibility', 'filter_market_visibility', '', 'string'))));
    $this->setState('filter.market_status', strtolower(trim((string) $app->getUserStateFromRequest($this->context . '.filter.market_status', 'filter_market_status', '', 'string'))));
    $this->setState('filter.sold_state', strtolower(trim((string) $app->getUserStateFromRequest($this->context . '.filter.sold_state', 'filter_sold_state', '', 'string'))));
    $this->setState('filter.active_checkout', strtolower(trim((string) $app->getUserStateFromRequest($this->context . '.filter.active_checkout', 'filter_active_checkout', '', 'string'))));
    $this->setState('filter.exclusive', strtolower(trim((string) $app->getUserStateFromRequest($this->context . '.filter.exclusive', 'filter_exclusive', '', 'string'))));
    $this->setState('filter.recent_action', strtolower(trim((string) $app->getUserStateFromRequest($this->context . '.filter.recent_action', 'filter_recent_action', '', 'string'))));
    parent::populateState($ordering, $direction);
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('l.*')
      ->select('(SELECT COUNT(*) FROM #__leadmarket_orders o WHERE o.lead_id=l.id) AS orders_count')
      ->select('(SELECT COUNT(*) FROM #__leadmarket_orders o WHERE o.lead_id=l.id AND o.status IN (' . $db->q('pending') . ',' . $db->q('submitted') . ')) AS active_checkout_count')
      ->select('(SELECT COUNT(*) FROM #__leadmarket_topups t WHERE (t.target_type=' . $db->q('lead') . ' AND t.target_id=l.id) OR EXISTS (SELECT 1 FROM #__leadmarket_orders o2 WHERE o2.id=t.unlocked_order_id AND o2.lead_id=l.id)) AS topups_count')
      ->select('(SELECT COUNT(DISTINCT o3.batch_id) FROM #__leadmarket_orders o3 WHERE o3.lead_id=l.id AND o3.batch_id > 0) AS batches_count')
      ->select('(SELECT e.event_type FROM #__leadmarket_order_events e WHERE e.lead_id=l.id ORDER BY e.created_utc DESC, e.id DESC LIMIT 1) AS last_event_type')
      ->select('(SELECT e.event_message FROM #__leadmarket_order_events e WHERE e.lead_id=l.id ORDER BY e.created_utc DESC, e.id DESC LIMIT 1) AS last_event_message')
      ->select('(SELECT e.created_utc FROM #__leadmarket_order_events e WHERE e.lead_id=l.id ORDER BY e.created_utc DESC, e.id DESC LIMIT 1) AS last_event_utc')
      ->from($db->qn('#__leadmarket_leads', 'l'));

    $state = $this->getState('filter.state');
    if ($state) {
      $query->where('l.' . $db->qn('state') . '=' . $db->q(strtoupper($state)));
    }

    $marketVisibility = $this->getState('filter.market_visibility');
    if ($marketVisibility === 'listed') {
      $query->where('l.' . $db->qn('lead_status') . ' IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')');
    } elseif ($marketVisibility === 'hidden') {
      $query->where('l.' . $db->qn('lead_status') . ' NOT IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')');
    }

    $marketStatus = $this->getState('filter.market_status');
    if (in_array($marketStatus, array('fresh','aged','archived'), true)) {
      $query->where('l.' . $db->qn('lead_status') . '=' . $db->q($marketStatus));
    }

    $soldState = $this->getState('filter.sold_state');
    if ($soldState === 'sold') {
      $query->where('l.' . $db->qn('sold_count') . ' > 0');
    } elseif ($soldState === 'unsold') {
      $query->where('l.' . $db->qn('sold_count') . ' = 0');
    }

    $activeCheckout = $this->getState('filter.active_checkout');
    if ($activeCheckout === 'yes') {
      $query->where('(SELECT COUNT(*) FROM #__leadmarket_orders o WHERE o.lead_id=l.id AND o.status IN (' . $db->q('pending') . ',' . $db->q('submitted') . ')) > 0');
    } elseif ($activeCheckout === 'no') {
      $query->where('(SELECT COUNT(*) FROM #__leadmarket_orders o WHERE o.lead_id=l.id AND o.status IN (' . $db->q('pending') . ',' . $db->q('submitted') . ')) = 0');
    }

    $exclusive = $this->getState('filter.exclusive');
    if ($exclusive === 'yes') {
      $query->where('((l.exclusive_expires_utc IS NOT NULL AND l.exclusive_expires_utc > UTC_TIMESTAMP()) OR (l.exclusive_until_utc IS NOT NULL AND l.exclusive_until_utc > UTC_TIMESTAMP()))');
    } elseif ($exclusive === 'no') {
      $query->where('((l.exclusive_expires_utc IS NULL OR l.exclusive_expires_utc <= UTC_TIMESTAMP()) AND (l.exclusive_until_utc IS NULL OR l.exclusive_until_utc <= UTC_TIMESTAMP()))');
    }

    $recentAction = $this->getState('filter.recent_action');
    if ($recentAction === 'reset') {
      $query->where('EXISTS (SELECT 1 FROM #__leadmarket_order_events e WHERE e.lead_id=l.id AND e.event_type=' . $db->q('lead_reset_restored') . ')');
    } elseif ($recentAction === 'refresh') {
      $query->where('EXISTS (SELECT 1 FROM #__leadmarket_order_events e WHERE e.lead_id=l.id AND e.event_type=' . $db->q('lead_arrival_refreshed') . ')');
    }

    $query->order('l.' . $db->qn('uploaded_at_utc') . ' DESC, l.' . $db->qn('id') . ' DESC');
    return $query;
  }
}
