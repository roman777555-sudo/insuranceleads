<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketModelReports extends JModelLegacy
{
  public function getFilters()
  {
    $app = JFactory::getApplication();
    $context = 'com_leadmarket.reports';
    $period = $app->getUserStateFromRequest($context . '.period', 'period', '7d', 'cmd');
    $search = trim((string) $app->getUserStateFromRequest($context . '.search', 'filter_search', '', 'string'));
    $dateFrom = trim((string) $app->getUserStateFromRequest($context . '.date_from', 'date_from', '', 'string'));
    $dateTo = trim((string) $app->getUserStateFromRequest($context . '.date_to', 'date_to', '', 'string'));
    $orderStatus = trim((string) $app->getUserStateFromRequest($context . '.order_status', 'filter_order_status', '', 'cmd'));
    $topupStatus = trim((string) $app->getUserStateFromRequest($context . '.topup_status', 'filter_topup_status', '', 'cmd'));

    if (!in_array($period, array('today', '7d', '30d', 'custom'), true)) {
      $period = '7d';
    }

    list($rangeFrom, $rangeTo) = $this->resolveDateRange($period, $dateFrom, $dateTo);

    return array(
      'period' => $period,
      'search' => $search,
      'date_from' => $dateFrom,
      'date_to' => $dateTo,
      'range_from' => $rangeFrom,
      'range_to' => $rangeTo,
      'order_status' => $orderStatus,
      'topup_status' => $topupStatus,
    );
  }

  protected function resolveDateRange($period, $dateFrom, $dateTo)
  {
    $todayStart = gmdate('Y-m-d 00:00:00');
    $tomorrowStart = gmdate('Y-m-d 00:00:00', strtotime('+1 day'));
    switch ($period) {
      case 'today':
        return array($todayStart, $tomorrowStart);
      case '30d':
        return array(gmdate('Y-m-d 00:00:00', strtotime('-29 days')), $tomorrowStart);
      case 'custom':
        $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateFrom) ? $dateFrom . ' 00:00:00' : gmdate('Y-m-d 00:00:00', strtotime('-6 days'));
        $to = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dateTo) ? $dateTo . ' 23:59:59' : gmdate('Y-m-d 23:59:59');
        if ($from > $to) {
          $tmp = $from;
          $from = substr($to, 0, 10) . ' 00:00:00';
          $to = substr($tmp, 0, 10) . ' 23:59:59';
        }
        return array($from, $to);
      case '7d':
      default:
        return array(gmdate('Y-m-d 00:00:00', strtotime('-6 days')), $tomorrowStart);
    }
  }

  protected function applyDateRange($query, $column, array $filters)
  {
    $db = $this->getDbo();
    if (!empty($filters['range_from'])) {
      $query->where($column . ' >= ' . $db->q($filters['range_from']));
    }
    if (!empty($filters['range_to'])) {
      $query->where($column . ' <= ' . $db->q($filters['range_to']));
    }
  }

  protected function parseSearch(array $filters)
  {
    $search = trim((string) $filters['search']);
    $numeric = null;
    if ($search !== '' && preg_match('/^#?(\d+)$/', $search, $m)) {
      $numeric = (int) $m[1];
    }
    return array($search, $numeric);
  }

  public function getSummary(array $filters)
  {
    $db = $this->getDbo();

    $q = $db->getQuery(true)->select('COUNT(*)')->from($db->qn('#__leadmarket_leads', 'l'));
    $this->applyDateRange($q, 'l.uploaded_at_utc', $filters);
    $db->setQuery($q);
    $newLeads = (int) $db->loadResult();

    $q = $db->getQuery(true)
      ->select('COUNT(DISTINCT o.lead_id)')
      ->from($db->qn('#__leadmarket_orders', 'o'))
      ->where('o.status=' . $db->q('paid'));
    $this->applyDateRange($q, 'COALESCE(o.paid_at_utc, o.created_at_utc)', $filters);
    $db->setQuery($q);
    $soldLeads = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COUNT(*)')->from($db->qn('#__leadmarket_orders', 'o'));
    $this->applyDateRange($q, 'o.created_at_utc', $filters);
    $db->setQuery($q);
    $orders = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COUNT(*)')->from($db->qn('#__leadmarket_batches', 'b'));
    $this->applyDateRange($q, 'b.created_at_utc', $filters);
    $db->setQuery($q);
    $batches = (int) $db->loadResult();

    $q = $db->getQuery(true)->select('COUNT(*)')->from($db->qn('#__leadmarket_topups', 't'));
    $this->applyDateRange($q, 't.created_at_utc', $filters);
    $db->setQuery($q);
    $topups = (int) $db->loadResult();

    $q = $db->getQuery(true)
      ->select('COALESCE(SUM(o.amount_usd),0.00)')
      ->from($db->qn('#__leadmarket_orders', 'o'))
      ->where('o.status=' . $db->q('paid'));
    $this->applyDateRange($q, 'COALESCE(o.paid_at_utc, o.created_at_utc)', $filters);
    $db->setQuery($q);
    $revenue = (float) $db->loadResult();

    return array(
      'new_leads' => $newLeads,
      'sold_leads' => $soldLeads,
      'orders' => $orders,
      'batches' => $batches,
      'topups' => $topups,
      'revenue' => $revenue,
    );
  }

  public function getRevenueSlice(array $filters)
  {
    $db = $this->getDbo();

    $q = $db->getQuery(true)
      ->select('COALESCE(SUM(o.amount_usd),0.00)')
      ->from($db->qn('#__leadmarket_orders', 'o'))
      ->where('o.status=' . $db->q('paid'));
    $this->applyDateRange($q, 'COALESCE(o.paid_at_utc, o.created_at_utc)', $filters);
    $db->setQuery($q);
    $ordersTotal = (float) $db->loadResult();

    $q = $db->getQuery(true)
      ->select('COALESCE(SUM(t.topup_amount_usd),0.00)')
      ->from($db->qn('#__leadmarket_topups', 't'))
      ->where('t.status=' . $db->q('paid'));
    $this->applyDateRange($q, 'COALESCE(t.paid_at_utc, t.created_at_utc)', $filters);
    $db->setQuery($q);
    $topupsTotal = (float) $db->loadResult();

    $q = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from($db->qn('#__leadmarket_orders', 'o'))
      ->where('o.status=' . $db->q('paid'));
    $this->applyDateRange($q, 'COALESCE(o.paid_at_utc, o.created_at_utc)', $filters);
    $db->setQuery($q);
    $paidOrders = (int) $db->loadResult();

    $q = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from($db->qn('#__leadmarket_topups', 't'))
      ->where('t.status=' . $db->q('paid'));
    $this->applyDateRange($q, 'COALESCE(t.paid_at_utc, t.created_at_utc)', $filters);
    $db->setQuery($q);
    $paidTopups = (int) $db->loadResult();

    $q = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from($db->qn('#__leadmarket_orders', 'o'))
      ->where('(o.payment_status=' . $db->q('late_no_slots') . ' OR o.payment_status=' . $db->q('refund_pending') . ' OR o.payment_status=' . $db->q('mismatch') . ')');
    $this->applyDateRange($q, 'o.created_at_utc', $filters);
    $db->setQuery($q);
    $manualReviewOrders = (int) $db->loadResult();

    $q = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from($db->qn('#__leadmarket_topups', 't'))
      ->where('(t.result_status=' . $db->q('failed_manual_review') . ' OR t.result_message LIKE ' . $db->q('%manual review%') . ')');
    $this->applyDateRange($q, 't.created_at_utc', $filters);
    $db->setQuery($q);
    $manualReviewTopups = (int) $db->loadResult();

    return array(
      'orders_total' => $ordersTotal,
      'topups_total' => $topupsTotal,
      'paid_items' => $paidOrders + $paidTopups,
      'manual_review' => $manualReviewOrders + $manualReviewTopups,
    );
  }

  public function getRecentOrders(array $filters, $limit = 15)
  {
    $db = $this->getDbo();
    list($search, $numeric) = $this->parseSearch($filters);
    $q = $db->getQuery(true)
      ->select('o.id, o.lead_id, o.batch_id, o.buyer_email, o.amount_usd, o.status, o.payment_status, o.created_at_utc, o.paid_at_utc, o.tx_hash, l.state, l.type')
      ->from($db->qn('#__leadmarket_orders', 'o'))
      ->join('LEFT', $db->qn('#__leadmarket_leads', 'l') . ' ON l.id = o.lead_id');
    $this->applyDateRange($q, 'o.created_at_utc', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('o.buyer_email LIKE ' . $like, 'CAST(o.lead_id AS CHAR) LIKE ' . $like, 'CAST(o.batch_id AS CHAR) LIKE ' . $like, 'o.tx_hash LIKE ' . $like);
      if ($numeric !== null) {
        $parts[] = 'o.id=' . (int) $numeric;
      }
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $orderStatus = trim((string) $filters['order_status']);
    if ($orderStatus !== '') {
      if ($orderStatus === 'checking') {
        $q->where('o.payment_status=' . $db->q('checking'));
      } elseif ($orderStatus === 'manual_review') {
        $q->where('(o.payment_status=' . $db->q('late_no_slots') . ' OR o.payment_status=' . $db->q('refund_pending') . ' OR o.payment_status=' . $db->q('mismatch') . ')');
      } else {
        $q->where('o.status=' . $db->q($orderStatus));
      }
    }
    $q->order('o.created_at_utc DESC');
    $db->setQuery($q, 0, (int) $limit);
    return (array) $db->loadObjectList();
  }

  public function getRecentTopups(array $filters, $limit = 15)
  {
    $db = $this->getDbo();
    list($search, $numeric) = $this->parseSearch($filters);
    $q = $db->getQuery(true)
      ->select('t.id, t.buyer_email, t.topup_amount_usd, t.target_type, t.target_id, t.status, t.result_status, t.result_message, t.created_at_utc, t.paid_at_utc')
      ->from($db->qn('#__leadmarket_topups', 't'));
    $this->applyDateRange($q, 't.created_at_utc', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('t.buyer_email LIKE ' . $like, 'CAST(t.target_id AS CHAR) LIKE ' . $like);
      if ($numeric !== null) {
        $parts[] = 't.id=' . (int) $numeric;
      }
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $topupStatus = trim((string) $filters['topup_status']);
    if ($topupStatus !== '') {
      if ($topupStatus === 'manual_review') {
        $q->where('(t.result_status=' . $db->q('failed_manual_review') . ' OR t.result_message LIKE ' . $db->q('%manual review%') . ')');
      } elseif ($topupStatus === 'checking') {
        $q->where('t.status=' . $db->q('checking'));
      } else {
        $q->where('t.status=' . $db->q($topupStatus));
      }
    }
    $q->order('t.created_at_utc DESC');
    $db->setQuery($q, 0, (int) $limit);
    return (array) $db->loadObjectList();
  }

  public function getRecentLeads(array $filters, $limit = 12)
  {
    $db = $this->getDbo();
    list($search, $numeric) = $this->parseSearch($filters);
    $q = $db->getQuery(true)
      ->select('l.id, l.type, l.state, l.city, l.lead_status, l.price_usd, l.uploaded_at_utc')
      ->from($db->qn('#__leadmarket_leads', 'l'));
    $this->applyDateRange($q, 'l.uploaded_at_utc', $filters);
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $parts = array('l.state LIKE ' . $like, 'l.city LIKE ' . $like, 'l.type LIKE ' . $like);
      if ($numeric !== null) {
        $parts[] = 'l.id=' . (int) $numeric;
      }
      $q->where('(' . implode(' OR ', $parts) . ')');
    }
    $q->order('l.uploaded_at_utc DESC');
    $db->setQuery($q, 0, (int) $limit);
    return (array) $db->loadObjectList();
  }

  public function getWalletPreview(array $filters, $limit = 12)
  {
    $db = $this->getDbo();
    list($search,) = $this->parseSearch($filters);
    $ledgerAgg = '(SELECT buyer_email, MAX(created_at_utc) AS last_activity_at, ROUND(SUM(CASE WHEN direction="credit" THEN amount_usd ELSE 0 END),2) AS total_credits, ROUND(SUM(CASE WHEN direction="debit" THEN amount_usd ELSE 0 END),2) AS total_debits FROM ' . $db->qn('#__leadmarket_wallet_ledger') . ' GROUP BY buyer_email) AS x';
    $q = $db->getQuery(true)
      ->select('w.buyer_email, w.balance_usd, w.updated_at_utc, x.last_activity_at, COALESCE(x.total_credits,0.00) AS total_credits, COALESCE(x.total_debits,0.00) AS total_debits')
      ->from($db->qn('#__leadmarket_wallets', 'w'))
      ->join('LEFT', $ledgerAgg . ' ON x.buyer_email = w.buyer_email');
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $q->where('w.buyer_email LIKE ' . $like);
    }
    $q->order('w.updated_at_utc DESC');
    $db->setQuery($q, 0, (int) $limit);
    return (array) $db->loadObjectList();
  }

  public function getExportRows($type, array $filters)
  {
    $type = strtolower((string) $type);
    switch ($type) {
      case 'orders':
        return $this->getExportOrders($filters);
      case 'topups':
        return $this->getExportTopups($filters);
      case 'wallets':
        return $this->getExportWallets($filters);
      case 'leads':
      default:
        return $this->getExportLeads($filters);
    }
  }

  protected function getExportLeads(array $filters)
  {
    $rows = array();
    foreach ($this->getRecentLeads($filters, 10000) as $it) {
      $rows[] = array(
        'lead_id' => $it->id,
        'type' => $it->type,
        'state' => $it->state,
        'city' => $it->city,
        'market_status' => $it->lead_status,
        'price_usd' => number_format((float) $it->price_usd, 2, '.', ''),
        'market_arrival_utc' => $it->uploaded_at_utc,
      );
    }
    return $rows;
  }

  protected function getExportOrders(array $filters)
  {
    $rows = array();
    foreach ($this->getRecentOrders($filters, 10000) as $it) {
      $rows[] = array(
        'order_id' => $it->id,
        'buyer_email' => $it->buyer_email,
        'lead_id' => $it->lead_id,
        'batch_id' => $it->batch_id,
        'lead_label' => trim($it->state . ' ' . $it->type),
        'amount_usd' => number_format((float) $it->amount_usd, 2, '.', ''),
        'status' => $it->status,
        'payment_status' => $it->payment_status,
        'created_at_utc' => $it->created_at_utc,
        'paid_at_utc' => $it->paid_at_utc,
      );
    }
    return $rows;
  }

  protected function getExportTopups(array $filters)
  {
    $rows = array();
    foreach ($this->getRecentTopups($filters, 10000) as $it) {
      $rows[] = array(
        'topup_id' => $it->id,
        'buyer_email' => $it->buyer_email,
        'target_type' => $it->target_type,
        'target_id' => $it->target_id,
        'topup_amount_usd' => number_format((float) $it->topup_amount_usd, 2, '.', ''),
        'status' => $it->status,
        'result_status' => $it->result_status,
        'result_message' => $it->result_message,
        'created_at_utc' => $it->created_at_utc,
        'paid_at_utc' => $it->paid_at_utc,
      );
    }
    return $rows;
  }

  protected function getExportWallets(array $filters)
  {
    $rows = array();
    foreach ($this->getWalletPreview($filters, 10000) as $it) {
      $rows[] = array(
        'buyer_email' => $it->buyer_email,
        'balance_usd' => number_format((float) $it->balance_usd, 2, '.', ''),
        'total_credits' => number_format((float) $it->total_credits, 2, '.', ''),
        'total_debits' => number_format((float) $it->total_debits, 2, '.', ''),
        'last_activity_at' => $it->last_activity_at,
        'updated_at_utc' => $it->updated_at_utc,
      );
    }
    return $rows;
  }


  protected function analyticsEventsTableExists()
  {
    static $exists = null;
    if ($exists !== null) return $exists;
    try {
      $db = $this->getDbo();
      $table = $db->replacePrefix('#__leadmarket_events');
      $db->setQuery('SHOW TABLES LIKE ' . $db->q($table));
      $exists = (bool) $db->loadResult();
    } catch (Exception $e) {
      $exists = false;
    }
    return $exists;
  }

  protected function analyticsBaseQuery(array $filters)
  {
    $db = $this->getDbo();
    $q = $db->getQuery(true)->from($db->qn('#__leadmarket_events', 'e'));
    $this->applyDateRange($q, 'e.created_at', $filters);
    return $q;
  }

  protected function analyticsEventCounts(array $filters, array $eventNames)
  {
    $out = array();
    foreach ($eventNames as $name) $out[$name] = 0;
    if (!$this->analyticsEventsTableExists()) return $out;
    if (empty($eventNames)) return $out;
    try {
      $db = $this->getDbo();
      $quoted = array();
      foreach ($eventNames as $name) $quoted[] = $db->q((string) $name);
      $q = $this->analyticsBaseQuery($filters)
        ->select('e.event_name, COUNT(*) AS cnt')
        ->where('e.event_name IN (' . implode(',', $quoted) . ')')
        ->group('e.event_name');
      $db->setQuery($q);
      foreach ((array) $db->loadObjectList() as $row) {
        $out[(string) $row->event_name] = (int) $row->cnt;
      }
    } catch (Exception $e) {}
    return $out;
  }

  public function getAnalyticsSummary(array $filters)
  {
    $summary = array(
      'events_total' => 0,
      'visitors' => 0,
      'sessions' => 0,
      'lead_views' => 0,
      'checkout_starts' => 0,
      'topups_created' => 0,
      'credit_submitted' => 0,
    );
    if (!$this->analyticsEventsTableExists()) return $summary;
    try {
      $db = $this->getDbo();
      $q = $this->analyticsBaseQuery($filters)->clear('select')->select('COUNT(*)');
      $db->setQuery($q);
      $summary['events_total'] = (int) $db->loadResult();

      $q = $this->analyticsBaseQuery($filters)->clear('select')->select('COUNT(DISTINCT e.visitor_id)')->where("e.visitor_id <> ''");
      $db->setQuery($q);
      $summary['visitors'] = (int) $db->loadResult();

      $q = $this->analyticsBaseQuery($filters)->clear('select')->select('COUNT(DISTINCT e.session_id)')->where("e.session_id <> ''");
      $db->setQuery($q);
      $summary['sessions'] = (int) $db->loadResult();

      $counts = $this->analyticsEventCounts($filters, array('lead_preview_view','lead_open_click','checkout_start','topup_created','credit_request_submitted'));
      $summary['lead_views'] = (int) ($counts['lead_preview_view'] + $counts['lead_open_click']);
      $summary['checkout_starts'] = (int) $counts['checkout_start'];
      $summary['topups_created'] = (int) $counts['topup_created'];
      $summary['credit_submitted'] = (int) $counts['credit_request_submitted'];
    } catch (Exception $e) {}
    return $summary;
  }

  public function getLeadInterestAnalytics(array $filters, $limit = 12)
  {
    if (!$this->analyticsEventsTableExists()) return array();
    try {
      $db = $this->getDbo();
      $q = $this->analyticsBaseQuery($filters)
        ->clear('select')
        ->select(array('e.event_name','e.lead_id','e.order_id','e.props_json','e.referrer_url'))
        ->where("e.event_name IN ('lead_preview_view','lead_open_click','add_to_batch','checkout_start','order_paid','batch_paid')");
      $db->setQuery($q);
      $events = (array) $db->loadAssocList();
      if (empty($events)) return array();

      $totals = array();
      $missingOrderIds = array();
      foreach ($events as $event) {
        $eventName = (string) ($event['event_name'] ?? '');
        $leadId = $this->resolveAnalyticsLeadId($event);
        $orderId = (int) ($event['order_id'] ?? 0);
        if ($leadId <= 0 && $orderId > 0 && in_array($eventName, array('order_paid','batch_paid'), true)) {
          $missingOrderIds[$orderId] = $orderId;
          continue;
        }
        if ($leadId <= 0) continue;
        if (!isset($totals[$leadId])) {
          $totals[$leadId] = array('lead_id'=>$leadId,'preview_views'=>0,'lead_opens'=>0,'added_to_batch'=>0,'checkout_starts'=>0,'purchases'=>0,'state'=>'','type'=>'');
        }
        if ($eventName === 'lead_preview_view') $totals[$leadId]['preview_views']++;
        elseif ($eventName === 'lead_open_click') $totals[$leadId]['lead_opens']++;
        elseif ($eventName === 'add_to_batch') $totals[$leadId]['added_to_batch']++;
        elseif ($eventName === 'checkout_start') $totals[$leadId]['checkout_starts']++;
        elseif ($eventName === 'order_paid' || $eventName === 'batch_paid') $totals[$leadId]['purchases']++;
      }

      if (!empty($missingOrderIds)) {
        $q = $db->getQuery(true)
          ->select(array('id','lead_id'))
          ->from($db->qn('#__leadmarket_orders'))
          ->where('id IN (' . implode(',', array_map('intval', array_values($missingOrderIds))) . ')');
        $db->setQuery($q);
        $orderMap = array();
        foreach ((array) $db->loadAssocList() as $row) {
          $oid = (int) ($row['id'] ?? 0);
          $lid = (int) ($row['lead_id'] ?? 0);
          if ($oid > 0 && $lid > 0) $orderMap[$oid] = $lid;
        }
        foreach ($events as $event) {
          $eventName = (string) ($event['event_name'] ?? '');
          if (!in_array($eventName, array('order_paid','batch_paid'), true)) continue;
          $leadId = $this->resolveAnalyticsLeadId($event);
          if ($leadId <= 0) $leadId = (int) ($orderMap[(int) ($event['order_id'] ?? 0)] ?? 0);
          if ($leadId <= 0) continue;
          if (!isset($totals[$leadId])) {
            $totals[$leadId] = array('lead_id'=>$leadId,'preview_views'=>0,'lead_opens'=>0,'added_to_batch'=>0,'checkout_starts'=>0,'purchases'=>0,'state'=>'','type'=>'');
          }
          $totals[$leadId]['purchases']++;
        }
      }

      if (empty($totals)) return array();

      // Meta is optional. Never let a schema mismatch blank the whole report.
      try {
        $leadIds = array_map('intval', array_keys($totals));
        if (!empty($leadIds)) {
          $leadCols = $db->getTableColumns('#__leadmarket_leads', false);
          $select = array('id');
          if (isset($leadCols['state'])) $select[] = 'state';
          if (isset($leadCols['type'])) $select[] = 'type';
          if (count($select) > 1) {
            $q = $db->getQuery(true)
              ->select($select)
              ->from($db->qn('#__leadmarket_leads'))
              ->where('id IN (' . implode(',', $leadIds) . ')');
            $db->setQuery($q);
            foreach ((array) $db->loadAssocList() as $row) {
              $lid = (int) ($row['id'] ?? 0);
              if ($lid > 0 && isset($totals[$lid])) {
                if (isset($row['state'])) $totals[$lid]['state'] = (string) $row['state'];
                if (isset($row['type'])) $totals[$lid]['type'] = (string) $row['type'];
              }
            }
          }
        }
      } catch (Exception $e) {}

      $rows = array();
      foreach ($totals as $leadId => $row) {
        $row['_score'] = (int)$row['preview_views'] + (int)$row['lead_opens'] + (int)$row['added_to_batch'] + (int)$row['checkout_starts'] + (int)$row['purchases'];
        $rows[] = (object) $row;
      }
      usort($rows, function($a, $b){
        foreach (array('_score','preview_views','lead_opens','added_to_batch','checkout_starts','purchases','lead_id') as $k) {
          $av = (int) ($a->$k ?? 0);
          $bv = (int) ($b->$k ?? 0);
          if ($av === $bv) continue;
          return ($av < $bv) ? 1 : -1;
        }
        return 0;
      });
      return array_slice($rows, 0, max(1, (int) $limit));
    } catch (Exception $e) {
      return array();
    }
  }

  protected function resolveAnalyticsLeadId(array $event)
  {
    $leadId = (int) ($event['lead_id'] ?? 0);
    if ($leadId > 0) return $leadId;
    $props = array();
    if (!empty($event['props_json'])) {
      $props = json_decode((string) $event['props_json'], true);
      if (!is_array($props)) $props = array();
    }
    if (!empty($props['lead_id'])) return (int) $props['lead_id'];
    $ref = (string) ($event['referrer_url'] ?? '');
    if ($ref !== '' && preg_match('~(?:[?&]|/)(?:id|lead_id)=(\d+)~', $ref, $m)) return (int) $m[1];
    return 0;
  }

  public function getFunnelAnalytics(array $filters)
  {
    $keys = array('marketplace_view','lead_preview_view','lead_open_click','add_to_batch','batch_summary_view','checkout_start','insufficient_balance','topup_created','topup_reference_submitted','order_paid','batch_paid');
    $counts = $this->analyticsEventCounts($filters, $keys);
    return array(
      'marketplace_views' => (int) ($counts['marketplace_view'] ?? 0),
      'lead_preview_views' => (int) ($counts['lead_preview_view'] ?? 0),
      'lead_open_clicks' => (int) ($counts['lead_open_click'] ?? 0),
      'add_to_batch' => (int) ($counts['add_to_batch'] ?? 0),
      'batch_summary_views' => (int) ($counts['batch_summary_view'] ?? 0),
      'checkout_starts' => (int) ($counts['checkout_start'] ?? 0),
      'insufficient_balance' => (int) ($counts['insufficient_balance'] ?? 0),
      'topup_created' => (int) ($counts['topup_created'] ?? 0),
      'topup_reference_submitted' => (int) ($counts['topup_reference_submitted'] ?? 0),
      'order_paid' => (int) ($counts['order_paid'] ?? 0),
      'batch_paid' => (int) ($counts['batch_paid'] ?? 0),
    );
  }

  public function getTopupMethodAnalytics(array $filters)
  {
    $out = array();
    if (!$this->analyticsEventsTableExists()) return $out;
    try {
      $db = $this->getDbo();
      $q = $this->analyticsBaseQuery($filters)
        ->clear('select')
        ->select('e.event_name, e.props_json')
        ->where("e.event_name IN ('topup_method_selected','topup_created','topup_reference_submitted','topup_cancelled','topup_paid','topup_expired')");
      $db->setQuery($q);
      foreach ((array) $db->loadObjectList() as $row) {
        $props = json_decode((string) $row->props_json, true);
        if (!is_array($props)) $props = array();
        $method = trim((string) ($props['method'] ?? $props['topup_method'] ?? 'unknown'));
        if ($method === '') $method = 'unknown';
        if (!isset($out[$method])) {
          $out[$method] = array('topup_method_selected'=>0,'topup_created'=>0,'topup_reference_submitted'=>0,'paid'=>0,'topup_cancelled'=>0,'expired'=>0);
        }
        $event = (string) $row->event_name;
        if ($event === 'topup_paid') $out[$method]['paid']++;
        elseif ($event === 'topup_expired') $out[$method]['expired']++;
        elseif (isset($out[$method][$event])) $out[$method][$event]++;
      }
    } catch (Exception $e) {}
    return $out;
  }

  public function getCreditRequestAnalytics(array $filters, $limit = 10)
  {
    $out = array(
      'credit_request_opened' => 0,
      'credit_request_submitted' => 0,
      'credit_request_approved' => 0,
      'credit_request_rejected' => 0,
      'reasons' => array(),
    );
    if (!$this->analyticsEventsTableExists()) return $out;
    try {
      $counts = $this->analyticsEventCounts($filters, array('credit_request_opened','credit_request_submitted','credit_request_approved','credit_request_rejected'));
      foreach ($counts as $k => $v) $out[$k] = (int) $v;
      $db = $this->getDbo();
      $q = $this->analyticsBaseQuery($filters)
        ->clear('select')
        ->select('e.props_json')
        ->where('e.event_name=' . $db->q('credit_request_submitted'));
      $db->setQuery($q);
      $reasonCounts = array();
      foreach ((array) $db->loadColumn() as $propsJson) {
        $props = json_decode((string) $propsJson, true);
        if (!is_array($props)) $props = array();
        $reason = trim((string) ($props['reason'] ?? $props['reason_code'] ?? 'unknown'));
        if ($reason === '') $reason = 'unknown';
        if (!isset($reasonCounts[$reason])) $reasonCounts[$reason] = 0;
        $reasonCounts[$reason]++;
      }
      arsort($reasonCounts);
      $reasonCounts = array_slice($reasonCounts, 0, (int) $limit, true);
      $rows = array();
      foreach ($reasonCounts as $reason => $cnt) {
        $o = new stdClass();
        $o->reason_code = $reason;
        $o->cnt = (int) $cnt;
        $rows[] = $o;
      }
      $out['reasons'] = $rows;
    } catch (Exception $e) {}
    return $out;
  }

}
