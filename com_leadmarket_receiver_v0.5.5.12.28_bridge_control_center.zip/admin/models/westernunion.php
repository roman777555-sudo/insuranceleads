<?php
defined('_JEXEC') or die;

class LeadMarketModelWesternUnion extends JModelList
{
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array(
        'id', 't.id',
        'created_at_utc', 't.created_at_utc',
        'buyer_email', 't.buyer_email',
        'status', 't.status',
        'target_type', 't.target_type',
        'target_id', 't.target_id',
        'topup_amount_usd', 't.topup_amount_usd',
        'balance_after_credit', 't.balance_after_credit',
      );
    }
    parent::__construct($config);
  }

  protected function populateState($ordering = 't.created_at_utc', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    $this->setState('filter.search', $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '', 'string'));
    $this->setState('filter.status', $app->getUserStateFromRequest($this->context . '.filter.status', 'filter_status', '', 'string'));
    $this->setState('filter.target_type', $app->getUserStateFromRequest($this->context . '.filter.target_type', 'filter_target_type', '', 'string'));
    parent::populateState($ordering, $direction);
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('t.*')
      ->from($db->qn('#__leadmarket_topups', 't'))
      ->where('(t.payment_method=' . $db->q('moneygram') . ' OR t.payment_method=' . $db->q('westernunion') . ')');

    $search = trim((string) $this->getState('filter.search'));
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      if (preg_match('/^#?(\d+)$/', $search, $m)) {
        $query->where('(t.buyer_email LIKE ' . $like . ' OR t.id=' . (int) $m[1] . ' OR t.manual_reference LIKE ' . $like . ')');
      } else {
        $query->where('(t.buyer_email LIKE ' . $like . ' OR t.manual_reference LIKE ' . $like . ' OR t.manual_sender_name LIKE ' . $like . ')');
      }
    }

    $status = trim((string) $this->getState('filter.status'));
    if ($status !== '') {
      $query->where('t.status=' . $db->q($status));
    }

    $targetType = trim((string) $this->getState('filter.target_type'));
    if ($targetType !== '') {
      $query->where('t.target_type=' . $db->q($targetType));
    }

    $ordering = (string) $this->state->get('list.ordering', 't.created_at_utc');
    $direction = strtoupper((string) $this->state->get('list.direction', 'DESC'));
    if (!in_array($direction, array('ASC','DESC'), true)) $direction = 'DESC';
    $allowed = array('t.id','t.created_at_utc','t.buyer_email','t.status','t.target_type','t.target_id','t.topup_amount_usd','t.balance_after_credit');
    if (!in_array($ordering, $allowed, true)) $ordering = 't.created_at_utc';
    $query->order($ordering . ' ' . $direction);

    return $query;
  }

  public function getSummary()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('COUNT(*) AS total_requests')
      ->select('SUM(CASE WHEN status=' . $db->q('pending_review') . ' THEN 1 ELSE 0 END) AS awaiting_review')
      ->select('SUM(CASE WHEN status=' . $db->q('paid') . ' THEN 1 ELSE 0 END) AS paid_count')
      ->select('SUM(CASE WHEN status IN (' . $db->q('pending') . ',' . $db->q('checking') . ',' . $db->q('pending_review') . ') THEN 1 ELSE 0 END) AS active_count')
      ->select('SUM(CASE WHEN status=' . $db->q('paid') . ' THEN topup_amount_usd ELSE 0 END) AS paid_amount')
      ->from($db->qn('#__leadmarket_topups', 't'))
      ->where('(t.payment_method=' . $db->q('moneygram') . ' OR t.payment_method=' . $db->q('westernunion') . ')');
    $db->setQuery($query);
    $row = (array) $db->loadAssoc();
    return array(
      'total_requests' => (int) ($row['total_requests'] ?? 0),
      'awaiting_review' => (int) ($row['awaiting_review'] ?? 0),
      'paid_count' => (int) ($row['paid_count'] ?? 0),
      'active_count' => (int) ($row['active_count'] ?? 0),
      'paid_amount' => (float) ($row['paid_amount'] ?? 0),
    );
  }
}
