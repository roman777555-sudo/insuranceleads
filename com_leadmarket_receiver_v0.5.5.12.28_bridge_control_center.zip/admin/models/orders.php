<?php
defined('_JEXEC') or die;

class LeadMarketModelOrders extends JModelList
{
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array('id','o.id','status','o.status','payment_status','o.payment_status','buyer_email','o.buyer_email','lead_id','o.lead_id','created_at_utc','o.created_at_utc');
    }
    parent::__construct($config);
  }

  protected function populateState($ordering = 'o.id', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    $this->setState('filter.search', $app->getUserStateFromRequest($this->context.'.filter.search', 'filter_search', '', 'string'));
    $this->setState('filter.status', $app->getUserStateFromRequest($this->context.'.filter.status', 'filter_status', '', 'string'));
    $this->setState('filter.payment_status', $app->getUserStateFromRequest($this->context.'.filter.payment_status', 'filter_payment_status', '', 'string'));
    parent::populateState($ordering, $direction);
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('o.*, l.type, l.state, l.city, l.zip')
      ->from($db->qn('#__leadmarket_orders','o'))
      ->join('LEFT', $db->qn('#__leadmarket_leads','l') . ' ON l.id = o.lead_id');

    $search = trim((string)$this->getState('filter.search'));
    if ($search !== '') {
      if (strpos($search, '#') === 0) {
        $query->where('o.id=' . (int)substr($search,1));
      } else {
        $like = $db->q('%' . $db->escape($search, true) . '%', false);
        $query->where('(o.buyer_email LIKE ' . $like . ' OR CAST(o.lead_id AS CHAR) LIKE ' . $like . ' OR o.tx_hash LIKE ' . $like . ')');
      }
    }

    $status = trim((string)$this->getState('filter.status'));
    if ($status !== '') $query->where('o.status=' . $db->q($status));
    $paymentStatus = trim((string)$this->getState('filter.payment_status'));
    if ($paymentStatus !== '') $query->where('o.payment_status=' . $db->q($paymentStatus));

    $query->order($db->qn('o.id').' DESC');
    return $query;
  }
}
