<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketModelWallets extends JModelList
{
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array(
        'buyer_email', 'w.buyer_email',
        'balance_usd', 'w.balance_usd',
        'created_at_utc', 'w.created_at_utc',
        'updated_at_utc', 'w.updated_at_utc',
        'last_activity_at', 'last_activity_at',
        'total_credits', 'total_credits',
        'total_debits', 'total_debits',
      );
    }
    parent::__construct($config);
  }

  protected function populateState($ordering = 'w.updated_at_utc', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    $this->setState('filter.search', $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '', 'string'));
    parent::populateState($ordering, $direction);
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();

    $ledgerAgg = '(SELECT buyer_email,'
      . ' MAX(created_at_utc) AS last_activity_at,'
      . ' ROUND(SUM(CASE WHEN direction="credit" THEN amount_usd ELSE 0 END), 2) AS total_credits,'
      . ' ROUND(SUM(CASE WHEN direction="debit" THEN amount_usd ELSE 0 END), 2) AS total_debits'
      . ' FROM ' . $db->qn('#__leadmarket_wallet_ledger')
      . ' GROUP BY buyer_email) AS x';

    $query = $db->getQuery(true)
      ->select(array(
        'w.*',
        'x.last_activity_at',
        'COALESCE(x.total_credits, 0.00) AS total_credits',
        'COALESCE(x.total_debits, 0.00) AS total_debits'
      ))
      ->from($db->qn('#__leadmarket_wallets', 'w'))
      ->join('LEFT', $ledgerAgg . ' ON x.buyer_email = w.buyer_email');

    $search = trim((string) $this->getState('filter.search'));
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $query->where('w.buyer_email LIKE ' . $like);
    }

    $ordering = (string) $this->state->get('list.ordering', 'w.updated_at_utc');
    $direction = strtoupper((string) $this->state->get('list.direction', 'DESC'));
    if (!in_array($direction, array('ASC', 'DESC'), true)) $direction = 'DESC';
    $allowed = array('w.buyer_email','w.balance_usd','w.created_at_utc','w.updated_at_utc','last_activity_at','total_credits','total_debits');
    if (!in_array($ordering, $allowed, true)) $ordering = 'w.updated_at_utc';
    $query->order($ordering . ' ' . $direction);

    return $query;
  }

  public function getRecentActivity($limit = 20)
  {
    return LeadMarketHelper::getWalletActivity('', $limit);
  }
}
