<?php
defined('_JEXEC') or die;

class LeadMarketModelPromocodes extends JModelList
{
  public function __construct($config = array())
  {
    if (empty($config['filter_fields'])) {
      $config['filter_fields'] = array('id','p.id','code','p.code','is_active','p.is_active','updated_at','p.updated_at');
    }
    parent::__construct($config);
  }

  protected function populateState($ordering = 'p.updated_at', $direction = 'DESC')
  {
    $app = JFactory::getApplication();
    $this->setState('filter.search', $app->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '', 'string'));
    $this->setState('filter.active', $app->getUserStateFromRequest($this->context . '.filter.active', 'filter_active', '', 'string'));
    parent::populateState($ordering, $direction);
  }

  protected function getListQuery()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('p.*, (SELECT COUNT(*) FROM ' . $db->qn('#__leadmarket_promocode_usages') . ' pu WHERE pu.promocode_id = p.id AND pu.status=' . $db->q('confirmed') . ') AS confirmed_uses')
      ->from($db->qn('#__leadmarket_promocodes', 'p'));

    $search = trim((string) $this->getState('filter.search'));
    if ($search !== '') {
      $like = $db->q('%' . $db->escape($search, true) . '%', false);
      $query->where('(p.code LIKE ' . $like . ' OR p.title LIKE ' . $like . ')');
    }

    $active = trim((string) $this->getState('filter.active'));
    if ($active !== '') {
      $query->where('p.is_active=' . (int) $active);
    }

    $query->order('p.updated_at DESC, p.id DESC');
    return $query;
  }
}
