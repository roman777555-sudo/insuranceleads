<?php
defined('_JEXEC') or die;

class LeadMarketModelSubscribers extends JModelList
{
  protected function getListQuery()
  {
    $db = $this->getDbo();
    $query = $db->getQuery(true)
      ->select('s.*')
      ->select("GROUP_CONCAT(DISTINCT COALESCE(l.state, 'GENERAL') ORDER BY COALESCE(l.state, 'GENERAL') SEPARATOR ', ') AS subscribed_lists")
      ->from($db->qn('#__leadmarket_subscribers', 's'))
      ->join('LEFT', $db->qn('#__leadmarket_subscriber_lists', 'sl') . ' ON sl.subscriber_id = s.id')
      ->join('LEFT', $db->qn('#__leadmarket_lists', 'l') . ' ON l.id = sl.list_id')
      ->group('s.id')
      ->order($db->qn('s.id') . ' DESC');
    return $query;
  }
}
