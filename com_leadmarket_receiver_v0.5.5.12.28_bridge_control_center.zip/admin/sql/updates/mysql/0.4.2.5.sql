-- v0.4.2.5 expired late gate
ALTER TABLE `#__leadmarket_orders` ADD COLUMN `late_payment_declared` TINYINT(1) NOT NULL DEFAULT 0;
