-- 0.3.4: subscriber lead_type filter
ALTER TABLE `#__leadmarket_subscribers`
  ADD COLUMN `lead_type` VARCHAR(8) NOT NULL DEFAULT 'both' AFTER `mode`;

ALTER TABLE `#__leadmarket_leads` ADD COLUMN `lead_json` MEDIUMTEXT NULL AFTER `payload_raw`;
