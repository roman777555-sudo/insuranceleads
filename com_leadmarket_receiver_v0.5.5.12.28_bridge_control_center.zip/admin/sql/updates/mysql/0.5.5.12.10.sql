CREATE TABLE IF NOT EXISTS `#__leadmarket_trial_lead_views` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `access_id` INT(11) NOT NULL DEFAULT 0,
  `subscriber_id` INT(11) NOT NULL DEFAULT 0,
  `email` VARCHAR(190) NOT NULL DEFAULT '',
  `lead_id` INT(11) NOT NULL DEFAULT 0,
  `lead_state` VARCHAR(4) NULL,
  `lead_type` VARCHAR(16) NULL,
  `lead_city` VARCHAR(128) NULL,
  `viewed_at_utc` DATETIME NOT NULL,
  `request_ip` VARCHAR(64) NULL,
  `user_agent` VARCHAR(255) NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access` (`access_id`),
  KEY `idx_email` (`email`),
  KEY `idx_lead` (`lead_id`),
  KEY `idx_viewed` (`viewed_at_utc`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
