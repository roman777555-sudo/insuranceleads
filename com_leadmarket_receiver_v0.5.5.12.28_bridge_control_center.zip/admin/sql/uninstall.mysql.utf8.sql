-- Keep data by default (no DROP). If you really want to drop, do it manually.

DROP TABLE IF EXISTS `#__leadmarket_buyer_access_tokens`;

DROP TABLE IF EXISTS `#__leadmarket_credit_requests`;
