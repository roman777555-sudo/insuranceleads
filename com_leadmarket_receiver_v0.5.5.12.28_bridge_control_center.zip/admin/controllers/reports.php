<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerReports extends JControllerAdmin
{
  public function __construct($config = array())
  {
    parent::__construct($config);
    LeadMarketHelper::ensureSchema();
    $this->registerTask('export', 'export');
  }

  public function getModel($name = 'Reports', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  public function export()
  {
    if (!JSession::checkToken('get')) {
      jexit('Invalid Token');
    }

    $app = JFactory::getApplication();
    $model = $this->getModel();
    $filters = $model->getFilters();
    $type = strtolower((string) $app->input->getCmd('export_type', 'orders'));
    if (!in_array($type, array('leads', 'orders', 'topups', 'wallets'), true)) {
      $type = 'orders';
    }

    $rows = (array) $model->getExportRows($type, $filters);
    $filename = 'leadmarket-' . $type . '-' . gmdate('Ymd-His') . '.csv';

    while (ob_get_level()) {
      ob_end_clean();
    }

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $out = fopen('php://output', 'w');
    if (!empty($rows)) {
      fputcsv($out, array_keys(reset($rows)));
      foreach ($rows as $row) {
        fputcsv($out, $row);
      }
    } else {
      fputcsv($out, array('notice'));
      fputcsv($out, array('No rows matched the current filters.'));
    }
    fclose($out);
    $app->close();
  }
}
