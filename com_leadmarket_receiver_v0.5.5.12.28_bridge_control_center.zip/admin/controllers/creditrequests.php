<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerCreditrequests extends JControllerAdmin
{
  public function __construct($config = array())
  {
    parent::__construct($config);
    LeadMarketHelper::ensureSchema();
    $this->registerTask('approve', 'approve');
    $this->registerTask('decline', 'decline');
  }

  public function getModel($name = 'Creditrequests', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  public function approve()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $input = $app->input;
    $id = (int) $input->getInt('id', 0);
    $approvedAmount = LeadMarketHelper::parseMoneyInput($input->getString('approved_amount', '0'));
    $adminNote = trim((string) $input->getString('admin_note', ''));
    $user = JFactory::getUser();
    $result = LeadMarketHelper::approveCreditRequest($id, $approvedAmount, $adminNote, (int) ($user->id ?? 0), (string) ($user->name ?? 'Admin'));
    if (!empty($result['ok'])) { LeadMarketHelper::trackEvent('credit_request_approved', array('page_name' => 'admin_creditrequests', 'credit_request_id' => $id)); }
    $app->enqueueMessage((string) ($result['message'] ?? 'Done.'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=creditrequests', false));
    return !empty($result['ok']);
  }

  public function decline()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $input = $app->input;
    $id = (int) $input->getInt('id', 0);
    $adminNote = trim((string) $input->getString('admin_note', ''));
    $user = JFactory::getUser();
    $result = LeadMarketHelper::declineCreditRequest($id, $adminNote, (int) ($user->id ?? 0));
    if (!empty($result['ok'])) { LeadMarketHelper::trackEvent('credit_request_rejected', array('page_name' => 'admin_creditrequests', 'credit_request_id' => $id)); }
    $app->enqueueMessage((string) ($result['message'] ?? 'Done.'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=creditrequests', false));
    return !empty($result['ok']);
  }
}
