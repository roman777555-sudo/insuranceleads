<?php
defined('_JEXEC') or die;

class LeadMarketControllerConfig extends JControllerLegacy
{
  /**
   * Save settings. Used by toolbar tasks: config.save, config.apply, config.save2close
   */
  public function save($key = null, $urlVar = null)
  {
    JSession::checkToken() or jexit('Invalid Token');

    $app   = JFactory::getApplication();
    $input = $app->input;

    $data = $input->post->get('jform', array(), 'array');

    $params = array(
      'from_email'         => trim((string)($data['from_email'] ?? 'support@insuranceleads.co')),
      'from_name'          => trim((string)($data['from_name'] ?? 'InsuranceLeads.co')),
      'usdt_trc20_address' => trim((string)($data['usdt_trc20_address'] ?? '')),
      'admin_activity_notify_enabled' => (int)($data['admin_activity_notify_enabled'] ?? 0),
      'admin_activity_notify_email' => trim((string)($data['admin_activity_notify_email'] ?? 'roman777555123@icloud.com')),
      'reserve_minutes'    => (int)($data['reserve_minutes'] ?? 30),
      'exclusive_hours'    => (int)($data['exclusive_hours'] ?? 3),
      'exclusive_hours_auto' => (int)($data['exclusive_hours_auto'] ?? 6),
      'exclusive_hours_home' => (int)($data['exclusive_hours_home'] ?? 12),
      'instant_enabled'    => (int)($data['instant_enabled'] ?? 1),
      'daily_enabled'      => (int)($data['daily_enabled'] ?? 1),
      'daily_time_utc'     => trim((string)($data['daily_time_utc'] ?? '10:00')),
      'mini_widget_limit' => (int)($data['mini_widget_limit'] ?? 5),
      'mini_widget_hours' => (int)($data['mini_widget_hours'] ?? 25),
      'mini_widget_title' => trim((string)($data['mini_widget_title'] ?? 'Latest Lead Activity')),
      'opening_promo_text' => (string)($data['opening_promo_text'] ?? 'Launch offer: <strong>shared auto leads from $10</strong> for the first 2 months.'),
      'free_test_enabled' => (int)($data['free_test_enabled'] ?? 1),
      'free_test_badge_text' => trim((string)($data['free_test_badge_text'] ?? 'Free Buyer Trial')),
      'free_test_title' => trim((string)($data['free_test_title'] ?? 'Unlock Real Insurance Test Leads')),
      'free_test_subtitle' => trim((string)($data['free_test_subtitle'] ?? 'Choose your states and lead types, subscribe to instant email alerts, and unlock a curated set of real auto and home insurance leads from our marketplace.')),
      'free_test_unlock_button_text' => trim((string)($data['free_test_unlock_button_text'] ?? 'Unlock Free Test Leads')),
      'free_test_success_title' => trim((string)($data['free_test_success_title'] ?? 'Your free test leads are unlocked')),
      'free_test_success_text' => trim((string)($data['free_test_success_text'] ?? 'You are now subscribed to instant alerts for new matching leads.')),
      'free_test_market_cta_text' => trim((string)($data['free_test_market_cta_text'] ?? 'Open Live Marketplace')),
      'free_test_market_cta_url' => trim((string)($data['free_test_market_cta_url'] ?? 'index.php?option=com_leadmarket&view=leads')),
      'free_test_access_days' => (int)($data['free_test_access_days'] ?? 30),
      'free_test_welcome_email_enabled' => (int)($data['free_test_welcome_email_enabled'] ?? 1),
      'marketplace_show_freshness' => (int)($data['marketplace_show_freshness'] ?? 1),
      'marketplace_freshness_today_hours' => (int)($data['marketplace_freshness_today_hours'] ?? 24),
      'marketplace_freshness_relative_days' => (int)($data['marketplace_freshness_relative_days'] ?? 7),
      'public_home_url' => trim((string)($data['public_home_url'] ?? '/')),
      'public_how_it_works_url' => trim((string)($data['public_how_it_works_url'] ?? 'how-it-works')),
      'public_pricing_url' => trim((string)($data['public_pricing_url'] ?? 'pricing')),
      'public_faq_url' => trim((string)($data['public_faq_url'] ?? 'faq')),
      'credit_request_window_hours' => (int)($data['credit_request_window_hours'] ?? 24),
      'trc20_verify_enabled' => (int)($data['trc20_verify_enabled'] ?? 0),
      'trc20_amount_tolerance' => trim((string)($data['trc20_amount_tolerance'] ?? '0.01')),
      'trc20_verify_api_base' => trim((string)($data['trc20_verify_api_base'] ?? 'https://apilist.tronscanapi.com/api/transfer/trc20')),
      'trc20_token_contract' => trim((string)($data['trc20_token_contract'] ?? 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t')),
      'trc20_verify_api_key' => trim((string)($data['trc20_verify_api_key'] ?? '')),
      'trc20_time_window_before_minutes' => (int)($data['trc20_time_window_before_minutes'] ?? 20),
      'trc20_time_window_after_minutes' => (int)($data['trc20_time_window_after_minutes'] ?? 180),
      'trc20_verify_limit' => (int)($data['trc20_verify_limit'] ?? 50),
      'auto_confirm_matched_payment' => (int)($data['auto_confirm_matched_payment'] ?? 0),
      'enable_order_event_log' => (int)($data['enable_order_event_log'] ?? 1),
      'background_verify_enabled' => (int)($data['background_verify_enabled'] ?? 0),
      'background_verify_secret' => trim((string)($data['background_verify_secret'] ?? '')),
      'background_verify_interval_minutes' => (int)($data['background_verify_interval_minutes'] ?? 5),
      'background_verify_batch_limit' => (int)($data['background_verify_batch_limit'] ?? 25),
      'background_verify_include_expired_late' => (int)($data['background_verify_include_expired_late'] ?? 0),
      'background_verify_retry_limit' => (int)($data['background_verify_retry_limit'] ?? 50),
      'background_verify_retry_delay_minutes' => (int)($data['background_verify_retry_delay_minutes'] ?? 5),
      'checking_timeout_minutes' => (int)($data['checking_timeout_minutes'] ?? 60),
      'late_checking_timeout_minutes' => (int)($data['late_checking_timeout_minutes'] ?? 180),
      'amount_reuse_quarantine_minutes' => (int)($data['amount_reuse_quarantine_minutes'] ?? 1440),
      'amount_reuse_short_minutes' => (int)($data['amount_reuse_short_minutes'] ?? 1440),
      'amount_reuse_paid_minutes' => (int)($data['amount_reuse_paid_minutes'] ?? 4320),
      'amount_overflow_max_extra' => (int)($data['amount_overflow_max_extra'] ?? 5),
      'auto_shared_max_sales' => (int)($data['auto_shared_max_sales'] ?? 3),
      'home_shared_max_sales' => (int)($data['home_shared_max_sales'] ?? 2),
      'post_exclusive_shared_slots' => (int)($data['post_exclusive_shared_slots'] ?? 1),
      'exclusive_buyer_block_text' => trim((string)($data['exclusive_buyer_block_text'] ?? 'Exclusive protected first-contact access for {{hours}} hours|You receive the first protected contact window for this {{type_label}}. {{distribution_note}}')),
      'exclusive_buyer_notice_text' => trim((string)($data['exclusive_buyer_notice_text'] ?? 'Checkout: Protected first-contact access|You are purchasing a protected first-contact window for {{hours}} hours on this {{type_label}}. {{distribution_note}}')),
      'premium_multiplier' => trim((string)($data['premium_multiplier'] ?? '1.20')),
      'standard_multiplier' => trim((string)($data['standard_multiplier'] ?? '1.00')),
      'premium_states_csv' => trim((string)($data['premium_states_csv'] ?? 'CA,TX,FL,NY,NJ,PA,IL,OH,GA,NC,MI,VA,WA,MA,AZ,TN,IN,MO,MD,CO,MN,WI,CT,OR,SC')),
      'auto_shared_base' => trim((string)($data['auto_shared_base'] ?? '15')),
      'auto_exclusive_base' => trim((string)($data['auto_exclusive_base'] ?? '35')),
      'home_shared_base' => trim((string)($data['home_shared_base'] ?? '25')),
      'home_exclusive_base' => trim((string)($data['home_exclusive_base'] ?? '55')),
      'age_coef_0_1h' => trim((string)($data['age_coef_0_1h'] ?? '1.00')),
      'age_coef_1_3h' => trim((string)($data['age_coef_1_3h'] ?? '0.80')),
      'age_coef_3_12h' => trim((string)($data['age_coef_3_12h'] ?? '0.60')),
      'age_coef_12p_h' => trim((string)($data['age_coef_12p_h'] ?? '0.40')),
      'fresh_max_hours' => (int)($data['fresh_max_hours'] ?? 12),
      'aged_auto_max_hours' => (int)($data['aged_auto_max_hours'] ?? 24),
      'aged_home_max_hours' => (int)($data['aged_home_max_hours'] ?? 48),
      'show_archived_unsold_in_market' => (int)($data['show_archived_unsold_in_market'] ?? 1),
      'show_archived_sold_in_market' => (int)($data['show_archived_sold_in_market'] ?? 0),
      'archived_unsold_price_coef' => trim((string)($data['archived_unsold_price_coef'] ?? '0.45')),
      'archived_sold_price_coef' => trim((string)($data['archived_sold_price_coef'] ?? '0.25')),
      'cooldown_minutes'   => (int)($data['cooldown_minutes'] ?? 5),
      'minimum_topup_usd' => trim((string)($data['minimum_topup_usd'] ?? '10')),
      'topup_presets' => trim((string)($data['topup_presets'] ?? '10,50,100')),
      'topup_allow_custom' => (int)($data['topup_allow_custom'] ?? 1),
      'topup_custom_min' => trim((string)($data['topup_custom_min'] ?? '10')),
      'topup_default_preset' => trim((string)($data['topup_default_preset'] ?? '10')),
      'topup_auto_apply_on_paid' => (int)($data['topup_auto_apply_on_paid'] ?? 0),
      'wallet_allow_partial_usage' => (int)($data['wallet_allow_partial_usage'] ?? 1),
      'wallet_allow_direct_when_insufficient' => (int)($data['wallet_allow_direct_when_insufficient'] ?? 0),
      'paypal_enabled' => (int)($data['paypal_enabled'] ?? 0),
      'paypal_client_id' => trim((string)($data['paypal_client_id'] ?? '')),
      'paypal_client_secret' => trim((string)($data['paypal_client_secret'] ?? '')),
      'paypal_webhook_id' => trim((string)($data['paypal_webhook_id'] ?? '')),
      'moneygram_enabled' => (int)($data['moneygram_enabled'] ?? 1),
      'moneygram_min_amount_usd' => trim((string)($data['moneygram_min_amount_usd'] ?? '100')),
      'moneygram_receiver_name' => trim((string)($data['moneygram_receiver_name'] ?? '')),
      'moneygram_receiver_country' => trim((string)($data['moneygram_receiver_country'] ?? 'Turkey')),
      'moneygram_instructions' => (string)($data['moneygram_instructions'] ?? ''),
      'cron_key'           => trim((string)($data['cron_key'] ?? '')),
      'instant_subject_tpl'=> (string)($data['instant_subject_tpl'] ?? 'New {{state}} {{type}} lead (UTC)'),
      'daily_subject_tpl'  => (string)($data['daily_subject_tpl'] ?? '{{state}} {{type_label}} Leads Digest: {{count}} new leads'),
      'instant_body_tpl'   => (string)($data['instant_body_tpl'] ?? ''),
      'daily_body_tpl'     => (string)($data['daily_body_tpl'] ?? ''),
      'bridge_enabled' => (int)($data['bridge_enabled'] ?? 0),
      'bridge_key_id' => trim((string)($data['bridge_key_id'] ?? 'paperclip-main')),
      'bridge_shared_secret' => trim((string)($data['bridge_shared_secret'] ?? '')),
      'bridge_allowed_ips' => trim((string)($data['bridge_allowed_ips'] ?? '')),
      'bridge_max_skew_seconds' => (int)($data['bridge_max_skew_seconds'] ?? 300),
      'bridge_read_rpm' => (int)($data['bridge_read_rpm'] ?? 60),
      'bridge_write_rpm' => (int)($data['bridge_write_rpm'] ?? 20),
      'bridge_approve_rpm' => (int)($data['bridge_approve_rpm'] ?? 10),
      'bridge_storage_path' => trim((string)($data['bridge_storage_path'] ?? 'administrator/logs/leadmarket_bridge')),
      'bridge_allow_live_site_writes' => (int)($data['bridge_allow_live_site_writes'] ?? 0),
      'bridge_live_allowed_article_ids' => trim((string)($data['bridge_live_allowed_article_ids'] ?? '')),
      'bridge_live_allowed_module_ids' => trim((string)($data['bridge_live_allowed_module_ids'] ?? '')),
      'bridge_live_allowed_component_params' => trim((string)($data['bridge_live_allowed_component_params'] ?? '')),
    );

    $db = JFactory::getDbo();
    $db->setQuery('SELECT extension_id, params FROM #__extensions WHERE element=' . $db->q('com_leadmarket') . ' AND type=' . $db->q('component'));
    $row = $db->loadObject();

    if (!$row) {
      $app->enqueueMessage('Cannot find extension row for com_leadmarket', 'error');
      $this->setRedirect('index.php?option=com_leadmarket&view=config');
      return false;
    }

    $registry = new JRegistry($row->params);
    foreach ($params as $k => $v) {
      $registry->set($k, $v);
    }

    $db->setQuery(
      $db->getQuery(true)
        ->update('#__extensions')
        ->set('params=' . $db->q($registry->toString()))
        ->where('extension_id=' . (int) $row->extension_id)
    );
    $db->execute();

    $app->enqueueMessage('Settings saved.', 'message');

    // Decide where to go depending on task
    $task = $this->getTask();
    $returnView = preg_replace('/[^a-z0-9_]/i', '', (string) $input->getCmd('return_view', 'config'));
    if ($returnView === '') $returnView = 'config';
    if ($task === 'save2close') {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads');
    } else {
      $this->setRedirect('index.php?option=com_leadmarket&view=' . $returnView);
    }

    return true;
  }

  public function apply()
  {
    return $this->save();
  }

  public function save2close()
  {
    // Map to save() with task check
    return $this->save();
  }

  public function cancel($key = null)
  {
    $this->setRedirect('index.php?option=com_leadmarket&view=leads');
    return true;
  }
}
