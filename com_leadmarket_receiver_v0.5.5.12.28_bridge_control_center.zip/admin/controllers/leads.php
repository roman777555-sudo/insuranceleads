<?php
defined('_JEXEC') or die;

class LeadMarketControllerLeads extends JControllerAdmin
{
  public function getModel($name = 'Leads', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  /**
   * Toolbar "Settings" action.
   * Redirects to the component settings page (view=config).
   */
  public function settings()
  {
    $this->setRedirect('index.php?option=com_leadmarket&view=config');
  }

  public function deleteSelected()
  {
    JSession::checkToken() or jexit('Invalid Token');

    $app = JFactory::getApplication();
    $cid = (array) $app->input->get('cid', array(), 'array');
    $ids = array();
    foreach ($cid as $id) {
      $id = (int) $id;
      if ($id > 0) $ids[] = $id;
    }
    $ids = array_values(array_unique($ids));

    if (!count($ids)) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }

    $db = JFactory::getDbo();
    $terminalStatuses = array('cancelled', 'expired', 'failed');

    $db->setQuery('SELECT id, lead_id, status FROM #__leadmarket_orders WHERE lead_id IN (' . implode(',', $ids) . ') ORDER BY id ASC');
    $orderRows = (array) $db->loadAssocList();

    $ordersByLead = array();
    foreach ($orderRows as $row) {
      $leadId = (int) ($row['lead_id'] ?? 0);
      if ($leadId <= 0) continue;
      if (!isset($ordersByLead[$leadId])) $ordersByLead[$leadId] = array();
      $ordersByLead[$leadId][] = $row;
    }

    $deletable = array();
    $skipped = array();
    $terminalOrderIds = array();
    foreach ($ids as $id) {
      $rows = isset($ordersByLead[$id]) ? $ordersByLead[$id] : array();
      if (!$rows) {
        $deletable[] = $id;
        continue;
      }
      $hasBlocking = false;
      foreach ($rows as $row) {
        $status = strtolower(trim((string) ($row['status'] ?? '')));
        if (!in_array($status, $terminalStatuses, true)) {
          $hasBlocking = true;
          break;
        }
      }
      if ($hasBlocking) {
        $skipped[] = $id;
        continue;
      }
      $deletable[] = $id;
      foreach ($rows as $row) {
        $oid = (int) ($row['id'] ?? 0);
        if ($oid > 0) $terminalOrderIds[] = $oid;
      }
    }
    $terminalOrderIds = array_values(array_unique($terminalOrderIds));

    $deletedCount = 0;
    if ($deletable) {
      try {
        $db->transactionStart();
      } catch (Exception $e) {}

      try {
        $idList = implode(',', $deletable);
        $orderIdList = $terminalOrderIds ? implode(',', $terminalOrderIds) : '';
        $db->setQuery('DELETE FROM #__leadmarket_email_log WHERE lead_id IN (' . $idList . ')')->execute();
        if ($orderIdList !== '') {
          $db->setQuery('DELETE FROM #__leadmarket_order_events WHERE order_id IN (' . $orderIdList . ') OR lead_id IN (' . $idList . ')')->execute();
          $db->setQuery('DELETE FROM #__leadmarket_credit_requests WHERE order_id IN (' . $orderIdList . ') OR lead_id IN (' . $idList . ')')->execute();
          $db->setQuery('DELETE FROM #__leadmarket_promocode_usages WHERE order_id IN (' . $orderIdList . ')')->execute();
          // Keep historical top-up records, but unlink them from deleted orders/leads where possible.
          try {
            $db->setQuery('UPDATE #__leadmarket_topups SET unlocked_order_id=0 WHERE unlocked_order_id IN (' . $orderIdList . ')')->execute();
          } catch (Exception $ignore) {}
          try {
            $db->setQuery('UPDATE #__leadmarket_topups SET target_id=0, target_type=' . $db->q('deleted_lead') . ' WHERE target_type=' . $db->q('lead') . ' AND target_id IN (' . $idList . ')')->execute();
          } catch (Exception $ignore) {}
          $db->setQuery('DELETE FROM #__leadmarket_orders WHERE id IN (' . $orderIdList . ')')->execute();
        } else {
          $db->setQuery('DELETE FROM #__leadmarket_order_events WHERE lead_id IN (' . $idList . ')')->execute();
          $db->setQuery('DELETE FROM #__leadmarket_credit_requests WHERE lead_id IN (' . $idList . ')')->execute();
        }
        $db->setQuery('DELETE FROM #__leadmarket_leads WHERE id IN (' . $idList . ')')->execute();
        $deletedCount = count($deletable);
        try {
          $db->transactionCommit();
        } catch (Exception $e) {}
      } catch (Exception $e) {
        try {
          $db->transactionRollback();
        } catch (Exception $ignore) {}
        $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Delete failed: ' . $e->getMessage(), 'error');
        return;
      }
    }

    $parts = array();
    if ($deletedCount) $parts[] = 'Deleted leads: ' . $deletedCount . '.';
    if ($skipped) $parts[] = 'Skipped leads with non-terminal orders: #' . implode(', #', $skipped) . '.';
    if (!$parts) $parts[] = 'No leads were deleted.';

    $this->setRedirect('index.php?option=com_leadmarket&view=leads', implode(' ', $parts), $skipped ? 'warning' : 'message');
  }


  public function resetTestUsage()
  {
    JSession::checkToken() or jexit('Invalid Token');

    $app = JFactory::getApplication();
    $cid = (array) $app->input->get('cid', array(), 'array');
    $ids = array();
    foreach ($cid as $id) {
      $id = (int) $id;
      if ($id > 0) $ids[] = $id;
    }
    $ids = array_values(array_unique($ids));

    if (!count($ids)) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }

    require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

    try {
      $result = LeadMarketHelper::adminResetLeadTestUsage($ids);
    } catch (Exception $e) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Lead reset failed: ' . $e->getMessage(), 'error');
      return;
    }

    $db = JFactory::getDbo();
    $db->setQuery('SELECT id, type, state, uploaded_at_utc, original_uploaded_at_utc FROM #__leadmarket_leads WHERE id IN (' . implode(',', $ids) . ')');
    $rows = (array) $db->loadAssocList();
    if (!$rows) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Selected leads were not found after reset.', 'warning');
      return;
    }

    $restored = 0;
    $listedNow = 0;
    $archivedNow = 0;
    foreach ($rows as $row) {
      $type = strtolower(trim((string) ($row['type'] ?? ''))) ?: 'auto';
      $state = strtoupper(trim((string) ($row['state'] ?? '')));
      $timeRef = trim((string) ($row['original_uploaded_at_utc'] ?? ''));
      if ($timeRef === '') $timeRef = trim((string) ($row['uploaded_at_utc'] ?? ''));
      if ($timeRef === '') $timeRef = gmdate('Y-m-d H:i:s');
      $leadStatus = LeadMarketHelper::leadStatus($type, $timeRef);
      $freshnessCoef = LeadMarketHelper::freshnessCoef($timeRef);
      $priceUsd = LeadMarketHelper::calcPriceUsd($type, 'shared', $state, $timeRef);
      $q = $db->getQuery(true)
        ->update('#__leadmarket_leads')
        ->set('uploaded_at_utc=' . $db->q($timeRef))
        ->set('reserve_until_utc=NULL')
        ->set('lead_status=' . $db->q($leadStatus))
        ->set('freshness_coef=' . $db->q(number_format($freshnessCoef, 2, '.', '')))
        ->set('price_usd=' . $db->q(number_format($priceUsd, 2, '.', '')))
        ->where('id=' . (int) $row['id']);
      $db->setQuery($q)->execute();
      LeadMarketHelper::logLeadAdminEvent((int) $row['id'], 'lead_reset_restored', 'Lead reset and restored to original market arrival.', array('restored_uploaded_at_utc' => $timeRef, 'lead_status' => $leadStatus));
      if (in_array($leadStatus, array('fresh', 'aged'), true)) $listedNow++;
      if ($leadStatus === 'archived') $archivedNow++;
      $restored++;
    }

    $parts = array();
    $parts[] = 'Leads restored: ' . (int) ($result['leads_reset'] ?? 0) . '.';
    if (!empty($result['orders_voided'])) $parts[] = 'Orders voided: ' . (int) $result['orders_voided'] . '.';
    if (!empty($result['batches_voided'])) $parts[] = 'Batches voided: ' . (int) $result['batches_voided'] . '.';
    if (!empty($result['topups_voided'])) $parts[] = 'Top-ups voided: ' . (int) $result['topups_voided'] . '.';
    if (!empty($result['buyer_count'])) $parts[] = 'Buyer histories preserved for ' . (int) $result['buyer_count'] . ' buyer(s).';
    $parts[] = 'Original market arrival restored: ' . $restored . '.';
    $parts[] = 'In market now: ' . $listedNow . '. Archived by age: ' . $archivedNow . '.';
    $parts[] = 'Use Refresh Arrival Date separately only when you want to move restored leads higher in the marketplace.';

    $this->setRedirect('index.php?option=com_leadmarket&view=leads', implode(' ', $parts));
  }


  public function resetAndRefreshSelected()
  {
    // Keep this task as a backwards-compatible alias.
    $this->resetTestUsage();
  }

  public function refreshSelected()
  {
    JSession::checkToken() or jexit('Invalid Token');

    $app = JFactory::getApplication();
    $cid = (array) $app->input->get('cid', array(), 'array');
    $ids = array();
    foreach ($cid as $id) {
      $id = (int) $id;
      if ($id > 0) $ids[] = $id;
    }
    $ids = array_values(array_unique($ids));

    if (!count($ids)) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }

    require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

    $db = JFactory::getDbo();
    $db->setQuery('SELECT id, type, state, uploaded_at_utc, original_uploaded_at_utc FROM #__leadmarket_leads WHERE id IN (' . implode(',', $ids) . ')');
    $rows = (array) $db->loadAssocList();
    if (!$rows) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Selected leads were not found.', 'warning');
      return;
    }

    $params = LeadMarketHelper::params();
    $reserveMinutes = max(1, (int) $params->get('reserve_minutes', 30));
    $now = LeadMarketHelper::nowUtc();
    $reserveUntil = clone $now;
    $reserveUntil->modify('+' . $reserveMinutes . ' minutes');
    $nowSql = $db->q($now->format('Y-m-d H:i:s'));
    $reserveSql = $db->q($reserveUntil->format('Y-m-d H:i:s'));

    $updated = 0;
    $freshNow = 0;
    foreach ($rows as $row) {
      $type = strtolower(trim((string) $row['type'])) ?: 'auto';
      $state = strtoupper(trim((string) $row['state']));
      $leadStatus = LeadMarketHelper::leadStatus($type, $now);
      $freshnessCoef = LeadMarketHelper::freshnessCoef($now);
      $priceUsd = LeadMarketHelper::calcPriceUsd($type, 'shared', $state, $now);
      $q = $db->getQuery(true)
        ->update('#__leadmarket_leads')
        ->set('uploaded_at_utc=' . $nowSql)
        ->set('reserve_until_utc=' . $reserveSql)
        ->set('lead_status=' . $db->q($leadStatus))
        ->set('freshness_coef=' . $db->q(number_format($freshnessCoef, 2, '.', '')))
        ->set('price_usd=' . $db->q(number_format($priceUsd, 2, '.', '')))
        ->where('id=' . (int) $row['id']);
      $db->setQuery($q)->execute();
      LeadMarketHelper::logLeadAdminEvent((int) $row['id'], 'lead_arrival_refreshed', 'Lead arrival refreshed to market top.', array('refreshed_uploaded_at_utc' => $now->format('Y-m-d H:i:s'), 'reserve_until_utc' => $reserveUntil->format('Y-m-d H:i:s')));
      if ($leadStatus === 'fresh') $freshNow++;
      $updated++;
    }

    $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Refreshed arrival date for leads: ' . $updated . '. Fresh in market now: ' . $freshNow . '.');
  }


  protected function getSelectedLeadIds()
  {
    $cid = (array) JFactory::getApplication()->input->get('cid', array(), 'array');
    $ids = array();
    foreach ($cid as $id) {
      $id = (int) $id;
      if ($id > 0) $ids[] = $id;
    }
    return array_values(array_unique($ids));
  }

  protected function applyFreeTestFlagToIds($ids, $clear = false)
  {
    if (!$ids) return 0;
    $db = JFactory::getDbo();
    $sets = array();
    if ($clear) {
      $sets[] = 'is_free_test=0';
      $sets[] = 'free_test_active=0';
    } else {
      $sets[] = 'is_free_test=1';
      $sets[] = 'free_test_active=1';
      $sets[] = 'free_test_updated_at=' . $db->q(gmdate('Y-m-d H:i:s'));
    }
    $db->setQuery('UPDATE #__leadmarket_leads SET ' . implode(',', $sets) . ' WHERE id IN (' . implode(',', array_map('intval', $ids)) . ')');
    $db->execute();
    return count($ids);
  }

  public function markFreeTest()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $ids = $this->getSelectedLeadIds();
    if (!$ids) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }
    $count = $this->applyFreeTestFlagToIds($ids, false);
    $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Marked free test leads: ' . (int) $count . '.');
  }

  public function clearFreeTest()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $ids = $this->getSelectedLeadIds();
    if (!$ids) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }
    $count = $this->applyFreeTestFlagToIds($ids, true);
    $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Cleared free test flag on leads: ' . (int) $count . '.');
  }

  protected function applySampleFlagToIds($ids, $sampleType = '', $clear = false)
  {
    if (!$ids) return 0;
    $db = JFactory::getDbo();
    $sets = array();
    if ($clear) {
      $sets[] = 'is_sample=0';
      $sets[] = 'sample_active=0';
      $sets[] = 'sample_type=' . $db->q('');
    } else {
      $sets[] = 'is_sample=1';
      $sets[] = 'sample_active=1';
      $sets[] = 'sample_type=' . $db->q($sampleType);
      $sets[] = 'sample_updated_at=' . $db->q(gmdate('Y-m-d H:i:s'));
    }
    $db->setQuery('UPDATE #__leadmarket_leads SET ' . implode(',', $sets) . ' WHERE id IN (' . implode(',', array_map('intval', $ids)) . ')');
    $db->execute();
    return count($ids);
  }

  public function markSampleAuto()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $ids = $this->getSelectedLeadIds();
    if (!$ids) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }
    $count = $this->applySampleFlagToIds($ids, 'auto', false);
    $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Marked sample auto leads: ' . (int) $count . '.');
  }

  public function markSampleHome()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $ids = $this->getSelectedLeadIds();
    if (!$ids) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }
    $count = $this->applySampleFlagToIds($ids, 'home', false);
    $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Marked sample home leads: ' . (int) $count . '.');
  }

  public function clearSample()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $ids = $this->getSelectedLeadIds();
    if (!$ids) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'No leads selected.', 'warning');
      return;
    }
    $count = $this->applySampleFlagToIds($ids, '', true);
    $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Cleared sample flag on leads: ' . (int) $count . '.');
  }

  public function sampleSettings()
  {
    $id = (int) JFactory::getApplication()->input->getInt('id', 0);
    if ($id <= 0) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Lead not found.', 'error');
      return;
    }

    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_leads WHERE id=' . (int) $id);
    $lead = $db->loadAssoc();
    if (!$lead) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Lead not found.', 'error');
      return;
    }

    $token = JSession::getFormToken();
    $disclaimer = trim((string) ($lead['sample_disclaimer'] ?? ''));
    if ($disclaimer === '') $disclaimer = LeadMarketHelper::getDefaultSampleDisclaimer();

    header('Content-Type: text/html; charset=utf-8');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Sample Lead Settings</title><style>body{margin:0;background:#f6f9fc;font-family:Arial,sans-serif;color:#13232f}.wrap{max-width:860px;margin:24px auto;padding:0 16px}.card{background:#fff;border:1px solid #dbe6ef;border-radius:18px;padding:24px;box-shadow:0 14px 32px rgba(16,54,82,.08)}label{display:block;margin:14px 0 6px;font-weight:700;color:#22313b}input[type=text],input[type=email],select,textarea{display:block;width:100%;min-height:46px;padding:10px 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box}textarea{min-height:120px}.btns{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 18px;border-radius:12px;text-decoration:none;font-weight:700;border:1px solid transparent;cursor:pointer}.btnp{background:#0c5585;color:#fff}.btns2{background:#fff;color:#0c5585;border-color:#cfd9e3}.muted{color:#61717f;line-height:1.6}</style></head><body><div class="wrap"><div class="card">';
    echo '<h1 style="margin:0 0 10px;color:#0c5585">Sample Lead Settings</h1>';
    echo '<p class="muted">Lead #' . (int) $lead['id'] . ' · ' . htmlspecialchars(strtoupper((string) ($lead['type'] ?? 'AUTO')) . ' · ' . strtoupper((string) ($lead['state'] ?? '')), ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<form action="index.php?option=com_leadmarket&task=leads.saveSampleSettings" method="post">';
    echo '<input type="hidden" name="id" value="' . (int) $lead['id'] . '"><input type="hidden" name="' . $token . '" value="1">';
    echo '<label><input type="checkbox" name="is_sample" value="1"' . (!empty($lead['is_sample']) ? ' checked' : '') . '> Use as Sample Lead</label>';
    echo '<label><input type="checkbox" name="sample_active" value="1"' . (!empty($lead['sample_active']) ? ' checked' : '') . '> Sample Active</label>';
    echo '<label for="sample_type">Sample Type</label><select name="sample_type" id="sample_type"><option value="auto"' . (((string)($lead['sample_type'] ?: $lead['type']) === 'auto') ? ' selected' : '') . '>Auto</option><option value="home"' . (((string)($lead['sample_type'] ?: $lead['type']) === 'home') ? ' selected' : '') . '>Home</option></select>';
    echo '<label for="sample_name">Sample Name</label><input type="text" name="sample_name" id="sample_name" value="' . htmlspecialchars((string) ($lead['sample_name'] ?? ''), ENT_QUOTES, 'UTF-8') . '">';
    echo '<label for="sample_email">Sample Email</label><input type="email" name="sample_email" id="sample_email" value="' . htmlspecialchars((string) ($lead['sample_email'] ?? ''), ENT_QUOTES, 'UTF-8') . '">';
    echo '<label for="sample_phone">Sample Phone</label><input type="text" name="sample_phone" id="sample_phone" value="' . htmlspecialchars((string) ($lead['sample_phone'] ?? ''), ENT_QUOTES, 'UTF-8') . '">';
    echo '<label for="sample_sort">Sample Sort Order</label><input type="text" name="sample_sort" id="sample_sort" value="' . (int) ($lead['sample_sort'] ?? 0) . '">';
    echo '<label for="sample_disclaimer">Sample Disclaimer</label><textarea name="sample_disclaimer" id="sample_disclaimer">' . htmlspecialchars($disclaimer, ENT_QUOTES, 'UTF-8') . '</textarea>';
    echo '<div class="btns"><button class="btn btnp" type="submit">Save Sample Settings</button><a class="btn btns2" href="index.php?option=com_leadmarket&view=leads">Back to Leads</a></div></form></div></div></body></html>';
    JFactory::getApplication()->close();
  }

  public function saveSampleSettings()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $input = $app->input;
    $id = (int) $input->getInt('id', 0);
    if ($id <= 0) {
      $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Lead not found.', 'error');
      return;
    }
    $db = JFactory::getDbo();
    $sampleType = strtolower(trim((string) $input->getCmd('sample_type', '')));
    if (!in_array($sampleType, array('auto','home'), true)) $sampleType = 'auto';
    $fields = array(
      'is_sample=' . ((int) $input->getInt('is_sample', 0) === 1 ? 1 : 0),
      'sample_active=' . ((int) $input->getInt('sample_active', 0) === 1 ? 1 : 0),
      'sample_type=' . $db->q($sampleType),
      'sample_sort=' . (int) $input->getInt('sample_sort', 0),
      'sample_name=' . $db->q(trim((string) $input->getString('sample_name', ''))),
      'sample_email=' . $db->q(trim((string) $input->getString('sample_email', ''))),
      'sample_phone=' . $db->q(trim((string) $input->getString('sample_phone', ''))),
      'sample_disclaimer=' . $db->q(trim((string) $input->get('sample_disclaimer', '', 'raw'))),
      'sample_updated_at=' . $db->q(gmdate('Y-m-d H:i:s'))
    );
    $db->setQuery('UPDATE #__leadmarket_leads SET ' . implode(',', $fields) . ' WHERE id=' . (int) $id);
    $db->execute();
    $this->setRedirect('index.php?option=com_leadmarket&view=leads', 'Sample settings saved.');
  }

}
