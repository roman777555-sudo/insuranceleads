<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerOrders extends JControllerAdmin
{
  public function __construct($config = array())
  {
    parent::__construct($config);
    LeadMarketHelper::ensureSchema();
    $this->registerTask('markpaid', 'markPaid');
    $this->registerTask('markfailed', 'markFailed');
    $this->registerTask('verifyselected', 'verify');
    $this->registerTask('confirmselected', 'confirm');
    $this->registerTask('resendunlock', 'resendUnlock');
    $this->registerTask('runbackground', 'runBackground');
  }

  public function getModel($name = 'Orders', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  protected function getSelectedIds()
  {
    $app = JFactory::getApplication();
    $cid = (array) $app->input->get('cid', array(), 'array');
    if (!count($cid)) {
      $singleId = (int) $app->input->getInt('id', 0);
      if ($singleId > 0) $cid = array($singleId);
    }
    JArrayHelper::toInteger($cid);
    return array_values(array_filter($cid));
  }

  protected function validateRequest()
  {
    if (!JSession::checkToken() && !JSession::checkToken('get')) jexit('Invalid Token');
    LeadMarketHelper::cleanupExpiredOrders();
  }

  protected function loadOrder($id)
  {
    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_orders WHERE id=' . (int) $id);
    return $db->loadAssoc();
  }

  protected function loadLead($leadId)
  {
    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_leads WHERE id=' . (int) $leadId);
    return $db->loadAssoc();
  }

  public function markPaid()
  {
    $this->validateRequest();
    $app = JFactory::getApplication();
    $ids = $this->getSelectedIds();
    if (!$ids) {
      $app->enqueueMessage('No orders selected.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
      return false;
    }
    $updated = 0;
    foreach ($ids as $id) {
      $order = $this->loadOrder($id);
      if (!$order) continue;
      $lead = $this->loadLead($order['lead_id']);
      if (!$lead) continue;
      LeadMarketHelper::confirmPaid($order, $lead, 'admin', 'Mark Paid', array('mode'=>'manual_fallback'));
      $updated++;
    }
    $app->enqueueMessage($updated ? 'Order status updated.' : 'No orders were updated.', $updated ? 'message' : 'warning');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
    return true;
  }

  public function markFailed() { return $this->setSimpleStatus('failed', 'failed_at_utc', 'Order marked failed.', 'order_failed'); }
  public function cancel() { return $this->setSimpleStatus('cancelled', 'cancelled_at_utc', 'Order cancelled.', 'order_cancelled'); }

  protected function setSimpleStatus($target, $timeField, $message, $eventType)
  {
    $this->validateRequest();
    $app = JFactory::getApplication();
    $ids = $this->getSelectedIds();
    if (!$ids) {
      $app->enqueueMessage('No orders selected.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
      return false;
    }
    $db = JFactory::getDbo();
    $now = gmdate('Y-m-d H:i:s');
    $updated = 0;
    foreach ($ids as $id) {
      $order = $this->loadOrder($id);
      if (!$order) continue;
      $q = $db->getQuery(true)->update('#__leadmarket_orders')->set('status=' . $db->q($target))->set($timeField . '=' . $db->q($now))->where('id=' . (int)$id);
      $db->setQuery($q)->execute();
      LeadMarketHelper::logOrderEvent((int)$id, (int)$order['lead_id'], $eventType, $message, array(), 'admin', ucfirst($target));
      if (in_array($target, array('cancelled','failed'), true)) {
        LeadMarketHelper::logOrderEvent((int)$id, (int)$order['lead_id'], 'hold_released', 'Reservation hold released after ' . $target . '.', array(), 'system', 'orders');
      }
      $updated++;
    }
    $app->enqueueMessage($updated ? 'Order status updated.' : 'No orders were updated.', $updated ? 'message' : 'warning');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
    return true;
  }

  public function verify()
  {
    $this->validateRequest();
    $app = JFactory::getApplication();
    $ids = $this->getSelectedIds();
    if (!$ids) {
      $app->enqueueMessage('No orders selected.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
      return false;
    }
    $messages = array();
    $okCount = 0;
    foreach ($ids as $id) {
      $order = $this->loadOrder($id);
      if (!$order) continue;
      $result = LeadMarketHelper::verifyOrderPayment($order);
      if (!empty($result['ok'])) $okCount++;
      $messages[] = 'Order #' . (int)$id . ': ' . $result['message'];
    }
    $app->enqueueMessage(implode(' | ', $messages), $okCount ? 'message' : 'warning');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
    return true;
  }

  public function confirm()
  {
    $this->validateRequest();
    $app = JFactory::getApplication();
    $ids = $this->getSelectedIds();
    if (!$ids) {
      $app->enqueueMessage('No orders selected.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
      return false;
    }
    $updated = 0;
    $reasons = array();
    foreach ($ids as $id) {
      $order = $this->loadOrder($id);
      if (!$order) continue;
      $status = strtolower((string)$order['status']);
      $paymentStatus = strtolower((string)$order['payment_status']);
      if ($status === 'paid') {
        $reasons[] = 'Order #' . (int)$id . ' is already paid.';
        continue;
      }
      if (!in_array($paymentStatus, array('matched','late_matched'), true)) {
        $reasons[] = 'Order #' . (int)$id . ' is not ready to confirm. Payment status: ' . ($paymentStatus !== '' ? $paymentStatus : 'unverified') . '.';
        continue;
      }
      $lead = $this->loadLead($order['lead_id']);
      if (!$lead) {
        $reasons[] = 'Order #' . (int)$id . ' lead not found.';
        continue;
      }
      if ($paymentStatus === 'late_matched' && !LeadMarketHelper::canApproveLatePayment($order, $lead)) {
        $db = JFactory::getDbo();
        $q = $db->getQuery(true)->update('#__leadmarket_orders')->set('payment_status=' . $db->q('late_no_slots'))->set('verify_note=' . $db->q('Late payment detected, but no slots remain. Refund required.'))->where('id=' . (int)$id);
        $db->setQuery($q)->execute();
        LeadMarketHelper::logOrderEvent((int)$id, (int)$order['lead_id'], 'late_payment_no_slots', 'Late payment could not be approved because no slots remain.', array(), 'admin', 'Confirm Payment');
        $reasons[] = 'Order #' . (int)$id . ' late payment found, but no slots remain. Refund required.';
        continue;
      }
      LeadMarketHelper::confirmPaid($order, $lead, 'admin', $paymentStatus === 'late_matched' ? 'Approve Late Payment' : 'Confirm Payment', array('mode'=>$paymentStatus === 'late_matched' ? 'approve_late_payment' : 'confirm','tx_hash'=>(string)$order['tx_hash']));
      $updated++;
    }
    if ($updated) {
      $app->enqueueMessage('Matched payments confirmed: ' . (int)$updated . '.', 'message');
    }
    if ($reasons) {
      $app->enqueueMessage(implode(' | ', $reasons), $updated ? 'warning' : 'warning');
    }
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
    return true;
  }


  public function runBackground()
  {
    $this->validateRequest();
    $app = JFactory::getApplication();
    $summary = LeadMarketHelper::runBackgroundVerify(null, 'admin-manual');
    $msg = 'Background verify finished. Scanned: ' . (int)$summary['scanned']
      . ', matched: ' . (int)$summary['matched']
      . ', auto-confirmed: ' . (int)$summary['auto_confirmed']
      . ', late matched: ' . (int)$summary['late_matched']
      . ', late no-slots: ' . (int)$summary['late_no_slots']
      . ', mismatches: ' . (int)$summary['mismatch']
      . ', checking: ' . (int)$summary['checking']
      . ', errors: ' . (int)$summary['errors'] . '.';
    $app->enqueueMessage($msg, 'message');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
    return true;
  }

  public function resendUnlock()
  {
    $this->validateRequest();
    $app = JFactory::getApplication();
    $ids = $this->getSelectedIds();
    if (!$ids) {
      $app->enqueueMessage('No orders selected.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
      return false;
    }
    $sent = 0;
    foreach ($ids as $id) {
      if (LeadMarketHelper::resendUnlockEmailByOrderId((int)$id, 'admin', 'Resend Unlock Email')) $sent++;
    }
    $app->enqueueMessage($sent ? 'Unlock email resent.' : 'No paid orders were resent.', $sent ? 'message' : 'warning');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=orders', false));
    return true;
  }
}
