<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerTopups extends JControllerAdmin
{
  public function __construct($config = array())
  {
    parent::__construct($config);
    LeadMarketHelper::ensureSchema();
    $this->registerTask('markpaid', 'markpaid');
    $this->registerTask('cancel', 'cancel');
  }

  public function getModel($name = 'Topups', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  public function markpaid()
  {
    if (!JSession::checkToken() && !JSession::checkToken('get')) jexit('Invalid Token');
    $app = JFactory::getApplication();
    $id = $app->input->getInt('id', 0);
    $result = LeadMarketHelper::markTopupPaid($id, JFactory::getUser()->username, array('actor_type' => 'admin'));
    if (!empty($result['ok'])) {
      $topup = LeadMarketHelper::loadTopupById($id);
      if ($topup) LeadMarketHelper::trackEvent('topup_paid', array('page_name' => 'admin_topups', 'buyer_email' => (string) ($topup['buyer_email'] ?? ''), 'topup_id' => $id, 'lead_id' => ((string) ($topup['target_type'] ?? '') === 'lead') ? (int) ($topup['target_id'] ?? 0) : 0, 'batch_id' => ((string) ($topup['target_type'] ?? '') === 'batch') ? (int) ($topup['target_id'] ?? 0) : 0, 'props' => array('method' => (string) ($topup['payment_method'] ?? ''))));
    }
    $app->enqueueMessage((string) ($result['message'] ?? 'Done'), !empty($result['ok']) ? 'message' : 'error');
    $returnView = preg_replace('/[^a-z0-9_]/i', '', (string) $app->input->getCmd('return_view', 'topups'));
    if ($returnView === '') $returnView = 'topups';
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=' . $returnView, false));
    return !empty($result['ok']);
  }

  public function cancel()
  {
    if (!JSession::checkToken() && !JSession::checkToken('get')) jexit('Invalid Token');
    $app = JFactory::getApplication();
    $id = $app->input->getInt('id', 0);
    $result = LeadMarketHelper::markTopupCancelled($id, JFactory::getUser()->username, array('actor_type' => 'admin'));
    if (!empty($result['ok'])) {
      $topup = LeadMarketHelper::loadTopupById($id);
      if ($topup) LeadMarketHelper::trackEvent('topup_cancelled', array('page_name' => 'admin_topups', 'buyer_email' => (string) ($topup['buyer_email'] ?? ''), 'topup_id' => $id, 'props' => array('method' => (string) ($topup['payment_method'] ?? ''))));
    }
    $app->enqueueMessage((string) ($result['message'] ?? 'Done'), !empty($result['ok']) ? 'message' : 'error');
    $returnView = preg_replace('/[^a-z0-9_]/i', '', (string) $app->input->getCmd('return_view', 'topups'));
    if ($returnView === '') $returnView = 'topups';
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=' . $returnView, false));
    return !empty($result['ok']);
  }
}
