<?php
defined('_JEXEC') or die;

class LeadMarketControllerSubscribers extends JControllerAdmin
{
  public function getModel($name = 'Subscribers', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  public function delete()
  {
    $app = JFactory::getApplication();
    $cid = (array) $app->input->get('cid', array(), 'array');
    JSession::checkToken() or jexit('Invalid Token');

    $ids = array();
    foreach ($cid as $id) {
      $id = (int)$id;
      if ($id) $ids[] = $id;
    }
    if (!count($ids)) {
      $this->setRedirect('index.php?option=com_leadmarket&view=subscribers', 'No items selected.', 'warning');
      return;
    }

    $db = JFactory::getDbo();
    $db->setQuery('DELETE FROM #__leadmarket_subscriber_lists WHERE subscriber_id IN (' . implode(',', $ids) . ')')->execute();
    $db->setQuery('DELETE FROM #__leadmarket_subscribers WHERE id IN (' . implode(',', $ids) . ')')->execute();

    $this->setRedirect('index.php?option=com_leadmarket&view=subscribers', 'Deleted: ' . count($ids));
  }
}
