<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerPromocodes extends JControllerAdmin
{
  public function __construct($config = array())
  {
    parent::__construct($config);
    LeadMarketHelper::ensureSchema();
    $this->registerTask('save', 'save');
    $this->registerTask('delete', 'delete');
  }

  public function getModel($name = 'Promocodes', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  public function save()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $data = array(
      'id' => (int) $app->input->post->getInt('id', 0),
      'code' => (string) $app->input->post->getString('code', ''),
      'title' => (string) $app->input->post->getString('title', ''),
      'note' => (string) $app->input->post->getString('note', ''),
      'is_active' => (int) $app->input->post->getInt('is_active', 0),
      'discount_type' => (string) $app->input->post->getCmd('discount_type', 'fixed'),
      'discount_value' => (string) $app->input->post->getString('discount_value', '0'),
      'max_discount_amount' => (string) $app->input->post->getString('max_discount_amount', ''),
      'min_order_amount' => (string) $app->input->post->getString('min_order_amount', '0'),
      'usage_mode' => (string) $app->input->post->getCmd('usage_mode', 'multi_use'),
      'max_total_uses' => (string) $app->input->post->getString('max_total_uses', ''),
      'max_uses_per_buyer' => (string) $app->input->post->getString('max_uses_per_buyer', ''),
      'applies_checkout_type' => (string) $app->input->post->getCmd('applies_checkout_type', 'both'),
      'applies_lead_type' => (string) $app->input->post->getCmd('applies_lead_type', 'both'),
      'starts_at' => (string) $app->input->post->getString('starts_at', ''),
      'ends_at' => (string) $app->input->post->getString('ends_at', ''),
    );
    $result = LeadMarketHelper::savePromoCodeRecord($data);
    $app->enqueueMessage((string) ($result['message'] ?? 'Done.'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=promocodes', false));
    return !empty($result['ok']);
  }

  public function delete()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $id = (int) $app->input->post->getInt('id', 0);
    $result = LeadMarketHelper::deletePromoCodeRecord($id);
    $app->enqueueMessage((string) ($result['message'] ?? 'Done.'), !empty($result['ok']) ? 'message' : 'error');
    $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=promocodes', false));
    return !empty($result['ok']);
  }
}
