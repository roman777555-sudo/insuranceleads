<?php
defined('_JEXEC') or die;

class LeadMarketControllerLists extends JControllerAdmin
{
  public function getModel($name = 'Lists', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }
}
