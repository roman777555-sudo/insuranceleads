<?php
defined('_JEXEC') or die;

require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerApi extends JControllerLegacy
{
  public function version()
  {
    echo 'LM_VER_5_5_4';
    JFactory::getApplication()->close();
  }

  private function readPayload()
  {
    $input = JFactory::getApplication()->input;

    // Accept payload via POST (form)
    $payloadB64 = $input->post->get('payload_b64', '', 'raw');
    if ($payloadB64) {
      $raw = base64_decode($payloadB64, true);
      return array('raw' => $raw, 'via' => 'payload_b64');
    }

    $itemB64 = $input->post->get('item_b64', '', 'raw');
    if ($itemB64) {
      $raw = base64_decode($itemB64, true);
      return array('raw' => $raw, 'via' => 'item_b64');
    }

    $item = $input->post->get('item', '', 'raw');
    if ($item) {
      return array('raw' => $item, 'via' => 'item');
    }

    // JSON body fallback
    $body = file_get_contents('php://input');
    if ($body) {
      $j = json_decode($body, true);
      if (is_array($j)) {
        foreach (array('payload_b64','item_b64','data_b64') as $k) {
          if (!empty($j[$k])) {
            $raw = base64_decode($j[$k], true);
            return array('raw' => $raw, 'via' => 'json:' . $k);
          }
        }
      }
    }

    return array('raw' => '', 'via' => 'none');
  }

  public function receive()
  {
    // Important: output must be EXACT for QAI: 'uploaded'
    $app = JFactory::getApplication();
    $input = $app->input;

    try { LeadMarketHelper::ensureSchema(); } catch (Exception $e) {}

    $payload = $this->readPayload();
    if (empty($payload['raw'])) {
      echo 'LM_ERR_EMPTY_PAYLOAD';
      $app->close();
    }

    $obj = @unserialize($payload['raw']);
    if ($obj === false || !is_object($obj)) {
      // Still store raw for debugging
      $obj = null;
    }

    $type = 'auto';
    $state = '';
    $city = '';
    $zip = '';
    $name = '';
    $phone = '';
    $email = '';
    $occupation = '';
    $sourceLeadId = null;

    $normalizedIncoming = LeadMarketHelper::normalizeIncomingPayload($payload['raw'], $obj);
    if (is_array($normalizedIncoming) && !empty($normalizedIncoming)) {
      if (!empty($normalizedIncoming['type'])) $type = strtolower((string)$normalizedIncoming['type']);
      if (!empty($normalizedIncoming['state'])) $state = strtoupper((string)$normalizedIncoming['state']);
      if (!empty($normalizedIncoming['city'])) $city = (string)$normalizedIncoming['city'];
      if (!empty($normalizedIncoming['zip'])) $zip = (string)$normalizedIncoming['zip'];
      if (!empty($normalizedIncoming['name'])) $name = (string)$normalizedIncoming['name'];
      if (!empty($normalizedIncoming['phone'])) $phone = (string)$normalizedIncoming['phone'];
      if (!empty($normalizedIncoming['email'])) $email = (string)$normalizedIncoming['email'];
      if (!empty($normalizedIncoming['occupation'])) $occupation = (string)$normalizedIncoming['occupation'];
    }

    if ($obj && !empty($obj->id)) {
      $sourceLeadId = (int)$obj->id;
    }


    $leadJson = '{}';
    if ($obj) {
      $leadJson = json_encode($obj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
      if ($leadJson === false || $leadJson === null || $leadJson === '') {
        $leadJson = '{}';
      }
    }

    $created = LeadMarketHelper::nowUtc();

    $leadStatus = LeadMarketHelper::leadStatus($type, $created);
    $tierCoef = LeadMarketHelper::stateTierCoef($state);
    $freshCoef = LeadMarketHelper::freshnessCoef($created);

    $pricingMode = 'shared';
    $params = LeadMarketHelper::params();
    $maxSales = LeadMarketHelper::defaultMaxSalesShared($type);
    $postExclusiveMaxSales = max(0, (int)$params->get('post_exclusive_shared_slots', 1));
    $exclusiveHours = LeadMarketHelper::getExclusiveHoursForLead($type);

    $priceUsd = LeadMarketHelper::calcPriceUsd($type, $pricingMode, $state, $created);

    $reserveMin = (int)$params->get('reserve_minutes', 30);
    $reserveUntil = clone $created;
    $reserveUntil->modify('+' . max(1,$reserveMin) . ' minutes');
    $exclusiveUntil = clone $created;
    $exclusiveUntil->modify('+' . $exclusiveHours . ' hours');

    // Ensure lists exist
    $generalListId = LeadMarketHelper::ensureList('General', null);
    $stateListId = null;
    if ($state) {
      $stateListId = LeadMarketHelper::ensureList('State: ' . $state, $state);
    }

    $db = JFactory::getDbo();
    $cols = array(
      'source_site','source_lead_id','type','state','city','zip','name','phone','email','payload_raw','lead_json',
      'pricing_mode','exclusive_until_utc','max_sales','post_exclusive_max_sales','sold_count',
      'state_tier_coef','freshness_coef','lead_status','price_usd','reserve_until_utc','uploaded_at_utc','original_uploaded_at_utc','sent_emails_count'
    );

    $vals = array(
      $db->q('quotesautoinsurance.org'),
      $sourceLeadId !== null ? (int)$sourceLeadId : 'NULL',
      $db->q($type),
      $state ? $db->q($state) : 'NULL',
      $city ? $db->q($city) : 'NULL',
      $zip ? $db->q($zip) : 'NULL',
      $name ? $db->q($name) : 'NULL',
      $phone ? $db->q($phone) : 'NULL',
      $email ? $db->q($email) : 'NULL',
      $db->q($payload['raw']),
      $db->q($leadJson),
      $db->q($pricingMode),
      $db->q($exclusiveUntil->format('Y-m-d H:i:s')),
      (int)$maxSales,
      (int)$postExclusiveMaxSales,
      0,
      $db->q(number_format($tierCoef,2,'.','')),
      $db->q(number_format($freshCoef,2,'.','')),
      $db->q($leadStatus),
      $db->q(number_format($priceUsd,2,'.','')),
      $db->q($reserveUntil->format('Y-m-d H:i:s')),
      $db->q($created->format('Y-m-d H:i:s')),
      $db->q($created->format('Y-m-d H:i:s')),
      0
    );

    $query = $db->getQuery(true)
      ->insert($db->qn('#__leadmarket_leads'))
      ->columns(array_map(array($db,'qn'), $cols))
      ->values(implode(',', $vals));
    $db->setQuery($query);
    $db->execute();
    $leadId = (int)$db->insertid();

    // Instant emails
    $params = LeadMarketHelper::params();
    $instantEnabled = (int)$params->get('instant_enabled', 1) === 1;
    if ($instantEnabled && $leadStatus === 'fresh') {
      $this->sendLeadToLists($leadId, array($generalListId, $stateListId), 'instant');
    }

    echo 'uploaded';
    $app->close();
  }

  private function sendLeadToLists($leadId, $listIds, $mode)
  {
    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_leads WHERE id='.(int)$leadId);
    $lead = (array)$db->loadAssoc();
    if (!$lead) return;

    $createdUtc = new DateTime($lead['uploaded_at_utc'], new DateTimeZone('UTC'));
    $nowUtc = LeadMarketHelper::nowUtc();
    $params = LeadMarketHelper::params();
    $reserveMin = (int)$params->get('reserve_minutes', 30);
    $exclusiveHours = LeadMarketHelper::getExclusiveHoursForLead($lead);

    $reserveUntil = $lead['reserve_until_utc'];
    $reserveTxt = $reserveUntil ? (new DateTime($reserveUntil, new DateTimeZone('UTC')))->format('H:i') . ' UTC' : '';

    $masked = LeadMarketHelper::buildMaskedPreview($lead);
    $tierLabel = LeadMarketHelper::stateTierLabel($masked['state']);
    $activityLabel = ucfirst((string)$lead['lead_status']);
    $availabilityText = LeadMarketHelper::availabilityEmailText($lead);
    $saleOptions = LeadMarketHelper::buildSaleOptions($lead);
    $sharedPriceUsd = (string)($saleOptions['shared']['price_usd'] ?? number_format((float)$lead['price_usd'], 2, '.', ''));
    $exclusiveAvailable = !empty($saleOptions['exclusive']['enabled']);
    $exclusiveHoursLead = (int)($saleOptions['exclusive']['hours'] ?? LeadMarketHelper::getExclusiveHoursForLead($lead));
    $exclusiveTeaserText = $exclusiveAvailable
      ? ('Exclusive available • ' . $exclusiveHoursLead . 'h protected first-contact window.')
      : 'Exclusive currently unavailable.';

    $leadUrl = JUri::root() . 'index.php?option=com_leadmarket&view=lead&id='.(int)$leadId;

    $card = '<div style="border:1px solid #ddd;border-radius:10px;padding:14px;margin:10px 0;background:#fff">'
      . '<div style="font-size:18px;margin-bottom:6px;"><b>'.htmlspecialchars($masked['state']).' '.htmlspecialchars($masked['type']).' lead</b></div>'
      . '<div style="color:#666;font-size:13px;">Reserve until: '.htmlspecialchars($reserveTxt).' • Captured: '.$createdUtc->format('Y-m-d H:i').' UTC</div>'
      . '<ul style="margin:10px 0 0 18px;line-height:1.7;">'
      . '<li><b>Location:</b> '.htmlspecialchars($masked['city']).' '.htmlspecialchars($masked['state']).' '.htmlspecialchars($masked['zip']).'</li>'
      . '<li><b>Masked contact:</b> '.htmlspecialchars($masked['phone_masked']).' / '.htmlspecialchars($masked['email_masked']).'</li>'
      . '<li><b>Tier:</b> '.htmlspecialchars($tierLabel).'</li>'
      . '<li><b>Activity:</b> '.htmlspecialchars($activityLabel).'</li>'
      . '<li><b>Exclusive option:</b> '.htmlspecialchars($exclusiveTeaserText).'</li>'
      . '<li><b>Availability:</b> '.htmlspecialchars($availabilityText).'</li>'
      . '</ul>'
      . '<div style="margin-top:12px;">'
      . '<a href="'.htmlspecialchars($leadUrl).'" style="display:inline-block;padding:10px 14px;background:#0c5585;color:#fff;text-decoration:none;border-radius:8px;">Review Lead</a>'
      . '</div>'
      . '</div>';

    $recipientMap = array();
    foreach ($listIds as $listId) {
      if (!$listId) continue;
      $db->setQuery('SELECT name FROM #__leadmarket_lists WHERE id='.(int)$listId);
      $listName = (string)$db->loadResult();
      $recipients = LeadMarketHelper::getRecipientsForListIdFiltered((int)$listId, strtolower((string)$lead['type']), 'instant');
      if (!$recipients) {
        LeadMarketHelper::logEmail($leadId, (int)$listId, '', 'instant-alert', 'skip', 'No active recipients matched this list for instant delivery.');
        continue;
      }
      foreach ($recipients as $toEmail) {
        if (!isset($recipientMap[$toEmail])) {
          $recipientMap[$toEmail] = array('list_id' => (int)$listId, 'list_names' => array());
        }
        $recipientMap[$toEmail]['list_names'][] = $listName;
      }
    }

    foreach ($recipientMap as $toEmail => $meta) {
      $context = array(
        'headline' => 'Fresh lead available',
        'now_utc' => $nowUtc->format('Y-m-d H:i') . ' UTC',
        'leads_html' => $card,
        'state' => $masked['state'],
        'type' => $masked['type'],
        'count' => '1',
        'list_name' => implode(', ', array_unique(array_filter($meta['list_names']))),
        'unsubscribe_url' => LeadMarketHelper::buildUnsubscribeUrl($toEmail),
        'reserve_minutes' => (string)$reserveMin,
        'exclusive_hours' => (string)$exclusiveHours,
        'market_url' => LeadMarketHelper::getMarketplaceUrl(true),
        'lead_url' => $leadUrl,
        'activity' => ucfirst((string)$lead['lead_status']),
        'tier' => $tierLabel,
        'current_price' => $sharedPriceUsd,
        'shared_price' => $sharedPriceUsd,
        'exclusive_option_text' => $exclusiveTeaserText,
        'availability_text' => $availabilityText,
      );

      $rendered = LeadMarketHelper::renderEmail($mode, $context);

      $mailer = LeadMarketHelper::getMailer();
      $mailer->clearAllRecipients();
      $mailer->addRecipient($toEmail);
      $mailer->setSubject($rendered['subject']);
      $mailer->setBody($rendered['body']);

      try {
        $ok = $mailer->Send();
        if ($ok === true) {
          LeadMarketHelper::logEmail($leadId, (int)$meta['list_id'], $toEmail, $rendered['subject'], 'sent', '');
          $this->incrementLeadEmailCount($leadId);
        } else {
          $errMsg = '';
          if (is_object($ok) && isset($ok->message)) { $errMsg = (string)$ok->message; }
          elseif (is_object($mailer) && property_exists($mailer, 'ErrorInfo')) { $errMsg = (string)$mailer->ErrorInfo; }
          if ($errMsg === '') $errMsg = 'send failed';
          LeadMarketHelper::logEmail($leadId, (int)$meta['list_id'], $toEmail, $rendered['subject'], 'error', $errMsg);
        }
      } catch (Exception $e) {
        LeadMarketHelper::logEmail($leadId, (int)$meta['list_id'], $toEmail, $rendered['subject'], 'error', $e->getMessage());
      }
    }
  }

  private function incrementLeadEmailCount($leadId)
  {
    $db = JFactory::getDbo();
    $db->setQuery('UPDATE #__leadmarket_leads SET sent_emails_count = sent_emails_count + 1 WHERE id='.(int)$leadId);
    $db->execute();
  }

  public function cronDailyDigest()
  {
    // Run via cron: /administrator/index.php?option=com_leadmarket&task=api.cronDailyDigest&key=...
    $params = LeadMarketHelper::params();
    if ((int)$params->get('daily_enabled', 1) !== 1) {
      echo 'daily_disabled';
      JFactory::getApplication()->close();
    }

    $key = (string)$params->get('cron_key','');
    $reqKey = JFactory::getApplication()->input->getString('key','');
    if ($key && $reqKey !== $key) {
      echo 'forbidden';
      JFactory::getApplication()->close();
    }

    // For MVP: send digest of last 24h to each list.
    $db = JFactory::getDbo();
    $now = LeadMarketHelper::nowUtc();
    $start = clone $now;
    $start->modify('-24 hours');

    $db->setQuery('SELECT * FROM #__leadmarket_lists');
    $lists = $db->loadObjectList();

    $sent = 0;

    foreach ($lists as $list) {
      // leads for list
      if ($list->name === 'General') {
        $q = $db->getQuery(true)
          ->select('*')->from('#__leadmarket_leads')
          ->where('uploaded_at_utc >= ' . $db->q($start->format('Y-m-d H:i:s')))
          ->where('lead_status IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')')
          ->order('uploaded_at_utc DESC, id DESC');
      } else {
        $state = strtoupper((string)$list->state);
        if (!$state) continue;
        $q = $db->getQuery(true)
          ->select('*')->from('#__leadmarket_leads')
          ->where('uploaded_at_utc >= ' . $db->q($start->format('Y-m-d H:i:s')))
          ->where('state=' . $db->q($state))
          ->where('lead_status IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')')
          ->order('uploaded_at_utc DESC, id DESC');
      }

      $db->setQuery($q);
      $leads = $db->loadAssocList();
      if (!$leads) continue;

      // Partition leads by type and send to recipients based on their lead_type preference.
      $byType = array('auto' => array(), 'home' => array());
      foreach ($leads as $lead) {
        $t = strtolower((string)$lead['type']);
        if (!isset($byType[$t])) continue;
        $byType[$t][] = $lead;
      }

      foreach (array('auto','home') as $t) {
        if (!count($byType[$t])) continue;

        $recipients = LeadMarketHelper::getRecipientsForListIdFiltered((int)$list->id, $t, 'daily');
        if (!$recipients) {
        LeadMarketHelper::logEmail($leadId, (int)$listId, '', 'instant-alert', 'skip', 'No active recipients matched this list for instant delivery.');
        continue;
      }

        $cards = '';
        $exclusiveHours = LeadMarketHelper::getExclusiveHoursForLead($t);
        foreach ($byType[$t] as $lead) {
          $masked = LeadMarketHelper::buildMaskedPreview($lead);
          $leadUrl = JUri::root() . 'index.php?option=com_leadmarket&view=lead&id='.(int)$lead['id'];
          $availabilityText = LeadMarketHelper::availabilityEmailText($lead);
          $saleOptions = LeadMarketHelper::buildSaleOptions($lead);
          $sharedPriceUsd = (string)($saleOptions['shared']['price_usd'] ?? number_format((float)$lead['price_usd'], 2, '.', ''));
          $exclusiveAvailable = !empty($saleOptions['exclusive']['enabled']);
          $exclusiveHoursLead = (int)($saleOptions['exclusive']['hours'] ?? LeadMarketHelper::getExclusiveHoursForLead($lead));
          $exclusiveTeaserText = $exclusiveAvailable
            ? ('Exclusive available • ' . $exclusiveHoursLead . 'h protected first-contact window.')
            : 'Exclusive currently unavailable.';
          $cards .= '<div style="border:1px solid #ddd;border-radius:10px;padding:12px;margin:10px 0;background:#fff">'
            . '<div style="font-size:17px;margin-bottom:6px;"><b>'.htmlspecialchars($masked['state']).' '.htmlspecialchars($masked['type']).' lead</b></div>'
            . '<div style="color:#666;font-size:13px;">'.htmlspecialchars($masked['city']).' '.htmlspecialchars($masked['state']).' '.htmlspecialchars($masked['zip']).' • '.htmlspecialchars($masked['phone_masked']).'</div>'
            . '<ul style="margin:10px 0 0 18px;line-height:1.7;">'
                  . '<li><b>Exclusive option:</b> '.htmlspecialchars($exclusiveTeaserText).'</li>'
            . '<li><b>Availability:</b> '.htmlspecialchars($availabilityText).'</li>'
            . '</ul>'
            . '<div style="margin-top:12px;"><a href="'.htmlspecialchars($leadUrl).'" style="display:inline-block;padding:10px 14px;background:#0c5585;color:#fff;text-decoration:none;border-radius:8px;">Review Lead</a></div>'
            . '</div>';
        }

        foreach ($recipients as $toEmail) {
          $context = array(
            'headline' => (($list->state ? strtoupper((string)$list->state) : 'ALL') . ' ' . ($t === 'home' ? 'Home' : 'Auto') . ' Leads Digest'),
            'now_utc' => $now->format('Y-m-d H:i').' UTC',
            'leads_html' => $cards,
            'state' => $list->state ? strtoupper($list->state) : 'ALL',
            'type' => strtoupper($t),
              'type_label' => ($t === 'home' ? 'Home' : 'Auto'),
            'count' => (string)count($byType[$t]),
            'list_name' => $list->name,
            'unsubscribe_url' => LeadMarketHelper::buildUnsubscribeUrl($toEmail),
          );

          $rendered = LeadMarketHelper::renderEmail('daily', $context);
          $mailer = LeadMarketHelper::getMailer();
          $mailer->clearAllRecipients();
          $mailer->addRecipient($toEmail);
          $mailer->setSubject($rendered['subject']);
          $mailer->setBody($rendered['body']);

          try {
            $ok = $mailer->Send();
            if ($ok === true) {
              LeadMarketHelper::logEmail(0, (int)$list->id, $toEmail, $rendered['subject'], 'sent', '');
              $sent++;
            } else {
              LeadMarketHelper::logEmail(0, (int)$list->id, $toEmail, $rendered['subject'], 'error', is_object($ok) && isset($ok->message) ? $ok->message : 'send failed');
            }
          } catch (Exception $e) {
            LeadMarketHelper::logEmail(0, (int)$list->id, $toEmail, $rendered['subject'], 'error', $e->getMessage());
          }
        }
      }
    }

    echo 'digest_sent=' . $sent;
    JFactory::getApplication()->close();
  }

  public function cronCheckPayments()
  {
    $params = LeadMarketHelper::params();
    $key = (string)$params->get('cron_key','');
    $reqKey = JFactory::getApplication()->input->getString('key','');
    if ($key && $reqKey !== $key) {
      echo 'forbidden';
      JFactory::getApplication()->close();
    }

    LeadMarketHelper::ensureSchema();
    $summary = LeadMarketHelper::runBackgroundVerify(50, 'legacy_cron');
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($summary);
    JFactory::getApplication()->close();
  }


  private function markOrderPaid($orderId, $txid)
  {
    $db = JFactory::getDbo();
    $db->setQuery('SELECT * FROM #__leadmarket_orders WHERE id='.(int)$orderId);
    $order = $db->loadAssoc();
    if (!$order) return;
    $db->setQuery('SELECT * FROM #__leadmarket_leads WHERE id='.(int)$order['lead_id']);
    $lead = $db->loadAssoc();
    if (!$lead) return;
    LeadMarketHelper::confirmPaid($order, $lead, 'system', 'Legacy API Payment Match', array('mode'=>'legacy_api_match','tx_hash'=>(string)$txid));
  }

}
