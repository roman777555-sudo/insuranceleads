<?php
defined('_JEXEC') or die;

class LeadmarketControllerSubscriber extends JControllerForm
{
  protected $view_list = 'subscribers';
}
