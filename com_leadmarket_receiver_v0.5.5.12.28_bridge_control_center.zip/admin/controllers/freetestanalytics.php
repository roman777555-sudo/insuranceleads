<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerFreetestanalytics extends JControllerAdmin
{
  public function __construct($config = array())
  {
    parent::__construct($config);
    LeadMarketHelper::ensureSchema();
    $this->registerTask('deleteSignup', 'deleteSignup');
    $this->registerTask('deleteLeadView', 'deleteLeadView');
    $this->registerTask('deleteTopLead', 'deleteTopLead');
  }

  public function getModel($name = 'Freetestanalytics', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  protected function getReturnUrl()
  {
    $input = JFactory::getApplication()->input;
    $return = base64_decode((string) $input->getString('return', ''), true);
    if (!is_string($return) || $return === '' || strpos($return, 'index.php?') !== 0) {
      $return = 'index.php?option=com_leadmarket&view=freetestanalytics';
    }
    return JRoute::_($return, false);
  }

  protected function redirectWith($message, $type = 'message')
  {
    $this->setRedirect($this->getReturnUrl(), $message, $type);
    return false;
  }

  public function deleteSignup()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $id = (int) $app->input->getInt('id', 0);
    if ($id <= 0) {
      return $this->redirectWith('Signup record was not selected.', 'warning');
    }

    $db = JFactory::getDbo();
    $db->setQuery(
      $db->getQuery(true)
        ->select('id, email')
        ->from('#__leadmarket_trial_access')
        ->where('id=' . $id)
        ->where('source_page=' . $db->q('free_test_leads'))
    );
    $row = $db->loadObject();
    if (!$row) {
      return $this->redirectWith('Free-test signup record was not found.', 'warning');
    }

    try {
      $db->transactionStart();
    } catch (Exception $ignore) {}

    try {
      $db->setQuery('DELETE FROM #__leadmarket_trial_lead_views WHERE access_id=' . (int) $row->id)->execute();
      $db->setQuery('DELETE FROM #__leadmarket_trial_access WHERE id=' . (int) $row->id . ' AND source_page=' . $db->q('free_test_leads'))->execute();
      try { $db->transactionCommit(); } catch (Exception $ignore) {}
    } catch (Exception $e) {
      try { $db->transactionRollback(); } catch (Exception $ignore) {}
      return $this->redirectWith('Delete signup failed: ' . $e->getMessage(), 'error');
    }

    LeadMarketHelper::trackEvent('admin_free_test_signup_deleted', array('page_name' => 'admin_freetestanalytics', 'trial_access_id' => (int) $row->id, 'email' => (string) $row->email));
    $this->setRedirect($this->getReturnUrl(), 'Free-test signup removed from analytics: ' . (string) $row->email . '.');
    return true;
  }

  public function deleteLeadView()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $id = (int) $app->input->getInt('id', 0);
    if ($id <= 0) {
      return $this->redirectWith('Lead-open record was not selected.', 'warning');
    }

    $db = JFactory::getDbo();
    $q = $db->getQuery(true)
      ->select('v.id, v.email, v.lead_id')
      ->from('#__leadmarket_trial_lead_views AS v')
      ->join('LEFT', '#__leadmarket_trial_access AS a ON a.id = v.access_id')
      ->where('v.id=' . $id)
      ->where('a.source_page=' . $db->q('free_test_leads'));
    $db->setQuery($q);
    $row = $db->loadObject();
    if (!$row) {
      return $this->redirectWith('Lead-open record was not found.', 'warning');
    }

    try {
      $db->setQuery('DELETE v FROM #__leadmarket_trial_lead_views AS v LEFT JOIN #__leadmarket_trial_access AS a ON a.id=v.access_id WHERE v.id=' . (int) $row->id . ' AND a.source_page=' . $db->q('free_test_leads'))->execute();
    } catch (Exception $e) {
      return $this->redirectWith('Delete lead-open failed: ' . $e->getMessage(), 'error');
    }

    LeadMarketHelper::trackEvent('admin_free_test_lead_view_deleted', array('page_name' => 'admin_freetestanalytics', 'trial_view_id' => (int) $row->id, 'lead_id' => (int) $row->lead_id, 'email' => (string) $row->email));
    $this->setRedirect($this->getReturnUrl(), 'Lead-open record removed for lead #' . (int) $row->lead_id . '.');
    return true;
  }

  public function deleteTopLead()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $leadId = (int) $app->input->getInt('lead_id', 0);
    if ($leadId <= 0) {
      return $this->redirectWith('Lead ID was not selected.', 'warning');
    }

    $db = JFactory::getDbo();
    $q = $db->getQuery(true)
      ->select('COUNT(*)')
      ->from('#__leadmarket_trial_lead_views AS v')
      ->join('LEFT', '#__leadmarket_trial_access AS a ON a.id = v.access_id')
      ->where('v.lead_id=' . $leadId)
      ->where('a.source_page=' . $db->q('free_test_leads'));
    $db->setQuery($q);
    $count = (int) $db->loadResult();
    if ($count <= 0) {
      return $this->redirectWith('No free-test lead-open history was found for lead #' . $leadId . '.', 'warning');
    }

    try {
      $db->setQuery('DELETE v FROM #__leadmarket_trial_lead_views AS v LEFT JOIN #__leadmarket_trial_access AS a ON a.id=v.access_id WHERE v.lead_id=' . $leadId . ' AND a.source_page=' . $db->q('free_test_leads'))->execute();
    } catch (Exception $e) {
      return $this->redirectWith('Delete top-lead history failed: ' . $e->getMessage(), 'error');
    }

    LeadMarketHelper::trackEvent('admin_free_test_top_lead_deleted', array('page_name' => 'admin_freetestanalytics', 'lead_id' => $leadId, 'rows_deleted' => $count));
    $this->setRedirect($this->getReturnUrl(), 'Removed ' . $count . ' free-test open record(s) for lead #' . $leadId . '.');
    return true;
  }
}
