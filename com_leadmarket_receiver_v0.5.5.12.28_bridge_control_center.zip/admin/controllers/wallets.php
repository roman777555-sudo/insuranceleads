<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';

class LeadMarketControllerWallets extends JControllerAdmin
{
  public function __construct($config = array())
  {
    parent::__construct($config);
    LeadMarketHelper::ensureSchema();
    $this->registerTask('adjust', 'adjust');
    $this->registerTask('setexact', 'setExact');
    $this->registerTask('reset', 'resetBalance');
  }

  public function getModel($name = 'Wallets', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  public function adjust()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $input = $app->input;

    $buyerEmail = trim((string) $input->getString('buyer_email', ''));
    $amount = LeadMarketHelper::parseMoneyInput($input->getString('amount_usd', '0'));
    $note = trim((string) $input->getString('note', ''));

    if ($buyerEmail === '') {
      $app->enqueueMessage('Buyer email is required.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=wallets', false));
      return false;
    }
    if (abs($amount) < 0.00001) {
      $app->enqueueMessage('Enter a non-zero amount.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=wallets', false));
      return false;
    }

    $result = LeadMarketHelper::adjustBuyerBalance(
      $buyerEmail,
      $amount,
      'adjust',
      $note,
      'admin_manual',
      0,
      'admin',
      'Wallet adjustment'
    );

    if (!empty($result['ok'])) {
      $msg = 'Wallet updated for ' . htmlspecialchars(LeadMarketHelper::normalizeEmail($buyerEmail), ENT_QUOTES, 'UTF-8')
        . '. New balance: $' . number_format((float) $result['balance_after'], 2, '.', '') . '.';
      $app->enqueueMessage($msg, 'message');
    } else {
      $app->enqueueMessage(!empty($result['message']) ? $result['message'] : 'Wallet update failed.', 'error');
    }

    $redirect = 'index.php?option=com_leadmarket&view=wallets';
    if ($buyerEmail !== '') $redirect .= '&filter_search=' . urlencode($buyerEmail);
    $this->setRedirect(JRoute::_($redirect, false));
    return !empty($result['ok']);
  }

  public function setExact()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $input = $app->input;
    $buyerEmail = trim((string) $input->getString('buyer_email', ''));
    $amount = LeadMarketHelper::parseMoneyInput($input->getString('exact_amount_usd', '0'));
    $note = trim((string) $input->getString('note', ''));
    if ($buyerEmail === '') {
      $app->enqueueMessage('Buyer email is required.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=wallets', false));
      return false;
    }
    $result = LeadMarketHelper::setBuyerBalanceExact($buyerEmail, $amount, $note, 'admin', 'Wallet set exact');
    $app->enqueueMessage((string) ($result['message'] ?? 'Balance updated.'), !empty($result['ok']) ? 'message' : 'error');
    $redirect = 'index.php?option=com_leadmarket&view=wallets&filter_search=' . urlencode($buyerEmail);
    $this->setRedirect(JRoute::_($redirect, false));
    return !empty($result['ok']);
  }

  public function resetBalance()
  {
    JSession::checkToken() or jexit('Invalid Token');
    $app = JFactory::getApplication();
    $input = $app->input;
    $buyerEmail = trim((string) $input->getString('buyer_email', ''));
    $note = trim((string) $input->getString('note', ''));
    if ($buyerEmail === '') {
      $app->enqueueMessage('Buyer email is required.', 'error');
      $this->setRedirect(JRoute::_('index.php?option=com_leadmarket&view=wallets', false));
      return false;
    }
    $result = LeadMarketHelper::resetBuyerBalance($buyerEmail, $note, 'admin', 'Wallet reset');
    $app->enqueueMessage((string) ($result['message'] ?? 'Balance reset.'), !empty($result['ok']) ? 'message' : 'error');
    $redirect = 'index.php?option=com_leadmarket&view=wallets&filter_search=' . urlencode($buyerEmail);
    $this->setRedirect(JRoute::_($redirect, false));
    return !empty($result['ok']);
  }
}
