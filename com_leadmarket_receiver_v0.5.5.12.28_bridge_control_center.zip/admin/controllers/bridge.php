<?php
defined('_JEXEC') or die;

require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/bridge.php';

class LeadMarketControllerBridge extends JControllerLegacy
{
    protected function redirectUrl()
    {
        $input = JFactory::getApplication()->input;
        $url = trim((string) $input->post->getString('return_url', ''));
        if ($url === '' || strpos($url, 'index.php') !== 0) {
            $url = 'index.php?option=com_leadmarket&view=bridge';
        }
        return $url;
    }

    protected function adminActor()
    {
        $user = JFactory::getUser();
        $name = '';
        if ($user && !empty($user->id)) {
            $name = trim((string) ($user->username !== '' ? $user->username : $user->name));
        }
        return $name !== '' ? $name : 'admin';
    }

    public function approveProposal()
    {
        JSession::checkToken('post') or jexit('Invalid Token');
        $app = JFactory::getApplication();
        try {
            $proposalId = trim((string) $app->input->post->getString('proposal_id', ''));
            LeadMarketBridgeHelper::adminProposalApprove($proposalId, $this->adminActor());
            $app->enqueueMessage('Proposal approved.', 'message');
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
        }
        $this->setRedirect($this->redirectUrl());
    }

    public function rejectProposal()
    {
        JSession::checkToken('post') or jexit('Invalid Token');
        $app = JFactory::getApplication();
        try {
            $proposalId = trim((string) $app->input->post->getString('proposal_id', ''));
            $reason = trim((string) $app->input->post->getString('reason', ''));
            LeadMarketBridgeHelper::adminProposalReject($proposalId, $this->adminActor(), $reason);
            $app->enqueueMessage('Proposal rejected.', 'warning');
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
        }
        $this->setRedirect($this->redirectUrl());
    }

    public function expireProposal()
    {
        JSession::checkToken('post') or jexit('Invalid Token');
        $app = JFactory::getApplication();
        try {
            $proposalId = trim((string) $app->input->post->getString('proposal_id', ''));
            $reason = trim((string) $app->input->post->getString('reason', ''));
            LeadMarketBridgeHelper::adminProposalExpire($proposalId, $this->adminActor(), $reason);
            $app->enqueueMessage('Proposal expired.', 'warning');
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
        }
        $this->setRedirect($this->redirectUrl());
    }

    public function updateTaskStatus()
    {
        JSession::checkToken('post') or jexit('Invalid Token');
        $app = JFactory::getApplication();
        try {
            $taskId = trim((string) $app->input->post->getString('task_id', ''));
            $status = trim((string) $app->input->post->getCmd('status', ''));
            $note = trim((string) $app->input->post->getString('notes_append', ''));
            LeadMarketBridgeHelper::adminTaskSetStatus($taskId, $status, $this->adminActor(), $note);
            $app->enqueueMessage('Task updated.', 'message');
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
        }
        $this->setRedirect($this->redirectUrl());
    }

    public function duplicateTask()
    {
        JSession::checkToken('post') or jexit('Invalid Token');
        $app = JFactory::getApplication();
        try {
            $taskId = trim((string) $app->input->post->getString('task_id', ''));
            LeadMarketBridgeHelper::adminTaskDuplicate($taskId, $this->adminActor());
            $app->enqueueMessage('Task duplicated.', 'message');
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
        }
        $this->setRedirect($this->redirectUrl());
    }

    public function testAuditWrite()
    {
        JSession::checkToken('post') or jexit('Invalid Token');
        $app = JFactory::getApplication();
        try {
            LeadMarketBridgeHelper::adminTestAuditWrite($this->adminActor());
            $app->enqueueMessage('Bridge audit write test completed.', 'message');
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
        }
        $this->setRedirect($this->redirectUrl());
    }
}
