<?php
defined('_JEXEC') or die;

class LeadMarketTableLead extends JTable
{
  public function __construct(&$db)
  {
    parent::__construct('#__leadmarket_leads', 'id', $db);
  }
}
