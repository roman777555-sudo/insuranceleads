<?php
defined('_JEXEC') or die;

class LeadMarketTableList extends JTable
{
  public function __construct(&$db)
  {
    parent::__construct('#__leadmarket_lists', 'id', $db);
  }
}
