<?php
defined('_JEXEC') or die;

class LeadmarketTableSubscriber extends JTable
{
  public function __construct(&$db)
  {
    parent::__construct('#__leadmarket_subscribers', 'id', $db);
  }
}
