<?php
defined('_JEXEC') or die;

class LeadMarketTableOrder extends JTable
{
  public function __construct(&$db)
  {
    parent::__construct('#__leadmarket_orders', 'id', $db);
  }
}
