<?php
defined('_JEXEC') or die;

require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';
LeadMarketHelper::ensureSchema();

$controller = JControllerLegacy::getInstance('LeadMarket');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();
