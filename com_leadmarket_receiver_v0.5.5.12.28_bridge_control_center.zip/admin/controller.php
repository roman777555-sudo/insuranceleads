<?php
defined('_JEXEC') or die;

class LeadMarketController extends JControllerLegacy
{
  protected $default_view = 'leads';
}
