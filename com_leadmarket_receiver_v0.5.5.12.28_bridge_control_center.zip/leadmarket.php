<?php
defined('_JEXEC') or die;

$input = JFactory::getApplication()->input;

$taskFromQuery = '';
if (!empty($_SERVER['QUERY_STRING'])) {
  $qs = array();
  parse_str($_SERVER['QUERY_STRING'], $qs);
  if (!empty($qs['task'])) {
    $taskFromQuery = (string)$qs['task'];
  }
}
if ($taskFromQuery === '' && isset($_GET['task'])) {
  $taskFromQuery = (string)$_GET['task'];
}
$taskRaw = trim($taskFromQuery !== '' ? $taskFromQuery : (string) $input->get('task', '', 'raw'));
$task = trim($taskRaw !== '' ? $taskRaw : (string) $input->getString('task', ''));
$taskNormalized = strtolower(str_replace(array('.', '-', '_'), '', $task));


$viewRaw = trim((string)$input->get('view', '', 'raw'));
$viewNormalized = strtolower(str_replace(array('.', '-', '_'), '', $viewRaw));


if (!function_exists("lmBuyerCreditReasonLabel")) {
  function lmBuyerCreditReasonLabel($code, $options)
  {
    $code = strtolower(trim((string) $code));
    return isset($options[$code]) ? (string) $options[$code] : ucfirst(str_replace('_', ' ', $code));
  }
}

function lmApplyTechnicalSeoProtection($viewName)
{
  $viewName = strtolower(trim((string)$viewName));
  $robotsByView = array(
    'lead' => 'noindex, nofollow',
    'batch' => 'noindex, nofollow',
    'orders' => 'noindex, nofollow',
    'order' => 'noindex, nofollow',
    'subscriber' => 'noindex, nofollow',
    'subscribers' => 'noindex, nofollow',
    'lists' => 'noindex, nofollow',
    'list' => 'noindex, nofollow',
    'config' => 'noindex, nofollow',
    'access' => 'noindex, nofollow',
    'buyeraccess' => 'noindex, nofollow',
    'topup' => 'noindex, nofollow',
    'sample' => 'noindex, nofollow',
  );
  if (empty($robotsByView[$viewName])) {
    return;
  }

  $robots = (string) $robotsByView[$viewName];
  $app = JFactory::getApplication();
  $doc = JFactory::getDocument();
  if ($doc && method_exists($doc, 'setMetaData')) {
    $doc->setMetaData('robots', $robots);
  }
  if (!headers_sent()) {
    header('X-Robots-Tag: ' . $robots, true);
  }
  try {
    $app->setHeader('X-Robots-Tag', $robots, true);
  } catch (Exception $e) {}
}

lmApplyTechnicalSeoProtection($viewNormalized);

if ($taskNormalized === '' && $viewNormalized === 'batch') {
  require_once JPATH_COMPONENT . '/helpers/leadmarket.php';
  $app = JFactory::getApplication();
  try {
    LeadMarketHelper::ensureSchema();
    LeadMarketHelper::cleanupExpiredOrders();
    LeadMarketHelper::cleanupExpiredBatches();
    $session = JFactory::getSession();
    $batchId = (int)$input->getInt('id', 0);
    $token = LeadMarketHelper::readBuyerAccessTokenFromRequest();
    $address = LeadMarketHelper::cryptoWalletAddress();
    $mode = 'summary';
    $accessDenied = false;
    $selection = array();
    $items = array();
    $batch = null;
    $removedCount = 0;
    $summaryNotice = '';
    $summaryTone = 'warn';
    $showResend = false;
    $buyerEmailValue = '';
    $queryNotice = trim((string)$input->get('summary_notice', '', 'raw'));
    if ($queryNotice === '' && !empty($_SERVER['QUERY_STRING'])) {
      $qsBatch = array();
      parse_str($_SERVER['QUERY_STRING'], $qsBatch);
      if (!empty($qsBatch['summary_notice'])) $queryNotice = trim((string)$qsBatch['summary_notice']);
    }
    if ($queryNotice === '' && isset($_GET['summary_notice'])) $queryNotice = trim((string)$_GET['summary_notice']);
    if ($queryNotice !== '') $summaryNotice = $queryNotice;
    $queryTone = trim((string)$input->get('summary_tone', '', 'raw'));
    if ($queryTone === '' && !empty($_SERVER['QUERY_STRING'])) {
      $qsBatch = array();
      parse_str($_SERVER['QUERY_STRING'], $qsBatch);
      if (!empty($qsBatch['summary_tone'])) $queryTone = trim((string)$qsBatch['summary_tone']);
    }
    if ($queryTone === '' && isset($_GET['summary_tone'])) $queryTone = trim((string)$_GET['summary_tone']);
    if ($queryTone !== '') $summaryTone = $queryTone;
    $showResend = (int)$input->getInt('show_resend', 0) === 1;
    if (!$showResend && !empty($_SERVER['QUERY_STRING'])) {
      $qsBatch = array();
      parse_str($_SERVER['QUERY_STRING'], $qsBatch);
      if (!empty($qsBatch['show_resend'])) $showResend = ((int)$qsBatch['show_resend'] === 1);
    }
    $buyerEmailValue = trim((string)$input->get('buyer_email', '', 'raw'));
    if ($buyerEmailValue === '' && isset($_GET['buyer_email'])) $buyerEmailValue = trim((string)$_GET['buyer_email']);
    if ($buyerEmailValue === '' && !empty($_SERVER['QUERY_STRING'])) {
      $qsBatch = array();
      parse_str($_SERVER['QUERY_STRING'], $qsBatch);
      if (!empty($qsBatch['buyer_email'])) $buyerEmailValue = trim((string)$qsBatch['buyer_email']);
    }
    if ($buyerEmailValue === '') $buyerEmailValue = trim((string)$session->get('lm.batch_buyer_email', '', 'com_leadmarket'));
    if ($buyerEmailValue !== '') $session->set('lm.batch_buyer_email', $buyerEmailValue, 'com_leadmarket');
    $showCreditOrderId = (int)$input->getInt('show_credit_order', 0);
    if ($showCreditOrderId <= 0 && isset($_GET['show_credit_order'])) $showCreditOrderId = (int)$_GET['show_credit_order'];
    $sessionNotice = trim((string)$session->get('lm.batch_removed_notice', '', 'com_leadmarket'));
    if ($sessionNotice !== '') { $summaryNotice = $sessionNotice; if ($summaryTone === '') $summaryTone = 'warn'; }
    $session->clear('lm.batch_removed_notice', 'com_leadmarket');
    $errorNotice = trim((string)$session->get('lm.batch_error_notice', '', 'com_leadmarket'));
    $errorTone = trim((string)$session->get('lm.batch_error_tone', 'warn', 'com_leadmarket'));
    if ($errorNotice !== '') { $summaryNotice = $errorNotice; $summaryTone = $errorTone !== '' ? $errorTone : 'warn'; }
    $session->clear('lm.batch_error_notice', 'com_leadmarket');
    $session->clear('lm.batch_error_tone', 'com_leadmarket');
    if ($batchId > 0) {
      $mode = 'checkout';
      $batch = LeadMarketHelper::loadBatchById($batchId);
      if (!$batch) {
        while (ob_get_level()) { @ob_end_clean(); }
        header('Content-Type: text/plain; charset=utf-8');
        echo 'batch_error: Shared checkout not found';
        $app->close();
      }
      $batch = LeadMarketHelper::reconcileBatchById((int)$batch['id']);
      $batch['access_token'] = LeadMarketHelper::ensureBatchToken($batch);
      if (!LeadMarketHelper::canAccessBatch($batch, $token)) {
        $accessDenied = true;
      }
      foreach ((array) LeadMarketHelper::getBatchItems($batchId) as $item) {
        $lead = null;
        if (!empty($item['lead_id'])) {
          $lead = LeadMarketHelper::loadLeadById((int)$item['lead_id']);
        }
        if (!$lead) {
          $lead = array(
            'id' => (int)($item['lead_id'] ?? 0),
            'type' => (string)($item['type'] ?? ($item['lead_type'] ?? 'auto')),
            'state' => (string)($item['state'] ?? ($item['lead_state'] ?? '')),
            'city' => (string)($item['city'] ?? ($item['lead_city'] ?? '')),
            'email' => (string)($item['email'] ?? ($item['lead_email'] ?? '')),
            'phone' => (string)($item['phone'] ?? ($item['lead_phone'] ?? '')),
            'lead_status' => (string)($item['lead_status'] ?? 'fresh'),
            'captured_at_utc' => (string)($item['captured_at_utc'] ?? ''),
            'uploaded_at_utc' => (string)($item['uploaded_at_utc'] ?? ''),
            'payload_raw' => (string)($item['payload_raw'] ?? ''),
            'lead_json' => (string)($item['lead_json'] ?? ''),
            'price_usd' => (float)($item['lead_base_price_usd'] ?? $item['amount_usd'] ?? 0),
          );
        }
        $items[] = array('order'=>$item,'lead'=>$lead,'price'=>(float)($item['amount_usd'] ?? 0));
      }
    } else {
      $selectedFromQuery = '';
      if (!empty($_SERVER['QUERY_STRING'])) {
        $qsBatch = array();
        parse_str($_SERVER['QUERY_STRING'], $qsBatch);
        if (!empty($qsBatch['selected'])) {
          $selectedFromQuery = (string)$qsBatch['selected'];
        }
      }
      if ($selectedFromQuery === '' && isset($_GET['selected'])) {
        $selectedFromQuery = (string)$_GET['selected'];
      }
      $csv = trim($selectedFromQuery !== '' ? $selectedFromQuery : (string)$input->get('selected', '', 'raw'));
      if ($csv === '') {
        $csv = trim((string)$input->getString('selected', ''));
      }
      $ids = array();
      if ($csv !== '') {
        $ids = array_values(array_unique(array_filter(array_map('intval', preg_split('/\s*,\s*/', $csv)))));
        $session->set('lm.shared_selection_ids', $ids, 'com_leadmarket');
      }
      if (!$ids) {
        $ids = (array)$session->get('lm.shared_selection_ids', array(), 'com_leadmarket');
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
      }
      foreach ($ids as $leadId) {
        $lead = LeadMarketHelper::loadLeadById($leadId);
        if (!$lead) continue;
        $opts = LeadMarketHelper::getSaleModeOptions($lead);
        if (empty($opts['shared']['enabled'])) continue;
        $selection[] = array('lead'=>$lead,'price'=>(float)$opts['shared']['price_usd']);
      }
    }
    $marketUrl = LeadMarketHelper::getMarketplaceUrl(false);
    $homeUrl = JUri::root();
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex, nofollow">';
    echo '<style>body{margin:0;background:#f6f9fc;font-family:Arial,sans-serif;color:#13232f}.wrap{max-width:1080px;margin:24px auto;padding:0 16px}.hero{background:linear-gradient(135deg,#f6fbff 0%,#eef7fd 100%);border:1px solid #d8e7f3;border-radius:20px;padding:24px}.h1{margin:0 0 8px;font-size:38px;color:#0c5585;line-height:1.1}.muted{margin:0;color:#44545e;line-height:1.7;max-width:760px}.grid{display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:18px;margin-top:18px;align-items:start}.card{border:1px solid #dbe6ef;border-radius:14px;padding:14px;background:#fff;margin-bottom:12px}.title{font-size:22px;font-weight:800;color:#13232f;margin:0 0 6px}.meta{color:#61717f;line-height:1.6;margin:0 0 10px}.miniGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.info{background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px}.label{font-size:11px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px;display:block}.side{position:sticky;top:16px;background:#fff;border:1px solid #dbe6ef;border-radius:16px;padding:18px;box-shadow:0 4px 16px rgba(12,85,133,.05)}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid transparent;cursor:pointer;background:#0c5585;color:#fff}.btn[disabled]{opacity:.72;cursor:not-allowed}.btnGhost{display:inline-flex;align-items:center;justify-content:center;min-height:46px;padding:0 16px;border-radius:12px;text-decoration:none;font-weight:800;border:1px solid #d5e3ee;cursor:pointer;background:#fff;color:#44545e}.copyRow{display:flex;gap:8px;align-items:flex-start}.copyText{flex:1;word-break:break-all}.copyBtn{display:inline-flex;align-items:center;justify-content:center;min-height:36px;padding:0 12px;border-radius:10px;border:1px solid #d5e3ee;background:#fff;color:#0c5585;font-weight:700;cursor:pointer;white-space:nowrap}.spinner{display:inline-block;width:16px;height:16px;border:2px solid rgba(255,255,255,.35);border-top-color:#fff;border-radius:50%;animation:lmspin .9s linear infinite;margin-right:8px;vertical-align:middle}@keyframes lmspin{to{transform:rotate(360deg)}}.notice{padding:12px 14px;border-radius:10px;background:#eefaf0;border:1px solid #cfe5d4;color:#1f6b35;margin-bottom:12px}.warn{padding:12px 14px;border-radius:10px;background:#fff8ef;border:1px solid #eadfc7;color:#7a5c1e;margin-bottom:12px}.err{padding:12px 14px;border-radius:10px;background:#fff5f5;border:1px solid #efd5d5;color:#7a2b2b;margin-bottom:12px}.topbar{margin:0 auto 18px;max-width:1080px;padding:0 16px}.logo{display:inline-block;margin-bottom:14px}.nav{background:#160060;height:40px;border-radius:3px}.nav a{color:#ffe500;text-decoration:none;font-weight:700;padding:11px 14px;display:inline-block}@media(max-width:900px){.grid{grid-template-columns:1fr}.miniGrid{grid-template-columns:1fr}}.lmPromoBox{margin:0 0 12px;padding:12px;border:1px solid #dbe6ef;border-radius:14px;background:linear-gradient(135deg,#fbfdff 0%,#f4faf7 100%)}.lmPromoTitle{display:block;margin:0 0 6px;color:#18384b;font-size:13px;font-weight:800}.lmPromoHelp{margin:0 0 8px;color:#607080;font-size:12px;line-height:1.6}.lmPromoRow{display:flex;flex-wrap:wrap;gap:8px;align-items:center}.lmPromoInput{flex:1 1 160px;min-height:40px;padding:0 12px;border:1px solid #cfd9e3;border-radius:10px;box-sizing:border-box;background:#fff;color:#18384b}.lmPromoInput.isApplied{background:#f3f5f7;border-color:#d8e0e7;color:#7a8894}.lmPromoBtn,.lmPromoRemove{display:inline-flex;align-items:center;justify-content:center;min-height:40px;padding:0 14px;border-radius:10px;font-weight:700;cursor:pointer}.lmPromoBtn{border:1px solid #0c5585;background:#fff;color:#0c5585}.lmPromoRemove{border:1px solid #d7e2eb;background:#fff;color:#425561}.lmPromoRemove.hidden,.hidden{display:none !important}.lmPromoBtn.isLoading{position:relative;padding-right:34px;pointer-events:none;opacity:.92}.lmPromoBtn.isLoading:after{content:"";position:absolute;right:12px;top:50%;width:15px;height:15px;margin-top:-8px;border-radius:50%;border:2px solid rgba(12,85,133,.22);border-top-color:#0c5585;animation:lmspin .8s linear infinite}.lmPromoStatus{display:none;margin-top:8px;padding:10px 12px;border-radius:12px;font-size:13px;line-height:1.6}.lmPromoStatus.ok{display:block;border:1px solid #cfe5d4;background:#eefaf0;color:#1f6b35}.lmPromoStatus.err{display:block;border:1px solid #ebc9c9;background:#fff4f4;color:#8a2d2d}.lmPromoStatus.info{display:block;border:1px solid #d5e6f1;background:#eef6fb;color:#24475d}.lmPromoCheck{display:none;align-items:center;gap:6px;font-size:13px;font-weight:800;color:#1f6a3c;width:100%;margin-top:2px}.lmPromoCheck.visible{display:inline-flex}.lmPromoCheckmark{display:inline-flex;align-items:center;justify-content:center;width:18px;height:18px;border-radius:50%;background:#1f6a3c;color:#fff;font-size:12px;line-height:1;flex:0 0 18px}.lmPromoSummary{margin-top:10px;display:none;border:1px solid #dbe6ef;border-radius:12px;background:#fff;padding:12px}.lmPromoSummary.visible{display:block}.lmPromoSummaryHead{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:0 0 8px}.lmPromoBadge{display:inline-block;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:800;border:1px solid #cfe7d8;background:#edf8f1;color:#1f6a3c}.lmPromoBadgeSoft{border-color:#d8e8f3;background:#eef6fb;color:#0c5585}.lmPromoSummaryGrid,.lmPromoInlineGrid{display:flex;flex-direction:column;gap:8px;font-size:14px;line-height:1.4}.lmPromoSummaryGrid>div,.lmPromoInlineGrid>div{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:10px 12px;border:1px solid #edf2f7;border-radius:10px;background:#f8fbfd;color:#607080;font-size:12px;font-weight:800;letter-spacing:.03em;text-transform:uppercase}.lmPromoSummaryGrid strong,.lmPromoInlineGrid strong{display:block;margin-left:auto;color:#13232f;font-size:15px;font-weight:800;text-align:right;letter-spacing:normal;text-transform:none}.lmPromoTotals{margin-top:10px;background:#f8fbfd;border:1px solid #edf2f7;border-radius:12px;padding:12px}.lmPromoTotalsRow{display:flex;justify-content:space-between;gap:10px;font-size:14px;line-height:1.6}.lmPromoTotalsRowStrong{font-size:15px}.lmPromoMeta{margin-top:10px;padding:10px 12px;border-radius:12px;background:#f6fbff;border:1px solid #d8e7f3;color:#24475d;line-height:1.6;font-size:13px}.lmPromoInlineCard{margin:0 0 12px;padding:12px;border:1px solid #dbe6ef;border-radius:12px;background:#f8fbfd}.lmPayMethods{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px;margin-top:12px}.lmPayMethod{border:1px solid #d5e3ee;border-radius:12px;padding:12px;background:#fff;cursor:pointer}.lmPayMethod.active{border-color:#0c5585;box-shadow:0 0 0 2px rgba(12,85,133,.08)}.lmPayMethod.disabled{opacity:.55;cursor:not-allowed;background:#fafcfe}.lmPayMethodTitle{display:block;font-size:14px;font-weight:800;color:#13232f;margin-bottom:4px}.lmPayMethodMeta{display:block;font-size:12px;color:#607080;line-height:1.6}.lmPayMethodNote{margin-top:8px;color:#607080;font-size:12px;line-height:1.6}@media(max-width:700px){.lmPromoSummaryGrid>div,.lmPromoInlineGrid>div{padding:10px}}</style></head><body>';
    echo '<div class="topbar"><div class="logo"><img src="' . htmlspecialchars(JUri::root() . 'images/insuranceleads-logo.png', ENT_QUOTES, 'UTF-8') . '" alt="InsuranceLeads.co" style="max-width:240px;height:auto"></div><div class="nav"><a href="' . htmlspecialchars($homeUrl, ENT_QUOTES, 'UTF-8') . '">Home</a></div></div>';
    echo '<div class="wrap">';
    if ($mode === 'summary') {
      echo '<div class="hero"><h1 class="h1">Shared Checkout Summary</h1><p class="muted">Review your selected leads below. Enter your buyer email to create one shared checkout set with a combined total payment.</p></div>';
      if ($summaryNotice !== '') {
        $noticeClass = 'warn';
        if ($summaryTone === 'error') $noticeClass = 'err';
        elseif ($summaryTone === 'success') $noticeClass = 'notice';
        echo '<div class="' . $noticeClass . '" style="margin-top:16px">' . htmlspecialchars($summaryNotice, ENT_QUOTES, 'UTF-8') . '</div>';
      }
      echo '<div class="grid"><div>';
      $sum = 0.0;
      if (!$selection) {
        echo '<div class="card" style="color:#50616d">No shared leads are selected right now. Please return to the marketplace and choose at least one lead.</div>';
      } else {
        foreach ($selection as $row) {
          $sum += (float)$row['price'];
          $lead = $row['lead'];
          $masked = LeadMarketHelper::buildMaskedPreview($lead);
          $title = LeadMarketHelper::formatLeadTitle($lead);
          $loc = trim($masked['city'] . ', ' . $masked['state'] . ' ' . $masked['zip']);
          echo '<div class="card"><div class="title">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</div><div class="meta">' . htmlspecialchars($loc, ENT_QUOTES, 'UTF-8') . ' • ' . htmlspecialchars((string)$masked['phone_masked'], ENT_QUOTES, 'UTF-8') . '</div><div class="miniGrid"><div class="info"><span class="label">Shared price</span><strong>from $' . htmlspecialchars(number_format((float)$row['price'], 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div><div class="info"><span class="label">Availability</span><span>' . htmlspecialchars(LeadMarketHelper::getBuyerAvailabilityLabel($lead), ENT_QUOTES, 'UTF-8') . '</span></div></div></div>';
        }
      }
      echo '</div><aside class="side"><h3 style="margin:0 0 8px;font-size:20px;color:#0c5585">Checkout set</h3><p style="margin:0 0 12px;color:#51626d;line-height:1.7;font-size:14px">Shared-only batch checkout combines selected leads into one payment set. Exclusive access remains on individual lead pages with a protected first-contact window.</p>';
      if ($removedCount > 0) echo '<div class="warn" style="margin:0 0 12px">' . (int)$removedCount . ' selected lead(s) were removed because they are no longer eligible for shared checkout.</div>';
      echo '<div class="miniGrid" style="margin:0 0 12px"><div class="info"><span class="label">Selected leads</span><strong>' . count($selection) . '</strong></div><div class="info"><span class="label">Estimated total</span><strong id="lmBatchEstimateTotal">$' . htmlspecialchars(number_format($sum, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div></div>';
      if ($selection) {
        $selectedCsv = array(); foreach ($selection as $row) { $selectedCsv[] = (int)($row['lead']['id'] ?? 0); }
        $allPurchased = false;
        $disableSharedCheckout = false;
        if ($buyerEmailValue !== '' && filter_var($buyerEmailValue, FILTER_VALIDATE_EMAIL)) {
          $elig = LeadMarketHelper::getSharedBatchEmailEligibilitySummary($selectedCsv, $buyerEmailValue);
          $allPurchased = !empty($elig['all_purchased']);
          $disableSharedCheckout = !empty($elig['disable_submit']) && !$allPurchased;
          if ($summaryNotice === '' && !empty($elig['message']) && (!empty($elig['all_purchased']) || !empty($elig['partially_purchased']) || !empty($elig['disable_submit']) || !empty($elig['active_checkout_count']))) {
            $noticeClass = (!empty($elig['tone']) && $elig['tone'] === 'error') ? 'err' : ((!empty($elig['tone']) && $elig['tone'] === 'success') ? 'notice' : 'warn');
            echo '<div class="' . $noticeClass . '" style="margin:0 0 12px">' . htmlspecialchars((string)$elig['message'], ENT_QUOTES, 'UTF-8') . '</div>';
            if (!empty($elig['all_purchased'])) $showResend = true;
          }
        }
        $summaryBtnLabel = $allPurchased ? 'Already Purchased for This Email' : ($disableSharedCheckout ? 'Selection Already in Active Checkout' : 'Create Shared Checkout');
        $summaryBtnDisabled = ($allPurchased || $disableSharedCheckout);
        echo '<form id="lmBatchSummaryForm" action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=batchsummarysubmit'), ENT_QUOTES, 'UTF-8') . '" method="post">' . JHtml::_('form.token') . '<input type="hidden" name="selected_ids_csv" value="' . htmlspecialchars(implode(',', $selectedCsv), ENT_QUOTES, 'UTF-8') . '"><input type="hidden" id="batch_promo_code_hidden" name="promo_code" value=""><label style="display:block;margin:0 0 6px;font-weight:700" for="batch_buyer_email">Buyer email</label><input id="batch_buyer_email" name="buyer_email" type="email" value="' . htmlspecialchars($buyerEmailValue, ENT_QUOTES, 'UTF-8') . '" required style="display:block;width:100%;min-height:46px;padding:0 12px;border:1px solid #cfd9e3;border-radius:12px;box-sizing:border-box;margin-bottom:12px"><div style="margin-top:10px"><button type="button" id="lmBatchPromoToggle" style="background:none;border:0;padding:0;color:#0c5585;font-weight:700;text-decoration:underline;cursor:pointer">Have a promo code?</button><div id="lmBatchPromoPanel" class="lmPromoBox" style="display:none;margin-top:10px"><label class="lmPromoLabel" for="batch_promo_code">Promo code</label><div class="lmPromoHelp" style="margin-top:6px">Apply a promo before creating the shared checkout.</div><div class="lmPromoRow"><input id="batch_promo_code" class="lmPromoInput" type="text" value="" placeholder="Enter promo code"><button type="button" id="lmBatchApplyPromo" class="lmPromoBtn">Apply</button><button type="button" id="lmBatchRemovePromo" class="lmPromoRemove hidden">Remove</button></div><div id="lmBatchPromoMessage" class="lmPromoStatus"></div><div id="lmBatchPromoSummary" class="lmPromoSummary"><div class="lmPromoSummaryHead"><span class="lmPromoBadge">Discount summary</span></div><div class="lmPromoSummaryGrid"><div>Code<strong id="lmBatchPromoCodeText">—</strong></div><div>Discount<strong id="lmBatchPromoDiscountText">$0.00</strong></div><div>Final total<strong id="lmBatchPromoTotalText">$' . htmlspecialchars(number_format($sum, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div></div></div></div><div class="lmPromoTotals"><div class="lmPromoTotalsRow"><span>Subtotal</span><strong id="lmBatchSubtotal">$' . htmlspecialchars(number_format($sum, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div><div id="lmBatchDiscountRow" class="lmPromoTotalsRow hidden" style="margin-top:6px"><span>Promo discount</span><strong id="lmBatchDiscount">$0.00</strong></div><div class="lmPromoTotalsRow lmPromoTotalsRowStrong" style="margin-top:6px"><span>Final total</span><strong id="lmBatchFinalTotal">$' . htmlspecialchars(number_format($sum, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div></div></div><button id="lmBatchSummarySubmit" type="submit" class="btn" style="width:100%"' . ($summaryBtnDisabled ? ' disabled="disabled"' : '') . '>' . $summaryBtnLabel . '</button></form>';
        echo '<script>(function(){var form=document.getElementById("lmBatchSummaryForm");if(!form)return;var email=document.getElementById("batch_buyer_email");var codeInput=document.getElementById("batch_promo_code");var applyBtn=document.getElementById("lmBatchApplyPromo");var removeBtn=document.getElementById("lmBatchRemovePromo");var hidden=document.getElementById("batch_promo_code_hidden");var subtotalText=document.getElementById("lmBatchSubtotal");var finalText=document.getElementById("lmBatchFinalTotal");var estimate=document.getElementById("lmBatchEstimateTotal");var promoMsg=document.getElementById("lmBatchPromoMessage");var promoSummary=document.getElementById("lmBatchPromoSummary");var promoCodeText=document.getElementById("lmBatchPromoCodeText");var promoDiscountText=document.getElementById("lmBatchPromoDiscountText");var promoTotalText=document.getElementById("lmBatchPromoTotalText");var promoAccepted=document.getElementById("lmBatchPromoAccepted");var promoDiscountRow=document.getElementById("lmBatchDiscountRow");var promoDiscount=document.getElementById("lmBatchDiscount");var selectedField=form.querySelector("input[name=selected_ids_csv]");function money(v){var n=parseFloat(v||0);if(!isFinite(n))n=0;return "$"+n.toFixed(2);}function setMessage(type,text){if(!promoMsg)return;promoMsg.className="lmPromoStatus";if(!text){promoMsg.style.display="none";promoMsg.textContent="";return;}promoMsg.style.display="block";promoMsg.textContent=text;promoMsg.classList.add(type==="success"?"ok":(type==="error"?"err":"info"));}function setPromoPanelOpen(on){var panel=document.getElementById("lmBatchPromoPanel");var toggle=document.getElementById("lmBatchPromoToggle");if(panel)panel.style.display=on?"block":"none";if(toggle){toggle.setAttribute("aria-expanded",on?"true":"false");toggle.textContent=on?"Hide promo code":"Have a promo code?";}}function setApplied(on){if(promoAccepted)promoAccepted.classList[on?"add":"remove"]("visible");if(codeInput){codeInput.readOnly=!!on;codeInput.classList[on?"add":"remove"]("isApplied");}if(removeBtn)removeBtn.classList[on?"remove":"add"]("hidden");if(on)setPromoPanelOpen(true);}function clearPromo(message,collapsePanel){if(hidden)hidden.value="";if(codeInput){codeInput.value="";codeInput.readOnly=false;codeInput.classList.remove("isApplied");}if(promoDiscountRow)promoDiscountRow.classList.add("hidden");if(finalText&&subtotalText)finalText.textContent=subtotalText.textContent;if(estimate&&subtotalText)estimate.textContent=subtotalText.textContent;if(promoSummary)promoSummary.classList.remove("visible");if(promoCodeText)promoCodeText.textContent="—";if(promoDiscountText)promoDiscountText.textContent="$0.00";if(promoTotalText&&subtotalText)promoTotalText.textContent=subtotalText.textContent;setApplied(false);if(collapsePanel)setPromoPanelOpen(false);if(message)setMessage("info",message);else setMessage("","");}function applySummary(data){if(hidden)hidden.value=data.promo_code||"";if(promoDiscountRow)promoDiscountRow.classList.remove("hidden");if(promoDiscount)promoDiscount.textContent=money(data.discount_amount||0);if(finalText)finalText.textContent=money(data.final_total||0);if(estimate)estimate.textContent=money(data.final_total||0);if(promoCodeText)promoCodeText.textContent=data.promo_code||"—";if(promoDiscountText)promoDiscountText.textContent=money(data.discount_amount||0);if(promoTotalText)promoTotalText.textContent=money(data.final_total||0);if(promoSummary)promoSummary.classList.add("visible");setApplied(true);}function tokenInput(){var hs=form.querySelectorAll("input[type=hidden]");for(var i=0;i<hs.length;i++){var el=hs[i];if(el.name!=="selected_ids_csv"&&el.name!=="promo_code"&&el.value==="1")return el;}return null;}if(removeBtn){removeBtn.addEventListener("click",function(){clearPromo("Promo removed.",true);});}if(document.getElementById("lmBatchPromoToggle")){document.getElementById("lmBatchPromoToggle").addEventListener("click",function(){var panel=document.getElementById("lmBatchPromoPanel");var isOpen=!!(panel&&panel.style.display!=="none");setPromoPanelOpen(!isOpen);});}if(codeInput){codeInput.addEventListener("keydown",function(e){if(e.key==="Enter"){e.preventDefault();if(applyBtn&&!applyBtn.disabled)applyBtn.click();}});}if(applyBtn){applyBtn.addEventListener("click",function(){var code=(codeInput&&codeInput.value?codeInput.value:"").trim();if(!code){if(codeInput)codeInput.focus();setMessage("error","Enter a promo code.");return;}var fd=new FormData();fd.append("option","com_leadmarket");fd.append("task","applypromo");fd.append("context_type","batch");fd.append("selected_ids_csv",selectedField?selectedField.value:"");fd.append("buyer_email",email&&email.value?email.value.trim():"");fd.append("promo_code",code);var tk=tokenInput();if(tk)fd.append(tk.name,tk.value);var old=applyBtn.textContent;applyBtn.disabled=true;applyBtn.classList.add("isLoading");applyBtn.textContent="Applying...";fetch("' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=applypromo', false), ENT_QUOTES, 'UTF-8') . '",{method:"POST",body:fd,credentials:"same-origin",headers:{"Accept":"application/json","X-Requested-With":"XMLHttpRequest"}}).then(function(r){return r.text().then(function(t){try{return JSON.parse(t);}catch(e){return {ok:false,message:"Unexpected server response. Please try again."};}});}).then(function(data){if(data&&data.ok){applySummary(data);setMessage("success",data.message||"Discount added.");}else{clearPromo();setMessage("error",data&&data.message?data.message:"Promo code could not be applied.");}}).catch(function(){setMessage("error","Connection error. Please try again.");}).finally(function(){applyBtn.disabled=false;applyBtn.classList.remove("isLoading");applyBtn.textContent=old;});});}var submitBtn=document.getElementById("lmBatchSummarySubmit");if(form&&submitBtn&&!submitBtn.disabled){form.addEventListener("submit",function(){submitBtn.disabled=true;submitBtn.innerHTML="<span class=\"spinner\"></span>Checking Selection...";});}})();</script>';
        if (($showResend || $summaryNotice !== '') && $buyerEmailValue !== '') {
          echo '<form action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=access.requestlink'), ENT_QUOTES, 'UTF-8') . '" method="post" style="margin-top:10px">' . JHtml::_('form.token') . '<input type="hidden" name="buyer_email" value="' . htmlspecialchars($buyerEmailValue, ENT_QUOTES, 'UTF-8') . '"><input type="hidden" name="return_url" value="' . htmlspecialchars('index.php?option=com_leadmarket&view=batch&selected=' . urlencode(implode(',', $selectedCsv)) . '&buyer_email=' . urlencode($buyerEmailValue), ENT_QUOTES, 'UTF-8') . '"><button type="submit" class="btn" style="width:100%">Send Buyer Access Link</button></form>';
          if ($showResend) echo '<form action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=resendbatchaccesslinks'), ENT_QUOTES, 'UTF-8') . '" method="post" style="margin-top:10px">' . JHtml::_('form.token') . '<input type="hidden" name="selected_ids_csv" value="' . htmlspecialchars(implode(',', $selectedCsv), ENT_QUOTES, 'UTF-8') . '"><input type="hidden" name="buyer_email" value="' . htmlspecialchars($buyerEmailValue, ENT_QUOTES, 'UTF-8') . '"><button type="submit" class="btnGhost" style="width:100%;color:#0c5585">Send Access Links Again</button></form>';
        }
      }
      echo '</aside></div>';
    } else {
      if ($accessDenied) {
        echo '<div class="err">Access denied. This shared checkout requires a valid secure token.</div>';
      } else {
        $status = strtolower((string)($batch['status'] ?? 'pending'));
        $paymentStatus = strtolower((string)($batch['payment_status'] ?? 'unverified'));
        $secureBatchUrl = LeadMarketHelper::buildAbsoluteBatchUrl((int)$batch['id'], LeadMarketHelper::ensureBatchToken($batch));
        $sessionNotice = (string)JFactory::getSession()->get('lm.batch_removed_notice', '', 'com_leadmarket');
        JFactory::getSession()->clear('lm.batch_removed_notice', 'com_leadmarket');
        echo '<div class="hero"><h1 class="h1">Shared Batch Checkout</h1><p class="muted">Complete one shared payment to unlock all selected leads in this checkout set. Availability is rechecked before final confirmation.</p></div>';
        if ($sessionNotice !== '') echo '<div class="warn" style="margin:0 0 16px">' . htmlspecialchars($sessionNotice, ENT_QUOTES, 'UTF-8') . '</div>';
        echo '<div class="grid"><div>';
        foreach ($items as $row) {
          $lead = $row['lead'];
          $masked = LeadMarketHelper::buildMaskedPreview($lead);
          $title = LeadMarketHelper::formatLeadTitle($lead);
          $loc = trim($masked['city'] . ', ' . $masked['state'] . ' ' . $masked['zip']);
          echo '<div class="card"><div class="title">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</div><div class="meta">' . htmlspecialchars($loc, ENT_QUOTES, 'UTF-8') . ' • ' . htmlspecialchars((string)$masked['phone_masked'], ENT_QUOTES, 'UTF-8') . '</div><div class="miniGrid"><div class="info"><span class="label">Shared price</span><strong>from $' . htmlspecialchars(number_format((float)$row['price'], 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div><div class="info"><span class="label">Availability</span><span>' . htmlspecialchars(LeadMarketHelper::getBuyerAvailabilityLabel($lead), ENT_QUOTES, 'UTF-8') . '</span></div></div></div>';
        }
        echo '</div><aside class="side"><h3 style="margin:0 0 8px;font-size:20px;color:#0c5585">Checkout status</h3><p style="margin:0 0 12px;color:#51626d;line-height:1.7;font-size:14px">Batch ID <b>' . (int)$batch['id'] . '</b> for <b>' . htmlspecialchars((string)$batch['buyer_email'], ENT_QUOTES, 'UTF-8') . '</b>.</p>';
        if (!empty($batch['promo_code']) || (float)($batch['promo_discount_amount'] ?? 0) > 0) {
          $promoSubtotalFast = (float)($batch['subtotal_before_discount'] ?? ($batch['amount_usd'] ?? 0));
          $promoDiscountFast = (float)($batch['promo_discount_amount'] ?? 0);
          $promoFinalFast = (float)($batch['total_after_discount'] ?? ($batch['amount_usd'] ?? 0));
          echo '<div class="lmPromoInlineCard"><div class="lmPromoSummaryHead"><span class="lmPromoBadge">Discount summary</span><span class="lmPromoBadge lmPromoBadgeSoft">' . htmlspecialchars((string)($batch['promo_code'] ?? ''), ENT_QUOTES, 'UTF-8') . '</span></div><div class="lmPromoInlineGrid"><div>Subtotal<strong>$' . htmlspecialchars(number_format($promoSubtotalFast, 2, '.', ','), ENT_QUOTES, 'UTF-8') . '</strong></div><div>Discount<strong>$' . htmlspecialchars(number_format($promoDiscountFast, 2, '.', ','), ENT_QUOTES, 'UTF-8') . '</strong></div><div>Final total<strong>$' . htmlspecialchars(number_format($promoFinalFast, 2, '.', ','), ENT_QUOTES, 'UTF-8') . '</strong></div></div></div>';
        }
        if ($status === 'paid') {
          echo '<div class="notice">Payment confirmed. Selected shared lead access is now available below.</div>';
          $paidRows = array();
          foreach ($items as $__row) {
            $item = $__row['order'];
            if (strtolower((string)($item['status'] ?? '')) === 'paid' && strtolower((string)($item['payment_status'] ?? '')) === 'confirmed') $paidRows[] = $__row;
          }
          $paidBatchOrderIds = array();
          foreach ($paidRows as $__row) {
            $paidBatchOrderIds[] = (int) ($__row['order']['id'] ?? 0);
          }
          $creditWindowHours = (int) LeadMarketHelper::creditRequestWindowHours();
          $creditReasonOptions = LeadMarketHelper::getCreditRequestReasonOptions();
          $paidBatchCreditMap = LeadMarketHelper::getBuyerCreditRequestMap($paidBatchOrderIds, (string) ($batch['buyer_email'] ?? ''));
          $buyerActionToken = '';
          $rememberedBuyerToken = LeadMarketHelper::getRememberedBuyerAccessToken();
          $rememberedBuyerAccess = $rememberedBuyerToken !== '' ? LeadMarketHelper::validateBuyerAccessToken($rememberedBuyerToken) : false;
          if ($rememberedBuyerAccess && strtolower((string) ($rememberedBuyerAccess['buyer_email'] ?? '')) === strtolower((string) ($batch['buyer_email'] ?? ''))) {
            $buyerActionToken = $rememberedBuyerToken;
          } else {
            $createdBuyerAccess = LeadMarketHelper::createBuyerAccessRequest((string) ($batch['buyer_email'] ?? ''));
            if (!empty($createdBuyerAccess['token_row']['access_token'])) {
              $buyerActionToken = (string) $createdBuyerAccess['token_row']['access_token'];
            } elseif (!empty($createdBuyerAccess['access_token'])) {
              $buyerActionToken = (string) $createdBuyerAccess['access_token'];
            }
            if ($buyerActionToken !== '') {
              LeadMarketHelper::rememberBuyerAccessToken($buyerActionToken);
            }
          }
          $batchReturnBase = JRoute::_(LeadMarketHelper::buildBatchUrl((int) $batch['id'], LeadMarketHelper::ensureBatchToken($batch)), false);
          $batchReturnSep = (strpos($batchReturnBase, '?') === false) ? '?' : '&';
          echo '<div style="margin:0 0 12px;padding:12px;border:1px solid #e5edf4;border-radius:12px;background:#fbfdff"><div style="font-size:13px;font-weight:800;color:#607080;text-transform:uppercase;letter-spacing:.03em;margin:0 0 10px">Lead actions</div>';
          foreach ($paidRows as $idx => $__row) {
            $item = $__row['order'];
            $lead = $__row['lead'];
            $orderId = (int) ($item['id'] ?? 0);
            $leadUrl = JRoute::_(LeadMarketHelper::buildLeadUrl((int)$item['lead_id'], $orderId, LeadMarketHelper::ensureOrderToken($item)), false);
            $itemCreditMeta = (array) ($paidBatchCreditMap[$orderId] ?? array());
            $hasCreditMeta = !empty($itemCreditMeta);
            $creditTarget = 'batch-credit-box-' . $orderId;
            $creditOpenUrl = $batchReturnBase . $batchReturnSep . 'show_credit_order=' . $orderId . '#' . $creditTarget;
            $creditIsOpen = ((int) $showCreditOrderId === $orderId);
            echo '<div style="display:flex;justify-content:space-between;gap:10px;align-items:flex-start;flex-wrap:wrap' . ($idx < count($paidRows)-1 ? ';margin-bottom:10px;padding-bottom:10px;border-bottom:1px solid #edf2f7' : '') . '"><div><div style="font-weight:800;color:#13232f">' . htmlspecialchars(LeadMarketHelper::formatLeadTitle($lead), ENT_QUOTES, 'UTF-8') . '</div><div style="color:#61717f;font-size:14px;line-height:1.5">Open the paid lead or request a credit review.</div></div><div style="display:flex;gap:8px;flex-wrap:wrap"><a class="btnGhost" rel="nofollow" href="' . htmlspecialchars($leadUrl, ENT_QUOTES, 'UTF-8') . '">Open lead</a><a class="btnGhost lm-js-fast-batch-credit-link" rel="nofollow" href="' . htmlspecialchars($creditOpenUrl, ENT_QUOTES, 'UTF-8') . '" data-target="' . htmlspecialchars($creditTarget, ENT_QUOTES, 'UTF-8') . '">Request credit</a></div></div>';
            echo '<div id="' . htmlspecialchars($creditTarget, ENT_QUOTES, 'UTF-8') . '" style="display:' . ($creditIsOpen ? 'block' : 'none') . ';margin:10px 0 0;padding:14px;border:1px solid #e5edf4;border-radius:12px;background:#fbfdff">';
            echo '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 0 8px"><div style="font-size:14px;font-weight:800;color:#13232f">Lead review / credit request</div><div style="font-size:12px;color:#61717f;line-height:1.45">Opens only when needed</div></div>';
            echo '<p style="margin:0 0 10px;color:#61717f;line-height:1.6;font-size:13px">Use this only for verified data-quality issues. The review window is limited to ' . (int) $creditWindowHours . ' hours after purchase.</p>';
            if (!empty($itemCreditMeta['existing'])) {
              $req = $itemCreditMeta['existing'];
              $reqStatus = $itemCreditMeta['status_meta'] ?? array('label' => 'Submitted', 'tone' => 'warn');
              $tone = (string) ($reqStatus['tone'] ?? 'warn');
              $bg = $tone === 'ok' ? '#eaf7ef' : ($tone === 'danger' ? '#fff1f1' : '#fff8e6');
              $bd = $tone === 'ok' ? '#cfe8d8' : ($tone === 'danger' ? '#f1caca' : '#f0ddad');
              echo '<div style="padding:10px 12px;border:1px solid ' . $bd . ';border-radius:12px;background:' . $bg . '"><div style="font-weight:700;color:#13232f">' . htmlspecialchars((string) ($reqStatus['label'] ?? 'Submitted'), ENT_QUOTES, 'UTF-8') . '</div><div style="margin-top:8px;color:#61717f;font-size:13px;line-height:1.55">Reason: ' . htmlspecialchars(lmBuyerCreditReasonLabel((string) ($req['reason_code'] ?? ''), $creditReasonOptions), ENT_QUOTES, 'UTF-8');
              if ((string) ($req['status'] ?? '') === 'approved' && (float) ($req['approved_amount'] ?? 0) > 0) {
                echo ' · Approved — $' . htmlspecialchars(number_format((float) ($req['approved_amount'] ?? 0), 2, '.', ','), ENT_QUOTES, 'UTF-8') . ' credited to your balance';
              }
              echo '</div>';
              if (!empty($req['buyer_note'])) echo '<div style="margin-top:6px;color:#61717f;font-size:13px;line-height:1.55">Your note: ' . nl2br(htmlspecialchars((string) $req['buyer_note'], ENT_QUOTES, 'UTF-8')) . '</div>';
              if (!empty($req['admin_note']) && (string) ($req['status'] ?? '') === 'declined') echo '<div style="margin-top:6px;color:#61717f;font-size:13px;line-height:1.55">Review note: ' . nl2br(htmlspecialchars((string) $req['admin_note'], ENT_QUOTES, 'UTF-8')) . '</div>';
              echo '</div>';
            } elseif (!empty($itemCreditMeta['can_request']) && $buyerActionToken !== '') {
              echo '<form class="lm-js-credit-submit-form" action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket', false), ENT_QUOTES, 'UTF-8') . '" method="post">' . JHtml::_('form.token') . '<input type="hidden" name="task" value="creditrequestsubmit"><input type="hidden" name="buyer_token" value="' . htmlspecialchars($buyerActionToken, ENT_QUOTES, 'UTF-8') . '"><input type="hidden" name="order_id" value="' . $orderId . '"><input type="hidden" name="return_url" value="' . htmlspecialchars($creditOpenUrl, ENT_QUOTES, 'UTF-8') . '"><label for="batch-credit-reason-' . $orderId . '" style="display:block;margin:0 0 6px;font-weight:700">Reason</label><select id="batch-credit-reason-' . $orderId . '" name="reason_code" required style="display:block;width:100%;min-height:46px;padding:0 12px;border:1px solid #cfd9e3;border-radius:12px;box-sizing:border-box;margin-bottom:10px">';
              foreach ($creditReasonOptions as $reasonCode => $reasonLabel) {
                echo '<option value="' . htmlspecialchars($reasonCode, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($reasonLabel, ENT_QUOTES, 'UTF-8') . '</option>';
              }
              echo '</select><label for="batch-credit-note-' . $orderId . '" style="display:block;margin:0 0 6px;font-weight:700">Comment</label><textarea id="batch-credit-note-' . $orderId . '" name="buyer_note" rows="3" placeholder="Add a short explanation for the review team." style="display:block;width:100%;padding:12px;border:1px solid #cfd9e3;border-radius:12px;box-sizing:border-box;margin-bottom:10px"></textarea><button type="submit" class="btnGhost" style="width:100%">Request Credit</button></form>';
            } else {
              $msg = $hasCreditMeta ? (string) ($itemCreditMeta['message'] ?? ('Review window closed. Credit requests must be submitted within ' . (int) $creditWindowHours . ' hours of purchase.')) : 'Review availability is loading. Refresh and try again.';
              echo '<div style="color:#61717f;font-size:13px;line-height:1.6">' . htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') . '</div>';
            }
            echo '</div>';
          }
          echo '</div>';
          echo '<script>(function(){var links=document.querySelectorAll(".lm-js-fast-batch-credit-link");for(var i=0;i<links.length;i++){links[i].addEventListener("click",function(ev){var targetId=this.getAttribute("data-target");var box=targetId?document.getElementById(targetId):null;if(!box)return;ev.preventDefault();var all=document.querySelectorAll("[id^=batch-credit-box-]");for(var j=0;j<all.length;j++){all[j].style.display="none";}box.style.display="block";setTimeout(function(){try{box.scrollIntoView({behavior:"smooth",block:"nearest"});}catch(e){}},10);});}var forms=document.querySelectorAll(".lm-js-credit-submit-form");for(var f=0;f<forms.length;f++){forms[f].addEventListener("submit",function(){var task=this.querySelector("input[name=task]");if(task)task.value="creditrequestsubmit";this.action="' . rtrim(JUri::root(), '/') . '/index.php?option=com_leadmarket&task=creditrequestsubmit' . '";});}})();</script>';
        } else {
          $batchPricing = LeadMarketHelper::getBatchPricingForBuyer((int)$batch['id'], (string)$batch['buyer_email']);
          $batchTotalUsd = (float)($batchPricing['recalculated_total_usd'] ?? ($batch['amount_usd'] ?? 0));
          $batchCurrentBalance = LeadMarketHelper::getBuyerBalance((string)$batch['buyer_email']);
          $batchRoute = LeadMarketHelper::determinePurchaseRoute('batch', (int)$batch['id'], (string)$batch['buyer_email']);
          $routeKey = (string)($batchRoute['route'] ?? 'topup_required');
          $minimumTransfer = (float)LeadMarketHelper::minimumTopupUsd();
          $batchAppliedFromWallet = (float)($batchRoute['applied_from_balance'] ?? LeadMarketHelper::calculateAppliedFromWallet($batchTotalUsd, $batchCurrentBalance));
          $batchRemainingShortage = (float)($batchRoute['amount_needed'] ?? LeadMarketHelper::calculateWalletShortage($batchTotalUsd, $batchCurrentBalance));
          $batchWalletLeftAfterUnlock = max(0, $batchCurrentBalance - $batchTotalUsd);
          $batchTopupOptions = !empty($batchRoute['suggested_topups']) ? (array)$batchRoute['suggested_topups'] : LeadMarketHelper::getSuggestedTopupOptions($batchTotalUsd, $batchCurrentBalance, 'batch');
          $batchSuggestedTopup = (float)($batchTopupOptions['recommended_amount'] ?? LeadMarketHelper::calculateSuggestedTopup($batchTotalUsd, $batchCurrentBalance));
          $batchExactTransferAmount = (float)($batch['expected_amount'] ?? 0);
          if ($batchExactTransferAmount <= 0 && $routeKey === 'direct_or_topup') $batchExactTransferAmount = $batchRemainingShortage;
          echo '<div class="miniGrid" style="margin:0 0 12px"><div class="info"><span class="label">Lead count</span><strong>' . count($items) . '</strong></div><div class="info"><span class="label">Final batch value</span><strong>' . htmlspecialchars(number_format($batchTotalUsd, 2, '.', ''), ENT_QUOTES, 'UTF-8') . ' USD</strong></div></div>';
          echo '<div class="miniGrid" style="margin:0 0 12px"><div class="info"><span class="label">Wallet balance before</span><strong>$' . htmlspecialchars(number_format($batchCurrentBalance, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div><div class="info"><span class="label">Applied from wallet</span><strong>$' . htmlspecialchars(number_format($batchAppliedFromWallet, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div><div class="info"><span class="label">Remaining shortage</span><strong>$' . htmlspecialchars(number_format($batchRemainingShortage, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div><div class="info"><span class="label">Wallet left after unlock</span><strong>$' . htmlspecialchars(number_format($batchWalletLeftAfterUnlock, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '</strong></div></div>';
          if ($routeKey === 'balance_only') {
            echo '<div class="notice" style="margin:0 0 12px">This buyer wallet already covers the full batch. No external transfer is needed.</div>';
            echo '<form action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=batchunlockbalance'), ENT_QUOTES, 'UTF-8') . '" method="post" style="margin-bottom:10px">' . JHtml::_('form.token') . '<input type="hidden" name="batch_id" value="' . (int)$batch['id'] . '"><input type="hidden" name="token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '"><button type="submit" class="btn" style="width:100%;background:#1f6b35">Unlock Batch Using Balance</button></form>';
          } elseif ($routeKey === 'topup_required') {
            if ($batchRemainingShortage < $minimumTransfer) {
              echo '<div class="warn" style="margin:0 0 12px">Your wallet applies first. The remaining shortage is below the minimum direct transfer of $' . htmlspecialchars(number_format($minimumTransfer, 2, '.', ''), ENT_QUOTES, 'UTF-8') . ', so this batch must continue through a linked top-up.</div>';
            } else {
              echo '<div class="warn" style="margin:0 0 12px">Your wallet is used first. This batch continues through a linked top-up. The extra balance stays in your wallet for the next purchase.</div>';
            }
            echo '<form action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=batchcreatelinkedtopup'), ENT_QUOTES, 'UTF-8') . '" method="post" style="margin-bottom:10px" id="lmBatchFundingForm">' . JHtml::_('form.token') . '<input type="hidden" name="batch_id" value="' . (int)$batch['id'] . '"><input type="hidden" name="token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '"><input type="hidden" name="payment_method" id="lm_batch_payment_method" value="crypto"><label style="display:block;margin:0 0 6px;font-weight:700" for="lm_batch_topup_amount">Recommended top-up (USD)</label><input id="lm_batch_topup_amount" name="topup_amount_usd" type="number" step="0.01" min="' . htmlspecialchars(number_format(LeadMarketHelper::topupCustomMinimumUsd(), 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars(number_format($batchSuggestedTopup, 2, '.', ''), ENT_QUOTES, 'UTF-8') . '" style="display:block;width:100%;min-height:46px;padding:0 12px;border:1px solid #cfd9e3;border-radius:12px;box-sizing:border-box;margin-bottom:12px"><div class="lmPayMethods" id="lmBatchFundingMethods"><button type="button" class="lmPayMethod active" data-method="crypto"><span class="lmPayMethodTitle">Crypto</span><span class="lmPayMethodMeta">Use the current secure crypto top-up flow.</span></button><button type="button" class="lmPayMethod" data-method="moneygram" data-min="' . htmlspecialchars(number_format(LeadMarketHelper::moneygramMinimumUsd(), 2, '.', ''), ENT_QUOTES, 'UTF-8') . '"><span class="lmPayMethodTitle">Western Union</span><span class="lmPayMethodMeta">Manual wallet top-up. Visible always, active from $' . htmlspecialchars(number_format(LeadMarketHelper::moneygramMinimumUsd(), 2, '.', ','), ENT_QUOTES, 'UTF-8') . '.</span></button></div><div class="lmPayMethodNote" id="lmBatchFundingNote">Crypto is selected. Western Union becomes available once the top-up amount reaches $' . htmlspecialchars(number_format(LeadMarketHelper::moneygramMinimumUsd(), 2, '.', ','), ENT_QUOTES, 'UTF-8') . '.</div><button type="submit" class="btn" style="width:100%;margin-top:10px" id="lmBatchFundingSubmit">Create Linked Top-up</button></form>';
            echo '<script>(function(){var input=document.getElementById("lm_batch_topup_amount");var hidden=document.getElementById("lm_batch_payment_method");var note=document.getElementById("lmBatchFundingNote");var submit=document.getElementById("lmBatchFundingSubmit");var cards=document.querySelectorAll("#lmBatchFundingMethods .lmPayMethod");var mgMin=' . htmlspecialchars(number_format(LeadMarketHelper::moneygramMinimumUsd(), 2, '.', ''), ENT_QUOTES, 'UTF-8') . ';function sync(){var amount=input?parseFloat(input.value||"0"):0;if(!isFinite(amount))amount=0;var selected=hidden&&hidden.value?hidden.value:"crypto";for(var i=0;i<cards.length;i++){var card=cards[i];var method=card.getAttribute("data-method")||"crypto";var min=parseFloat(card.getAttribute("data-min")||"0");var allowed=(method!=="moneygram")||amount>=min;if(method===selected&&!allowed){selected="crypto";if(hidden)hidden.value="crypto";}card.classList[allowed?"remove":"add"]("disabled");card.classList[(method===selected&&allowed)?"add":"remove"]("active");}if(note){if(hidden&&hidden.value==="moneygram"&&amount>=mgMin)note.textContent="Western Union is selected. The checkout summary stays the same; after submit, the secure request page will show receiver details and the MTCN / reference form.";else if(amount<mgMin)note.textContent="Crypto is selected. Western Union stays visible but activates only from $"+mgMin.toFixed(2)+".";else note.textContent="Crypto is selected. You can switch to Western Union for a manual top-up if you prefer.";}if(submit){submit.textContent=(hidden&&hidden.value==="moneygram")?"Create Western Union request":"Create Linked Top-up";}}for(var i=0;i<cards.length;i++){cards[i].addEventListener("click",function(){if(!hidden)return;var method=this.getAttribute("data-method")||"crypto";var min=parseFloat(this.getAttribute("data-min")||"0");var amount=input?parseFloat(input.value||"0"):0;if(method==="moneygram"&&amount<min){sync();return;}hidden.value=method;sync();});}if(input){input.addEventListener("input",sync);}sync();})();</script>';
          } else {
            echo '<div class="info" style="margin:0 0 12px"><p style="margin:0 0 8px;line-height:1.6"><b>USDT TRC20 Address:</b></p><div class="copyRow" style="margin:0 0 10px"><span id="lmBatchAddress" class="copyText">' . ($address !== '' ? htmlspecialchars($address, ENT_QUOTES, 'UTF-8') : 'Address not configured') . '</span><button type="button" class="copyBtn" data-copy="#lmBatchAddress">Copy</button></div><p style="margin:0 0 8px;line-height:1.6"><b>Exact transfer amount:</b> ' . htmlspecialchars(number_format($batchExactTransferAmount, 2, '.', ''), ENT_QUOTES, 'UTF-8') . ' USDT<br><b>Expires (UTC):</b> ' . htmlspecialchars((string)($batch['expires_at_utc'] ?? ''), ENT_QUOTES, 'UTF-8') . '<br><b>Payment status:</b> ' . htmlspecialchars($paymentStatus, ENT_QUOTES, 'UTF-8') . '</p><p style="margin:0 0 8px;line-height:1.6"><b>Secure access:</b><br><span style="word-break:break-all">' . htmlspecialchars($secureBatchUrl, ENT_QUOTES, 'UTF-8') . '</span></p></div>';
            if ($paymentStatus === 'matched') echo '<div class="notice">Payment detected and matched. All selected shared leads will unlock automatically after confirmation.</div>';
            elseif ($status === 'submitted' || $paymentStatus === 'checking') echo '<div class="warn">Payment has been marked as sent. We are checking the batch transfer now. This page refreshes automatically until access is unlocked.</div>';
            $checking = ($status === 'submitted' || $paymentStatus === 'checking' || $paymentStatus === 'matched');
            $btnText = $checking ? '<span class="spinner"></span>Checking Payment...' : 'I Paid';
            $btnDisabled = $checking ? ' disabled="disabled"' : '';
            echo '<form action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=batchipaid'), ENT_QUOTES, 'UTF-8') . '" method="post" style="margin-bottom:10px" id="lmBatchPaidForm">' . JHtml::_('form.token') . '<input type="hidden" name="batch_id" value="' . (int)$batch['id'] . '"><input type="hidden" name="token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '"><button type="submit" class="btn" style="width:100%" id="lmBatchPaidBtn"' . $btnDisabled . '>' . $btnText . '</button></form>';
          }
          echo '<form action="' . htmlspecialchars(JRoute::_('index.php?option=com_leadmarket&task=cancelbatch'), ENT_QUOTES, 'UTF-8') . '" method="post">' . JHtml::_('form.token') . '<input type="hidden" name="batch_id" value="' . (int)$batch['id'] . '"><input type="hidden" name="token" value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '"><button type="submit" class="btnGhost" style="width:100%">Cancel checkout</button></form>';
          echo '<script>(function(){var copyBtns=document.querySelectorAll("[data-copy]");for(var i=0;i<copyBtns.length;i++){copyBtns[i].addEventListener("click",function(){var el=document.querySelector(this.getAttribute("data-copy"));if(!el)return;var txt=(el.innerText||el.textContent||"").trim();if(!txt)return;if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt);}else{var ta=document.createElement("textarea");ta.value=txt;document.body.appendChild(ta);ta.select();try{document.execCommand("copy");}catch(e){}document.body.removeChild(ta);}var old=this.textContent;this.textContent="Copied";var btn=this;setTimeout(function(){btn.textContent=old;},1400);});}var paidForm=document.getElementById("lmBatchPaidForm");var paidBtn=document.getElementById("lmBatchPaidBtn");if(paidForm&&paidBtn&&!paidBtn.disabled){paidForm.addEventListener("submit",function(){paidBtn.disabled=true;paidBtn.innerHTML="<span class=\"spinner\"></span>Checking Payment...";});}';
          if ($status === 'submitted' || $paymentStatus === 'checking' || $paymentStatus === 'matched') {
            echo 'function lmBatchPoll(){var url=new URL(window.location.href);url.searchParams.set("_lmts", String(Date.now()));window.location.replace(url.toString());}setTimeout(lmBatchPoll,10000);';
          }
          echo '})();</script>';
        }
        echo '</aside></div>';
      }
    }
    echo '<script>(function(){var loader=document.getElementById("lm-widget-loader");if(loader){loader.style.display="none";}})();</script>';
    echo '</div></body></html>';
  } catch (Exception $e) {
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    echo 'batch_error: ' . $e->getMessage();
  } catch (Error $e) {
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    echo 'batch_error: ' . $e->getMessage();
  }
  $app->close();
}

if (in_array($taskNormalized, array('widgetmarket', 'widgetmarketmini'), true)) {
  require_once JPATH_COMPONENT . '/helpers/leadmarket.php';
  $app = JFactory::getApplication();
  try {
    LeadMarketHelper::ensureSchema();
    $params = LeadMarketHelper::params();
    $forceMini = ($taskNormalized === 'widgetmarketmini');
    $layoutRaw = strtolower((string)$input->get('layout', '', 'raw'));
    $mini = $forceMini || $layoutRaw === 'mini';
    $limitDefault = $mini ? max(1, (int)$params->get('mini_widget_limit', 5)) : 10;
    $hoursDefault = max(1, (int)$params->get('mini_widget_hours', 25));
    $limit = max(1, min($mini ? 12 : 50, (int)$input->getInt('limit', $limitDefault)));
    $hours = max(1, min(168, (int)$input->getInt('hours', $hoursDefault)));
    $titleDefault = trim((string)$params->get('mini_widget_title', 'Latest Lead Activity'));
    if ($titleDefault === '') $titleDefault = 'Latest Lead Activity';
    $title = trim((string)$input->getString('title', $titleDefault));
    if ($title === '') $title = $titleDefault;

    $marketUrl = LeadMarketHelper::getMarketplaceUrl(false);
    $embed = (int)$input->getInt('embed', 0) === 1;
    $linkTargetAttr = $embed ? ' target="_top"' : '';

    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/html; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    echo '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex, nofollow">';
    echo '<style>';
    echo 'body{margin:0;font-family:Arial,sans-serif;background:' . ($embed ? 'transparent' : '#f6f9fc') . ';color:#13232f}';
    echo '.lm-wrap{padding:' . ($embed ? '0' : ($mini ? '8px' : '18px')) . ';box-sizing:border-box;position:relative}';
    echo '.lm-head{display:flex;justify-content:space-between;align-items:flex-end;gap:12px;margin:0 0 ' . ($embed ? '0' : '12px') . '}';
    echo '.lm-title{font-size:' . ($mini ? '16px' : '28px') . ';font-weight:800;color:#0c5585;margin:0;letter-spacing:-.01em}';
    echo '.lm-meta{font-size:12px;color:#607080;margin-top:2px}';
    echo '.lm-offer{display:flex;align-items:center;gap:8px;flex-wrap:wrap;background:#fff8ef;border:1px solid #eadfc7;border-radius:12px;padding:' . ($mini ? '8px 10px' : '9px 12px') . ';margin:0 0 12px;color:#6a5621;line-height:1.5;font-size:' . ($mini ? '12px' : '13px') . ';font-weight:600}';
    echo '.lm-offer__badge{display:inline-block;background:#fff;border:1px solid #eadfc7;color:#9a6711;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.03em}';
    echo '.lm-loading{display:flex;align-items:flex-start;gap:12px;background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:' . ($mini ? '12px' : '16px') . ';box-shadow:0 4px 16px rgba(12,85,133,.06);margin:0 0 ' . ($mini ? '8px' : '12px') . '}';
    echo '.lm-loading__spinner{width:18px;height:18px;border-radius:50%;border:2px solid #cfe0ec;border-top-color:#0c5585;animation:lmspin .8s linear infinite;flex:0 0 auto;margin-top:2px}';
    echo '.lm-loading__text{min-width:0}';
    echo '.lm-loading__title{font-size:' . ($mini ? '13px' : '15px') . ';font-weight:800;color:#0c5585;margin:0 0 5px}';
    echo '.lm-loading__sub{font-size:12px;color:#61717f;line-height:1.5;margin:0 0 10px}';
    echo '.lm-skeleton{display:grid;grid-template-columns:1fr;gap:8px}';
    echo '.lm-skeleton__line{height:10px;border-radius:999px;background:linear-gradient(90deg,#eef4f8 20%,#dfeaf2 50%,#eef4f8 80%);background-size:200% 100%;animation:lmshine 1.3s ease-in-out infinite}';
    echo '.lm-skeleton__line--short{width:42%}';
    echo '.lm-skeleton__line--mid{width:68%}';
    echo '.lm-skeleton__cards{display:grid;grid-template-columns:1fr;gap:' . ($mini ? '8px' : '10px') . ';margin-top:10px}';
    echo '.lm-skeleton__card{background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:' . ($mini ? '12px' : '14px') . ';box-shadow:0 3px 10px rgba(12,85,133,.04)}';
    echo '@keyframes lmspin{to{transform:rotate(360deg)}}';
    echo '@keyframes lmshine{0%{background-position:200% 0}100%{background-position:-200% 0}}';
    echo '.lm-list{display:grid;grid-template-columns:1fr;gap:' . ($mini ? '8px' : '14px') . '}';
    echo '.lm-card{background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:' . ($mini ? '12px' : '16px') . ';box-shadow:0 4px 16px rgba(12,85,133,.06)}';
    echo '.lm-card__head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}';
    echo '.lm-card__titlewrap{min-width:0}';
    echo '.lm-card__title{font-size:' . ($mini ? '14px' : '22px') . ';font-weight:800;margin:0 0 5px;color:#13232f;line-height:1.2}';
    echo '.lm-card__meta{font-size:' . ($mini ? '12px' : '13px') . ';color:#61717f;margin:0;line-height:1.5}';
    echo '.lm-dot{opacity:.5;padding:0 4px}';
    echo '.lm-card__badges{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}';
    echo '.lm-badge{display:inline-block;background:#eef7fd;color:#0c5585;border-radius:999px;padding:4px 8px;font-size:11px;font-weight:800;white-space:nowrap}';
    echo '.lm-status{display:inline-block;border-radius:999px;padding:4px 8px;font-size:11px;font-weight:800;white-space:nowrap;background:#f2f5f8;color:#51626d}';
    echo '.lm-status--ok{background:#e8f7ee;color:#1d7a43}';
    echo '.lm-status--warn{background:#fff4df;color:#9a6711}';
    echo '.lm-card__grid{display:grid;grid-template-columns:' . ($mini ? '1fr' : 'repeat(2,minmax(0,1fr))') . ';gap:' . ($mini ? '8px' : '12px') . ';margin-top:10px}';
    echo '.lm-card__info{background:' . ($mini ? 'transparent' : '#f8fbfd') . ';border:' . ($mini ? '0' : '1px solid #edf2f7') . ';border-radius:10px;padding:' . ($mini ? '0' : '10px 12px') . '}';
    echo '.lm-card__info--exclusive.is-available{background:#edf9f1;border-color:#cfead9}';
    echo '.lm-card__info--exclusive.is-locked{background:#fff7e8;border-color:#f0ddb6}';
    echo '.lm-card__info--exclusive.is-unavailable{background:' . ($mini ? 'transparent' : '#f8fbfd') . ';border-color:' . ($mini ? 'transparent' : '#edf2f7') . '}';
    echo '.lm-card__info-note{display:block;margin-top:4px;color:#44545e;line-height:1.45;font-size:' . ($mini ? '12px' : '14px') . ';font-weight:700}';
    echo '.lm-card--exclusive-available{border-color:#b7e3c7;box-shadow:0 0 0 3px rgba(29,122,67,.08),0 4px 16px rgba(12,85,133,.05)}';
    echo '.lm-card--exclusive-locked{border-color:#f0ddb6}';
    echo '.lm-label{display:block;font-size:11px;font-weight:800;color:#607080;letter-spacing:.02em;text-transform:uppercase;margin-bottom:4px}';
    echo '.lm-card__info strong{font-size:' . ($mini ? '13px' : '16px') . '}';
    echo '.lm-card__actions{display:flex;justify-content:flex-start;align-items:center;gap:10px;margin-top:10px}';
    echo '.lm-btn{display:inline-block;background:#0c5585;color:#fff;text-decoration:none;border-radius:9px;padding:' . ($mini ? '8px 12px' : '10px 14px') . ';font-size:' . ($mini ? '13px' : '14px') . ';font-weight:700}';
    echo '.lm-link{font-size:13px;color:#0c5585;text-decoration:none;font-weight:700}';
    echo '.lm-empty{background:#fff;border:1px solid #dbe6ef;border-radius:14px;padding:18px;color:#50616d}';
    echo '.lm-bottomcta{margin-top:' . ($mini ? '10px' : '16px') . ';text-align:center}';
    echo '.lm-market-btn{display:inline-block;background:#fff;color:#0c5585;border:1px solid #cddce8;text-decoration:none;border-radius:10px;padding:10px 16px;font-size:13px;font-weight:800}';
    echo '.lm-select{display:inline-flex;align-items:center;gap:6px;font-size:12px;font-weight:700;color:#0c5585;margin-bottom:6px}';
    echo '.lm-select__input{width:16px;height:16px}';
    echo '.lm-summary{position:sticky;top:16px;background:#ffffff;border:1px solid #dbe6ef;border-radius:14px;padding:16px;box-shadow:0 4px 16px rgba(12,85,133,.05)}';
    echo '.lm-summary__title{margin:0 0 8px;font-size:18px;color:#0c5585;font-weight:800}';
    echo '.lm-summary__meta{font-size:14px;color:#51626d;line-height:1.7;margin:0 0 12px}';
    echo '.lm-summary__actions{display:flex;gap:10px;flex-wrap:wrap}';
    echo '.lm-summary__btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 14px;border-radius:10px;text-decoration:none;font-weight:800;border:1px solid #d5e3ee;background:#0c5585;color:#fff}';
    echo '.lm-summary__btn--ghost{background:#fff;color:#44545e}';
    echo '@media (max-width:768px){.lm-card__head{flex-direction:column}.lm-card__badges{justify-content:flex-start}.lm-card__grid{grid-template-columns:1fr}}';
    echo '</style></head><body><div class="lm-wrap">';
    echo '<div id="lm-widget-loader" class="lm-loading"><div class="lm-loading__spinner" aria-hidden="true"></div><div class="lm-loading__text"><div class="lm-loading__title">Loading recent leads…</div><div class="lm-loading__sub">Fetching the latest masked marketplace activity.</div><div class="lm-skeleton"><div class="lm-skeleton__line"></div><div class="lm-skeleton__line lm-skeleton__line--mid"></div><div class="lm-skeleton__line lm-skeleton__line--short"></div></div><div class="lm-skeleton__cards"><div class="lm-skeleton__card"><div class="lm-skeleton"><div class="lm-skeleton__line"></div><div class="lm-skeleton__line lm-skeleton__line--mid"></div><div class="lm-skeleton__line lm-skeleton__line--short"></div></div></div>' . ($mini ? '' : '<div class="lm-skeleton__card"><div class="lm-skeleton"><div class="lm-skeleton__line"></div><div class="lm-skeleton__line lm-skeleton__line--mid"></div><div class="lm-skeleton__line lm-skeleton__line--short"></div></div></div>') . '</div></div></div>';
    echo str_repeat(' ', 8192);
    if (function_exists('flush')) { @flush(); }
    if (function_exists('ob_flush')) { @ob_flush(); }
    $db = JFactory::getDbo();
    $start = LeadMarketHelper::nowUtc();
    $start->modify('-' . $hours . ' hours');
    $q = $db->getQuery(true)
      ->select('*')
      ->from('#__leadmarket_leads')
      ->where('uploaded_at_utc >= ' . $db->q($start->format('Y-m-d H:i:s')))
      ->where('lead_status IN (' . $db->q('fresh') . ',' . $db->q('aged') . ')')
      ->where('COALESCE(is_sample,0)=0')
      ->order('uploaded_at_utc DESC, id DESC');
    $db->setQuery($q, 0, $limit);
    $leads = (array)$db->loadAssocList();
    echo LeadMarketHelper::renderOpeningPromoBar('lm-offer', 'lm-offer__badge');
    if (!$embed) {
      echo '<div class="lm-head"><div><h1 class="lm-title">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</h1><div class="lm-meta">Latest masked leads from the last ' . (int)$hours . ' hours</div></div>';
      if (!$mini) echo '<a class="lm-link" href="' . htmlspecialchars($marketUrl, ENT_QUOTES, 'UTF-8') . '">Open Marketplace</a>';
      echo '</div>';
    }
    if (!$leads) {
      echo '<div class="lm-empty">No recent masked leads available right now.</div>';
    } else {
      echo '<div class="lm-list">';
      foreach ($leads as $lead) {
        echo LeadMarketHelper::renderBuyerLeadCard($lead, array(
          'mini' => $mini,
          'show_exclusive' => !$mini,
          'show_marketplace_link' => false,
          'market_url' => $marketUrl,
          'link_target' => ($embed ? '_top' : ''),
        ));
      }
      echo '</div>';
      echo '<div class="lm-bottomcta"><a class="lm-market-btn" href="' . htmlspecialchars($marketUrl, ENT_QUOTES, 'UTF-8') . '"' . $linkTargetAttr . '>Open Marketplace</a></div>';
    }
    echo '<script>(function(){var loader=document.getElementById("lm-widget-loader");if(loader){loader.style.display="none";}})();</script>';
    echo '</div></body></html>';
  } catch (Exception $e) {
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    echo 'widget_error: ' . $e->getMessage();
  } catch (Error $e) {
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    echo 'widget_error: ' . $e->getMessage();
  }
  $app->close();
}

if (in_array($taskNormalized, array('apireceive', 'apicrondailydigest'), true)) {
  require_once JPATH_COMPONENT . '/controllers/api.php';
  $app = JFactory::getApplication();
  try {
    $controller = new LeadMarketControllerApi();
    if ($taskNormalized === 'apireceive') {
      $controller->receive();
    } else {
      $controller->cronDailyDigest();
    }
  } catch (Exception $e) {
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    echo 'api_error: ' . $e->getMessage();
  } catch (Error $e) {
    while (ob_get_level()) { @ob_end_clean(); }
    header('Content-Type: text/plain; charset=utf-8');
    echo 'api_error: ' . $e->getMessage();
  }
  $app->close();
}


if (in_array($taskNormalized, array('subscribeadd', 'subscribesave', 'subscribe'), true)) {
  require_once JPATH_COMPONENT . '/controller.php';
  $controller = new LeadMarketController();
  $controller->subscribeAdd();
  $controller->redirect();
  JFactory::getApplication()->close();
}

if (in_array($taskNormalized, array('leadunsubscribe', 'unsubscribe'), true)) {
  require_once JPATH_COMPONENT . '/controllers/lead.php';
  $controller = new LeadMarketControllerLead();
  $controller->unsubscribe();
  $controller->redirect();
  JFactory::getApplication()->close();
}

if ($taskNormalized === 'creditrequestsubmit') {
  require_once JPATH_COMPONENT . '/controller.php';
  $controller = new LeadMarketController();
  $controller->creditRequestSubmit();
  JFactory::getApplication()->close();
}

if (in_array($taskNormalized, array('freetestunlock', 'freetestmarketplaceclick'), true)) {
  require_once JPATH_COMPONENT . '/controller.php';
  $controller = new LeadMarketController();
  if ($taskNormalized === 'freetestunlock') {
    $controller->freeTestUnlock();
  } else {
    $controller->freeTestMarketplaceClick();
  }
  $controller->redirect();
  JFactory::getApplication()->close();
}

if (in_array($taskNormalized, array('crondigest', 'cronverify', 'croncheckpayments'), true)) {
  require_once JPATH_COMPONENT . '/controller.php';
  $controller = new LeadMarketController();
  switch ($taskNormalized) {
    case 'crondigest': $controller->cronDigest(); break;
    case 'cronverify':
    case 'croncheckpayments': $controller->cronVerify(); break;
  }
  JFactory::getApplication()->close();
}

$controller = JControllerLegacy::getInstance('LeadMarket');
$controller->execute($task);
$controller->redirect();
