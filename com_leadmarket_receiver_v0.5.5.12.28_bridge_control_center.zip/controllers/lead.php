<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/helpers/leadmarket.php';

class LeadMarketControllerLead extends JControllerLegacy
{
    public function unsubscribe()
    {
        $app = JFactory::getApplication();
        $input = $app->input;
        $email = trim((string)$input->getString('email', ''));
        $token = LeadMarketHelper::readBuyerAccessTokenFromRequest();

        try {
            $db = JFactory::getDbo();
            $q = $db->getQuery(true)
                ->select('*')
                ->from('#__leadmarket_subscribers');

            $where = array();
            $hasEmail = ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL));
            if ($token !== '' && $hasEmail) {
                $where[] = 'unsubscribe_token=' . $db->q($token);
                $where[] = 'email=' . $db->q($email);
            } elseif ($token !== '') {
                $where[] = 'unsubscribe_token=' . $db->q($token);
            } elseif ($hasEmail) {
                $where[] = 'email=' . $db->q($email);
            }
            if (!$where) {
                throw new Exception('Invalid unsubscribe request.');
            }
            foreach ($where as $cond) { $q->where($cond); }
            $db->setQuery($q, 0, 1);
            $subscriber = (array)$db->loadAssoc();

            if (!$subscriber || empty($subscriber['id'])) {
                throw new Exception('Subscription not found.');
            }

            $subscriberId = (int)$subscriber['id'];
            $db->setQuery('UPDATE #__leadmarket_subscribers SET is_active=0 WHERE id=' . $subscriberId)->execute();
            $db->setQuery('DELETE FROM #__leadmarket_subscriber_lists WHERE subscriber_id=' . $subscriberId)->execute();
            $db->setQuery('DELETE FROM #__leadmarket_subscribers WHERE id=' . $subscriberId)->execute();

            $db->setQuery('SELECT COUNT(*) FROM #__leadmarket_subscribers WHERE id=' . $subscriberId);
            $remaining = (int)$db->loadResult();
            if ($remaining > 0) {
                throw new Exception('Unsubscribe could not be completed. Please try again.');
            }

            $app->enqueueMessage('You have been unsubscribed from future alerts.', 'message');
        } catch (Exception $e) {
            $app->enqueueMessage($e->getMessage(), 'error');
        }

        $this->setRedirect(LeadMarketHelper::getMarketplaceUrl(true));
    }

    public function buy()
    {
        $root = JControllerLegacy::getInstance('LeadMarket');
        return $root->buy();
    }
}
