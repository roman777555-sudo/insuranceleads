<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/controller.php';

class LeadMarketControllerTopup extends LeadMarketController
{
  public function create()
  {
    return $this->createTopup();
  }

  public function ipaid()
  {
    return $this->topupIPaid();
  }

  public function cancel()
  {
    return $this->topupCancel();
  }
}
