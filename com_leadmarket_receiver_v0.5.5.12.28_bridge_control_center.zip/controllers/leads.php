<?php
defined('_JEXEC') or die;

class LeadMarketControllerLeads extends JControllerAdmin
{
  public function getModel($name = 'Leads', $prefix = 'LeadMarketModel', $config = array('ignore_request' => true))
  {
    return parent::getModel($name, $prefix, $config);
  }

  /**
   * Toolbar "Settings" action.
   * Redirects to the component settings page (view=config).
   */
  public function settings()
  {
    $this->setRedirect('index.php?option=com_leadmarket&view=config');
  }
}
