<?php
/**
 * Private bridge controller for orchestrator access.
 * Machine API only. JSON responses only.
 */
defined('_JEXEC') or die;

require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/leadmarket.php';
require_once JPATH_COMPONENT_ADMINISTRATOR . '/helpers/bridge.php';

class LeadMarketControllerBridge extends JControllerLegacy
{
    public function capabilities()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            return array('data' => LeadMarketBridgeHelper::getCapabilities());
        });
    }

    public function health()
    {
        $this->systemStatus();
    }

    public function systemStatus()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            return array('data' => LeadMarketBridgeHelper::getSystemStatus());
        });
    }

    public function projectSnapshot()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            return array('data' => LeadMarketBridgeHelper::getProjectSnapshot());
        });
    }

    public function connectionSummary()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $days = JFactory::getApplication()->input->getInt('days', 7);
            return array('data' => LeadMarketBridgeHelper::getConnectionSummary($days));
        });
    }

    public function recentFailures()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $limit = JFactory::getApplication()->input->getInt('limit', 25);
            return array('items' => LeadMarketBridgeHelper::getRecentFailures($limit));
        });
    }


    public function siteContentSummary()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            return array('data' => LeadMarketBridgeHelper::getSiteContentSummary());
        });
    }

    public function articlesList()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            return array(
                'items' => LeadMarketBridgeHelper::getArticles(
                    trim((string) $input->getString('q', '')),
                    trim((string) $input->getCmd('status', 'all')),
                    $input->getInt('limit', 100)
                ),
            );
        });
    }

    public function articleGet()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $articleId = JFactory::getApplication()->input->getInt('article_id', 0);
            return array('item' => LeadMarketBridgeHelper::getArticle($articleId));
        });
    }

    public function modulesList()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            return array(
                'items' => LeadMarketBridgeHelper::getModules(
                    trim((string) $input->getString('q', '')),
                    trim((string) $input->getCmd('client_id', 'all')),
                    trim((string) $input->getCmd('published', 'all')),
                    $input->getInt('limit', 100)
                ),
            );
        });
    }

    public function moduleGet()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $moduleId = JFactory::getApplication()->input->getInt('module_id', 0);
            return array('item' => LeadMarketBridgeHelper::getModule($moduleId));
        });
    }

    public function componentConfigGet()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            return array('data' => LeadMarketBridgeHelper::getComponentConfig());
        });
    }

    public function kpi()
    {
        $this->kpiOverview();
    }

    public function kpiOverview()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            return array('data' => LeadMarketBridgeHelper::getKpiOverview());
        });
    }

    public function buyers()
    {
        $input = JFactory::getApplication()->input;
        if ($input->getString('buyer_email', '') !== '' || $input->getString('email', '') !== '') {
            $this->buyerProfile();
            return;
        }

        $segment = $input->getCmd('segment', 'free_test_pending');
        switch ($segment) {
            case 'inactive':
                $this->buyersInactive();
                return;
            case 'repeat':
                $this->buyersRepeat();
                return;
            case 'search':
            case 'all':
                $this->buyersSearch();
                return;
            case 'free_test_pending':
            default:
                $this->buyersFreeTestPending();
                return;
        }
    }

    public function buyersSearch()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            return array(
                'items' => LeadMarketBridgeHelper::searchBuyers(
                    $input->getCmd('segment', 'all'),
                    trim((string) $input->getString('q', '')),
                    strtoupper(trim((string) $input->getString('state', ''))),
                    strtolower(trim((string) $input->getCmd('type', ''))),
                    $input->getInt('limit', 100)
                ),
            );
        });
    }

    public function buyerProfile()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            $buyerEmail = trim((string) $input->getString('buyer_email', $input->getString('email', '')));
            return array('data' => LeadMarketBridgeHelper::getBuyerProfile($buyerEmail));
        });
    }

    public function buyerTimeline()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            $buyerEmail = trim((string) $input->getString('buyer_email', $input->getString('email', '')));
            return array('items' => LeadMarketBridgeHelper::getBuyerTimeline($buyerEmail, $input->getInt('limit', 100)));
        });
    }

    public function buyerTags()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            $buyerEmail = trim((string) $input->getString('buyer_email', $input->getString('email', '')));
            return array('items' => LeadMarketBridgeHelper::getBuyerTags($buyerEmail, $input->getInt('limit', 500)));
        });
    }

    public function buyersFreeTestPending()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $limit = JFactory::getApplication()->input->getInt('limit', 100);
            return array('items' => LeadMarketBridgeHelper::getBuyersFreeTestPending($limit));
        });
    }

    public function buyersInactive()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $bucket = JFactory::getApplication()->input->getCmd('bucket', '30d');
            $limit  = JFactory::getApplication()->input->getInt('limit', 100);
            return array(
                'bucket' => $bucket,
                'items'  => LeadMarketBridgeHelper::getBuyersInactive($bucket, $limit),
            );
        });
    }

    public function buyersRepeat()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $limit = JFactory::getApplication()->input->getInt('limit', 100);
            return array('items' => LeadMarketBridgeHelper::getBuyersRepeat($limit));
        });
    }

    public function leads()
    {
        $segment = JFactory::getApplication()->input->getCmd('segment', 'inventory');
        if ($segment === 'stale') {
            $this->leadsStale();
            return;
        }
        $this->leadsInventory();
    }

    public function leadsInventory()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            $state = strtoupper(trim((string) $input->getString('state', '')));
            $type  = strtolower(trim((string) $input->getCmd('type', '')));
            $limit = $input->getInt('limit', 100);
            return array('items' => LeadMarketBridgeHelper::getLeadInventory($state, $type, $limit));
        });
    }

    public function leadsStale()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            $minAgeHours = $input->getInt('min_age_hours', 24);
            $state       = strtoupper(trim((string) $input->getString('state', '')));
            $type        = strtolower(trim((string) $input->getCmd('type', '')));
            $limit       = $input->getInt('limit', 100);
            return array('items' => LeadMarketBridgeHelper::getStaleLeads($minAgeHours, $state, $type, $limit));
        });
    }

    public function eventsRecent()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $limit = JFactory::getApplication()->input->getInt('limit', 100);
            return array('items' => LeadMarketBridgeHelper::getRecentEvents($limit));
        });
    }

    public function auditRecent()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            return array(
                'items' => LeadMarketBridgeHelper::getAuditRecent(
                    $input->getInt('limit', 100),
                    trim((string) $input->getCmd('event_type', ''))
                ),
            );
        });
    }

    public function tasksList()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            return array(
                'items' => LeadMarketBridgeHelper::getTasks(array(
                    'limit' => $input->getInt('limit', 100),
                    'status' => trim((string) $input->getCmd('status', '')),
                    'type' => trim((string) $input->getCmd('type', '')),
                    'owner' => trim((string) $input->getString('owner', '')),
                    'buyer_email' => trim((string) $input->getString('buyer_email', $input->getString('email', ''))),
                )),
            );
        });
    }

    public function taskGet()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $taskId = trim((string) JFactory::getApplication()->input->getString('task_id', ''));
            return array('item' => LeadMarketBridgeHelper::getTask($taskId));
        });
    }

    public function proposalsAll()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $input = JFactory::getApplication()->input;
            return array(
                'items' => LeadMarketBridgeHelper::getAllProposals(
                    trim((string) $input->getCmd('status', 'all')),
                    $input->getInt('limit', 100)
                ),
            );
        });
    }

    public function proposalGet()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $proposalId = trim((string) JFactory::getApplication()->input->getString('proposal_id', ''));
            return array('item' => LeadMarketBridgeHelper::getProposal($proposalId));
        });
    }

    public function createFollowupDraft()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createFollowupDraft($payload, $ctx);
        });
    }

    public function createCampaignDraft()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createCampaignDraft($payload, $ctx);
        });
    }

    public function createCheckoutExperimentDraft()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createCheckoutExperimentDraft($payload, $ctx);
        });
    }

    public function createDiscountCodeDraft()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createDiscountCodeDraft($payload, $ctx);
        });
    }


    public function createArticlePatchDraft()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createArticlePatchDraft($payload, $ctx);
        });
    }

    public function createModulePatchDraft()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createModulePatchDraft($payload, $ctx);
        });
    }

    public function createComponentConfigPatchDraft()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createComponentConfigPatchDraft($payload, $ctx);
        });
    }

    public function applyArticlePatch()
    {
        LeadMarketBridgeHelper::handleWrite('approve', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::applyArticlePatch($payload, $ctx);
        });
    }

    public function applyModulePatch()
    {
        LeadMarketBridgeHelper::handleWrite('approve', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::applyModulePatch($payload, $ctx);
        });
    }

    public function applyComponentConfigPatch()
    {
        LeadMarketBridgeHelper::handleWrite('approve', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::applyComponentConfigPatch($payload, $ctx);
        });
    }

    public function createInternalNote()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createInternalNote($payload, $ctx);
        });
    }

    public function addBuyerTag()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::addBuyerTag($payload, $ctx);
        });
    }

    public function removeBuyerTag()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::removeBuyerTag($payload, $ctx);
        });
    }

    public function createTask()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::createTask($payload, $ctx);
        });
    }

    public function taskUpdate()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::updateTask($payload, $ctx);
        });
    }

    public function markOutreachAttempted()
    {
        LeadMarketBridgeHelper::handleWrite('write', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::markOutreachAttempted($payload, $ctx);
        });
    }

    public function proposalCreate()
    {
        LeadMarketBridgeHelper::handleWrite('proposal', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::proposalCreate($payload, $ctx);
        });
    }

    public function proposalsPending()
    {
        LeadMarketBridgeHelper::handleRead('read', function () {
            $limit = JFactory::getApplication()->input->getInt('limit', 100);
            return array('items' => LeadMarketBridgeHelper::getPendingProposals($limit));
        });
    }

    public function proposalApprove()
    {
        LeadMarketBridgeHelper::handleWrite('approve', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::proposalApprove($payload, $ctx);
        });
    }

    public function proposalReject()
    {
        LeadMarketBridgeHelper::handleWrite('approve', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::proposalReject($payload, $ctx);
        });
    }

    public function proposalExpire()
    {
        LeadMarketBridgeHelper::handleWrite('approve', function ($payload, $ctx) {
            return LeadMarketBridgeHelper::proposalExpire($payload, $ctx);
        });
    }
}
