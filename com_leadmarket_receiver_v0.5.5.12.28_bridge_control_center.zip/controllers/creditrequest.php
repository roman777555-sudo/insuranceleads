<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/controller.php';

class LeadMarketControllerCreditrequest extends LeadMarketController
{
  public function submit()
  {
    return parent::creditRequestSubmit();
  }
}
