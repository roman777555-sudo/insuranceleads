<?php
defined('_JEXEC') or die;
require_once JPATH_COMPONENT . '/controller.php';

class LeadMarketControllerAccess extends LeadMarketController
{
  public function open()
  {
    return $this->accessOpen();
  }

  public function requestlink()
  {
    return $this->accessRequestLink();
  }
}
